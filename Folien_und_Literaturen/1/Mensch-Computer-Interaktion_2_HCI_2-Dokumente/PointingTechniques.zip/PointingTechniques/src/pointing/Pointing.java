package pointing;

import java.util.ArrayList;
import java.util.Random;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

interface PointingTechnique {
	void move(double x, double y);
	void click(double x, double y);
}

class PointCursor implements PointingTechnique {
	protected Pointing app;
	
	public PointCursor(Pointing app) {
		this.app = app;
	}

	@Override
	public void move(double x, double y) {}

	@Override 
	public void click(double x, double y) {}
}

class BubbleCursor extends ImplicitFanCursor {
	public BubbleCursor(Pointing app) {
		super(app);
	}

	@Override protected void computeArcAngle(double speed) {
		alpha = 360;
	}	
}

class ImplicitFanCursor implements PointingTechnique {
	public final double MIN_SPAN = 90;
	public final double MAX_SPAN = 180;
	public final double MAX_SPEED = 1200 / 50; // pixels/s (1200 pixels/s, 33.2 cm/s in Paper)
	// public final double MOUSE_SAMPLING_RATE = 60; // Hz, 30 Hz in Paper
	// alpha proportional to speed if speed below MAX_SPEED
	public final double LAMBDA = 0.20; // 0.95 in paper
	public final double BETA = (MAX_SPAN - MIN_SPAN) / MAX_SPEED; // scaling factor

	protected Pointing app = null;
	protected Point2D position = Point2D.ZERO;
	protected Point2D velocity = Point2D.ZERO;
	protected Point2D orientation = Point2D.ZERO;
	protected double speed = 0;
	protected double alpha = 0; // span between MIN_SPAN..MAX_SPAN

	protected Circle selected = null;

	public ImplicitFanCursor(Pointing app) {
		this.app = app;
	}

	protected void computeVelocity(double x, double y) {
		Point2D newVelocity = new Point2D(
				x - position.getX(), y - position.getY());
		position = new Point2D(x, y);
		velocity = new Point2D(
				(1 - LAMBDA) * velocity.getX() + LAMBDA * newVelocity.getX(), 
				(1 - LAMBDA) * velocity.getY() + LAMBDA * newVelocity.getY());

		speed = velocity.magnitude();
		orientation = velocity.normalize();
		computeArcAngle(speed);
	}
	
	protected void computeArcAngle(double speed) {
		alpha = Math.min(MIN_SPAN + BETA * speed, MAX_SPAN);
	}
	
	protected Circle getClosestTarget(Point2D pos) {
		Circle closest = null;
		double closestDistance = Double.MAX_VALUE;
		for (Circle c : app.targets) {
			double d = pos.distance(c.getCenterX(), c.getCenterY());
			Point2D direction = new Point2D(c.getCenterX() - pos.getX(), c.getCenterY() - pos.getY());
			direction = direction.normalize();
			double deviation = Math.acos(direction.dotProduct(orientation)) * 180 / Math.PI;
			if (deviation <= alpha / 2 || d <= c.getRadius()) {
				if (d < closestDistance || closest == null) {
					closestDistance = d;
					closest = c;
				}
			}
		}
		return closest;
	}

	protected void select(Circle c) {
		if (selected != null) {
			selected.setFill(Color.LIGHTBLUE);
		}
		selected = c;
		if (selected != null) {
			selected.setFill(Color.RED);			
		}
	}

	@Override public void move(double x, double y) {
		computeVelocity(x, y);
		Circle closest = getClosestTarget(position);
		select(closest);
		Arc arc = app.arc;
		if (closest != null) {
			double distance = position.distance(closest.getCenterX(), closest.getCenterY());
			arc.setVisible(app.showBubbleOrFan && distance > closest.getRadius());
			if (app.showBubbleOrFan) {
				double radius = closest.getRadius() + 4 + distance;
				arc.setCenterX(position.getX());
				arc.setCenterY(position.getY());
				arc.setRadiusX(radius);
				arc.setRadiusY(radius);
				arc.setStartAngle(180 / Math.PI * 
						Math.atan2(
								-orientation.getY(), 
								orientation.getX()) - alpha/2);
				arc.setLength(alpha);
				arc.setType(ArcType.ROUND);
			}
		} else {
			arc.setVisible(false);
		}

	}
	
	@Override public void click(double x, double y) {
		move(x, y);
		if (selected != null) {
			app.targets.remove(selected);
			app.targetsPane.getChildren().remove(selected);
			select(null);
			move(x, y);
		}
	}
}

public class Pointing extends Application {
	
	public final Random rnd = new Random(System.currentTimeMillis());
	ArrayList<Circle> targets = new ArrayList<>();

	public final int SCENE_W = 1024;
	public final int SCENE_H = 768;
	private PointingTechnique technique = new ImplicitFanCursor(this);
	
	Pane targetsPane = new Pane();
	Arc arc = new Arc();
	boolean showBubbleOrFan = false;


	private VBox createTechniqueSelector() {
		RadioButton rb1 = new RadioButton("Point Cursor");
		RadioButton rb2 = new RadioButton("Bubble Cursor");
		RadioButton rb3 = new RadioButton("Implicit Fan Cursor");
		VBox box = new VBox(5, rb1, rb2, rb3);
		box.setPadding(new Insets(10));

		ToggleGroup group = new ToggleGroup();
		rb1.setToggleGroup(group);
		rb2.setToggleGroup(group);
		rb3.setToggleGroup(group);
		rb3.setSelected(true);

		rb1.setOnAction(event -> {
			technique = new PointCursor(this);
		});
		rb2.setOnAction(event -> {
			technique = new BubbleCursor(this);
		});
		rb3.setOnAction(event -> {
			technique = new ImplicitFanCursor(this);
		});
		
		CheckBox cb = new CheckBox("Show Bubble/Fan");
		box.getChildren().add(cb);
		cb.selectedProperty().addListener((v, o, n) -> {
			showBubbleOrFan = n;
		});

		return box;
	}
	
	private ArrayList<Circle> createTargets(int n) {
		ArrayList<Circle> ts = new ArrayList<>(n);
		for (int i = 0; i < n; i++) {
			double cx = rnd.nextDouble() * SCENE_W;
			double cy = rnd.nextDouble() * SCENE_H;
			Circle c = new Circle(cx, cy, 10, Color.LIGHTBLUE);
			ts.add(c);

			// these event handlers are for the basic point cursor
			c.setOnMouseEntered(event -> {
				c.setFill(Color.RED);
			});
			c.setOnMouseExited(event -> {
				c.setFill(Color.LIGHTBLUE);
			});
			c.setOnMouseClicked(event -> {
				ts.remove(c);
				targetsPane.getChildren().remove(c);
			});
		
		}
		return ts;
	}

	@Override
	public void start(Stage stage) {
		Pane root = new Pane();
		root.setCursor(Cursor.CROSSHAIR);
		root.getChildren().add(targetsPane);
		
		arc.setFill(Color.LIGHTGRAY);
		targetsPane.getChildren().add(arc);
		
		targets = createTargets(30);
		targetsPane.getChildren().addAll(targets);

		root.setOnMouseMoved(event -> {
			technique.move(event.getSceneX(), event.getSceneY());
		});

		root.setOnMouseReleased(event -> {
			technique.click(event.getSceneX(), event.getSceneY());
		});

		root.getChildren().add(createTechniqueSelector());

		Scene scene = new Scene(root, SCENE_W, SCENE_H);
		stage.setTitle("Pointing");
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
