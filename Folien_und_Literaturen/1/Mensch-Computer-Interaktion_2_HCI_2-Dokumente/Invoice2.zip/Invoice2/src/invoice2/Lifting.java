package invoice2;

import java.util.ArrayList;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

/**
 *
 * @author michaelrohs
 */
public class Lifting {

	private static class OV1<A, R> implements ObservableValue<R> {

		private final ObservableValue<A> ovs;
		private final Function1<A, R> f;
		private final ArrayList<ChangeListener<? super R>> changeListeners;
		private final ArrayList<InvalidationListener> invalidationListeners;
		
		public OV1(ObservableValue<A> ovs, Function1<A, R> f) {
			this.ovs = ovs;
			this.f = f;
			this.changeListeners = new ArrayList();
			this.invalidationListeners = new ArrayList();
			ovs.addListener(new ChangeListener<A>() {
				@Override
				public void changed(ObservableValue<? extends A> observable, A sOld, A sNew) {
					R rOld = f.apply(sOld);
					R rNew = f.apply(sNew);
					for (ChangeListener l : changeListeners) {
						l.changed(OV1.this, rOld, rNew);
					}
				}
			});
			ovs.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					for (InvalidationListener l : invalidationListeners) {
						l.invalidated(OV1.this);
					}
				}
			});
		}

		@Override
		public void addListener(ChangeListener<? super R> listener) {
			// System.out.println("OV1: adding ChangeListener: " + listener);
			changeListeners.add(listener);
		}

		@Override
		public void removeListener(ChangeListener<? super R> listener) {
			changeListeners.remove(listener);
		}

		@Override
		public R getValue() {
			A s = ovs.getValue();
			R r = f.apply(s);
			return r;
		}

		@Override
		public void addListener(InvalidationListener listener) {
			// System.out.println("OV1: adding InvalidationListener: " + listener);
			invalidationListeners.add(listener);
		}

		@Override
		public void removeListener(InvalidationListener listener) {
			invalidationListeners.remove(listener);
		}
	}

	private static class OV2<A, B, R> implements ObservableValue<R> {

		private final ObservableValue<A> ovs;
		private final ObservableValue<B> ovt;
		private final Function2<A, B, R> f;
		private final ArrayList<ChangeListener<? super R>> changeListeners;
		private final ArrayList<InvalidationListener> invalidationListeners;
		
		public OV2(ObservableValue<A> ovs, ObservableValue<B> ovt, Function2<A, B, R> f) {
			this.ovs = ovs;
			this.ovt = ovt;
			this.f = f;
			this.changeListeners = new ArrayList();
			this.invalidationListeners = new ArrayList();
			ovs.addListener(new ChangeListener<A>() {
				@Override
				public void changed(ObservableValue<? extends A> observable, A sOld, A sNew) {
					B t = ovt.getValue();
					R rOld = f.apply(sOld, t);
					R rNew = f.apply(sNew, t);
					for (ChangeListener l : changeListeners) {
						l.changed(OV2.this, rOld, rNew);
					}
				}
			});
			ovt.addListener(new ChangeListener<B>() {
				@Override
				public void changed(ObservableValue<? extends B> observable, B tOld, B tNew) {
					A s = ovs.getValue();
					R rOld = f.apply(s, tOld);
					R rNew = f.apply(s, tNew);
					for (ChangeListener l : changeListeners) {
						l.changed(OV2.this, rOld, rNew);
					}
				}
			});
			ovs.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					for (InvalidationListener l : invalidationListeners) {
						l.invalidated(OV2.this);
					}
				}
			});
			ovt.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					for (InvalidationListener l : invalidationListeners) {
						l.invalidated(OV2.this);
					}
				}
			});
		}

		@Override
		public void addListener(ChangeListener<? super R> listener) {
			// System.out.println("OV2: adding ChangeListener: " + listener);
			changeListeners.add(listener);
		}

		@Override
		public void removeListener(ChangeListener<? super R> listener) {
			changeListeners.remove(listener);
		}

		@Override
		public R getValue() {
			A s = ovs.getValue();
			B b = ovt.getValue();
			R r = f.apply(s, b);
			return r;
		}

		@Override
		public void addListener(InvalidationListener listener) {
			// System.out.println("OV2: adding InvalidationListener: " + listener);
			invalidationListeners.add(listener);
		}

		@Override
		public void removeListener(InvalidationListener listener) {
			invalidationListeners.remove(listener);
		}

	}
	
	private static class OV3<A, B, C, R> implements ObservableValue<R> {

		private final ObservableValue<A> ova;
		private final ObservableValue<B> ovb;
		private final ObservableValue<C> ovc;
		private final Function3<A, B, C, R> f;
		private final ArrayList<ChangeListener<? super R>> changeListeners;
		private final ArrayList<InvalidationListener> invalidationListeners;
		
		public OV3(ObservableValue<A> ova, ObservableValue<B> ovb, ObservableValue<C> ovc, Function3<A, B, C, R> f) {
			this.ova = ova;
			this.ovb = ovb;
			this.ovc = ovc;
			this.f = f;
			this.changeListeners = new ArrayList();
			this.invalidationListeners = new ArrayList();
			ova.addListener(new ChangeListener<A>() {
				@Override
				public void changed(ObservableValue<? extends A> observable, A aOld, A aNew) {
					B b = ovb.getValue();
					C c = ovc.getValue();
					R rOld = f.apply(aOld, b, c);
					R rNew = f.apply(aNew, b, c);
					for (ChangeListener l : changeListeners) {
						l.changed(OV3.this, rOld, rNew);
					}
				}
			});
			ovb.addListener(new ChangeListener<B>() {
				@Override
				public void changed(ObservableValue<? extends B> observable, B bOld, B bNew) {
					A a = ova.getValue();
					C c = ovc.getValue();
					R rOld = f.apply(a, bOld, c);
					R rNew = f.apply(a, bNew, c);
					for (ChangeListener l : changeListeners) {
						l.changed(OV3.this, rOld, rNew);
					}
				}
			});
			ovc.addListener(new ChangeListener<C>() {
				@Override
				public void changed(ObservableValue<? extends C> observable, C cOld, C cNew) {
					A a = ova.getValue();
					B b = ovb.getValue();
					R rOld = f.apply(a, b, cOld);
					R rNew = f.apply(a, b, cNew);
					for (ChangeListener l : changeListeners) {
						l.changed(OV3.this, rOld, rNew);
					}
				}
			});
			ova.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					for (InvalidationListener l : invalidationListeners) {
						l.invalidated(OV3.this);
					}
				}
			});
			ovb.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					for (InvalidationListener l : invalidationListeners) {
						l.invalidated(OV3.this);
					}
				}
			});
			ovc.addListener(new InvalidationListener() {
				@Override
				public void invalidated(Observable observable) {
					for (InvalidationListener l : invalidationListeners) {
						l.invalidated(OV3.this);
					}
				}
			});
		}

		@Override
		public void addListener(ChangeListener<? super R> listener) {
			// System.out.println("OV3: adding ChangeListener: " + listener);
			changeListeners.add(listener);
		}

		@Override
		public void removeListener(ChangeListener<? super R> listener) {
			changeListeners.remove(listener);
		}

		@Override
		public R getValue() {
			A a = ova.getValue();
			B b = ovb.getValue();
			C c = ovc.getValue();
			R r = f.apply(a, b, c);
			return r;
		}

		@Override
		public void addListener(InvalidationListener listener) {
			// System.out.println("OV3: adding InvalidationListener: " + listener);
			invalidationListeners.add(listener);
		}

		@Override
		public void removeListener(InvalidationListener listener) {
			invalidationListeners.remove(listener);
		}

	}

	public static <A, R> ObservableValue<R> map(
			ObservableValue<A> ova, 
			Function1<A, R> f) 
	{
		OV1<A, R> ov1 = new OV1(ova, f);
		return ov1;
	}

	public static <A, B, R> ObservableValue<R> map2(
			ObservableValue<A> ova, 
			ObservableValue<B> ovb, 
			Function2<A, B, R> f) 
	{
		OV2<A, B, R> ov2 = new OV2(ova, ovb, f);
		return ov2;
	}

	public static <A, B, C, R> ObservableValue<R> map3(
			ObservableValue<A> ova, 
			ObservableValue<B> ovb, 
			ObservableValue<C> ovc, 
			Function3<A, B, C, R> f) 
	{
		OV3<A, B, C, R> ov3 = new OV3(ova, ovb, ovc, f);
		return ov3;
	}
	
	public static <A> void log(String tag, ObservableValue<A> ovs) {
		map(ovs, x -> {
			System.out.println(tag + x);
			return null;
		});	
	}
	/*
	public static <A> ObservableValue<A> filter(
			ObservableValue<A> ova, 
			Function1<A, Boolean> predicate) 
	{
		return null;
	}
	*/	
	
}
