package invoice2;

import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import static invoice2.Lifting.*;

/**
 *
 * @author michaelrohs
 */
public class Invoice2 extends Application {
	
	@Override
	public void start(Stage stage) {
		
		// structure
		
		Label priceLabel = new Label("Unit price:");
		TextField price = new TextField("10.00");

		Label quantityLabel = new Label("Quantity");
		TextField quantity = new TextField("20.00");

		Label totalLabel = new Label("Total:");
		Label total = new Label("0.00");

		Label taxLabel = new Label("Tax:");
		Label tax = new Label("0.00");

		VBox root = new VBox(10, priceLabel, price, quantityLabel, quantity, totalLabel, total, taxLabel, tax);
		root.setPadding(new Insets(10));
	
		Scene scene = new Scene(root, 100, 250);
		stage.setTitle("Invoice");
		stage.setScene(scene);
		stage.show();
	
		// behavior
		
		Function1<String, Double> stringToDouble = s -> {
			try {
				return Double.parseDouble(s);
			} catch (NumberFormatException ex) {
				return Double.NaN;
			}
		};

//		ObservableValue<Double> prices = map(price.textProperty(), Double::parseDouble);
//		ObservableValue<Double> quants = map(quantity.textProperty(), Double::parseDouble);
		ObservableValue<Double> prices = map(price.textProperty(), stringToDouble);
		ObservableValue<Double> quants = map(quantity.textProperty(), stringToDouble);
		log("prices: ", prices);
		log("quants: ", quants);
		
		ObservableValue<Double> totals = map2(prices, quants, (p, q) -> p * q);
		log("totals: ", totals);
//		
//		ObservableValue<Tuple2<Double, Double>> totals2 = 
//				map2(prices, quants, (p, q) -> new Tuple2(p, q));
//		Function1<Double, String> d2s = d -> String.valueOf(d);
//		ObservableValue<String> totalsString = map(totals, d2s);
		ObservableValue<String> totalsString = map(totals, String::valueOf);
		total.textProperty().bind(totalsString);
		
//		ObservableValue<Double> taxes = map2(prices, quants, (p, q) -> 0.19 * p * q);
//		log("taxes: ", taxes);
//		ObservableValue<String> taxesString = map(taxes, String::valueOf);
//		tax.textProperty().bind(taxesString);

//		tax.textProperty().bind(map(map2(prices, quants, (p, q) -> 0.19 * p * q), String::valueOf));
		tax.textProperty().bind(map(map(totals, t -> 0.19 * t), String::valueOf));
	
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		launch(args);
	}
	
}
