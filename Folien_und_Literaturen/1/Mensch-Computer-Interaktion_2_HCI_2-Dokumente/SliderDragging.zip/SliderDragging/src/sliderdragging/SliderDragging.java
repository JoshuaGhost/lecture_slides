package sliderdragging;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.PathElement;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

abstract class SnappingTechnique {
	abstract public double snap(double x, double w, double snapX, double catchUp);
	public void clear() {}
	public static double linearMap(double from1, double from2, double to1, double to2, double x) {
		return to1 + (x - from1) / (from2 - from1) * (to2 - to1);
	}
}

class NoSnappingTechnique2 extends SnappingTechnique {
	@Override
	public double snap(double x, double w, double snapX, double catchUp) {
		return x;
	}
}

class TraditionalSnappingTechnique2 extends SnappingTechnique {
	@Override
	public double snap(double x, double w, double snapX, double catchUp) {
		if (snapX - w / 2 < x && x < snapX + w / 2) {
			return snapX;
		} else {
			return x;
		}
	}
}

class SnapAndGoTechnique2 extends SnappingTechnique {
	@Override
	public double snap(double x, double w, double snapX, double catchUp) {
		if (x >= snapX + w) {
			return x - w + 1;
		} else if (x > snapX) {
			return snapX;
		} else {
			return x;
		}
	}
}

class OhSnapTechnique2 extends SnappingTechnique {
	private boolean isSnapped = false;
	private boolean isIncreasing = false;
	private double xPrev = 0;

	@Override
	public double snap(double x, double w, double snapX, double catchUp) {
		if (!isSnapped) {
			if (xPrev < snapX && x >= snapX && x < snapX + w) {
				isSnapped = true;
				isIncreasing = true;
			} else if (xPrev > snapX && x > snapX - w && x <= snapX) {
				isSnapped = true;
				isIncreasing = false;
			}
		}
		xPrev = x;
		
		if (isSnapped) {
			if (isIncreasing) {
				if (x < snapX) {
					isSnapped = false;
					return x;
				} else if (x < snapX + w) {
					return snapX;
				} else if (x < snapX + w + catchUp) {
					// map snapX + w .. snapX + w + catchUp     
					// to  snapX     .. snapX + w + catchUp
					// return snapX + (x - (snapX + w)) / catchUp * (w + catchUp);
					return linearMap(snapX + w, snapX + w + catchUp, snapX, snapX + w + catchUp, x);
				}
			} else /* isDecreasing */{
				if (x > snapX) {
					isSnapped = false;
					return x;
				} else if (x > snapX - w) {
					return snapX;
				} else if (x > snapX - w - catchUp) {
					// return snapX + (x - (snapX - w)) / catchUp * (w + catchUp);
					return linearMap(snapX - w, snapX - w - catchUp, snapX, snapX - w - catchUp, x);
				}
			}
		}
		isSnapped = false;
		return x;
	}
	
	@Override public void clear() {
		isSnapped = false;
	}
}

class SymmetricOhSnapTechnique2 extends SnappingTechnique {
	@Override
	public double snap(double x, double w, double snapX, double catchUp) {
		if (x < snapX - w/2 - catchUp) {
			return x;
		} else if (x < snapX - w/2) {
			return snapX + (x - (snapX - w/2)) / catchUp * (w/2 + catchUp);
		} else if (x < snapX + w/2) {
			return snapX;
		} else if (x < snapX + w/2 + catchUp) {
			return snapX + (x - (snapX + w/2)) / catchUp * (w/2 + catchUp);
		}
		return x;
	}
}

public class SliderDragging extends Application {

	private final static int WIDTH = 500;
	private double pressedX;
	private double thumbX;
	private SnappingTechnique technique = new NoSnappingTechnique2();
	private final static int SNAPPING_WIDTH = 50;

	private VBox createTechniqueSelector() {
		RadioButton rb1 = new RadioButton("No snapping");
		RadioButton rb2 = new RadioButton("Traditional snapping");
		RadioButton rb3 = new RadioButton("Snap-and-go");
		RadioButton rb4 = new RadioButton("Oh Snap");
		RadioButton rb5 = new RadioButton("Symmetric Oh Snap");
		VBox box = new VBox(5, rb1, rb2, rb3, rb4, rb5);
		box.setPadding(new Insets(10));

		ToggleGroup group = new ToggleGroup();
		rb1.setToggleGroup(group);
		rb2.setToggleGroup(group);
		rb3.setToggleGroup(group);
		rb4.setToggleGroup(group);
		rb5.setToggleGroup(group);
		rb1.setSelected(true);

		rb1.setOnAction(event -> {
			technique = new NoSnappingTechnique2();
		});
		rb2.setOnAction(event -> {
			technique = new TraditionalSnappingTechnique2();
		});
		rb3.setOnAction(event -> {
			technique = new SnapAndGoTechnique2();
		});
		rb4.setOnAction(event -> {
			technique = new OhSnapTechnique2();
		});
		rb5.setOnAction(event -> {
			technique = new SymmetricOhSnapTechnique2();
		});

		box.setTranslateY(100);
		return box;
	}

	@Override
	public void start(Stage stage) {
		Pane root = new Pane();

		Pane sliderPane = new Pane();
		sliderPane.setTranslateX(20);
		sliderPane.setTranslateY(50);
		root.getChildren().add(sliderPane);

		Path path = new Path();
		ObservableList<PathElement> pes = path.getElements();
		pes.addAll(
				new MoveTo(0, 0), new LineTo(WIDTH, 0),
				new MoveTo(WIDTH / 2, -30), new LineTo(WIDTH / 2, 30));
		sliderPane.getChildren().add(path);
		
		Rectangle thumb = new Rectangle(20, 20, Color.RED);
		thumb.setTranslateX(-10);
		thumb.setTranslateY(-10);
		thumb.setRotate(45);
		sliderPane.getChildren().add(thumb);
		// thumb.setCursor(Cursor.OPEN_HAND);

		thumb.setOnMousePressed(event -> {
			pressedX = event.getSceneX();
			thumbX = thumb.getX();
		});

		thumb.setOnMouseDragged(event -> {
			double x = thumbX + (event.getSceneX() - pressedX);
			x = technique.snap(x, SNAPPING_WIDTH, WIDTH / 2, SNAPPING_WIDTH);
			x = Math.min(Math.max(x, 0), WIDTH);
			thumb.setX(x);
		});

		thumb.setOnMouseReleased(event -> {
			technique.clear();
		});
		
		root.getChildren().add(createTechniqueSelector());

		Scene scene = new Scene(root, 550, 250);
		stage.setTitle("Slider Dragging");
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
