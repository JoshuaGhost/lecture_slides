package se.swq.exercise_5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;

public class HIndex {
	
	public static File getResourceAsFile(String resourcePath) {
	    try {
	        InputStream in = ClassLoader.getSystemClassLoader().getResourceAsStream(resourcePath);
	        if (in == null) {
	            return null;
	        }

	        File tempFile = File.createTempFile(String.valueOf(in.hashCode()), ".tmp");
	        tempFile.deleteOnExit();

	        try (FileOutputStream out = new FileOutputStream(tempFile)) {
	            //copy stream
	            byte[] buffer = new byte[1024];
	            int bytesRead;
	            while ((bytesRead = in.read(buffer)) != -1) {
	                out.write(buffer, 0, bytesRead);
	            }
	        }
	        return tempFile;
	    } catch (IOException e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	public static void initLinkedList(LinkedList<PaperCitation> list) throws FileNotFoundException {
		InputStream stream = Main.class.getResourceAsStream("/publishingsList.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(stream));
		try {
			String x;
			while ((x = br.readLine()) != null) {
				list.add(new PaperCitation(x.substring(x.indexOf("#author:") + 8, x.indexOf("#title:")),
						x.substring(x.indexOf("#title:") + 7, x.indexOf("#citations:")),
						x.substring(x.indexOf("#citations:") + 11, x.indexOf("#end;"))));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public static int[] searchAndExtractAuthorCitations(LinkedList<PaperCitation> list, String inputname) {
		/*
		 * Search in the LinkedList PaperCitation Objects for a sample input name using a filter method below.
		 * Read out the citations of found Papers containing the inputname (author) and store his/her.
		 * citations of that paper in a array (see filterAuthorname method below).
		 * The final array returns a collection of each authors paper citations.
		 * 
		 * */
	}
	
	public static boolean filterAuthorname() {
		/*
		 * Search in the LinkedList PaperCitation Objects -"Author" for matches 
		 * with inputname (searched Author) - line by line and return for each hit true or false.
		 * 
		 * */

	}

	public static int calc_hIndex(int[] citations) {
		/* Create/Add the h-index algorithm an return it as integer. 
		 * The formal describ. was presented in the SWQ class.
		 * 
		 * */
	}
}
