package se.swq.exercise_5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class GUI extends JFrame implements ActionListener {
	/**
	 * 
	 *
	

	GUI(String title) {
		super(title);
		setSize(300, 170);
		setResizable(false);
		setLayout(null);

		/*
		 * Space for individual GUI-Objects
		 * 
		 * */

		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent ae) {		
			/*
			 * Functional Unit for calculating the H_Index Search for Author
			 * Filters the LinkedList Objects by his/her paper citations Operate
			 * H_Index algorithm and returns the result to GUI
			 */	
	}
}
