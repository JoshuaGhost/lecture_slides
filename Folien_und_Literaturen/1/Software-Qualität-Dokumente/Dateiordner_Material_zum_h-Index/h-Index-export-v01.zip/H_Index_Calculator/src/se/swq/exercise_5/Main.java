package se.swq.exercise_5;

import java.awt.EventQueue;
import java.io.FileNotFoundException;
import java.util.LinkedList;

public class Main {

	static LinkedList<PaperCitation> list = new LinkedList<PaperCitation>();

	public static void main(String[] args) throws FileNotFoundException {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI("H-Index Kalkulator"); 
				    frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		/*
		 * Inits the LinkedList "list" with PaperCitation objects from the data/
		 * sourcefile
		 */
		HIndex.initLinkedList(list);
		

	}

}
