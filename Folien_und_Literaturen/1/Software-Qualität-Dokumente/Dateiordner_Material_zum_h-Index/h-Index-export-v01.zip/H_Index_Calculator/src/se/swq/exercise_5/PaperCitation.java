package se.swq.exercise_5;

public class PaperCitation {
	
	private String author;
	private String title;
	private String citations;

	PaperCitation(String author, String title, String citations){
		this.setAuthor(author);
		this.setTitle(title);
		this.setCitations(citations);
	}

	public String getCitations() {
		return citations;
	}

	public void setCitations(String citation) {
		this.citations = citation;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

}
