/**
 */
package miniProject1;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Receive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see miniProject1.MiniProject1Package#getReceive()
 * @model
 * @generated
 */
public interface Receive extends Transition {
} // Receive
