/**
 */
package miniProject1.impl;

import miniProject1.MiniProject1Package;
import miniProject1.Receive;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Receive</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ReceiveImpl extends TransitionImpl implements Receive {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ReceiveImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniProject1Package.Literals.RECEIVE;
	}

} //ReceiveImpl
