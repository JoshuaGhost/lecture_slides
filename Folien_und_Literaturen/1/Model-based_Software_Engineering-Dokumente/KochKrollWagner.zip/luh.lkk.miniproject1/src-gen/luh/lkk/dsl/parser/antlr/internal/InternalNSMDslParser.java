package luh.lkk.dsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import luh.lkk.dsl.services.NSMDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalNSMDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'NetworkStatemachine'", "'{'", "'domain'", "'statemachines'", "','", "'}'", "'channels'", "'Statemachine'", "'startState'", "'states'", "'transitions'", "'synchronous'", "'Channel'", "'State'", "'Receive'", "'source'", "'target'", "'label'", "'Send'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalNSMDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalNSMDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalNSMDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalNSMDsl.g"; }



     	private NSMDslGrammarAccess grammarAccess;

        public InternalNSMDslParser(TokenStream input, NSMDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "NetworkStatemachine";
       	}

       	@Override
       	protected NSMDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleNetworkStatemachine"
    // InternalNSMDsl.g:64:1: entryRuleNetworkStatemachine returns [EObject current=null] : iv_ruleNetworkStatemachine= ruleNetworkStatemachine EOF ;
    public final EObject entryRuleNetworkStatemachine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNetworkStatemachine = null;


        try {
            // InternalNSMDsl.g:64:60: (iv_ruleNetworkStatemachine= ruleNetworkStatemachine EOF )
            // InternalNSMDsl.g:65:2: iv_ruleNetworkStatemachine= ruleNetworkStatemachine EOF
            {
             newCompositeNode(grammarAccess.getNetworkStatemachineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNetworkStatemachine=ruleNetworkStatemachine();

            state._fsp--;

             current =iv_ruleNetworkStatemachine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNetworkStatemachine"


    // $ANTLR start "ruleNetworkStatemachine"
    // InternalNSMDsl.g:71:1: ruleNetworkStatemachine returns [EObject current=null] : ( () otherlv_1= 'NetworkStatemachine' otherlv_2= '{' (otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) ) )? (otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}' )? (otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) ;
    public final EObject ruleNetworkStatemachine() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        AntlrDatatypeRuleToken lv_domain_4_0 = null;

        EObject lv_statemachines_7_0 = null;

        EObject lv_statemachines_9_0 = null;

        EObject lv_channels_13_0 = null;

        EObject lv_channels_15_0 = null;



        	enterRule();

        try {
            // InternalNSMDsl.g:77:2: ( ( () otherlv_1= 'NetworkStatemachine' otherlv_2= '{' (otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) ) )? (otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}' )? (otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) )
            // InternalNSMDsl.g:78:2: ( () otherlv_1= 'NetworkStatemachine' otherlv_2= '{' (otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) ) )? (otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}' )? (otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            {
            // InternalNSMDsl.g:78:2: ( () otherlv_1= 'NetworkStatemachine' otherlv_2= '{' (otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) ) )? (otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}' )? (otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            // InternalNSMDsl.g:79:3: () otherlv_1= 'NetworkStatemachine' otherlv_2= '{' (otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) ) )? (otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}' )? (otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}' )? otherlv_17= '}'
            {
            // InternalNSMDsl.g:79:3: ()
            // InternalNSMDsl.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getNetworkStatemachineAccess().getNetworkStatemachineAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getNetworkStatemachineAccess().getNetworkStatemachineKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getNetworkStatemachineAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalNSMDsl.g:94:3: (otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalNSMDsl.g:95:4: otherlv_3= 'domain' ( (lv_domain_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getNetworkStatemachineAccess().getDomainKeyword_3_0());
                    			
                    // InternalNSMDsl.g:99:4: ( (lv_domain_4_0= ruleEString ) )
                    // InternalNSMDsl.g:100:5: (lv_domain_4_0= ruleEString )
                    {
                    // InternalNSMDsl.g:100:5: (lv_domain_4_0= ruleEString )
                    // InternalNSMDsl.g:101:6: lv_domain_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getNetworkStatemachineAccess().getDomainEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_domain_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkStatemachineRule());
                    						}
                    						set(
                    							current,
                    							"domain",
                    							lv_domain_4_0,
                    							"luh.lkk.dsl.NSMDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalNSMDsl.g:119:3: (otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}' )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==14) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalNSMDsl.g:120:4: otherlv_5= 'statemachines' otherlv_6= '{' ( (lv_statemachines_7_0= ruleStatemachine ) ) (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )* otherlv_10= '}'
                    {
                    otherlv_5=(Token)match(input,14,FOLLOW_3); 

                    				newLeafNode(otherlv_5, grammarAccess.getNetworkStatemachineAccess().getStatemachinesKeyword_4_0());
                    			
                    otherlv_6=(Token)match(input,12,FOLLOW_7); 

                    				newLeafNode(otherlv_6, grammarAccess.getNetworkStatemachineAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalNSMDsl.g:128:4: ( (lv_statemachines_7_0= ruleStatemachine ) )
                    // InternalNSMDsl.g:129:5: (lv_statemachines_7_0= ruleStatemachine )
                    {
                    // InternalNSMDsl.g:129:5: (lv_statemachines_7_0= ruleStatemachine )
                    // InternalNSMDsl.g:130:6: lv_statemachines_7_0= ruleStatemachine
                    {

                    						newCompositeNode(grammarAccess.getNetworkStatemachineAccess().getStatemachinesStatemachineParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_statemachines_7_0=ruleStatemachine();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkStatemachineRule());
                    						}
                    						add(
                    							current,
                    							"statemachines",
                    							lv_statemachines_7_0,
                    							"luh.lkk.dsl.NSMDsl.Statemachine");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalNSMDsl.g:147:4: (otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) ) )*
                    loop2:
                    do {
                        int alt2=2;
                        int LA2_0 = input.LA(1);

                        if ( (LA2_0==15) ) {
                            alt2=1;
                        }


                        switch (alt2) {
                    	case 1 :
                    	    // InternalNSMDsl.g:148:5: otherlv_8= ',' ( (lv_statemachines_9_0= ruleStatemachine ) )
                    	    {
                    	    otherlv_8=(Token)match(input,15,FOLLOW_7); 

                    	    					newLeafNode(otherlv_8, grammarAccess.getNetworkStatemachineAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalNSMDsl.g:152:5: ( (lv_statemachines_9_0= ruleStatemachine ) )
                    	    // InternalNSMDsl.g:153:6: (lv_statemachines_9_0= ruleStatemachine )
                    	    {
                    	    // InternalNSMDsl.g:153:6: (lv_statemachines_9_0= ruleStatemachine )
                    	    // InternalNSMDsl.g:154:7: lv_statemachines_9_0= ruleStatemachine
                    	    {

                    	    							newCompositeNode(grammarAccess.getNetworkStatemachineAccess().getStatemachinesStatemachineParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_8);
                    	    lv_statemachines_9_0=ruleStatemachine();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getNetworkStatemachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"statemachines",
                    	    								lv_statemachines_9_0,
                    	    								"luh.lkk.dsl.NSMDsl.Statemachine");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop2;
                        }
                    } while (true);

                    otherlv_10=(Token)match(input,16,FOLLOW_9); 

                    				newLeafNode(otherlv_10, grammarAccess.getNetworkStatemachineAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalNSMDsl.g:177:3: (otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==17) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalNSMDsl.g:178:4: otherlv_11= 'channels' otherlv_12= '{' ( (lv_channels_13_0= ruleChannel ) ) (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )* otherlv_16= '}'
                    {
                    otherlv_11=(Token)match(input,17,FOLLOW_3); 

                    				newLeafNode(otherlv_11, grammarAccess.getNetworkStatemachineAccess().getChannelsKeyword_5_0());
                    			
                    otherlv_12=(Token)match(input,12,FOLLOW_10); 

                    				newLeafNode(otherlv_12, grammarAccess.getNetworkStatemachineAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalNSMDsl.g:186:4: ( (lv_channels_13_0= ruleChannel ) )
                    // InternalNSMDsl.g:187:5: (lv_channels_13_0= ruleChannel )
                    {
                    // InternalNSMDsl.g:187:5: (lv_channels_13_0= ruleChannel )
                    // InternalNSMDsl.g:188:6: lv_channels_13_0= ruleChannel
                    {

                    						newCompositeNode(grammarAccess.getNetworkStatemachineAccess().getChannelsChannelParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_channels_13_0=ruleChannel();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkStatemachineRule());
                    						}
                    						add(
                    							current,
                    							"channels",
                    							lv_channels_13_0,
                    							"luh.lkk.dsl.NSMDsl.Channel");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalNSMDsl.g:205:4: (otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==15) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalNSMDsl.g:206:5: otherlv_14= ',' ( (lv_channels_15_0= ruleChannel ) )
                    	    {
                    	    otherlv_14=(Token)match(input,15,FOLLOW_10); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getNetworkStatemachineAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalNSMDsl.g:210:5: ( (lv_channels_15_0= ruleChannel ) )
                    	    // InternalNSMDsl.g:211:6: (lv_channels_15_0= ruleChannel )
                    	    {
                    	    // InternalNSMDsl.g:211:6: (lv_channels_15_0= ruleChannel )
                    	    // InternalNSMDsl.g:212:7: lv_channels_15_0= ruleChannel
                    	    {

                    	    							newCompositeNode(grammarAccess.getNetworkStatemachineAccess().getChannelsChannelParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_8);
                    	    lv_channels_15_0=ruleChannel();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getNetworkStatemachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"channels",
                    	    								lv_channels_15_0,
                    	    								"luh.lkk.dsl.NSMDsl.Channel");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    otherlv_16=(Token)match(input,16,FOLLOW_11); 

                    				newLeafNode(otherlv_16, grammarAccess.getNetworkStatemachineAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            otherlv_17=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getNetworkStatemachineAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNetworkStatemachine"


    // $ANTLR start "entryRuleTransition"
    // InternalNSMDsl.g:243:1: entryRuleTransition returns [EObject current=null] : iv_ruleTransition= ruleTransition EOF ;
    public final EObject entryRuleTransition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTransition = null;


        try {
            // InternalNSMDsl.g:243:51: (iv_ruleTransition= ruleTransition EOF )
            // InternalNSMDsl.g:244:2: iv_ruleTransition= ruleTransition EOF
            {
             newCompositeNode(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTransition=ruleTransition();

            state._fsp--;

             current =iv_ruleTransition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalNSMDsl.g:250:1: ruleTransition returns [EObject current=null] : (this_Receive_0= ruleReceive | this_Send_1= ruleSend ) ;
    public final EObject ruleTransition() throws RecognitionException {
        EObject current = null;

        EObject this_Receive_0 = null;

        EObject this_Send_1 = null;



        	enterRule();

        try {
            // InternalNSMDsl.g:256:2: ( (this_Receive_0= ruleReceive | this_Send_1= ruleSend ) )
            // InternalNSMDsl.g:257:2: (this_Receive_0= ruleReceive | this_Send_1= ruleSend )
            {
            // InternalNSMDsl.g:257:2: (this_Receive_0= ruleReceive | this_Send_1= ruleSend )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==25) ) {
                alt6=1;
            }
            else if ( (LA6_0==29) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalNSMDsl.g:258:3: this_Receive_0= ruleReceive
                    {

                    			newCompositeNode(grammarAccess.getTransitionAccess().getReceiveParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Receive_0=ruleReceive();

                    state._fsp--;


                    			current = this_Receive_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalNSMDsl.g:267:3: this_Send_1= ruleSend
                    {

                    			newCompositeNode(grammarAccess.getTransitionAccess().getSendParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Send_1=ruleSend();

                    state._fsp--;


                    			current = this_Send_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTransition"


    // $ANTLR start "entryRuleStatemachine"
    // InternalNSMDsl.g:279:1: entryRuleStatemachine returns [EObject current=null] : iv_ruleStatemachine= ruleStatemachine EOF ;
    public final EObject entryRuleStatemachine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatemachine = null;


        try {
            // InternalNSMDsl.g:279:53: (iv_ruleStatemachine= ruleStatemachine EOF )
            // InternalNSMDsl.g:280:2: iv_ruleStatemachine= ruleStatemachine EOF
            {
             newCompositeNode(grammarAccess.getStatemachineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStatemachine=ruleStatemachine();

            state._fsp--;

             current =iv_ruleStatemachine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatemachine"


    // $ANTLR start "ruleStatemachine"
    // InternalNSMDsl.g:286:1: ruleStatemachine returns [EObject current=null] : (otherlv_0= 'Statemachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'startState' ( ( ruleEString ) ) otherlv_5= 'states' otherlv_6= '{' ( (lv_states_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_states_9_0= ruleState ) ) )* otherlv_10= '}' (otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) ;
    public final EObject ruleStatemachine() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_states_7_0 = null;

        EObject lv_states_9_0 = null;

        EObject lv_transitions_13_0 = null;

        EObject lv_transitions_15_0 = null;



        	enterRule();

        try {
            // InternalNSMDsl.g:292:2: ( (otherlv_0= 'Statemachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'startState' ( ( ruleEString ) ) otherlv_5= 'states' otherlv_6= '{' ( (lv_states_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_states_9_0= ruleState ) ) )* otherlv_10= '}' (otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) )
            // InternalNSMDsl.g:293:2: (otherlv_0= 'Statemachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'startState' ( ( ruleEString ) ) otherlv_5= 'states' otherlv_6= '{' ( (lv_states_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_states_9_0= ruleState ) ) )* otherlv_10= '}' (otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            {
            // InternalNSMDsl.g:293:2: (otherlv_0= 'Statemachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'startState' ( ( ruleEString ) ) otherlv_5= 'states' otherlv_6= '{' ( (lv_states_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_states_9_0= ruleState ) ) )* otherlv_10= '}' (otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            // InternalNSMDsl.g:294:3: otherlv_0= 'Statemachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'startState' ( ( ruleEString ) ) otherlv_5= 'states' otherlv_6= '{' ( (lv_states_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_states_9_0= ruleState ) ) )* otherlv_10= '}' (otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getStatemachineAccess().getStatemachineKeyword_0());
            		
            // InternalNSMDsl.g:298:3: ( (lv_name_1_0= ruleEString ) )
            // InternalNSMDsl.g:299:4: (lv_name_1_0= ruleEString )
            {
            // InternalNSMDsl.g:299:4: (lv_name_1_0= ruleEString )
            // InternalNSMDsl.g:300:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getStatemachineAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStatemachineRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"luh.lkk.dsl.NSMDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_12); 

            			newLeafNode(otherlv_2, grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,19,FOLLOW_5); 

            			newLeafNode(otherlv_3, grammarAccess.getStatemachineAccess().getStartStateKeyword_3());
            		
            // InternalNSMDsl.g:325:3: ( ( ruleEString ) )
            // InternalNSMDsl.g:326:4: ( ruleEString )
            {
            // InternalNSMDsl.g:326:4: ( ruleEString )
            // InternalNSMDsl.g:327:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStatemachineRule());
            					}
            				

            					newCompositeNode(grammarAccess.getStatemachineAccess().getStartStateStateCrossReference_4_0());
            				
            pushFollow(FOLLOW_13);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,20,FOLLOW_3); 

            			newLeafNode(otherlv_5, grammarAccess.getStatemachineAccess().getStatesKeyword_5());
            		
            otherlv_6=(Token)match(input,12,FOLLOW_14); 

            			newLeafNode(otherlv_6, grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_6());
            		
            // InternalNSMDsl.g:349:3: ( (lv_states_7_0= ruleState ) )
            // InternalNSMDsl.g:350:4: (lv_states_7_0= ruleState )
            {
            // InternalNSMDsl.g:350:4: (lv_states_7_0= ruleState )
            // InternalNSMDsl.g:351:5: lv_states_7_0= ruleState
            {

            					newCompositeNode(grammarAccess.getStatemachineAccess().getStatesStateParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_8);
            lv_states_7_0=ruleState();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStatemachineRule());
            					}
            					add(
            						current,
            						"states",
            						lv_states_7_0,
            						"luh.lkk.dsl.NSMDsl.State");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalNSMDsl.g:368:3: (otherlv_8= ',' ( (lv_states_9_0= ruleState ) ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==15) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalNSMDsl.g:369:4: otherlv_8= ',' ( (lv_states_9_0= ruleState ) )
            	    {
            	    otherlv_8=(Token)match(input,15,FOLLOW_14); 

            	    				newLeafNode(otherlv_8, grammarAccess.getStatemachineAccess().getCommaKeyword_8_0());
            	    			
            	    // InternalNSMDsl.g:373:4: ( (lv_states_9_0= ruleState ) )
            	    // InternalNSMDsl.g:374:5: (lv_states_9_0= ruleState )
            	    {
            	    // InternalNSMDsl.g:374:5: (lv_states_9_0= ruleState )
            	    // InternalNSMDsl.g:375:6: lv_states_9_0= ruleState
            	    {

            	    						newCompositeNode(grammarAccess.getStatemachineAccess().getStatesStateParserRuleCall_8_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_states_9_0=ruleState();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getStatemachineRule());
            	    						}
            	    						add(
            	    							current,
            	    							"states",
            	    							lv_states_9_0,
            	    							"luh.lkk.dsl.NSMDsl.State");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_10=(Token)match(input,16,FOLLOW_15); 

            			newLeafNode(otherlv_10, grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_9());
            		
            // InternalNSMDsl.g:397:3: (otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalNSMDsl.g:398:4: otherlv_11= 'transitions' otherlv_12= '{' ( (lv_transitions_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )* otherlv_16= '}'
                    {
                    otherlv_11=(Token)match(input,21,FOLLOW_3); 

                    				newLeafNode(otherlv_11, grammarAccess.getStatemachineAccess().getTransitionsKeyword_10_0());
                    			
                    otherlv_12=(Token)match(input,12,FOLLOW_16); 

                    				newLeafNode(otherlv_12, grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_10_1());
                    			
                    // InternalNSMDsl.g:406:4: ( (lv_transitions_13_0= ruleTransition ) )
                    // InternalNSMDsl.g:407:5: (lv_transitions_13_0= ruleTransition )
                    {
                    // InternalNSMDsl.g:407:5: (lv_transitions_13_0= ruleTransition )
                    // InternalNSMDsl.g:408:6: lv_transitions_13_0= ruleTransition
                    {

                    						newCompositeNode(grammarAccess.getStatemachineAccess().getTransitionsTransitionParserRuleCall_10_2_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_transitions_13_0=ruleTransition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStatemachineRule());
                    						}
                    						add(
                    							current,
                    							"transitions",
                    							lv_transitions_13_0,
                    							"luh.lkk.dsl.NSMDsl.Transition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalNSMDsl.g:425:4: (otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) ) )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==15) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // InternalNSMDsl.g:426:5: otherlv_14= ',' ( (lv_transitions_15_0= ruleTransition ) )
                    	    {
                    	    otherlv_14=(Token)match(input,15,FOLLOW_16); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getStatemachineAccess().getCommaKeyword_10_3_0());
                    	    				
                    	    // InternalNSMDsl.g:430:5: ( (lv_transitions_15_0= ruleTransition ) )
                    	    // InternalNSMDsl.g:431:6: (lv_transitions_15_0= ruleTransition )
                    	    {
                    	    // InternalNSMDsl.g:431:6: (lv_transitions_15_0= ruleTransition )
                    	    // InternalNSMDsl.g:432:7: lv_transitions_15_0= ruleTransition
                    	    {

                    	    							newCompositeNode(grammarAccess.getStatemachineAccess().getTransitionsTransitionParserRuleCall_10_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_8);
                    	    lv_transitions_15_0=ruleTransition();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getStatemachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"transitions",
                    	    								lv_transitions_15_0,
                    	    								"luh.lkk.dsl.NSMDsl.Transition");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    otherlv_16=(Token)match(input,16,FOLLOW_11); 

                    				newLeafNode(otherlv_16, grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_10_4());
                    			

                    }
                    break;

            }

            otherlv_17=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatemachine"


    // $ANTLR start "entryRuleChannel"
    // InternalNSMDsl.g:463:1: entryRuleChannel returns [EObject current=null] : iv_ruleChannel= ruleChannel EOF ;
    public final EObject entryRuleChannel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChannel = null;


        try {
            // InternalNSMDsl.g:463:48: (iv_ruleChannel= ruleChannel EOF )
            // InternalNSMDsl.g:464:2: iv_ruleChannel= ruleChannel EOF
            {
             newCompositeNode(grammarAccess.getChannelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChannel=ruleChannel();

            state._fsp--;

             current =iv_ruleChannel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChannel"


    // $ANTLR start "ruleChannel"
    // InternalNSMDsl.g:470:1: ruleChannel returns [EObject current=null] : ( () ( (lv_synchronous_1_0= 'synchronous' ) )? otherlv_2= 'Channel' ( (lv_name_3_0= ruleEString ) ) ) ;
    public final EObject ruleChannel() throws RecognitionException {
        EObject current = null;

        Token lv_synchronous_1_0=null;
        Token otherlv_2=null;
        AntlrDatatypeRuleToken lv_name_3_0 = null;



        	enterRule();

        try {
            // InternalNSMDsl.g:476:2: ( ( () ( (lv_synchronous_1_0= 'synchronous' ) )? otherlv_2= 'Channel' ( (lv_name_3_0= ruleEString ) ) ) )
            // InternalNSMDsl.g:477:2: ( () ( (lv_synchronous_1_0= 'synchronous' ) )? otherlv_2= 'Channel' ( (lv_name_3_0= ruleEString ) ) )
            {
            // InternalNSMDsl.g:477:2: ( () ( (lv_synchronous_1_0= 'synchronous' ) )? otherlv_2= 'Channel' ( (lv_name_3_0= ruleEString ) ) )
            // InternalNSMDsl.g:478:3: () ( (lv_synchronous_1_0= 'synchronous' ) )? otherlv_2= 'Channel' ( (lv_name_3_0= ruleEString ) )
            {
            // InternalNSMDsl.g:478:3: ()
            // InternalNSMDsl.g:479:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getChannelAccess().getChannelAction_0(),
            					current);
            			

            }

            // InternalNSMDsl.g:485:3: ( (lv_synchronous_1_0= 'synchronous' ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==22) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalNSMDsl.g:486:4: (lv_synchronous_1_0= 'synchronous' )
                    {
                    // InternalNSMDsl.g:486:4: (lv_synchronous_1_0= 'synchronous' )
                    // InternalNSMDsl.g:487:5: lv_synchronous_1_0= 'synchronous'
                    {
                    lv_synchronous_1_0=(Token)match(input,22,FOLLOW_17); 

                    					newLeafNode(lv_synchronous_1_0, grammarAccess.getChannelAccess().getSynchronousSynchronousKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getChannelRule());
                    					}
                    					setWithLastConsumed(current, "synchronous", true, "synchronous");
                    				

                    }


                    }
                    break;

            }

            otherlv_2=(Token)match(input,23,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getChannelAccess().getChannelKeyword_2());
            		
            // InternalNSMDsl.g:503:3: ( (lv_name_3_0= ruleEString ) )
            // InternalNSMDsl.g:504:4: (lv_name_3_0= ruleEString )
            {
            // InternalNSMDsl.g:504:4: (lv_name_3_0= ruleEString )
            // InternalNSMDsl.g:505:5: lv_name_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChannelRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"luh.lkk.dsl.NSMDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChannel"


    // $ANTLR start "entryRuleEString"
    // InternalNSMDsl.g:526:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalNSMDsl.g:526:47: (iv_ruleEString= ruleEString EOF )
            // InternalNSMDsl.g:527:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalNSMDsl.g:533:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalNSMDsl.g:539:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalNSMDsl.g:540:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalNSMDsl.g:540:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_STRING) ) {
                alt11=1;
            }
            else if ( (LA11_0==RULE_ID) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalNSMDsl.g:541:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalNSMDsl.g:549:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleState"
    // InternalNSMDsl.g:560:1: entryRuleState returns [EObject current=null] : iv_ruleState= ruleState EOF ;
    public final EObject entryRuleState() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleState = null;


        try {
            // InternalNSMDsl.g:560:46: (iv_ruleState= ruleState EOF )
            // InternalNSMDsl.g:561:2: iv_ruleState= ruleState EOF
            {
             newCompositeNode(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleState=ruleState();

            state._fsp--;

             current =iv_ruleState; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalNSMDsl.g:567:1: ruleState returns [EObject current=null] : ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) ) ;
    public final EObject ruleState() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;



        	enterRule();

        try {
            // InternalNSMDsl.g:573:2: ( ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) ) )
            // InternalNSMDsl.g:574:2: ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) )
            {
            // InternalNSMDsl.g:574:2: ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) )
            // InternalNSMDsl.g:575:3: () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) )
            {
            // InternalNSMDsl.g:575:3: ()
            // InternalNSMDsl.g:576:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStateAccess().getStateAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,24,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getStateAccess().getStateKeyword_1());
            		
            // InternalNSMDsl.g:586:3: ( (lv_name_2_0= ruleEString ) )
            // InternalNSMDsl.g:587:4: (lv_name_2_0= ruleEString )
            {
            // InternalNSMDsl.g:587:4: (lv_name_2_0= ruleEString )
            // InternalNSMDsl.g:588:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStateRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"luh.lkk.dsl.NSMDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleReceive"
    // InternalNSMDsl.g:609:1: entryRuleReceive returns [EObject current=null] : iv_ruleReceive= ruleReceive EOF ;
    public final EObject entryRuleReceive() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleReceive = null;


        try {
            // InternalNSMDsl.g:609:48: (iv_ruleReceive= ruleReceive EOF )
            // InternalNSMDsl.g:610:2: iv_ruleReceive= ruleReceive EOF
            {
             newCompositeNode(grammarAccess.getReceiveRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReceive=ruleReceive();

            state._fsp--;

             current =iv_ruleReceive; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReceive"


    // $ANTLR start "ruleReceive"
    // InternalNSMDsl.g:616:1: ruleReceive returns [EObject current=null] : ( () otherlv_1= 'Receive' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleReceive() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalNSMDsl.g:622:2: ( ( () otherlv_1= 'Receive' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalNSMDsl.g:623:2: ( () otherlv_1= 'Receive' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalNSMDsl.g:623:2: ( () otherlv_1= 'Receive' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' )
            // InternalNSMDsl.g:624:3: () otherlv_1= 'Receive' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalNSMDsl.g:624:3: ()
            // InternalNSMDsl.g:625:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getReceiveAccess().getReceiveAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,25,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getReceiveAccess().getReceiveKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_18); 

            			newLeafNode(otherlv_2, grammarAccess.getReceiveAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalNSMDsl.g:639:3: (otherlv_3= 'source' ( ( ruleEString ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==26) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalNSMDsl.g:640:4: otherlv_3= 'source' ( ( ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getReceiveAccess().getSourceKeyword_3_0());
                    			
                    // InternalNSMDsl.g:644:4: ( ( ruleEString ) )
                    // InternalNSMDsl.g:645:5: ( ruleEString )
                    {
                    // InternalNSMDsl.g:645:5: ( ruleEString )
                    // InternalNSMDsl.g:646:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getReceiveRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getReceiveAccess().getSourceStateCrossReference_3_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalNSMDsl.g:661:3: (otherlv_5= 'target' ( ( ruleEString ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==27) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalNSMDsl.g:662:4: otherlv_5= 'target' ( ( ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getReceiveAccess().getTargetKeyword_4_0());
                    			
                    // InternalNSMDsl.g:666:4: ( ( ruleEString ) )
                    // InternalNSMDsl.g:667:5: ( ruleEString )
                    {
                    // InternalNSMDsl.g:667:5: ( ruleEString )
                    // InternalNSMDsl.g:668:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getReceiveRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getReceiveAccess().getTargetStateCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalNSMDsl.g:683:3: (otherlv_7= 'label' ( ( ruleEString ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==28) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalNSMDsl.g:684:4: otherlv_7= 'label' ( ( ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getReceiveAccess().getLabelKeyword_5_0());
                    			
                    // InternalNSMDsl.g:688:4: ( ( ruleEString ) )
                    // InternalNSMDsl.g:689:5: ( ruleEString )
                    {
                    // InternalNSMDsl.g:689:5: ( ruleEString )
                    // InternalNSMDsl.g:690:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getReceiveRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getReceiveAccess().getLabelChannelCrossReference_5_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getReceiveAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReceive"


    // $ANTLR start "entryRuleSend"
    // InternalNSMDsl.g:713:1: entryRuleSend returns [EObject current=null] : iv_ruleSend= ruleSend EOF ;
    public final EObject entryRuleSend() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSend = null;


        try {
            // InternalNSMDsl.g:713:45: (iv_ruleSend= ruleSend EOF )
            // InternalNSMDsl.g:714:2: iv_ruleSend= ruleSend EOF
            {
             newCompositeNode(grammarAccess.getSendRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSend=ruleSend();

            state._fsp--;

             current =iv_ruleSend; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSend"


    // $ANTLR start "ruleSend"
    // InternalNSMDsl.g:720:1: ruleSend returns [EObject current=null] : ( () otherlv_1= 'Send' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleSend() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalNSMDsl.g:726:2: ( ( () otherlv_1= 'Send' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalNSMDsl.g:727:2: ( () otherlv_1= 'Send' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalNSMDsl.g:727:2: ( () otherlv_1= 'Send' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}' )
            // InternalNSMDsl.g:728:3: () otherlv_1= 'Send' otherlv_2= '{' (otherlv_3= 'source' ( ( ruleEString ) ) )? (otherlv_5= 'target' ( ( ruleEString ) ) )? (otherlv_7= 'label' ( ( ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalNSMDsl.g:728:3: ()
            // InternalNSMDsl.g:729:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getSendAccess().getSendAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,29,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getSendAccess().getSendKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_18); 

            			newLeafNode(otherlv_2, grammarAccess.getSendAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalNSMDsl.g:743:3: (otherlv_3= 'source' ( ( ruleEString ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==26) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalNSMDsl.g:744:4: otherlv_3= 'source' ( ( ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getSendAccess().getSourceKeyword_3_0());
                    			
                    // InternalNSMDsl.g:748:4: ( ( ruleEString ) )
                    // InternalNSMDsl.g:749:5: ( ruleEString )
                    {
                    // InternalNSMDsl.g:749:5: ( ruleEString )
                    // InternalNSMDsl.g:750:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSendRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getSendAccess().getSourceStateCrossReference_3_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalNSMDsl.g:765:3: (otherlv_5= 'target' ( ( ruleEString ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==27) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalNSMDsl.g:766:4: otherlv_5= 'target' ( ( ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getSendAccess().getTargetKeyword_4_0());
                    			
                    // InternalNSMDsl.g:770:4: ( ( ruleEString ) )
                    // InternalNSMDsl.g:771:5: ( ruleEString )
                    {
                    // InternalNSMDsl.g:771:5: ( ruleEString )
                    // InternalNSMDsl.g:772:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSendRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getSendAccess().getTargetStateCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalNSMDsl.g:787:3: (otherlv_7= 'label' ( ( ruleEString ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==28) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalNSMDsl.g:788:4: otherlv_7= 'label' ( ( ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getSendAccess().getLabelKeyword_5_0());
                    			
                    // InternalNSMDsl.g:792:4: ( ( ruleEString ) )
                    // InternalNSMDsl.g:793:5: ( ruleEString )
                    {
                    // InternalNSMDsl.g:793:5: ( ruleEString )
                    // InternalNSMDsl.g:794:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSendRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getSendAccess().getLabelChannelCrossReference_5_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getSendAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSend"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000036000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000034000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000C00000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000210000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000022000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x000000001C010000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000018010000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000010010000L});

}