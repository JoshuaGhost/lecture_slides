package interpreter;

import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import miniProject1.MiniProject1Package;
import miniProject1.NetworkStatemachine;

public class interpreter {

	//Well...that doesn't work at all...
	public static void main(String[] args) {
		MiniProject1Package.eINSTANCE.eClass();
		
		Resource.Factory.Registry registry = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> map = registry.getExtensionToFactoryMap();
		map.put("nsm", new XMIResourceFactoryImpl());
		
		ResourceSet resourceSet = new ResourceSetImpl();
		Resource resource = resourceSet.getResource(URI.createURI("Semester.xmi"), true);

		EObject res = resource.getContents().get(0);
		NetworkStatemachine rtn = (NetworkStatemachine) res;
		System.out.println(rtn.getDomain());
	}

}
