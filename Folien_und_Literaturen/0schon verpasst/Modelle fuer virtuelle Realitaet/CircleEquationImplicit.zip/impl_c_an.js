
cx = 1;
cy = 0;
dt = 0.1;
console.log("cx,cy");
console.log(cx+","+cy);

for(var i=0; i<100; i++){
  cxn = (cx - dt * cy) / ( 1 + dt*dt);
  cyn = (cy + dt * cx) / ( 1 + dt*dt);
  cx = cxn;
  cy = cyn;
  console.log(cx + "," + cy);
}
