

function hx(x,y, x0, y0){
  return x - x0 + dt * y;
}

function hy(x,y, x0, y0){
  return y - y0 - dt * x;
}

function dx(h, x,y, x0,y0, dx){
  return (h(x+dx,y,x0,y0) - h(x,y,x0,y0)) / dx;
}

function dy(h, x,y, x0,y0, dy){
  return (h(x,y+dy,x0,y0) - h(x,y,x0,y0)) / dy;
}

function det(a,b,c,d){
  return 1 / (a*d - b*c);
}

cx = 1;
cy = 0;
dt = 0.1;
d_x = d_y = 0.01;

console.log("cx,cy");
console.log(cx+","+cy);

for(var i=0; i<100; i++){
  cx0 = cx;
  cy0 = cy;
  // newton iteration, initial guess (cx,cy)
  for(var j=0; j<20; j++){
    h_x = hx(cx,cy,cx0,cy0);
    h_y = hy(cx,cy,cx0,cy0);

    hx_dx = dx(hx,cx,cy,cx0,cy0,d_x);
    hx_dy = dy(hx,cx,cy,cx0,cy0,d_y);
    hy_dx = dx(hy,cx,cy,cx0,cy0,d_x);
    hy_dy = dy(hy,cx,cy,cx0,cy0,d_y);

    h_det = det(hx_dx,hx_dy,hy_dx,hy_dy);

    cx = cx - h_det * (hy_dy * h_x - hy_dx * h_y);
    cy = cy - h_det * (-hx_dy * h_x + hx_dx * h_y);
  }
  console.log(cx+","+cy);
}
