#!/usr/bin/env python3
# encoding: utf-8

def heun(funcs, state, timestep):
    new_state = [None] * len(state)
    new_state[0] = state[0] + timestep

    tmp_state = [None] * len(state)
    tmp_state[0] = state[0] + timestep

    for i in range(len(funcs)):
        f = funcs[i]
        tmp_state[i+1] = state[i+1] + timestep * f(state)

    for i in range(len(funcs)):
        f = funcs[i]
        new_state[i+1] = 0.5 * state[i+1] + 0.5 * (tmp_state[i+1] + timestep * f(tmp_state))

    return new_state

def print_state(state):
    print("{:.3f};{:.6f};{:.6f};{:.6f};{:.6f}".format(state[0], state[1], state[2],
        state[3], state[4]))

################################################################################

if __name__ == "__main__":
    births    = 0
    alpha     = 0.005  # human defeats zombie rate
    beta      = 0.0095 # transmission rate
    zeta      = 0.09   # resurrection rate
    delta     = 0.01   # non-zombie death rate
    rho       = 0.5    # infected turn rate
    cure_rate = 0.1

    funcs = [None, None, None, None]
    funcs[0] = lambda s: births - beta * s[1] * s[3] - delta * s[1] + cure_rate * s[3]
    funcs[1] = lambda s: beta * s[1] * s[3] - rho * s[2] - delta * s[2]
    funcs[2] = lambda s: rho * s[2] + zeta * s[4] - alpha * s[1] * s[3] - cure_rate * s[3]
    funcs[3] = lambda s: delta * s[1] + delta * s[2] + alpha * s[1] * s[3] - zeta * s[4]

    dt = 0.01
    T = 30
    n = round(T / dt)

    #         T   S   I  Z  R
    state =  [0, 500, 0, 0, 0]

    print("t;S;I;Z;R")
    print_state(state)
    for i in range(n):
        state = heun(funcs, state, dt)
        print_state(state)

