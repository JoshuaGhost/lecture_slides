package View;

import java.util.ArrayList;
import java.util.List;







import Model.WithTreatment;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Mainview extends Application {

	private XYChart.Series<Number, Number> sSeries;
	private XYChart.Series iSeries = new XYChart.Series();
	private XYChart.Series zSeries = new XYChart.Series();
	private XYChart.Series rSeries = new XYChart.Series();
	private Task<Void> updateTask;
	LineChart<Number, Number> chart;
	List<Slider> sliders;
	
	WithTreatment model = new WithTreatment();
	
	public static void main(String[] args) {
		launch(args);
	 }
	
	@Override
	public void stop() {
		System.exit(0);
	}
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {

		
		primaryStage.setTitle("Blatt 3");
		
		BorderPane borderP = new BorderPane();	
		Scene scene = new Scene(borderP, 800, 600);
		primaryStage.setScene(scene);
		
		sliders = new ArrayList<Slider>();
		
		//VBox
		VBox control = new VBox();
		borderP.setRight(control);
		control.setPadding(new Insets(5, 5, 5, 5));
		control.setSpacing(3);
		control.setAlignment(Pos.TOP_CENTER);
		
		Button run = new Button("Start");
		control.getChildren().add(run);
		run.setPrefWidth(100);

		control.getChildren().add(new Label("dt"));
		Slider dtSlider = new Slider();
		control.getChildren().add(dtSlider);
		bindSlider(dtSlider, model.getDt());
		sliders.add(dtSlider);
		dtSlider.setMin(0);
		dtSlider.setMax(0.8);
		
		control.getChildren().add(new Label("Anzahl Schritte"));
		Slider stepsSlider = new Slider();
		control.getChildren().add(stepsSlider);
		sliders.add(stepsSlider);
		stepsSlider.setMin(1);
		stepsSlider.setMax(6000);
		bindSlider(stepsSlider, model.getNumberSteps());

		control.getChildren().add(new Label("Startwerte"));
		
		control.getChildren().add(new Label("S"));
		Slider sSlider = new Slider();
		control.getChildren().add(sSlider);
		sliders.add(sSlider);
		sSlider.setMin(0);
		sSlider.setMax(1000);
		bindSlider(sSlider, model.getsStart());

		
		control.getChildren().add(new Label("I"));
		Slider iSlider = new Slider();
		control.getChildren().add(iSlider);
		sliders.add(iSlider);
		iSlider.setMin(0);
		iSlider.setMax(1000);
		bindSlider(iSlider, model.getiStart());

		control.getChildren().add(new Label("Z"));
		Slider zSlider = new Slider();
		control.getChildren().add(zSlider);
		sliders.add(zSlider);
		zSlider.setMin(0);
		zSlider.setMax(1000);
		bindSlider(zSlider, model.getzStart());

		control.getChildren().add(new Label("R"));
		Slider rSlider = new Slider();
		control.getChildren().add(rSlider);
		sliders.add(rSlider);
		rSlider.setMin(0);
		rSlider.setMax(1000);
		bindSlider(rSlider, model.getrStart());

		control.getChildren().add(new Label("Parameter"));
		control.getChildren().add(new Label("Pi (->S)"));
		Slider piSlider = new Slider();
		control.getChildren().add(piSlider);
		sliders.add(piSlider);
		piSlider.setMin(0);
		piSlider.setMax(1);
		bindSlider(piSlider, model.getPi());

		control.getChildren().add(new Label("Beta (S->I)"));
		Slider betaSlider = new Slider();
		control.getChildren().add(betaSlider);
		sliders.add(betaSlider);
		betaSlider.setMin(0);
		betaSlider.setMax(0.025);
		bindSlider(betaSlider, model.getBeta());

		
		control.getChildren().add(new Label("Delta (S->R)"));
		Slider deltaSlider = new Slider();
		control.getChildren().add(deltaSlider);
		sliders.add(deltaSlider);
		deltaSlider.setMin(0);
		deltaSlider.setMax(0.00025);
		bindSlider(deltaSlider, model.getDelta());

		
		control.getChildren().add(new Label("c (Z->S)"));
		Slider cSlider = new Slider();
		control.getChildren().add(cSlider);
		sliders.add(cSlider);
		cSlider.setMin(0);
		cSlider.setMax(0.085);
		bindSlider(cSlider, model.getC());

		control.getChildren().add(new Label("Rho (I->Z)"));
		Slider rhoSlider = new Slider();
		control.getChildren().add(rhoSlider);
		sliders.add(rhoSlider);
		rhoSlider.setMin(0);
		rhoSlider.setMax(0.025);
		bindSlider(rhoSlider, model.getRho());

		control.getChildren().add(new Label("Zheta (R->Z)"));
		Slider zhetaSlider = new Slider();
		control.getChildren().add(zhetaSlider);
		sliders.add(zhetaSlider);
		zhetaSlider.setMin(0);
		zhetaSlider.setMax(0.025);
		bindSlider(zhetaSlider, model.getZheta());

		control.getChildren().add(new Label("Alpha (Z->R)"));
		Slider alphaSlider = new Slider();
		control.getChildren().add(alphaSlider);
		sliders.add(alphaSlider);
		alphaSlider.setMin(0);
		alphaSlider.setMax(0.025);
		bindSlider(alphaSlider, model.getAlpha());

		//Chart initialisieren
		NumberAxis xAxis = new NumberAxis();
		NumberAxis yAxis = new NumberAxis();
		chart = new LineChart<Number, Number>(xAxis, yAxis);
		
		
		
		//Buttons
		run.setOnAction((event) -> {
			for(Slider s: sliders) {
				s.setDisable(true);
			}
			updateTask = new Task<Void>() {
				@SuppressWarnings("unchecked")
				@Override			
				protected Void call() throws Exception {
					model.reset();
					chart.getData().clear();
					sSeries = new XYChart.Series<Number, Number>();
					sSeries.setName("S");
					chart.getData().add(sSeries);
					iSeries = new XYChart.Series<Number, Number>();
					iSeries.setName("I");
					chart.getData().add(iSeries);
					zSeries = new XYChart.Series<Number, Number>();
					zSeries.setName("Z");
					chart.getData().add(zSeries);
					rSeries = new XYChart.Series<Number, Number>();
					rSeries.setName("R");
					chart.getData().add(rSeries);
					
					//System.out.println("Pi: "+model.getPi().get()+", beta: "+model.getBeta().get()+", delta: "+model.getDelta().get()+", c: "+model.getC().get()+", rho: "
						//	+model.getRho().get()+", zheta: "+model.getZheta().get()+", alpha: "+model.getAlpha().get()+", dt: "+model.getDt().get()+", steps: "+model.getNumberSteps().get());
					
					for (int j=0; j < model.getNumberSteps().get() ; j++) {
						
						final int n = j;
						final double s = model.getS();
						final double i = model.getI();
						final double z = model.getZ();
						final double r = model.getR();

						Platform.runLater(new Runnable() {		
							@SuppressWarnings("rawtypes")
							@Override
							public void run() {
								sSeries.getData().add(new XYChart.Data(n*model.getDt().get(), s));	
								iSeries.getData().add(new XYChart.Data(n*model.getDt().get(), i));								
								zSeries.getData().add(new XYChart.Data(n*model.getDt().get(), z));								
								rSeries.getData().add(new XYChart.Data(n*model.getDt().get(), r));								
							}
						});
						model.heunStep();				

						if (Thread.currentThread().isInterrupted()) {
							activateButtons();
							return null;
						}
					}
					Platform.runLater(new Runnable() {							
						@Override
						public void run() {
							activateButtons();					
						}
					});

					return null;
				}
				
			};
			updateTask.run();
		});
		

		
		borderP.setCenter(chart);
		primaryStage.show();
	}

	private void activateButtons() {
		for(Slider s: sliders) {
			s.setDisable(false);
		}
	}
	
	private void bindSlider(Slider slid, DoubleProperty prop) {
		slid.setValue(prop.get());
		prop.bind(slid.valueProperty());
	}
	
}
