package Model;


import java.util.Observable;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

@FunctionalInterface
interface DGL {
	public double calculate(double S, double I, double Z, double R);
}

public class WithTreatment extends Observable {

	//Parameters with default values
	DoubleProperty pi = new SimpleDoubleProperty(0);
	DoubleProperty beta = new SimpleDoubleProperty(0.0067);
	DoubleProperty delta = new SimpleDoubleProperty(0.00138);
	DoubleProperty c= new SimpleDoubleProperty(0.017);
	DoubleProperty rho= new SimpleDoubleProperty(0.024);
	DoubleProperty zheta= new SimpleDoubleProperty(0.015);
	DoubleProperty alpha = new SimpleDoubleProperty(0.005);
	DoubleProperty sStart = new SimpleDoubleProperty(500);
	DoubleProperty iStart = new SimpleDoubleProperty(0);
	DoubleProperty zStart = new SimpleDoubleProperty(0);
	DoubleProperty rStart = new SimpleDoubleProperty(0);
	DoubleProperty numberSteps = new SimpleDoubleProperty(1430);
	DoubleProperty dt = new SimpleDoubleProperty(0.5);
	
	
	//State
	double S;
	double I;
	double Z;
	double R;
		
	
	//Derivations
	DGL SPrime = (s, i, z, r) -> {
		return (pi.get()) - (beta.get() * s * z) - (delta.get() *s) + (c.get() * z);
	};
	
	DGL IPrime = (s, i, z, r) -> {
		return (beta.get() * s * z ) - (rho.get() * i) - (delta.get() * i);
	};
	
	DGL ZPrime = (s, i, z, r) -> {
		return (rho.get() * i) + (zheta.get() * r) - (alpha.get() * s * z) - (c.get() * z);
	};
	
	DGL RPrime = (s, i, z, r) -> {
		return (delta.get() * s) + (delta.get() * i) + (alpha.get() * s * z) - (zheta.get() * r);
	};
	
	
	
	public void heunStep() {
		double sp = heunPartOne(S, SPrime);
		double ip = heunPartOne(I, IPrime);
		double zp = heunPartOne(Z, ZPrime);
		double rp = heunPartOne(R, RPrime);
		double[] xp = {sp, ip, zp, rp};
		
		S = heunPartTwo(S, xp, 0, SPrime);
		I = heunPartTwo(I, xp, 1, IPrime);
		Z = heunPartTwo(Z, xp, 2, ZPrime);
		R = heunPartTwo(R, xp, 3, RPrime);
		//System.out.println("S: "+S+", I: "+I+", Z: "+Z+", R: "+R);
		
	}
	
	private double heunPartOne(double x0, DGL f) {
		return  x0 + dt.get() * f.calculate(S, I, Z, R);
	}
	
	private double heunPartTwo(double x0, double[] xp, int var, DGL f) {
		return 0.5 * x0 + 0.5 * (xp[var] + dt.get() * f.calculate(xp[0], xp[1], xp[2], xp[3]) );
	}
	
	public void reset() {
		S=sStart.get();
		I=iStart.get();
		Z=zStart.get();
		R=rStart.get();
	}

	public DoubleProperty getPi() {
		return pi;
	}

	public DoubleProperty getBeta() {
		return beta;
	}

	public DoubleProperty getDelta() {
		return delta;
	}

	public DoubleProperty getC() {
		return c;
	}

	public DoubleProperty getRho() {
		return rho;
	}

	public DoubleProperty getAlpha() {
		return alpha;
	}
	
	public DoubleProperty getZheta() {
		return zheta;
	}

	public DoubleProperty getNumberSteps() {
		return numberSteps;
	}

	public DoubleProperty getDt() {
		return dt;
	}

	public DoubleProperty getsStart() {
		return sStart;
	}

	public DoubleProperty getiStart() {
		return iStart;
	}

	public DoubleProperty getzStart() {
		return zStart;
	}

	public DoubleProperty getrStart() {
		return rStart;
	}

	public double getR() {
		return R;
	}

	public double getS() {
		return S;
	}

	public double getI() {
		return I;
	}

	public double getZ() {
		return Z;
	}
}
