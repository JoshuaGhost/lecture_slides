#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:
    void valueChange();
    void valueChangeLV();

private:
    Ui::MainWindow *ui;
    QVector<double> t,s,i,z,r;
    QVector<double> t2,raub,beut;
    double S;
    double I;
    double Z;
    double R;
};

#endif // MAINWINDOW_H
