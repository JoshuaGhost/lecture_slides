#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->slA,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));
    connect(ui->slB,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));
    connect(ui->slC,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));
    connect(ui->slD,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));
    connect(ui->slE,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));
    connect(ui->slF,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));
    connect(ui->slG,SIGNAL(valueChanged(int)),this,SLOT(valueChange()));


    connect(ui->txtS,SIGNAL(valueChanged(double)),this,SLOT(valueChange()));
    connect(ui->txtI,SIGNAL(valueChanged(double)),this,SLOT(valueChange()));
    connect(ui->txtR,SIGNAL(valueChanged(double)),this,SLOT(valueChange()));
    connect(ui->txtZ,SIGNAL(valueChanged(double)),this,SLOT(valueChange()));


    connect(ui->slA_2,SIGNAL(valueChanged(int)),this,SLOT(valueChangeLV()));
    connect(ui->slB_2,SIGNAL(valueChanged(int)),this,SLOT(valueChangeLV()));
    connect(ui->slC_2,SIGNAL(valueChanged(int)),this,SLOT(valueChangeLV()));
    connect(ui->slD_2,SIGNAL(valueChanged(int)),this,SLOT(valueChangeLV()));

    connect(ui->txtS_2,SIGNAL(valueChanged(double)),this,SLOT(valueChangeLV()));
    connect(ui->txtI_2,SIGNAL(valueChanged(double)),this,SLOT(valueChangeLV()));

    ui->Plot->setInteraction(QCP::iRangeDrag, true);
    ui->Plot->setInteraction(QCP::iRangeZoom, true);
    ui->Plot_2->setInteraction(QCP::iRangeDrag, true);
    ui->Plot_2->setInteraction(QCP::iRangeZoom, true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::valueChange()
{
    s.clear();
    i.clear();
    z.clear();
    r.clear();
    t.clear();

    int preS = ui->txtS->value();
    int preI = ui->txtI->value();
    int preZ = ui->txtZ->value();
    int preR = ui->txtR->value();

    double Alpha = ui->slA->value()/100.0;
    double Beta = ui->slB->value()/100.0;
    double Delta = ui->slC->value()/100.0;
    double Zeta = ui->slD->value()/100.0;
    double Rho = ui->slE->value()/100.0;
    double c = ui->slF->value()/100.0;
    double Pi = ui->slG->value()/100.0;

    double dt = 0.001;
    t << 0.0;
    s << preS;
    i << preI;
    z << preZ;
    r << preR;

    for(int j = 0; j< 100000; ++j){
        t << (j*dt);
        double sp = (Pi-Beta*s[j]*z[j]-Delta*s[j]+c*z[j])*dt+s[j];
        s << 0.5*s[j]+0.5*(sp+dt*(Pi-Beta*s[j]*z[j]-Delta*s[j]+c*z[j]));

        double ip = (Beta*s[j]*z[j]-Rho*i[j]+Delta*i[j])*dt+i[j];
        i << 0.5*i[j]+0.5*(ip+dt*(Beta*s[j]*z[j]-Rho*i[j]+Delta*i[j]));

        double zp = (Rho*i[j]+Zeta*r[j]-Alpha*s[j]*z[j]-c*z[j])*dt+z[j];
        z << 0.5*z[j]+0.5*(zp+dt*(Rho*i[j]+Zeta*r[j]-Alpha*s[j]*z[j]-c*z[j]));

        double rp = (Delta*s[j]+Delta*i[j]+Alpha*s[j]*z[j]-Zeta*r[j])*dt+r[j];
        r << 0.5*r[j]+0.5*(rp+dt*(Delta*s[j]+Delta*i[j]+Alpha*s[j]*z[j]-Zeta*r[j]));
    }
    ui->Plot->addGraph();
    ui->Plot->addGraph();
    ui->Plot->addGraph();
    ui->Plot->graph(0)->setPen(QPen(Qt::red));
    ui->Plot->graph(1)->setPen(QPen(Qt::blue));
    ui->Plot->graph(0)->setData(t,z);
    ui->Plot->graph(1)->setData(t,s);
    ui->Plot->replot();
}

void MainWindow::valueChangeLV()
{
    t2.clear();
    raub.clear();
    beut.clear();

    int preR = ui->txtS_2->value();
    int preB = ui->txtI_2->value();


    double a = ui->slA_2->value()/100.0;
    double b = ui->slB_2->value()/100.0;
    double c = ui->slC_2->value()/100.0;
    double d = ui->slD_2->value()/100.0;

    double dt = 0.001;
    t << 0.0;
    beut << preB;
    raub << preR;

    for(int j = 0; j< 100000; ++j){
        t2 << (j*dt);
        double beutp = (beut[j]*(a-b*raub[j]))*dt+beut[j];
        beut << 0.5*beut[j]+0.5*(beutp+dt*(beut[j]*(a-b*raub[j])));

        double raubp = (raub[j]*(c*beut[j]-d))*dt+raub[j];
        raub << 0.5*raub[j]+0.5*(raubp+dt*(raub[j]*(c*beut[j]-d)));
    }
    ui->Plot_2->clearPlottables();
    QCPCurve *phasenraum = new QCPCurve(ui->Plot_2->xAxis,ui->Plot_2->yAxis);
    ui->Plot_2->addPlottable(phasenraum);
    phasenraum->setData(beut,raub);
    phasenraum->setPen(QPen(Qt::green));

    ui->Plot_2->addGraph();
    ui->Plot_2->addGraph();
    ui->Plot_2->addGraph();
    ui->Plot_2->graph(0)->setPen(QPen(Qt::red));
    ui->Plot_2->graph(1)->setPen(QPen(Qt::blue));
    ui->Plot_2->graph(0)->setData(t2,beut);
    ui->Plot_2->graph(1)->setData(t2,raub);
    ui->Plot_2->replot();

}

