from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import numpy as np
import math

#f = lambda a1,a2 : abs((cos(a1)*cos(a2)*(2 + abs(tan(a1)) + abs(tan(a2)))) / (sin(a1 - a2)))

fig = plt.figure()
ax = fig.gca(projection='3d')
X = np.arange(-math.pi/2,math.pi/2,0.05)
Y = np.arange(-math.pi/2,math.pi/2,0.05)
X, Y = np.meshgrid(X, Y)
A = np.tan(X)
A = np.abs(A)
B = np.tan(Y)
B = np.abs(B)
C = np.divide(np.cos(X) * np.cos(Y) * (2 + A + B), np.sin(X-Y))
Z = np.abs(C)
Z[Z > 20] = 20

surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm,
        linewidth=0, antialiased=False)


ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()

