#!/usr/bin/python
# author Christian Henning - 2843590
import sys
import matplotlib.pyplot as plt

if len(sys.argv) <> 11:
####################################
### input values
	# killed zombies
	alpha = 0.0075
	# susceptibles become zombies through an encounter with a zombie
	beta = 0.0055
	# cure of zombies
	cure  = 0.001
	# modelling non-zombi related death
	delta = 0.0001
	# birth rate
	pi = 0.0001
	# infected people that become a zombie
	rho = 0.01
	# removed people can resurrect and become zombie
	zeta = 0.09

	# step size
	dt = 0.01
	# number of steps
	T = 50000;
	# initial population
	N = 1000;
####################################
else:
	try:
		alpha = float(sys.argv[1])
		beta = float(sys.argv[2])
		cure = float(sys.argv[3])
		delta = float(sys.argv[4])
		pi = float(sys.argv[5])	
		rho = float(sys.argv[6])	
		zeta = float(sys.argv[7])
		dt = float(sys.argv[8])
		T = int(sys.argv[9])
		N = int(sys.argv[10])

	except:
		print 'Error: Invalid input arguments.'


S = list([N])
I = list([0])
Z = list([0])
R = list([0])

dS = lambda S,I,Z,R : pi - beta * S * Z - delta * S + cure * Z
dI = lambda S,I,Z,R : beta * S * Z - rho * I - delta * I
dZ = lambda S,I,Z,R : rho * I + zeta * R - alpha * S * Z - cure * Z
dR = lambda S,I,Z,R : delta * S + delta * I + alpha * S * Z - zeta * R

for i in range(1, T):
	S_temp = S[i-1] + dt * dS(S[i-1], I[i-1], Z[i-1], R[i-1])
	I_temp = I[i-1] + dt * dI(S[i-1], I[i-1], Z[i-1], R[i-1])
	Z_temp = Z[i-1] + dt * dZ(S[i-1], I[i-1], Z[i-1], R[i-1])
	R_temp = R[i-1] + dt * dR(S[i-1], I[i-1], Z[i-1], R[i-1])

	S.append(0.5 * S[i-1] + 0.5 * (S_temp + dt * dS(S_temp,I_temp,Z_temp,R_temp)))
	I.append(0.5 * I[i-1] + 0.5 * (I_temp + dt * dI(S_temp,I_temp,Z_temp,R_temp)))
	Z.append(0.5 * Z[i-1] + 0.5 * (Z_temp + dt * dZ(S_temp,I_temp,Z_temp,R_temp)))
	R.append(0.5 * R[i-1] + 0.5 * (R_temp + dt * dR(S_temp,I_temp,Z_temp,R_temp)))

# plot the solution
plt.plot(range(0,T), S, label="S")
plt.plot(range(0,T), I, label="I")
plt.plot(range(0,T), Z, label="Z")
plt.plot(range(0,T), R, label="R")
plt.legend(bbox_to_anchor=(1.05, 1),loc=2, borderaxespad=0.)
plt.xlabel('Time')
plt.ylabel('Population')
plt.show()
