#include "zombieSystem.h"
#include <iostream>

int main(int argc, char *argv[])
{

    zombieSystem system=zombieSystem(0.0001,0.00001,0.01,0,0,0.001,0.00001,1000,50);
    std::vector<std::vector<double> > lsg=system.integrate();

    std::cout<<"Normale"<<"\t"<<"Infizierte"<<"\t"<<"\t"<<"Zombies"<<"\t"<<"Tote"<<"\n";

    for(int i=0;i<lsg.size();i++){
        std::cout<<lsg[i][0]<<"\t"<<lsg[i][1] <<"\t"<<"\t"<<lsg[i][2]<<"\t"<< lsg[i][3] <<"\n";
    }


}
