#ifndef ZOMBIESYSTEM_H
#define ZOMBIESYSTEM_H
#include "heunsMethod.h"

class zombieSystem:public heunsMethod{

private:
    double biteRate;
    double treatmentRate;
    double zombificationRate;
    double deadRate;
    double destroyRate;
    double birthRate;
    double reanimationRate;

public:

    zombieSystem(double biteRate,double treatmentRate, double zombificationRate, double deadRate, double birthRate, double reanimationRate, double destroyRate, double survivors,double zombies){
        this->biteRate=biteRate;
        this->treatmentRate=treatmentRate;
        this->zombificationRate=zombificationRate;
        this->deadRate=deadRate;
        this->birthRate=birthRate;
        this->destroyRate=destroyRate;
        this->reanimationRate=reanimationRate;
        std::vector<double> init;
        init.push_back(survivors);
        init.push_back(0);
        init.push_back(zombies);
        init.push_back(0);
        setInitialValue(init);
        setDt(1);
        setSteps(100);
    }

    std::vector<double> dfgHeun(std::vector<double> f){
        double survivors=f[0];
        double infected=f[1];
        double zombies=f[2];
        double dead=f[3];
        double newSurvivors=birthRate-biteRate*survivors*zombies-deadRate*survivors+treatmentRate*zombies;
        double newInfected =biteRate*survivors*zombies-zombificationRate*infected-deadRate*infected;
        double newZombies=zombificationRate*infected+reanimationRate*dead-destroyRate*survivors*zombies-treatmentRate*zombies;
        double newDead=deadRate*survivors+deadRate*infected+destroyRate*survivors*zombies-reanimationRate*dead;
        std::vector<double> lsg;
        lsg.push_back(newSurvivors);
        lsg.push_back(newInfected);
        lsg.push_back(newZombies);
        lsg.push_back(newDead);
        return lsg;
    }


};

#endif // ZOMBIESYSTEM_H
