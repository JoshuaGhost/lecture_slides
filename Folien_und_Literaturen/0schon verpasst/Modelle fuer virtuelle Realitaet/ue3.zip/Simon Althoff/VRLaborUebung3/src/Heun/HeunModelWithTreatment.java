package Heun;
import java.util.ArrayList;
import java.util.List;


public class HeunModelWithTreatment {

	
	public static List<double[]> heun(double dt, double maxt, double[] startValues, Function[] functions){
		List<double[]> result = new ArrayList<double[]>();
		
		double t = 0; 
		double[] currentValues = startValues.clone();
		double[] nextValues = new double[startValues.length];
		
		
		while(t <= maxt){
			t += dt;
			
			double[] pValues = new double[startValues.length];
			for(int i = 0; i < startValues.length; i++){
				pValues[i] = currentValues[i] + dt*functions[i].valueAt(t, currentValues);
			}
			
			for(int i = 0; i < startValues.length; i++){
				nextValues[i] = 0.5*currentValues[i] + 0.5*(pValues[i]+dt*functions[i].valueAt(t, pValues));
			}
			
			currentValues = nextValues;
			
			double[] resultEntry = new double[startValues.length+1];
			resultEntry[0] = t;
			for(int i = 1; i < resultEntry.length; i++){
				resultEntry[i] = currentValues[i-1];
			}
			result.add(resultEntry);
			
			
			//Debug
			double totalEntities = 0.0;
			double functionss = 0.0;
			for(int i = 0; i < currentValues.length; i++){
				totalEntities += currentValues[i];
				functionss += functions[i].valueAt(0, currentValues);
			}
			
			System.out.println(totalEntities);
			System.out.println("Funct:" + functionss);
		}
		
		return result;
	}
	
	
	public static void main(String[] args){
		
		double[] start = {500.0,0.0,0.0,0.0};
		
		final double birthRate = 0.0; //PI
		final double transmission = 0.0095; //BETA
		final double resurrection = 0.005; // C
		final double deadZombie = 0.005; //alpha
		final double cure = 0.005; //c
		final double deathRate = 0.0001; //delta
		final double quarantine = 0.001; //p
		
		final int S = 0;
		final int I = 1;
		final int Z = 2;
		final int R = 3;
		
		Function SD = new Function(){
			@Override
			public double valueAt(double t, double[] point) {
				return   birthRate 
					   - transmission*point[S]*point[Z]
					   - deathRate*point[S]
					   + cure*point[Z];
			}};
			
		Function ID = new Function(){
			@Override
			public double valueAt(double t, double[] point) {
				return   transmission*point[S]*point[Z]
					   - quarantine*point[I]
					   - deathRate*point[I];
			}};
			
			
		Function ZD = new Function(){
			@Override
			public double valueAt(double t, double[] point) {
				return   quarantine*point[I]
					   + resurrection*point[R]
					   - deadZombie*point[S]*point[Z]
					   - cure*point[Z];
			}};
			
		Function RD = new Function(){
			@Override
			public double valueAt(double t, double[] point) {
				return   deathRate*point[S]
					   + deathRate*point[I]
					   + deadZombie*point[S]*point[Z]
					   - resurrection*point[R];
			}};
				
		Function[] functions = {SD,ID,ZD,RD};
		CSVExporter.export("", "heun", heun(0.1 , 3000, start, functions));;
	}
}
