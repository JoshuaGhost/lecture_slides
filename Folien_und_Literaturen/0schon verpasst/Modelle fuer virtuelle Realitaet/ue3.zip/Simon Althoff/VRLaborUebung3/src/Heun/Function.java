package Heun;

public abstract class Function {
	public abstract double valueAt(double t, double[] point);
}
