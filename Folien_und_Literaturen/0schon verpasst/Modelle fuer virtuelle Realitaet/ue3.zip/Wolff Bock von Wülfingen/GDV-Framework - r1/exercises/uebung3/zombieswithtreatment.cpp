#include "zombieswithtreatment.h"

ZombiesWithTreatment::ZombiesWithTreatment() {
    xMin = 0;
    xMax = 100;
    yMin = 0;
    yMax = 100;
}

ZombiesWithTreatment::~ZombiesWithTreatment() {

}

void ZombiesWithTreatment::setupGUI(GdvGui &userInterface) {

}

void ZombiesWithTreatment::initialize() {
    susceptibles = 100;
    infected = 0;
    zombies = 5;
    removed = 0;

    birthRate = 0;
    naturalDeathRate = 0;
    biteRate = 0.1;
    turnRate = 0.1;
    cureRate = 0.05;
    resurrectRate = 0.05;
    zombieKillRate = 0.05;
}

void ZombiesWithTreatment::deinitialize() {

}

void ZombiesWithTreatment::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));

    if(hasStarted) {
        qint64 timeElapsed = timer.elapsed();
        float tpf = timeElapsed/1000.0f;
        timer.restart();

        //calc values
        //recalcSystemProperties(); //only needed if gui controls are active
        recalcSystem(tpf);
    }

    //draw
    QVector3D col = QVector3D(0,0,0);
    float totalPop = susceptibles + infected + zombies + removed;
    qDebug() << totalPop; //to control that no population errors happen
    drawBigLine(canvas,getRealX(10),getRealX(10),getRealY(0),getRealY(susceptibles/totalPop * 100),col);
    drawBigLine(canvas,getRealX(20),getRealX(20),getRealY(0),getRealY(infected/totalPop * 100),col);
    drawBigLine(canvas,getRealX(30),getRealX(30),getRealY(0),getRealY(zombies/totalPop * 100),col);
    drawBigLine(canvas,getRealX(40),getRealX(40),getRealY(0),getRealY(removed/totalPop * 100),col);

    canvas.flipBuffer();
}

void ZombiesWithTreatment::recalcSystem(float tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }
    auto sPointer = std::bind(&ZombiesWithTreatment::susceptibleChange, this, _1, _2, _3, _4);
    auto iPointer = std::bind(&ZombiesWithTreatment::infectedChange, this, _1, _2, _3, _4);
    auto zPointer = std::bind(&ZombiesWithTreatment::zombiesChange, this, _1, _2, _3, _4);
    auto rPointer = std::bind(&ZombiesWithTreatment::removedChange, this, _1, _2, _3, _4);

    for(int t = 0; t < iterations;t++) {
        float nextSusceptibles = heunMethod(sPointer,susceptibles, 0);
        float nextInfected = heunMethod(iPointer,infected, 1);
        float nextZombies = heunMethod(zPointer,zombies, 2);
        float nextRemoved = heunMethod(rPointer,removed, 3);
        susceptibles = nextSusceptibles;
        infected = nextInfected;
        zombies = nextZombies;
        removed = nextRemoved;
    }
}

void ZombiesWithTreatment::mousePressed(int x, int y) {
    hasStarted = true;
    timer.start();
}

float ZombiesWithTreatment::heunMethod(std::function<float (float, float, float, float)> fun, float value, int index) {
    float funcEval = fun(susceptibles,infected,zombies,removed);
    float firstIter = value + timeStep * funcEval;
    float secondFuncEval = 0;
    switch (index) {
    case 0:
        secondFuncEval = fun(firstIter,infected,zombies,removed);
        break;
    case 1:
        secondFuncEval = fun(susceptibles,firstIter,zombies,removed);
        break;
    case 2:
        secondFuncEval = fun(susceptibles,infected,firstIter,removed);
        break;
    case 3:
        secondFuncEval = fun(susceptibles,infected,zombies,firstIter);
        break;
    default:
        qDebug() << "INDEX NOT 0-3!!!!";
    }
    return value + timeStep/2 * (funcEval + secondFuncEval);
}

float ZombiesWithTreatment::susceptibleChange(float S, float I, float Z, float R) {
    return birthRate - biteRate * S * Z - naturalDeathRate * S + cureRate * Z;
}

float ZombiesWithTreatment::infectedChange(float S, float I, float Z, float R) {
    return biteRate * S * Z - turnRate * I - naturalDeathRate * I;
}

float ZombiesWithTreatment::zombiesChange(float S, float I, float Z, float R) {
    return turnRate * I + resurrectRate * R - zombieKillRate * S *Z - cureRate * Z;
}

float ZombiesWithTreatment::removedChange(float S, float I, float Z, float R) {
    return naturalDeathRate * S + naturalDeathRate * I + zombieKillRate * S * Z - resurrectRate * R;
}
