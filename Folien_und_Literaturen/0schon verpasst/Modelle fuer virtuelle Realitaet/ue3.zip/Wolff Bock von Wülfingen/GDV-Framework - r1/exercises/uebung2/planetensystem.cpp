#include "planetensystem.h"

Planetensystem::Planetensystem()
{
    mass = QList<float>();
    position = QList<QVector2D>();
    velocity = QList<QVector2D>();
    connections = QList<QVector2D>();
    currentForce = QList<QVector2D>();
}

Planetensystem::~Planetensystem() {

}

void Planetensystem::setupGUI(GdvGui &userInterface) {
    //userInterface.addSlider("Dämpfung",0,100,0,dampingInt);
    //userInterface.addSlider("Gravitation",-100,100,10,gravitationInt);

    //userInterface.addSlider("Sonnenmasse", 1,100,3,sunMassInt);

    //recalcSystemProperties();
}

void Planetensystem::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));

    if(hasStarted) {
        qint64 timeElapsed = timer.elapsed();
        float tpf = timeElapsed/1000.0f;
        timer.restart();

        //calc values
        //recalcSystemProperties(); //only needed if gui controls are active
        recalcSystem(tpf);
    }

    //draw
    for(int i = 0; i < position.length(); i++) {
        drawBig(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),colors.at(i));
    }

    canvas.flipBuffer();
}

void Planetensystem::initialize() {
    //sun
    position.append(QVector2D(0,0));
    mass.append(sunMass);
    //planets
    position.append(QVector2D(1,0));
    mass.append(1);
    position.append(QVector2D(0,-2));
    mass.append(1);
    position.append(QVector2D(-3,0));
    mass.append(1);
    position.append(QVector2D(0,4));
    mass.append(1);

    //connection to sun
    for(int i = 1; i < position.length(); i++) {
        connections.append(QVector2D(0,i));
    }

    //connections between planets
    for(int i = 1; i < position.length(); i++) {
        for(int j = 1; j < position.length(); j++) {
            if(j!=i) {
                connections.append(QVector2D(i,j));
            }
        }
    }

    //add initial velocities
    velocity.append(QVector2D(0,0));
    velocity.append(QVector2D(0,-10));
    velocity.append(QVector2D(-7.071,0));
    velocity.append(QVector2D(0,5.774));
    velocity.append(QVector2D(5,0));

    //add initial forces
    for(int i = 0; i < position.length(); i++) {
        currentForce.append(QVector2D(0,0));
    }

    //add colors
    colors.append(QVector3D(1,1.0f,0.0f));
    for(int i = 1; i < position.length(); i++) {
        colors.append(QVector3D(rand()/(RAND_MAX*1.0f),rand()/(RAND_MAX*1.0f),rand()/(RAND_MAX*1.0f)));
    }
}

void Planetensystem::deinitialize() {
    hasStarted = false;
    mass.clear();
    position.clear();
    velocity.clear();
    connections.clear();
    currentForce.clear();
    colors.clear();
}

void Planetensystem::mousePressed(int x, int y) {
    hasStarted = true;
    timer.start();
}

void Planetensystem::recalcSystem(float tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }
    for(int t = 0; t < iterations;t++) {
        //calc forces
        for(int i = 0; i < connections.length(); i++) {
            QVector2D curCon = connections.at(i);
            QVector2D left = position.at(curCon.x());
            QVector2D right = position.at(curCon.y());
            QVector2D thisCon = right-left;

            //                      G                 m                      M                        r²                           e_r
            QVector2D forceLeft = gravitation * (mass.at(curCon.x()) * mass.at(curCon.y()))/ thisCon.lengthSquared() * thisCon.normalized();
            currentForce[curCon.x()] += forceLeft;
            currentForce[curCon.y()] -= forceLeft;
        }
        //remove force on sun - makes for prettier stuff
        currentForce[0] = QVector2D(0,0);


        //apply forces
        for(int i = 0; i < position.length(); i++) {
            QVector2D vNew = velocity.at(i) * (1-damping) + currentForce.at(i) * timeStep / mass.at(i);
            QVector2D posNew = position.at(i) + vNew * timeStep;

            velocity[i] = vNew;
            position[i] = posNew;

            //resetting force
            currentForce[i] = QVector2D(0,0);
        }
    }
}

void Planetensystem::recalcSystemProperties() {
    damping = dampingInt/1000.0f;
    gravitation = gravitationInt/10.0f;

    sunMass = sunMassInt;
    if(mass.length() > 0) {
        mass[0] = sunMass;
    }
}


void Planetensystem::drawBig(GdvCanvas& canvas, int x, int y, QVector3D color) {
    for(int r = x-3; r <= x+3; r++) {
        for(int h = y-3; h <= y+3; h++) {
            if(r > 0 && r < viewWidth && h > 0 && h < viewHeight) {
                canvas.setPixel(r,h, color);
            }
        }
    }
}
