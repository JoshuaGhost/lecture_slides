#ifndef PLANETENSYSTEM_H
#define PLANETENSYSTEM_H

#include "../vrbase.h"

class Planetensystem : public VRBase
{
public:
    Planetensystem();
    virtual ~Planetensystem();

    virtual void setupGUI(GdvGui& userInterface);
    virtual void render(GdvCanvas& canvas);
    virtual void initialize();
    virtual void deinitialize();

    virtual void mousePressed(int x, int y);
    virtual void drawBig(GdvCanvas& canvas, int x, int y,QVector3D color);

    float damping = 0.0f;
    int dampingInt = 0;
    float gravitation = 1;
    int gravitationInt = 10;

    //Planetensystem variablen
    QList<float> mass;
    QList<QVector2D> position;
    QList<QVector2D> velocity;
    QList<QVector2D> connections;
    QList<QVector2D> currentForce;

    int sunMassInt = 100000;
    float sunMass = 100;

    void recalcSystemProperties();
    void recalcSystem(float tpf);
    float timeRemainder = 0;
    bool hasStarted = false;

    QList<QVector3D> colors;
};

#endif // PLANETENSYSTEM_H
