#include "vrbase.h"

VRBase::VRBase() {

}

VRBase::~VRBase() {

}

void VRBase::sizeChanged(unsigned int width, unsigned int height) {
    viewWidth = width;
    viewHeight = height;
}

bool VRBase::usesOpenGL()
{
    return false;
}

void VRBase::drawLine(GdvCanvas &canvas, int xLeft, int xRight, int yLeft, int yRight, QVector3D color) {
    if(xLeft > xRight) {
        int xTemp = xLeft;
        xLeft = xRight;
        xRight = xTemp;
        int yTemp = yLeft;
        yLeft = yRight;
        yRight = yTemp;
    }

    float deltaX = xRight - xLeft;
    float deltaY = yRight - yLeft;
    float error = 0;
    float deltaError = 0;
    if(deltaX!=0) {
        deltaError = std::abs(deltaY/deltaX);
        int y = yLeft;
        for(int x = xLeft; x < xRight; x++) {
            drawPixel(canvas,x,y,color);
            error = error + deltaError;
            while(error >= 0.5) {
                drawPixel(canvas,x,y,color);
                y = y+copysign(1.0f,yRight-yLeft);
                error = error - 1.0f;
            }
        }
    } else {
        if(yLeft > yRight) {
            int yTemp = yLeft;
            yLeft = yRight;
            yRight = yTemp;
        }
        for(int i = yLeft; i < yRight; i++) {
            drawPixel(canvas,xLeft,i,color);
        }
    }
}

void VRBase::drawBigLine(GdvCanvas &canvas, int xLeft, int xRight, int yLeft, int yRight, QVector3D color) {
    if(xLeft > xRight) {
        int xTemp = xLeft;
        xLeft = xRight;
        xRight = xTemp;
        int yTemp = yLeft;
        yLeft = yRight;
        yRight = yTemp;
    }

    float deltaX = xRight - xLeft;
    float deltaY = yRight - yLeft;
    float error = 0;
    float deltaError = 0;
    if(deltaX!=0) {
        deltaError = std::abs(deltaY/deltaX);
        int y = yLeft;
        for(int x = xLeft; x < xRight; x++) {
            drawBig(canvas,x,y,color);
            error = error + deltaError;
            while(error >= 0.5) {
                drawBig(canvas,x,y,color);
                y = y+copysign(1.0f,yRight-yLeft);
                error = error - 1.0f;
            }
        }
    } else {
        if(yLeft > yRight) {
            int yTemp = yLeft;
            yLeft = yRight;
            yRight = yTemp;
        }
        for(int i = yLeft; i < yRight; i++) {
            drawBig(canvas,xLeft,i,color);
        }
    }
}

void VRBase::drawPixel(GdvCanvas &canvas, int x, int y, QVector3D color) {
    if(x >= viewWidth || y >= viewHeight || x <= 0 || y <= 0) {
    } else {
        canvas.setPixel(x, y, color);
    }
}

void VRBase::drawBig(GdvCanvas& canvas, int x, int y, QVector3D color) {
    for(int r = x-1; r <= x+1; r++) {
        for(int h = y-1; h <= y+1; h++) {
            if(r > 0 && r < viewWidth && h > 0 && h < viewHeight) {
                canvas.setPixel(r,h, color);
            }
        }
    }
}

int VRBase::getRealX(float x) {
    float xLength = std::abs(xMax - xMin);
    return ((x-xMin)/xLength)*viewWidth;
}

int VRBase::getRealY(float y) {
    float yLength = std::abs(yMax - yMin);
    return viewHeight-((y-yMin)/yLength)*viewHeight;
}
