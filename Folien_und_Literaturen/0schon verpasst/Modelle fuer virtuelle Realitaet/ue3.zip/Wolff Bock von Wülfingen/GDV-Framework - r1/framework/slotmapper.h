#ifndef SLOTMAPPER_H
#define SLOTMAPPER_H
/**
 ** slotmapper.h - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/

#include <QObject>
#include <QVector3D>
#include <QString>
#include <QColor>

/**
 * @brief Die SlotMapper Klasse
 *
 * Wird verwendet, um zwischen GUI und eigenem Code zu vermitteln.
 * Interne Klasse, bitte nicht direkt einbinden und/oder verändern!
 */
class SlotMapper : public QObject
{
    Q_OBJECT
public:
    SlotMapper(bool& mappedValue);
    SlotMapper(int& mappedValue);
    SlotMapper(QVector3D& mappedValue);
    SlotMapper(QString& mappedValue);

public slots:
    void mapBool(bool value);
    void mapInteger(int value);
    void mapColor(QColor value);
    void mapString(QString value);

    void mapToWidget();

signals:
    void boolChanged(bool);
    void intChanged(int);
    void colorChanged(QVector3D);
    void stringChanged(QString);
    void styleSheetChanged(QString);


private:
    bool*       boolValue;
    int*        intValue;
    QVector3D*  colorValue;
    QString*    stringValue;

    bool lastBool;
    int lastInt;
    QVector3D lastColor;
    QString lastString;    
};

#endif // SLOTMAPPER_H
