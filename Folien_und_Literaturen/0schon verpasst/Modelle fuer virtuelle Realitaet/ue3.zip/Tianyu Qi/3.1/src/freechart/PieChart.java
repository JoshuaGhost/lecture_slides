/*
 *���Ʊ�ͼ 
 */
package freechart;

import java.awt.BorderLayout;

import org.jfree.chart.servlet.ServletUtilities;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartPanel;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeriesDataItem;

import java.awt.Color;
//import java.time.Year;

import org.jfree.chart.title.TextTitle;

import javax.swing.*;

public class PieChart extends JFrame{
 //constructor
 public PieChart(){
       //����DataSetTimeSeries 
	 int dx=1,t=0;
	 double S=1,I=0,Z=0,R=0,bta=0.0095,c=1,ro=0.9,qiguai=0.0001,arfa=0.005,deta=0.0001,S0,I0,Z0,R0;
	 TimeSeries timeSeries = new TimeSeries("SIZR with Cure-R0>1 with IC =DEF\n(same values for parameters used in previous figure)", Millisecond.class);  
	 TimeSeriesCollection lineDataset = new TimeSeriesCollection();  
	 while(t<10){
		 t=t+dx;
		 S0=S;
		 I0=I;
		 Z0=Z;
		 R0=R;
		 S=(-bta*S0*Z0-deta*S0+c*Z0)*(dx+1);
		 I=(bta*S0*Z0-ro*I0-deta*I0)*(dx+1);
		 Z=(ro*I0+qiguai*R0-arfa*S0*Z0-c*Z0)*(dx+1);
		 R=(deta*S0+deta*I0+arfa*S0*Z0-qiguai*R0)*(dx+1);
		 timeSeries.add(new Millisecond(t,0,0,0,1,1,1900), Z);
		 
	 }

	 
	 lineDataset.addSeries(timeSeries);  

	 JFreeChart chart = ChartFactory.createTimeSeriesChart("Zombies", "Time", "Population Values (1000's)", lineDataset, true, true, true);

	 XYPlot plot = chart.getXYPlot();  
	 //�������񱳾���ɫ  
	 plot.setBackgroundPaint(Color.white);  
	 //��������������ɫ  
	 plot.setDomainGridlinePaint(Color.LIGHT_GRAY);  
	 //�������������ɫ  
	 plot.setRangeGridlinePaint(Color.LIGHT_GRAY);  

	 //����������
	 chart.setTitle(new TextTitle("SIZR with Cure-R0>jh1 with IC =DEF\n(same values for parameters used in previous figure)"));
	 chart.setAntiAlias(true);
	 String fileName = "";
	 ChartPanel panel = new ChartPanel(chart);
     JPanel jp = new JPanel();
     jp.add(panel, BorderLayout.CENTER);
     this.add(jp);
     this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
     this.setBounds(100, 100, 700, 500);
     this.setVisible(true);
 }
 public static void main(String [] args){
      new PieChart();
   }

}