#! /usr/bin/python3
# -*- coding: utf-8 -*-


import numpy


# creates exp. euler-integrator for f(t, y) = y'
def create_exp_euler_int(f):
    return lambda t, prev_t, dim, prev_vals: prev_vals[dim] + (t - prev_t) * f(prev_t, prev_vals)


def create_heun_int(fs):

    eulers = []
    heuns = []

    for i in range(0, len(fs)):
        eulers.append(create_exp_euler_int(fs[i]))

        def func(t, prev_t, dim, prev_vals):
            h = t - prev_t

            # use exp. euler to approximate y_n+1
            tmp_vals = []
            for i2 in range(0, len(fs)):
                tmp_vals.append(eulers[i2](t, prev_t, i2, prev_vals))

            return prev_vals[dim] + 1.0 / 2.0 * h * (fs[dim](prev_t, prev_vals) + fs[dim](t, tmp_vals))

        heuns.append(func)
    return heuns


def integrate(part_funcs, init_vals, interval):
    dimensions = range(0, len(part_funcs))

    x_vals = []
    y_vals = []
    prev_vals = []

    # insert init. values
    for i in dimensions:
        x_vals.append([])
        x_vals[i].append(interval[0])
        y_vals.append([])
        y_vals[i].append(init_vals[i])
        prev_vals.append(init_vals[i])

    # integrate
    prev_param = interval[0]
    for r in interval[1:]:
        new_vals = []

        for i in dimensions:
            new_vals.append(part_funcs[i](r, prev_param, i, prev_vals))
            x_vals[i].append(r)
            y_vals[i].append(new_vals[i])

        prev_vals = new_vals
        prev_param = r

    return [x_vals, y_vals]