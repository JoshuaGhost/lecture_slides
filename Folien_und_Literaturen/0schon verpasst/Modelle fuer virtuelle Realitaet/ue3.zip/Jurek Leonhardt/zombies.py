#! /usr/bin/python3
# -*- coding: utf-8 -*-


import integrator
import matplotlib.pyplot as plot
import numpy as np


birth_rate = 10
delta = 0.01
zeta = 0.01
beta = 0.01
alpha = 0.001
rho = 0.5
c = 0.1


f_S = lambda t, prev_vals: birth_rate - beta * prev_vals[0] * prev_vals[2] - delta * prev_vals[0] + c * prev_vals[2]
f_I = lambda t, prev_vals: beta * prev_vals[0] * prev_vals[2] - rho * prev_vals[1] - delta * prev_vals[1]
f_Z = lambda t, prev_vals: rho * prev_vals[1] + zeta * prev_vals[3] - alpha * prev_vals[0] * prev_vals[2] - c * prev_vals[2]
f_R = lambda t, prev_vals: delta * prev_vals[0] + delta * prev_vals[1] + alpha * prev_vals[0] * prev_vals[2] - zeta * prev_vals[3]
legend = ['S', 'I', 'Z', 'R']
init_vals = [500, 1, 0, 100]
rng = np.arange(0, 10, 0.01)


handles = []
result = integrator.integrate(integrator.create_heun_int([f_S, f_I, f_Z, f_R]), init_vals, rng)
for i in range(len(result[0])):
	handle, = plot.plot(result[0][i], result[1][i], label=legend[i])
	handles.append(handle)


plot.legend(handles=handles)
plot.show()