package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Vector;

import javax.swing.JFrame;

public class Main3 extends JFrame{

	BufferedImage image;
    Graphics buffer;
	
	public Main3(){
		super();
		this.setSize(500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.setVisible(true);
        image = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_ARGB);
        buffer = image.getGraphics();
	}

	public static void main(String[] args) {
		//init gui
		Main3 frame = new Main3();
		//Aufgabe 3.1)
		//parameter
		double S=100; //menschen
		double I=1; //infizierte
		double Z=0; //zombies
		double R=0; //tote
		
		double dt=0.1;
		
		double Pi=1; //geburtenrate
		double b=0.1;//infektions-wk.
		double d=0.1;//mensch-sterberate
		double c=0.05;//heil-wk;
		double p=0.1;//verwandlungs-wk;
		double a=0.05;//zombie-sterberate
		double q=0.03;//auferstehungs-wk;
				
		
		for(double t=0; t<100; t+=dt) {
		//ableitungen
		double dS = Pi - b*S*Z - d*S + c*Z;
		double dI = b*S*Z - p*I - d*I;
		double dZ = p*I + q*R - a*S*Z -c*Z;
		double dR = d*S + d*I + a*S*Z - q*R;
		//heun 1)
		double S1 = S + dt*dS;
		double I1 = I + dt*dI;
		double Z1 = Z + dt*dZ;
		double R1 = R + dt*dR;
		//heun 2)
		double dS1 = Pi - b*S*Z - d*S + c*Z;
		double dI1 = b*S*Z - p*I - d*I;
		double dZ1 = p*I + q*R - a*S*Z -c*Z;
		double dR1 = d*S + d*I + a*S*Z - q*R;
		//heun 3)
		S = 0.5*(S + S1 + dt*dS1);
		I = 0.5*(I + I1 + dt*dI1);
		Z = 0.5*(Z + Z1 + dt*dZ1);
		R = 0.5*(R + R1 + dt*dR1);
		if (((int)(t/dt))%((int)(1/dt))==0) {
			//draw
			for(int s=0;s<S;s++) {
				frame.draw(Color.green);//grün mensch
			}
			for(int i=0;i<I;i++) {
				frame.draw(Color.yellow);//gelb infiziert
			}
			for(int z=0;z<Z;z++) {
				frame.draw(Color.red);//rot zombie
			}
			for(int r=0;r<R;r++) {
				frame.draw(Color.gray);//grau tot
			}
			frame.clear();
		}
		}

/*		Aufgabe 3.2 a)
		ein equilibria (gleichgewicht)
		sagt aus dass sich in dem system nichts mehr ändert.
		das heißt die anzahl der menschen, infizierten, tombies, toten
		bleibt über die zeit hin gleich.
		anders ausgedrückt bedeutet das, dass die ableitungen alle veschwinden
		müssen. daher wird in dem paper alle ableitungen gleich 0 gesetzt.
		und ein gleichungssystem mit 4 gleichungen und 4 unbekannten gelöst.
		Pi wird gleich 0 gesetzt, weil dies der zufluss an menschen ist
		und für ein gleichgewicht muss insbesondere S+I+Z+R konstant sein
		und darf nicht immer größer werden.
		
		Aufgabe 3.2 b)
		Eigenwerte:
		charakteristisches poynom = -y(-b*Z-y)*(-q-y)=0
		-> y=0 oder y=-q oder y=-b*Z
		
		den eigenvektoren bekommt man durh scharfes hinsehen.
		J*(0,1,0) = (0,0,0) -> eigenvektor zur 0
		
		den eigenvektor zu -q bekommt man durch
		gaus von J+qI
		letzte zeile -> a=0 oder N=0 (aber ich gehe mal davon aus a!=0)
		weil zombies ja auch sterben können
		aus N=0 bekommt man den vekor (0,1,-1)
		
		den eigenvektor zu -b*Z bekommt man durch
		gaus von J-b*Z*I
		letzte zeile zur zweiten addieren ergibt:
		0   0   0
		bZ  bZ  bZ   
		aZ  0  -q+bZ
		daraus folgt mit (b!=0)
		0   0   0
		1   1   1
		0  -aZ  bZ-q-aZ
		also ist ein eigenvekor (bZ-q, q-bZ+aZ, -aZ)
		
		die eigenewerte geben das verhältnis zwischen dem zustand und der steigung an.
		hat man zb einen positiven eigenwert zum eigenvekor (N,Z,I), so bedeutet das falls
		(N,Z,I) vorliegt, so wird dieser bestand im nächsten zeitschrit um einen faktor ansteigen
		(abhängig vom eigenwert).
		das problem an einem solchen verhalten ist, dass sich so fehler verstärken.
		ist man zb im zustand (N,0,0) aber durch numerische fehler kommt man in
		den zustand (N,0,1/100) und (0,0,1) ist ein eigenvektor mit positivem eigenwert.
		so hat das zur folge dass dZ positiv sein wird und sich der fehler
		im nöchsten schritt vergrößtert, da Z <- Z + dt*dZ
		von einer anderen seite betrachtet, heißt das dass man erst garnicht in den
		zustand (N,0,0) kommen kann, (wenn man nicht gerade von anfang an drin ist)
		da jede annäherung zu diesem zustand eine entfernung dieses zustands zur folge hat.
		(negative rückkopplung)
		
		Aufgabe 3.3)
		bei der berechnung der determinate zwei mal das -lamda auf der diagonalen vergessen
		das sind zwei fehler
		sonst vermute ich dass das minuszeichen vor dem (bZ-y) falsch ist
		weil beim entwickeln nach dem eintrag (1,1) hat man doch ein positves vorzeichen
		da 1+1 gerade
		
		Aufgabe 3.4)
		ich habe nicht verstanden warum d(die sterberate von infizierten und
		menschen) auch auf 0 gesetzt wird.
		und ich bin mir nicht 100prozent sicher ob ich den zusammenhang
		zwischen stabilität und keine positiven eigenwerten richtig verstanden habe.
		
		Aufgabe 3.5)a)
		geradengleichung (x1,o1 + tan(a1)*x1) und (x2,o2 + tan(a2)*x2)
		 aus gleichheit folgt x1=x2 und daher
		 o1 + tan(a1)*x = o2 + tan(a2)*x
		also
		 x = (o2-o1) / (tan(a1)-tan(a2)) =  (o2-o1)*cos(a1)*cos(a2)/sin(a1-a2)
		 y = o1 + tan(a1*)*(o2-o1)*cos(a1)*cos(a2)/sin(a1-a2)
		ableiten
		x nach o1
		 -cos(a1)*cos(a2)/sin(a1-a2)
		x nach 2
		cos(a1)*cos(a2)/sin(a1-a2)
		y nach o1
		1 - tan(a1*)*cos(a1)*cos(a2)/sin(a1-a2)
		y nach o2
		tan(a1*)*cos(a1)*cos(a2)/sin(a1-a2)
		in der summe
		k = 2*|cos(a1)*cos(a2)/sin(a1-a2)| + |cos(a1)*cos(a2)/sin(a1-a2)|
		 	  + |1 - tan(a1*)*cos(a1)*cos(a2)/sin(a1-a2)|
		die konditionierung hängt von der winkeldifferenz ab.
		ist a1-a2 sehr klein, also ist a1 ungefähr = a2 so ist das problem sehr schlecht konditioniert
		man kann sich gemoetrisch vorstellen, dass sich der schnttpunkt zweier geraden mit ähnlicher
		steigung sehr stark ändert, wenn man den ordinatenabschnitt variiert.
		ist der winkelunterschied groß finde ich die kondition gut.
		
		Aufgabe 3.5)b)
		angenommen man will berechnen wie lange sein akku noch hält
		in abhängigkeit davon zu wie viel prozent er geladen ist.
		das problem ist gut konditioniert, da die abhängigkeit linear ist.
		hat man 10% abweichung der eingangsdaten so erhält man 10% abweichung im ergbnis.
		
		angenommen eine bakterienkultur verdoppelt sich jede stunde.
		man möchte die größe der kultur berechnen in abhängigkeit der stunden seit beginn.
		das problem ist schlecht konditioniert, da die abhängigkeit exponentiell ist.
		irrt man sich in der eingabe nur um eine stunde, so ist der fehler in der ausgabe 100%
		
		
		*/
	}

	
	//Gui stuff...
		@Override
		  public void paint( Graphics g )
		  {
			g.drawImage(image, 0, 0, null);
		  }
		public void draw(Color color) {

	        buffer.setColor(color);
		    buffer.fillOval((int)(Math.random()*image.getWidth()),
		    		(int)(Math.random()*image.getHeight()), 20, 20);
			
		}
		public void clear(){
			this.repaint();
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	        buffer.setColor(Color.WHITE);
	        buffer.clearRect(0, 0, image.getWidth(), image.getHeight());
	        buffer.fillRect(0, 0, image.getWidth(), image.getHeight());
			
		}
	    public void update(Graphics g)
	    {
	            paint(g);
	    }
	
}
