package main;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Vector;

import javax.swing.JFrame;


public class Main2 extends JFrame{

	Vector<Integer> x;//save all x and y positions
	Vector<Integer> y;
	BufferedImage image;
    Graphics buffer;

	//Gui Init
	public Main2(){
		super();
		x = new Vector<Integer>();
		y = new Vector<Integer>();
		this.setSize(500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.setVisible(true);
        image = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_ARGB);
        buffer = image.getGraphics();

	}
	
	public static void main(String[] args) {
		Main2 window=new Main2();
		
		//Aufgabe 2.1) in der aufgabe ist vom federpendel die rede
		//aber auch vom pendelarm, was für eine art pendel war gemeint?
		//eine feder oder ein faden mit einem stein dran?
		//Annahme: federpendel!
		
		double t0=0;
		double t1=10;
		double dt=0.05;
		
		double vy=1;//startwerte
		double py=200;//startwerte
			
		double D=1;//federkonstante (auch k genannt)
		double m=1;//masse ist konstant 1
		double yRuhe=250;//das ist die Ruheposition der feder

		for (double t=t0; t<t1; t=t+dt) {
			double y=yRuhe-py;//auslenkung
			double a = (D*y)/m;//beschelunigung
			
			vy = vy + a *dt;
			py = py + dt * vy;
			
			
			window.draw(250,(int) py);
			window.buffer.drawLine(250,(int)py, 250,(int)yRuhe);
			window.clear();
		}
		
		//Aufgabe 2.2)
		//Ich wusste nicht wie genau die kräfte der beiden pendel sich gegenseitig
		//beieinflussen, deshalb hab ich einfach die geschwindigkeit des ersten pendels
		//auf die geschwindigekit des 2ten drauf addiert.
		//das ganze ist nicht physikalisch korrekt
		//aber sah besser aus als die restlichen varianten,
		//die ich versucht habe
		t1=20;
		double X=200;//hier ist das pendel aufgehängt
		double Y=100;
		
		double x=300;//hier hängt der erste unterarm zum zeitpunkt 0
		double y=110;
		
		double x2=400;//hier hängt der 2te unterarm zum zeitpunkt 0
		double y2=120;
		
		double vx=0;
		vy=0;
		double vx2=0;
		double vy2=0;
		double v=0;
		double v2=0;
		dt = 0.05;
		
		double r1 = Math.sqrt((X-x)*(X-x)+(Y-y)*(Y-y));
		double r2 = Math.sqrt((x2-x)*(x2-x)+(y2-y)*(y2-y));
		for (double t=t0; t<t1; t=t+dt) {
			window.draw((int)X,(int)Y);
			double phi = Math.atan(-1*(X-x)/(Y-y));
			double phi2 = Math.atan(-1*(x-x2)/(y-y2));
			
			if(Y-y>0){//sonst war der winkel nicht stetig(hatte sprünge)
				phi+=Math.PI;
			}
			
			if(y-y2>0){//sonst war der winkel nicht stetig
				phi2+=Math.PI;
			}
			

			
			double F = -m*9.81*Math.sin(phi);
			double Fz = m*(vx*vx+vy*vy)/r1;//zentripetalkraft
			double a = F/m;//beschelunigung in richtung tangente
			double az = Fz/m;//beschleunigung in richtung mittelpunkt
			double F2 = -m*9.81*Math.sin(phi2);
			double Fz2 = m*(vx2*vx2+vy2*vy2)/r2;
			double a2 = F2/m;//beschelunigung
			double az2 = Fz2/m;
			
			double azx = az*Math.sin(phi);//zentripetalbeschleunigung in richtung mitttelpunkt
			double azy = -az*Math.cos(phi);	
			double ax = -a*Math.cos(phi);//beschelunigung in richtung tangente der bahn
			double ay = -a*Math.sin(phi);

			vx+= dt * (ax+azx);
			vy+= dt * (ay+azy);
			
			double az2x = az2*Math.sin(phi2);//zentripetalbeschleunigung in richtung mitttelpunkt
			double az2y = -az2*Math.cos(phi2);	
			double a2x = -a2*Math.cos(phi2);//beschelunigung in richtung tangente der bahn
			double a2y = -a2*Math.sin(phi2);
			
			vx2+= dt * (a2x+az2x);
			vy2+= dt * (a2y+az2y);

			x+= dt * vx;
			y+= dt * vy;
			x2+= dt * (vx2+vx);//die geschwindigkeit des ersten pendels hinzuaddiert
			y2+= dt * (vy2+vy);
			
			window.buffer.drawLine((int)X,(int)Y, (int)x,(int)y);
			window.draw((int)x,(int)y);
			window.buffer.drawLine((int)x,(int)y, (int)x2,(int)y2);
			window.draw((int)x2,(int)y2);
			window.clear();
		
		}
		
		
		//Aufgabe 2.3
		int numberOfPlanets=10;
		double[] xPlanet = new double[numberOfPlanets];
		double[] yPlanet = new double[numberOfPlanets];
		double[] vxPlanet = new double[numberOfPlanets];
		double[] vyPlanet = new double[numberOfPlanets];
		double[] sizePlanet = new double[numberOfPlanets];
		for(int k=0; k<numberOfPlanets; k++) {//random initalisierung
			xPlanet[k]=Math.random()*500;
			yPlanet[k]=Math.random()*500;
			vxPlanet[k]=Math.random()*20-10;
			vyPlanet[k]=Math.random()*20-10;
			sizePlanet[k]=Math.random()*5+20;
		}
		for (double t=t0; t<t1; t=t+dt) {
			double[] xKraftPlanet = new double[numberOfPlanets];
			double[] yKraftPlanet = new double[numberOfPlanets];
			for(int k=0; k<numberOfPlanets; k++) {//kräfte berechene
				for(int i=0; i<numberOfPlanets; i++) {
					if (i!=k) {
						double xDif = xPlanet[i]-xPlanet[k];
						double yDif = yPlanet[i]-yPlanet[k];
						double r = Math.sqrt(xDif*xDif+yDif*yDif);
						xKraftPlanet[k]+=300*sizePlanet[k]*sizePlanet[i]*xDif/r/r/r;
						yKraftPlanet[k]+=300*sizePlanet[k]*sizePlanet[i]*yDif/r/r/r;
					}

				}
			}
			for(int k=0; k<numberOfPlanets; k++) {//neue geschwindigkeit und position ermitteln anhand von kräften
				double ax = xKraftPlanet[k]/sizePlanet[k];
				double ay = yKraftPlanet[k]/sizePlanet[k];
				vxPlanet[k]+= dt*ax;
				vyPlanet[k]+= dt*ay;
				xPlanet[k]+= dt*vxPlanet[k];
				yPlanet[k]+= dt*vyPlanet[k];
				window.buffer.setColor(Color.BLACK);
				window.buffer.fillOval((int)xPlanet[k], (int)yPlanet[k], (int)sizePlanet[k], (int)sizePlanet[k]);
			}
			window.clear();
		}
		
		//Aufgabe 2.4)
		//a) ein beispiel für ein nicht konservatives system ist eine fahrrad das einmal im kreis fährt
		//je schneller er diesen weg fährt, desto größer ist die kraft des gegenwinds, die er erfährt.
		//Nachdem er einmal im kreis gefahren ist, ist das system wieder im startzustand.
		//trotzdem hat der radfahrer energie in form von kalorienen verloren
		//man könnte also denken, es ist energie verloren gegangen.
		//praktisch entstand durch den gegenwind aber wärme durch reibung, sodass die "velorene"
		//energie jetzt in form von wärme gespeichert ist
		
		//b)
		//lokaler fehler: angenommen die daten zum zeitpunkt t_i stimmen,
		//dann ist der lokale fehler, der der durch eine iteration bishin zum zeitpunkt t_i+1
		//entsteht, zb durch rundung von gleitkommazahlen
		//globaler fehler: ist die "Summe" aller lokalen fehler. also der fehler,
		//der sich seit dem zeitpunkt t0 fortgepflanzt hat.
		
		//lokaler fehler vom expliziter euler
		//f_neu = f_alt + dt * f'
		//der fehler hängt ansich von der funktion ab
		//allgemein gilt:
		//fehler = f(x+h)-f(x)-h*f'(x)
		//für den Fall dass f Lipschitz-stetig ist gilt f(a)-f(b)< L*(a-b), daher:
		//fehler < L*h-h*f'(x) = h*(L-f'(x))<h*(L-(-L)) = 2*h*L
		//also proportional zur schrittweite h
		
		//die konvergenzrate sagt mir nichts
		
		
		//Aufgabe 2.5
		//manchmal wird diese scene nicht angezeigt, einfach nochmal neu starten das programm
		//ein array für die teilchenpositionen anlegen
		dt=0.01;
		t1=30;
		int zeit = 10000;//milli sek
		int steps = (int) ((t1-t0)/dt);
		int frames = zeit/20;
		int stepsPerFrame = Math.max(steps/frames,1);
		int numberOfTeil=0;
		double abstand=4.32;
		double[] xTeil = new double[(int) (500*500/abstand/abstand)];
		double[] yTeil = new double[(int) (500*500/abstand/abstand)];
		double radius=50;
		double durchmesserTeil=3;
		int x0=250;
		int y0=0;
		int count = 0;
		for (int xCord = 0;xCord<500; xCord+=abstand) {//halbkreis bilden
			for (int yCord = 0;yCord<500; yCord+=abstand) {
				if ((xCord-x0)*(xCord-x0)+(yCord-y0)*(yCord-y0)<radius*radius){
					xTeil[count]=xCord/10.0;
					yTeil[count]=yCord/10.0;
					count++;
				}
			}	
		}
		numberOfTeil=count-1;
		double[] vxTeil = new double[numberOfTeil];
		double[] vyTeil = new double[numberOfTeil];
		int stepNumber = 0;
		for (double t=t0; t<t1; t=t+dt) {
			stepNumber++;
			double[] xKraft = new double[numberOfTeil];
			double[] yKraft = new double[numberOfTeil];
			for(int k=0; k< numberOfTeil; k++){//für alle teilchen die kräfte ermitteln
				if (yTeil[k]>0.01)  {//Teilchen in der oberen reihe sind fest. ("auf sie wirken keine kräfte")
					for(int i=0; i< numberOfTeil; i++){
						if (i!=k) {
							double factor = 1;
							if (yTeil[i]<0.01)  {
								factor = 1.75;//Teilchen in der oberen reihe haben erhöhte kraft auf andere
							}
							double rik=Math.sqrt((xTeil[i]-xTeil[k])*(xTeil[i]-xTeil[k])+//radius
									(yTeil[i]-yTeil[k])*(yTeil[i]-yTeil[k]));
							xKraft[k]+=(xTeil[i]-xTeil[k])/rik/rik/rik/rik*(20-8/rik/rik)*factor;
							yKraft[k]+=(yTeil[i]-yTeil[k])/rik/rik/rik/rik*(20-8/rik/rik)*factor;

						}
					}
					if (yTeil[k]>0.01)  {
						yKraft[k]+=19.81;
					}
				}
			}
			for(int k=0; k< numberOfTeil; k++){//für jedes teilchen die neue geschwindigkeit und position
				double ax = xKraft[k]/100;//anhand von kraft ermitteln
				double ay = yKraft[k]/100;
				vxTeil[k]+= dt*ax;
				vyTeil[k]+= dt*ay;
				xTeil[k]+= dt*vxTeil[k];
				yTeil[k]+= dt*vyTeil[k];
				if (stepNumber % stepsPerFrame == 0) {//nicht jeden zeitschritt ein bild ausgeben, da sonst zu langsam
					window.buffer.setColor(Color.BLACK);
					window.buffer.fillOval((int)(xTeil[k]*10), (int)(yTeil[k]*10)+10, (int)durchmesserTeil, (int)durchmesserTeil);
				}
			}
			if (stepNumber % stepsPerFrame == 0) {//nicht jeden zeitschritt ein bild ausgeben, da sonst zu langsam
				window.clear();
			}
		}
	}


	
	//Gui stuff...
	@Override
	  public void paint( Graphics g )
	  {
		g.drawImage(image, 0, 0, null);
	  }
	public void draw(int x, int y) {

        buffer.setColor(Color.BLACK);
	    buffer.fillOval(x,y, 10, 10);
		
	}
	public void clear(){
		this.repaint();
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        buffer.setColor(Color.WHITE);
        buffer.clearRect(0, 0, image.getWidth(), image.getHeight());
        buffer.fillRect(0, 0, image.getWidth(), image.getHeight());
		
	}
	
//aus perfomance gründen überschreiben, da die view nicht "resetet" werden muss
    public void update(Graphics g)
    {
            paint(g);
    }


	
	
	
	
	
	
	

}
