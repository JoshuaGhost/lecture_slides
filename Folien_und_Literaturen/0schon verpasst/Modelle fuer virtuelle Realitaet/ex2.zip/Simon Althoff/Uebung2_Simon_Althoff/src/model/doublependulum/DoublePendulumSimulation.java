package model.doublependulum;

import output.Vector2D;
import model.pendulum.SpringPendulum;

public class DoublePendulumSimulation {

	private Vector2D origin;
	private Vector2D middle;
	private Vector2D end;
	
	private Vector2D velocityMiddle;
	private Vector2D velocityEnd;

	
	private SpringPendulum springMiddleToEnd;
	private SpringPendulum springOriginToMiddle;
	
	
	public static final double massEnd = 10;
	public static final double massMiddle = 1.0*massEnd;
	
	public static final double constantSpringMiddleToEnd = 50;
	public static final double constantSpringOriginToMiddle = 50;
	
	public static final double g = 9.81;
	
	
	public DoublePendulumSimulation(Vector2D origin, Vector2D middle, Vector2D end) {
		super();

		this.origin = origin;
		this.middle = middle;
		this.end = end;
		
		this.velocityMiddle = new Vector2D(0.0, 0.0);
		this.velocityEnd = new Vector2D(0.0, 0.0);
		
		this.springMiddleToEnd = new SpringPendulum(constantSpringOriginToMiddle, massMiddle, 0.0, 0.0 , middle.getDistanceToVector(end).getLength());
		this.springOriginToMiddle = new SpringPendulum(constantSpringOriginToMiddle, massMiddle, 0.0, 0.0, middle.getDistanceToVector(origin).getLength());
	}
	
	public void nextSimulationStep(double dt){
		//Gravity
		Vector2D gForceMiddle = 	new Vector2D(0.0, g*massMiddle);
		Vector2D gForceEnd    = 	new Vector2D(0.0, g*massEnd);
		
		//Spring forces
		//Spring 1
		Vector2D middleToOrigin = middle.getDistanceToVector(origin);
		Vector2D middleToOriginNormed = middleToOrigin.multiply(1.0 / middleToOrigin.getLength());
		
		springOriginToMiddle.updateElongation(middleToOrigin.getLength());
		Vector2D springForceMiddle = middleToOriginNormed.multiply(springOriginToMiddle.getForce());
		
		//Spring 2
		Vector2D endToMiddle = end.getDistanceToVector(middle);
		Vector2D endToMiddleNormed = endToMiddle.multiply(1.0 /endToMiddle.getLength());
		
		springMiddleToEnd.updateElongation(endToMiddle.getLength());
		Vector2D springForceEnd = endToMiddleNormed.multiply(springMiddleToEnd.getForce());
		
		Vector2D middleForce = Vector2D.add(gForceMiddle, springForceMiddle);
		Vector2D endForce = Vector2D.add(gForceEnd, springForceEnd);
		
		Vector2D accelerationMiddle = middleForce.multiply(1.0/massMiddle);
		Vector2D accelerationEnd = endForce.multiply(1.0/massEnd);
		
		this.velocityMiddle = Vector2D.add(this.velocityMiddle, accelerationMiddle.multiply(dt));
		this.velocityEnd = Vector2D.add(this.velocityEnd, accelerationEnd.multiply(dt));
		
		this.middle = Vector2D.add(this.middle, this.velocityMiddle.multiply(dt));
		this.end = Vector2D.add(this.end, this.velocityEnd.multiply(dt));
	}
	
	public Vector2D getOrigin(){
		return this.origin;
	}
	
	public Vector2D getMiddle(){
		return this.middle;
	}
	
	public Vector2D getEnd(){
		return this.end;
	}
	

	
}
