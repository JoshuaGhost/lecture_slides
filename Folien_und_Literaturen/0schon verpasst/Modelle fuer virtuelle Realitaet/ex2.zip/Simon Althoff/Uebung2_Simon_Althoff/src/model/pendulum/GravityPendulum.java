package model.pendulum;

public class GravityPendulum extends SpringPendulum{

	
	public GravityPendulum(double constant, double length, double mass,
			double xElongation, double velocity) {
		super(constant, mass, xElongation, velocity, length);
	}

	public double getYElongation(){
		return super.getLength() - Math.sqrt(super.getLength()*super.getLength()+super.getElongation()*super.getElongation());
	}
	
	public double getXElongation(){
		return super.getElongation();
	}
}
