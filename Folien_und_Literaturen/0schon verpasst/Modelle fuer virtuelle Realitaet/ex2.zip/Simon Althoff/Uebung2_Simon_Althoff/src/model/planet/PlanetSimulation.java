package model.planet;

import java.util.List;

import output.Vector2D;

public class PlanetSimulation {
	

	private List<Planet> planets;

	private double gravityConstant;
	
	public PlanetSimulation(List<Planet> pPlanets){
		this.planets = pPlanets;
		this.gravityConstant = 90.0;
	}
	
	public void nextSimulationStep(double dt){
		
		for(Planet targetPlanet : this.planets){
			
			Vector2D force = new Vector2D(0, 0);
			
			for(Planet sourcePlanet : this.planets){
				if(targetPlanet == sourcePlanet){
					continue;
				}
				
				force = Vector2D.add(force, this.getForce(sourcePlanet, targetPlanet));
			}

			
			Vector2D acceleration = force.multiply(1.0/targetPlanet.getMass());
			targetPlanet.setVelocity(Vector2D.add(targetPlanet.getVelocity(), acceleration.multiply(dt)));
			targetPlanet.setPosition(Vector2D.add(targetPlanet.getPosition(), targetPlanet.getVelocity().multiply(dt)));
		}
	}
	
	private Vector2D getForce(Planet target, Planet source){
		
		Vector2D distance = source.getPosition().getDistanceToVector(target.getPosition());
		double r = distance.getLength();
		
		Vector2D normedDistance = distance.multiply(1.0/r);
		
		
		double term = gravityConstant*source.getMass()*target.getMass()/(r*r);
		
		return normedDistance.multiply(term);
	}
	
}
