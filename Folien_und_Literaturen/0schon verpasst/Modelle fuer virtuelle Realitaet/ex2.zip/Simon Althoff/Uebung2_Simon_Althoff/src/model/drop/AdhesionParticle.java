package model.drop;

import output.Vector2D;

public class AdhesionParticle extends Particle {

	public AdhesionParticle(double x, double y, double mass) {
		super(x, y, mass);
	}
	
	@Override
	public Vector2D getForceOn(Particle other) {
		return super.getForceOn(other).multiply(1.75);
	}

	
}
