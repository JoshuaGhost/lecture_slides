package model.drop;

import output.Vector2D;

public class MovingParticle extends Particle {

	public MovingParticle(double x, double y, double mass) {
		super(x, y, mass);
	}
	

	

	@Override
	public void getNextPosition(Vector2D force, double dt){
		double ax = force.getX() / this.getMass();
		double newXVelocity = this.velocity.getX() + ax*dt;
		
		double ay = force.getY() / this.getMass();
		double newYVelocity = this.velocity.getY() + ay*dt;
		
		this.velocity = new Vector2D(newXVelocity, newYVelocity);
		
		double newXPos = this.position.getX() + this.velocity.getX()*dt;
		double newYPos = this.position.getY() + this.velocity.getY()*dt;		
		
		this.position = new Vector2D(newXPos, newYPos);
	}

}
