package model.planet;

import output.Vector2D;

public class Planet {
	
	private Vector2D position;
	private Vector2D velocity;
	
	private double mass;

	public Planet(Vector2D position, Vector2D velocity, double mass) {
		super();
		this.position = position;
		this.velocity = velocity;
		this.mass = mass;
	}



	public Vector2D getPosition() {
		return position;
	}



	public void setPosition(Vector2D position) {
		this.position = position;
	}



	public Vector2D getVelocity() {
		return velocity;
	}



	public void setVelocity(Vector2D velocity) {
		this.velocity = velocity;
	}



	public double getMass() {
		return mass;
	}
}
