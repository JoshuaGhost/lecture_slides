package model.drop;

import java.util.ArrayList;
import java.util.List;

import output.Vector2D;

public class DropSimulation {
	
	private double wallHeight;
	private List<Particle> particles;
	
	private Vector2D gravity = new Vector2D(0.0, 9.81 * 1.0);
	
	public DropSimulation(double wallHeight){
		this.wallHeight = wallHeight;
		
		this.particles = new ArrayList<Particle>();
	}
	
	public void distributeParticles(double radius, double distance){
		int xSteps = 2*(int)(radius/distance);
		
		double offSet = (radius - xSteps*distance/2); //Rundungsfehler
		
		for(int t = -xSteps; t < xSteps; t++){
			this.particles.add(new AdhesionParticle(t*distance, wallHeight, 1));
		}
		
		for(int i = 0; i < xSteps; i++){
			int ySteps = (int)(halfCircleFunction(offSet,i,distance,radius)/distance);
			for(int j = 1; j < ySteps; j++){
				this.particles.add(new MovingParticle(i*distance, wallHeight+j*distance, 1));
			}
		}
	}
	
	private double halfCircleFunction(double offset, int i, double distance, double radius){
		double xPos = -radius + offset + i*distance;
		return Math.sqrt(radius*radius-xPos*xPos);
	}
	
	public void nextSimulationStep(double dt){
		
		List<Vector2D> forces = new ArrayList<Vector2D>();
		
		for(int i = 0; i < particles.size(); i++){
			
			Vector2D force = new Vector2D(0, 0);
			
			for(int j = 0; j < particles.size(); j++){
				if(i == j){
					continue;
				}
				
				force = Vector2D.add(force, particles.get(j).getForceOn(particles.get(i)));
			}
			
			force = Vector2D.add(force,gravity);
			forces.add(force);
		}
		
		for(int k = 0; k < particles.size(); k++){
			particles.get(k).getNextPosition(forces.get(k), dt);
			
			if(particles.get(k).getPosition().getY() < wallHeight){
				particles.get(k).setY(wallHeight);
			}
		}
	}
	
	public List<Particle> getParticles(){
		return particles;
	}
	
	public double getWallHeight(){
		return wallHeight;
	}
}
