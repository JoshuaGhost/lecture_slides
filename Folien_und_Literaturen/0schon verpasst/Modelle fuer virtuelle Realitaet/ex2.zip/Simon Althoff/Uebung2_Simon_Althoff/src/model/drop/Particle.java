package model.drop;

import output.Vector2D;

public class Particle {
	Vector2D position;
	Vector2D velocity;
	
	private double mass;
	
	public Particle(double x, double y, double mass) {
		super();
		this.position = new Vector2D(x, y);
		this.velocity = new Vector2D(0, 0);
		this.mass = mass;
	}

	private double lennardJonesPotential(double r){
		return 20/Math.pow(r, 3) - 8/Math.pow(r, 5);
	}
	
	public Vector2D getForceOn(Particle other) {
		Vector2D distance = other.getPosition().getDistanceToVector(this.position);
		return distance.multiply(lennardJonesPotential(distance.getLength())).multiply(1/distance.getLength());
	}

	public Vector2D getPosition() {
		return new Vector2D(position);
	}



	public void setPosition(Vector2D position) {
		this.position = position;
	}



	public double getMass() {
		return mass;
	}



	public void setMass(double mass) {
		this.mass = mass;
	}
	
	public double getX(){
		return position.getX();
	}
	
	public double getY(){
		return position.getY();
	}
	
	public void setX(double x){
		this.position = new Vector2D(x, this.getY());
	}
	
	public void setY(double y){
		this.position = new Vector2D(this.getX(), y);
	}
	
	

	public Vector2D getVelocity() {
		return velocity;
	}



	public void setVelocity(Vector2D velocity) {
		this.velocity = velocity;
	}

	public void getNextPosition(Vector2D force, double dt){
		return;
	}
}
