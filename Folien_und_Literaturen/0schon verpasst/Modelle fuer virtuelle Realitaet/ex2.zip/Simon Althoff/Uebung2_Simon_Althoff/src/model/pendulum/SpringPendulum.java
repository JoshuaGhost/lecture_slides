package model.pendulum;

public class SpringPendulum {
	
	private double springConstant;
	private double mass;
	
	private double elongation;
	private double velocity;
	
	private double length;
	
	
	public SpringPendulum(double springConstant, double mass, double elongation, double velocity, double length ) {
		super();
		this.springConstant = springConstant;
		this.mass = mass;
		
		this.elongation = elongation;
		this.velocity = velocity;
		
		this.length = length;
		
	}

	public double getForce(){
		return elongation*springConstant;
	}
	
	public void simulateNextTimeStep(double dt){
		double a = -getForce() / this.mass;
		this.velocity += a*dt;
		this.elongation += this.velocity*dt;
	}
	

	public double getElongation() {
		return elongation;
	}

	public void setElongation(double elongation) {
		this.elongation = elongation;
	}

	public double getSpringConstant() {
		return springConstant;
	}

	public void setSpringConstant(double springConstant) {
		this.springConstant = springConstant;
	}

	public double getMass() {
		return mass;
	}

	public void setMass(double mass) {
		this.mass = mass;
	}

	public double getVelocity() {
		return velocity;
	}

	public void setVelocity(double velocity) {
		this.velocity = velocity;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}
	
	
	public void updateElongation(double currentLength){
		this.elongation = currentLength-this.length; 
	}
	
	
	
}
