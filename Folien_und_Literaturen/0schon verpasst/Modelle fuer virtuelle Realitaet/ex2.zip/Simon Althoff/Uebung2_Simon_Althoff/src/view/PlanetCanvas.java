package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.Timer;

import output.Vector2D;
import model.planet.Planet;
import model.planet.PlanetSimulation;

public class PlanetCanvas extends JPanel implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2495599601788319105L;
	
	private List<Planet> planets;
	
	private PlanetSimulation simulation;
	
	

	public PlanetCanvas(){
		this.setBackground(Color.WHITE);
		
		this.planets = new ArrayList<Planet>();
		planets.add(new Planet(new Vector2D(300.0, 150.0), new Vector2D(0.0, 0.0),250.0));
		planets.add(new Planet(new Vector2D(250.0, 250.0), new Vector2D(0.0, -10.0),20.0));
		this.simulation = new PlanetSimulation(planets);
		
		Timer timer = new Timer(10, this);
		timer.start();
	}
	
	public void addPlanet(Planet p){
		this.planets.add(p);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		for(Planet p : this.planets){
			int radius = (int)(5);
			int x = (int)p.getPosition().getX();
			int y = (int)p.getPosition().getY();
			g.fillOval(x-radius, y-radius, radius*2, radius*2);
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.simulation.nextSimulationStep(10*0.001);
		repaint();
	}
	
}
