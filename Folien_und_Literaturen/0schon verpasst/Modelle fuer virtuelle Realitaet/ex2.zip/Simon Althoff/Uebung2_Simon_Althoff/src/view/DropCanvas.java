package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JPanel;
import javax.swing.Timer;

import model.drop.DropSimulation;
import model.drop.Particle;

public class DropCanvas extends JPanel implements ActionListener{

	private static final long serialVersionUID = -5439005148803833645L;
	
	private DropSimulation dropSim;
	
	private double xInitial;
	private double yInitial;
	private double radius = 1.0;
	private double factor = 10.0;
	private int xOffset = 0;
	private int yOffset = 100;

	public DropCanvas(){
		this.setBackground(Color.WHITE);

		this.dropSim = new DropSimulation(100.0);
		this.dropSim.distributeParticles(10.0, 0.5);
		this.xInitial = (int)dropSim.getParticles().get(0).getX();
		this.yInitial = (int)dropSim.getParticles().get(0).getY();
		
		Timer timer = new Timer(1, this);
		timer.start();
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		dropSim.nextSimulationStep(2*0.001);
		repaint();
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		g.drawLine(0, (int)(dropSim.getWallHeight()),this.getWidth(), (int)dropSim.getWallHeight());
		
		if(dropSim.getParticles().isEmpty()){
			return;
		}
		

		
		for(Particle p : dropSim.getParticles()){
			paintParticle(g, p.getX()-xInitial ,p.getY()-yInitial);
		}

	}
	
	public void paintParticle(Graphics g, double x, double y){
		g.fillOval((int)(factor*x-radius) + xOffset, (int)(factor*y-radius) + yOffset, (int)(2*radius), (int)(2*radius));
	}

}
