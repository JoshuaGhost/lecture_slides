package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;

import output.Vector2D;
import model.doublependulum.DoublePendulumSimulation;

public class DoublePendulumCanvas extends JPanel implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5803369400240514633L;
	
	private DoublePendulumSimulation sim;

	public DoublePendulumCanvas(){
		this.setBackground(Color.WHITE);

		this.sim = new DoublePendulumSimulation(new Vector2D(0.0, 0.0), new Vector2D(100.0, 0.0), new Vector2D(200.0, 0.0));
		
		Timer timer = new Timer(1, this);
		timer.start();
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		sim.nextSimulationStep(10*0.001);
		repaint();
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		Vector2D origin = sim.getOrigin();
		Vector2D middle = sim.getMiddle();
		Vector2D end = sim.getEnd();
		
		int offsetX = 300;
		int offsetY = 150;
		
		g.fillOval(offsetX + (int)(origin.getX()-2.5),offsetY + (int)(origin.getY()-2.5), 5, 5);
		g.fillOval(offsetX + (int)(middle.getX()-2.5), offsetY +(int)(middle.getY()-2.5), 5, 5);
		g.fillOval(offsetX + (int)(end.getX()-2.5), offsetY +(int)(end.getY()-2.5), 5, 5);
		
		g.drawLine(offsetX + (int)origin.getX(),offsetY+ (int)origin.getY(),offsetX + (int)middle.getX(),offsetY+ (int)middle.getY());
		g.drawLine(offsetX +(int)middle.getX(), offsetY +(int)middle.getY(),offsetX + (int)end.getX(),offsetY+ (int)end.getY());
	}
}
