package view;

import java.awt.Graphics;

public class PendulumView {

	private double x;
	private double y;
	
	private double length;
	private double xElongation;
	private double massRadius;
	
	public PendulumView(double x, double y, double length, double initialXElongation, double massRadius) {
		super();
		this.x = x;
		this.y = y;
		this.length = length;
		this.xElongation = initialXElongation;
		this.massRadius = massRadius;
	}
	
	public void paint(Graphics g){
		double x2 = this.x + xElongation;
		double y2 = this.y + length + (length - Math.sqrt(length*length+xElongation*xElongation));
		g.drawLine((int)x, (int)y, (int)x2, (int)y2);
		g.fillOval((int)(x2-massRadius), (int)(y2-massRadius), (int)massRadius*2, (int)massRadius*2);
	}
	
	public void setXElongation(double x){
		this.xElongation = x;
	}
}
