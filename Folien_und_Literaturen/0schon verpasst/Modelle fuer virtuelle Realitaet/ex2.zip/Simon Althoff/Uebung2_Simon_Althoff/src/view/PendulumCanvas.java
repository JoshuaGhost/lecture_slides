package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JPanel;
import javax.swing.Timer;

import model.pendulum.GravityPendulum;

public class PendulumCanvas extends JPanel implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7184874670810594768L;
	
	private PendulumView pendulumView;
	private GravityPendulum modelPendulum;

	public PendulumCanvas(){
		this.setBackground(Color.WHITE);

		pendulumView = new PendulumView(300, 50, 50, 0.5*Math.PI, 5);
		modelPendulum = new GravityPendulum(500, 50, 10, 50, 0.05);
		
		Timer timer = new Timer(10, this);
		timer.start();
	}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		modelPendulum.simulateNextTimeStep(10*0.001);
		pendulumView.setXElongation(modelPendulum.getElongation());
		repaint();
		
		
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		pendulumView.paint(g);
	}
}
