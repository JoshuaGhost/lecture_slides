package run;

import javax.swing.JFrame;
import javax.swing.JPanel;

import view.PendulumCanvas;


public class Aufgabe2_1 extends JPanel{
    /**
	 * 
	 */
	private static final long serialVersionUID = 8476374719343090779L;
	
	public Aufgabe2_1(){
		this.setBounds(0,0,600,800);
		this.setLayout(null);
		JPanel canvas = new PendulumCanvas();
		canvas.setBounds(0, 0, 600, 800);
		this.add(canvas);
	}

	public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	JFrame frame = new JFrame("Pendel");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
                
                //Create and set up the content pane.
                frame.setContentPane(new Aufgabe2_1());
                frame.setSize(600, 400);
                //Display the window.
                //frame.pack();
                frame.setVisible(true);
            }
        });
    }
}

