package output;

public class Vector2D {
	private double x;
	private double y;
	
	public Vector2D(double px, double py){
		this.x = px;
		this.y = py;
	}
	
	public Vector2D(Vector2D other){
		this.x = other.x;
		this.y = other.y;
	}
	
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	
	public static Vector2D add(Vector2D a, Vector2D b){
		return new Vector2D(a.getX()+b.getX(), a.getY()+b.getY());
	}
	
	public Vector2D getDistanceToVector(Vector2D other){
		return new Vector2D(other.x - this.x, other.y - this.y);
	}
	
	public double getLength(){
		return Math.sqrt(x*x+y*y);
	}
	
	public Vector2D multiply(double factor){
		return new Vector2D(factor*x, factor*y);
	}
	
	@Override 
	public String toString(){
		return x + ", " + y;
	}
}
