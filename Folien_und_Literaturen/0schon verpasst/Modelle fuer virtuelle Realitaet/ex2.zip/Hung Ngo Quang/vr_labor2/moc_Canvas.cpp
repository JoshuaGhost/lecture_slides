/****************************************************************************
** Meta object code from reading C++ file 'Canvas.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "Canvas.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Canvas.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Canvas[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x0a,
      15,    7,    7,    7, 0x0a,
      30,    7,    7,    7, 0x0a,
      52,    7,    7,    7, 0x0a,
      68,    7,    7,    7, 0x0a,
      78,    7,    7,    7, 0x0a,
      91,    7,    7,    7, 0x0a,
     112,    7,    7,    7, 0x0a,
     143,  130,    7,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Canvas[] = {
    "Canvas\0\0draw()\0drawPendulum()\0"
    "drawPlanetarySystem()\0simulateAStep()\0"
    "animate()\0drawLiquid()\0drawDoublePendulum()\0"
    "startSimulation()\0newSelection\0"
    "setSelection(QString)\0"
};

void Canvas::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Canvas *_t = static_cast<Canvas *>(_o);
        switch (_id) {
        case 0: _t->draw(); break;
        case 1: _t->drawPendulum(); break;
        case 2: _t->drawPlanetarySystem(); break;
        case 3: _t->simulateAStep(); break;
        case 4: _t->animate(); break;
        case 5: _t->drawLiquid(); break;
        case 6: _t->drawDoublePendulum(); break;
        case 7: _t->startSimulation(); break;
        case 8: _t->setSelection((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Canvas::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Canvas::staticMetaObject = {
    { &QGLViewer::staticMetaObject, qt_meta_stringdata_Canvas,
      qt_meta_data_Canvas, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Canvas::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Canvas::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Canvas::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Canvas))
        return static_cast<void*>(const_cast< Canvas*>(this));
    return QGLViewer::qt_metacast(_clname);
}

int Canvas::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLViewer::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
