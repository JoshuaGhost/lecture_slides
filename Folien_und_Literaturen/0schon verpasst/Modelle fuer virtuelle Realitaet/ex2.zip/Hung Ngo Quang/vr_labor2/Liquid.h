#ifndef LIQUID_H
#define LIQUID_H
#include <vector>
#include <math.h>
#include <iostream>


class Liquid{

private:

    std::vector<std::vector<double> > particlesCeiling;
    std::vector<std::vector<double> > particles;
    std::vector<std::vector<double> >velocities;
    std::vector<double> gravity;
    double dt;
    double mass;

public:

    Liquid(double dt){
        for(double i=0;i<20;i++){
            for(double j=0;j<2;j++){
                std::vector<double> position;
                position.push_back(i/100);
                position.push_back(-j/100);
                particlesCeiling.push_back(position);
            }
        }
        for(double i=0;i<20;i++){
            for(double j=0;j<10;j++){
                std::vector<double> position;
                if(i>(0+(0.1)*pow(j,2)) && i<(20-(0.1*pow(j,2)))){
                    position.push_back(i/100);
                    position.push_back(-((j/100)+(2.1/100)));
                    particles.push_back(position);
                    std::vector<double > startingVelocity;
                    startingVelocity.push_back(0.0);
                    startingVelocity.push_back(0.0);
                    velocities.push_back(startingVelocity);
}
            }
        }
        gravity.push_back(0.0);
        gravity.push_back(-2.807);
        this->dt=dt;
        mass=2,9916*pow(10,-26);
    }


    std::vector<double> computateAcceleration(int particle){
        std::vector<double> force;
        std::vector<double> acceleration;

        std::vector<double> particlePosition=particles[particle];
        force.push_back(0.0);
        force.push_back(0.0);
        acceleration.push_back(0.0);
        acceleration.push_back(0.0);
        for(int i=0;i<particlesCeiling.size();i++){
            std::vector<double> distance=sub(particlesCeiling[i],particlePosition);
            double r=length(sub(particlePosition,particlesCeiling[i]))*35;
            double lennardJonesPotential =((20/pow(r,3))-(8/pow(r,5)));
            force=add(force,mult((mult(mult(distance,(1/r)),lennardJonesPotential)),1.75));
        }
        for(int i=0;i<particles.size();i++){
            if(i!=particle){
                std::vector<double> distance=sub(particles[i],particlePosition);
                double r=length(sub(particlePosition,particles[i]))*100;
                double lennardJonesPotential =((20/pow(r,3))-(8/pow(r,5)));
                force=add(force,(mult(mult(distance,(1/r)),lennardJonesPotential)));
            }
        }


        acceleration=add(acceleration,mult(force,1/mass));
        acceleration=add(acceleration,gravity);
        return acceleration;
    }

    std:: vector<double> mult(std::vector<double> a, double c){
        std::vector<double> result;
        for(int i=0; i<a.size(); i++){
            result.push_back(a[i]*c);
        }
        return result;
    }

    std:: vector <double> add(std::vector<double> a, std::vector<double> b){
        std::vector<double> result;
        if(a.size()==b.size()){
            for(int i=0; i<a.size(); i++){
                result.push_back(a[i]+b[i]);
            }
            return result;
        }
    }
    std:: vector <double> sub(std::vector<double> a, std::vector<double> b){
        std::vector<double> result;
        if(a.size()==b.size()){
            for(int i=0; i<a.size(); i++){
                result.push_back(a[i]-b[i]);
            }
            return result;
        }
    }

    double length(std::vector<double> vector){
        double lsg=0;
        for(int i=0;i<vector.size();i++){
            lsg=lsg+pow(vector[i],2);
        }
        return sqrt(lsg);
    }

    void simulateStep(){
        for(int i=0;i<velocities.size();i++){
             velocities[i] = add(velocities[i], mult(computateAcceleration(i),dt));
        }
        for(int i=0;i<particles.size();i++){
            particles[i]=add(particles[i],mult(velocities[i],dt));
        }
    }

    std::vector<std::vector<double> > getParticlesCeiling(){
        return particlesCeiling;
    }

    std::vector<std::vector<double> > getParticles(){
        return particles;
    }


};

#endif // LIQUID_H
