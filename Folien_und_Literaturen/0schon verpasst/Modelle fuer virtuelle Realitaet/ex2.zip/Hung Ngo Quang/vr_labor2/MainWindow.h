#ifndef MAIN_WINDOW_H_INCLUDED
#define MAIN_WINDOW_H_INCLUDED 1

#include <QMainWindow>
#include <QtGui>
#include "ui_mainwindow.h"
#include "Canvas.h"

class Canvas;

class MainWindow: public QMainWindow
{
    Q_OBJECT
private:

    Canvas *canvas;
    Ui::MainWindow *ui;


public:
    MainWindow(QWidget *parent = 0, Qt::WindowFlags flags = 0);
    virtual ~MainWindow() {           delete ui;         }

private Q_SLOTS:

};



#endif
