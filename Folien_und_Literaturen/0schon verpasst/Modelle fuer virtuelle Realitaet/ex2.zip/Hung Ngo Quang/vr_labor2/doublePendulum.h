#ifndef DOUBLEPENDULUM_H
#define DOUBLEPENDULUM_H
#include <vector>

class doublePendulum{

private:
    std::vector<double> fixPoint, firstPendulum, secondPendulum, velocity1, velocity2;
    double dt;
    double mass;
    double k;
    double damping;


public:
    doublePendulum(double dt,double k, double mass){
        fixPoint.push_back(0);
        fixPoint.push_back(0);
        fixPoint.push_back(0);
        firstPendulum.push_back(-2);
        firstPendulum.push_back(0);
        firstPendulum.push_back(0);
        secondPendulum.push_back(-2);
        secondPendulum.push_back(-2);
        secondPendulum.push_back(0);
        this->dt=dt;
        this->mass=mass;
        this->k=k;
        velocity1.push_back(0);
        velocity1.push_back(0);
        velocity1.push_back(0);
        velocity2.push_back(0);
        velocity2.push_back(0);
        velocity2.push_back(0);
        damping=0.0;

    }

    std::vector<double> getAcceleration(int pendulum){
        std::vector<double> force;
        force.push_back(0);
        force.push_back(0);
        force.push_back(0);
        std::vector<double> acceleration;
        if(pendulum==0){
            std::vector<double> distance=sub(fixPoint,firstPendulum);
            double dlength=length(distance);
            force=mult(mult(distance,1/dlength),(k*dlength/mass));
            acceleration=add(mult(force,(1/mass)),getAcceleration(1));

        }else{
            std::vector<double> distance=sub(firstPendulum, secondPendulum);
            double dlength=length(distance);
            force=mult(mult(distance,1/dlength),(k*dlength/mass));
            std::vector<double> gravity;
            gravity.push_back(0);
            gravity.push_back(-9.807);
            gravity.push_back(0);
            acceleration=add(mult(force,(1/mass)),gravity);
        }
        return acceleration;
    }

    std:: vector<double> mult(std::vector<double> a, double c){
        std::vector<double> result;
        for(int i=0; i<a.size(); i++){
            result.push_back(a[i]*c);
        }
        return result;
    }

    std:: vector <double> add(std::vector<double> a, std::vector<double> b){
        std::vector<double> result;
        if(a.size()==b.size()){
            for(int i=0; i<a.size(); i++){
                result.push_back(a[i]+b[i]);
            }
            return result;
        }
    }
    std:: vector <double> sub(std::vector<double> a, std::vector<double> b){
        std::vector<double> result;
        if(a.size()==b.size()){
            for(int i=0; i<a.size(); i++){
                result.push_back(a[i]-b[i]);
            }
            return result;
        }
    }

    double length(std::vector<double> vector){
        double lsg=0;
        for(int i=0;i<vector.size();i++){
            lsg=lsg+pow(vector[i],2);
        }
        return sqrt(lsg);
    }

    void simulateStep(){
        velocity1=add(mult(velocity1,(1-damping)),mult(getAcceleration(0),dt));
        velocity2=add(mult(velocity2,(1-damping)),mult(getAcceleration(1),dt));
        firstPendulum=add(firstPendulum,mult(velocity1,dt));
        secondPendulum=add(secondPendulum,mult(velocity2,dt));
    }

    std::vector<double> getFirstPendulumPosition(){
        return firstPendulum;
    }

    std::vector<double> getSecondPendulumPosition(){
        return secondPendulum;
    }
};

#endif // DOUBLEPENDULUM_H
