#ifndef SPRINGPENDULUM_H
#define SPRINGPENDULUM_H

class SpringPendulum{
private:

    float k;
    float m;
    float velocity;
    float position;
    float dt;
    float damping;

public:

    SpringPendulum(float k, float m, float dt){
        this->k=k;
        this->m=m;
        this->dt=dt;
        position=0;
        velocity=0;
        damping=0.001;
    }

    float getAcceleration(){
        float lsg=(-k *position/m);
        lsg=lsg-9.807;
        return lsg;
    }


    void simulateStep(){
        velocity=velocity*(1-damping)+getAcceleration()*dt;
        position=position+velocity*dt;
    }

    float getPosition(){
        return position;
    }
    float getVelocity(){
        return velocity;
    }

    float getK(){
        return k;
    }

    float getDt(){
        return dt;
    }

    float getM(){
        return m;
    }

};

#endif // SPRINGPENDULUM_H
