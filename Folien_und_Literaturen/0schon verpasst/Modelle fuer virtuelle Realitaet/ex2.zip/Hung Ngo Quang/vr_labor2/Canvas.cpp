#include "Canvas.h"
#include <cmath>
#include <math.h>
#include <iostream>

Canvas::Canvas(QWidget *parent) : QGLViewer(parent){
    camera()->setSceneRadius(10);

}
void Canvas::draw(){

     if(selection=="Federpendel"){
        drawPendulum();
     }else if(selection=="Planetensystem"){
         drawPlanetarySystem();
     }else if(selection=="Wassertropfen"){
         drawLiquid();
     }
     else if(selection=="Doppelpendel"){
         drawDoublePendulum();
     }
}

void Canvas::drawPendulum(){
    glBegin(GL_LINE_STRIP);
    for (float i=-200; i<200; i++){
        for(float j=0;j<200;j++){

            float ratio=1.0/200.0;
            glColor3f(1.0, 0, 0);
            glVertex3f(ratio*i, springpendulum.getPosition()-j*ratio, -10);


        }
    }
    glEnd();
    glBegin(GL_LINE_STRIP);
    for (float i=-10; i<10; i++){
        double ratio=1/200;
        glVertex3f(ratio*i, 0, -10);
        glVertex3f(ratio*i, springpendulum.getPosition(), -10);
    }

    glEnd();
}

void Canvas::drawPlanetarySystem(){
    for(int i=0;i<planetarySystem.getPlanets().size();i++){
        glBegin(GL_POINTS);
        for(float j=0;j<50;j++){
            double stepU=(j/50)*M_PI;
            for (float k=0;k<50;k++){
                double stepV=(k/50)*2*M_PI;
                glColor3f(1.0, 0, 0);
                glVertex3f(0.5*sin(stepU)*cos(stepV)+planetarySystem.getPlanets()[i][0],
                        0.5*sin(stepU)*sin(stepV)+planetarySystem.getPlanets()[i][1],
                        0.5*cos(stepU)+planetarySystem.getPlanets()[i][2]-10);
            }
        }
    }

    glEnd();
}

void Canvas::drawDoublePendulum(){
    glBegin(GL_POINTS);
    for(float j=0;j<50;j++){
        double stepU=(j/50)*M_PI;
        for (float k=0;k<50;k++){
            double stepV=(k/50)*2*M_PI;
            glColor3f(1.0, 0, 0);
            glVertex3f(0.1*sin(stepU)*cos(stepV)+doubleP.getFirstPendulumPosition()[0],
                    0.1*sin(stepU)*sin(stepV)+doubleP.getFirstPendulumPosition()[1],
                    0.1*cos(stepU)+doubleP.getFirstPendulumPosition()[2]-10);
        }
    }
    for(float j=0;j<50;j++){
        double stepU=(j/50)*M_PI;
        for (float k=0;k<50;k++){
            double stepV=(k/50)*2*M_PI;
            glColor3f(1.0, 0, 0);
            glVertex3f(0.1*sin(stepU)*cos(stepV)+doubleP.getSecondPendulumPosition()[0],
                    0.1*sin(stepU)*sin(stepV)+doubleP.getSecondPendulumPosition()[1],
                    0.1*cos(stepU)+doubleP.getSecondPendulumPosition()[2]-10);
        }
    }
    for(float j=0;j<50;j++){
        double stepU=(j/50)*M_PI;
        for (float k=0;k<50;k++){
            double stepV=(k/50)*2*M_PI;
            glColor3f(1.0, 0, 0);
            glVertex3f(0.1*sin(stepU)*cos(stepV),
                    0.1*sin(stepU)*sin(stepV),
                    0.1*cos(stepU)-10);
        }
    }

    glEnd();
}


void Canvas::drawLiquid(){
    glBegin(GL_POINTS);
    std::vector<std::vector<double> > particlesCeiling=liquid.getParticlesCeiling();
    std::vector<std::vector<double> > particles=liquid.getParticles();
    for(int i=0;i<particlesCeiling.size();i++){
                glColor3f(1, 0, 1);
                glVertex3f(particlesCeiling[i][0],particlesCeiling[i][1],
                        0);
    }
    for(int i=0;i<particles.size();i++){
                glColor3f(0, 0, 1);
                glVertex3f(particles[i][0],particles[i][1],
                        0);
    }
    glEnd();
}

void Canvas::setSelection(QString newSelection){
            selection = newSelection;
            updateGL();
}

void Canvas::animate(){
    simulateAStep();
}

void Canvas::simulateAStep(){
    if(selection=="Federpendel"){
        springpendulum.simulateStep();
    }else if(selection=="Planetensystem"){
        planetarySystem.simulateStep();
    }
    else if(selection=="Wassertropfen"){
            liquid.simulateStep();
    }else if(selection=="Doppelpendel"){
        doubleP.simulateStep();
    }

}

void Canvas::startSimulation(){
    if(!animationRunning){
        startAnimation();
        animationRunning=true;
    }else{
        stopAnimation();
        animationRunning=false;
    }

}


