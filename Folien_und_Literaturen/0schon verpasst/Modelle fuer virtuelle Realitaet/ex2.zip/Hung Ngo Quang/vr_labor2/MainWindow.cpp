#include "MainWindow.h"
#include "Canvas.h"


#include <iostream>
using std::cerr;
using namespace std;

MainWindow::MainWindow(QWidget *parent, Qt::WindowFlags flags)
    : QMainWindow(parent, flags),
      ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    canvas=ui->central;


    ui->comboBox->addItem("Federpendel");
    ui->comboBox->addItem("Doppelpendel");
    ui->comboBox->addItem("Planetensystem");
    ui->comboBox->addItem("Wassertropfen");


    connect(ui->comboBox, SIGNAL(currentIndexChanged(QString)), canvas, SLOT(setSelection(QString)));
    connect(ui->simulateStep_button, SIGNAL(clicked()), canvas, SLOT(startSimulation()));

}


