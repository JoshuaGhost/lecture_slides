
#include "fluidsimulation.h"

#define DEFAULT_NUMBER_OF_PARTICLES 300
#define DEFAULT_NUMBER_OF_FIXED_PARTICLES 20
#define DEFAULT_RADIUS 5.0
#define DEFAULT_GRAVITY 9.8

FluidSimulation::FluidSimulation(qreal timestep, QObject *parent)
    : QGraphicsScene(parent),
      m_particleGrid(new ParticleGrid(DEFAULT_NUMBER_OF_PARTICLES, DEFAULT_NUMBER_OF_FIXED_PARTICLES, DEFAULT_RADIUS, DEFAULT_GRAVITY, timestep))
{
    addItem(m_particleGrid);
}

FluidSimulation::~FluidSimulation()
{
    delete m_particleGrid;
}

QRectF FluidSimulation::sceneRect() const
{
    return m_particleGrid->boundingRect();
}

void FluidSimulation::reset()
{
    m_particleGrid->reset();
}

void FluidSimulation::advance()
{
    m_particleGrid->advance(1);
}

