#ifndef PARTICLEGRID_H
#define PARTICLEGRID_H

#include <QGraphicsItem>
#include <QVector2D>
#include <QVector>

class ParticleGrid : public QGraphicsItem {
public:
    ParticleGrid(int numberOfParticles, int numberOfFixedParticles,
                 qreal radius, qreal gravity,
                 qreal m_timestep);

    virtual QRectF boundingRect() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = 0);

    virtual void advance(int phase);
    void reset();

    void setNumberOfParticles(int particles);
    void setNumberOfFixedParticles(int particles);
    void setRadius(qreal radius);
    void setGravity(qreal gravity);

    int numberOfParticles() const { return m_numberOfParticles; }
    int realNumberOfParticles() const { return m_realNumberOfParticles; }
    int numberOfFixedParticles() const { return m_numberOfFixedParticles; }
    qreal radius() const { return m_radius; }
    qreal gravity() const { return m_gravity; }

private:
    void createParticles();

    int m_numberOfParticles;
    int m_realNumberOfParticles;
    int m_numberOfFixedParticles;
    qreal m_radius;
    qreal m_gravity;
    qreal m_mass; // Mass of a particle
    qreal m_timestep;

    QVector<QPointF> m_fixedParticles;
    QVector<QPointF> m_particles;
    QVector<QVector2D> m_particlesForce;
    QVector<QVector2D> m_particlesVelocity;
};

#endif // PARTICLEGRID_H
