#include <QLabel>

#include "task5controller.h"
#include "fluidsimulation.h"

Task5Controller::Task5Controller(Ui::MainWindow *ui, QObject *parent)
    : TaskController(ui->task5StartStopButton, ui->task5ResetButton,
                     ui->task5GraphicsView, parent),
      m_numberOfParticlesField(ui->task5NumberOfParticlesField),
      m_numberOfFixedParticlesField(ui->task5NumberOfFixedParticlesField),
      m_radiusField(ui->task5RadiusField),
      m_gravityField(ui->task5GravityField),
      m_realNumberOfParticlesLabel(ui->task5RealNumberOfParticlesLabel),
      m_fluidSimulation(new FluidSimulation(TIMESTEP / 1000, this))
{
    m_graphicsView->setScene(m_fluidSimulation);
    m_graphicsView->setRenderHint(QPainter::Qt4CompatiblePainting);

    connect(m_numberOfParticlesField, SIGNAL(returnPressed()), this, SLOT(numberOfParticlesFieldChanged()));
    connect(m_numberOfFixedParticlesField, SIGNAL(returnPressed()), this, SLOT(numberOfFixedParticlesFieldChanged()));
    connect(m_radiusField, SIGNAL(returnPressed()), this, SLOT(radiusFieldChanged()));
    connect(m_gravityField, SIGNAL(returnPressed()), this, SLOT(gravityFieldChanged()));

    updateTextFields();
}

void Task5Controller::reset()
{
    m_fluidSimulation->reset();
    updateTextFields();
}

void Task5Controller::updateTextFields()
{
    setTextFieldToNumber(m_numberOfParticlesField, m_fluidSimulation->numberOfParticles());
    setTextFieldToNumber(m_numberOfFixedParticlesField, m_fluidSimulation->numberOfFixedParticles());
    setTextFieldToNumber(m_radiusField, m_fluidSimulation->radius());
    setTextFieldToNumber(m_gravityField, m_fluidSimulation->gravity());

    QString number;
    number.setNum(m_fluidSimulation->realNumberOfParticles());
    m_realNumberOfParticlesLabel->setText(number);
}

void Task5Controller::handleResize()
{
    m_graphicsView->setSceneRect(m_fluidSimulation->sceneRect());
    m_graphicsView->fitInView(m_fluidSimulation->sceneRect(), Qt::KeepAspectRatio);
}

void Task5Controller::advance()
{
    m_fluidSimulation->advance();
}

/***** Callbacks *****/

void Task5Controller::numberOfParticlesFieldChanged()
{
    int value = m_numberOfParticlesField->text().toInt();
    m_fluidSimulation->setNumberOfParticles(value);

    updateTextFields(); // for real number of particles label
}

void Task5Controller::numberOfFixedParticlesFieldChanged()
{
    int value = m_numberOfFixedParticlesField->text().toInt();
    m_fluidSimulation->setNumberOfFixedParticles(value);
}

void Task5Controller::radiusFieldChanged()
{
    double value = m_radiusField->text().toDouble();
    m_fluidSimulation->setRadius(value);
    handleResize();
}

void Task5Controller::gravityFieldChanged()
{
    double value = m_gravityField->text().toDouble();
    m_fluidSimulation->setGravity(value);
}
