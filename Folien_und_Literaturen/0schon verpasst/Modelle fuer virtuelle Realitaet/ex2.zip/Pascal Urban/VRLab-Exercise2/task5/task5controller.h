#ifndef TASK5CONTROLLER_H
#define TASK5CONTROLLER_H

#include "common/taskcontroller.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"

class FluidSimulation;
class QLineEdit;
class QLabel;

class Task5Controller : public TaskController
{
    Q_OBJECT
public:
    Task5Controller(Ui::MainWindow *ui, QObject *parent = 0);

public slots:
    virtual void reset();

protected:
    virtual void handleResize();

protected slots:
    virtual void advance();

private slots:
    void numberOfParticlesFieldChanged();
    void numberOfFixedParticlesFieldChanged();
    void radiusFieldChanged();
    void gravityFieldChanged();

private:
    void updateTextFields();

    QLineEdit *m_numberOfParticlesField;
    QLineEdit *m_numberOfFixedParticlesField;
    QLineEdit *m_radiusField;
    QLineEdit *m_gravityField;
    QLabel *m_realNumberOfParticlesLabel;

    FluidSimulation *m_fluidSimulation;
};

#endif // TASK5CONTROLLER_H
