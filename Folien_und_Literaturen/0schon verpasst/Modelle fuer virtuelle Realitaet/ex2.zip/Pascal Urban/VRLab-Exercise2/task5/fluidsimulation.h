#ifndef FLUIDSIMULATION_H
#define FLUIDSIMULATION_H

#include <QGraphicsScene>

#include "particlegrid.h"

class FluidSimulation : public QGraphicsScene
{
public:
    FluidSimulation(qreal timestep, QObject *parent = 0);
    ~FluidSimulation();

    virtual QRectF sceneRect() const;

    virtual void advance();
    void reset();

    int numberOfParticles() const { return m_particleGrid->numberOfParticles(); }
    int numberOfFixedParticles() const { return m_particleGrid->numberOfFixedParticles(); }
    int realNumberOfParticles() const { return m_particleGrid->realNumberOfParticles(); }
    qreal radius() const { return m_particleGrid->radius(); }
    qreal gravity() const { return m_particleGrid->gravity(); }

    void setNumberOfParticles(int particles) { m_particleGrid->setNumberOfParticles(particles); }
    void setNumberOfFixedParticles(int particles) { m_particleGrid->setNumberOfFixedParticles(particles); }
    void setRadius(qreal radius) { m_particleGrid->setRadius(radius); }
    void setGravity(qreal gravity) { m_particleGrid->setGravity(gravity); }

private:
    ParticleGrid *m_particleGrid;
};

#endif // FLUIDSIMULATION_H
