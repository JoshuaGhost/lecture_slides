#include <cmath>
#include <QPainter>
#include <QStyleOptionGraphicsItem>

#include "particlegrid.h"

ParticleGrid::ParticleGrid(int numberOfParticles, int numberOfFixedParticles,
                           qreal radius, qreal gravity,
                           qreal timestep)
    : m_numberOfParticles(numberOfParticles),
      m_numberOfFixedParticles(numberOfFixedParticles),
      m_radius(radius),
      m_gravity(gravity),
      m_timestep(timestep)

{
    createParticles();
}

QRectF ParticleGrid::boundingRect() const
{
    return QRectF(-m_radius*3, -m_radius*0.1, m_radius*6, m_radius*6);
}

void ParticleGrid::advance(int phase)
{
    (void)phase; // ignore the phase. method is not called by QGraphicsScene but directly in FluidSimulation

    QVector2D particle_i;
    QVector2D particle_j;
    QVector2D topParticle;
    QVector2D directionVector;
    QVector2D acceleration;

    qreal distance = 0;
    qreal distancePower2 = 0;
    qreal distancePower4 = 0;
    qreal distancePower6 = 0;

    for (int i = 0; i < m_realNumberOfParticles; ++i) {
        particle_i = QVector2D(m_particles[i]);
        QVector2D &force_i = m_particlesForce[i];

        // Both particles exert the same force on each other, just in
        // different directions. Therefore some iterations can be spared
        // by starting the second loop at the particle after i if the
        // force is added to particle i and subtracted from particle j
        for (int j = i+1; j < m_realNumberOfParticles; ++j) {
            particle_j = QVector2D(m_particles[j]);
            directionVector = (particle_j - particle_i);
            distance = directionVector.length();

            distancePower2 = distance * distance;
            distancePower4 = distancePower2 * distancePower2;
            distancePower6 = distancePower4 * distancePower2;

            force_i += (20 / distancePower4 - 8 / distancePower6) * directionVector;
            m_particlesForce[j] -= (20 / distancePower4 - 8 / distancePower6) * directionVector;
        }

        // Calcalute the forces of the fixed particles at the top
        for (int j = 0; j < m_numberOfFixedParticles; ++j) {
            topParticle = QVector2D(m_fixedParticles[j]);

            directionVector = (topParticle - particle_i);
            distance = directionVector.length();

            distancePower2 = distance * distance;
            distancePower4 = distancePower2 * distancePower2;
            distancePower6 = distancePower4 * distancePower2;

            force_i += 1.75 * (20 / distancePower4  - 8 / distancePower6) * directionVector;
        }

        force_i[1] += m_gravity;

        // Calculate the new velocity and position
        acceleration = force_i / m_mass;
        m_particlesVelocity[i] += acceleration * m_timestep;
        m_particles[i].rx() += m_particlesVelocity[i][0] * m_timestep;
        m_particles[i].ry() += m_particlesVelocity[i][1] * m_timestep;

        // Clear the forces for the next run.
        m_particlesForce[i][0] = 0.0;
        m_particlesForce[i][1] = 0.0;
    }

    update();
}

void ParticleGrid::reset()
{
    createParticles();
    update();
}

void ParticleGrid::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    (void)option, (void)widget;

    QPen pen(painter->pen());
    pen.setCosmetic(true);

//    pen.setWidth(1);
//    pen.setColor(Qt::blue);
//    painter->setPen(pen);
//    QRectF rect(-m_radius, -m_radius, m_radius*2, m_radius*2);
//    painter->drawRect(rect);

    pen.setWidth(4);
    pen.setColor(Qt::red);
    painter->setPen(pen);
    painter->drawPoints(m_fixedParticles.data(), m_fixedParticles.size());

    pen.setColor(Qt::black);
    painter->setPen(pen);
    painter->drawPoints(m_particles.data(), m_particles.size());
}

void ParticleGrid::createParticles()
{
    /*
     * Approximation of the grid spacing d under the condition that
     * N particles have to be inside the half-circle with a radius r.
     *
     * The area of the half circle is: Ahc = 1/2 * PI * r^2
     * The area of it's enclosing rectangle is: Ar= 1/2*(2*r)^2
     *
     * The ratio of the areas of the circle and rectangle should be
     * approximatively equal to the ratio of points inside the circle (N)
     * and points inside the rectangle (Nr).
     *
     * Ar / Ahc = Nr / N
     * => Nr = Ar / Ahc * N
     * => Nr = (1/2 * 4 * r^2) / (1/2 * PI * r^2) * N
     * => Nr = 4 / PI * N
     *
     * With this approximation of points inside the rectangle the following
     * can be solved:
     * Given the number of points inside the rectangle Nr and the grid space
     * d the area of the rectangle (in this case: one half of the rectangle)
     * can be calculated with:
     *
     * Ar = Nr * d^2
     * => d = sqrt(Ar / Nr)
     * => d = sqrt((2 * r^2) / (4/PI * N))
     * => d = sqrt(PI * r^2 / (2N))
     *
     * The real points can than be calculated by starting at point
     * (-r + d / 2.0, d / 2.0), the center of the first square created by
     * the grid, and incrementing those coordinates by d.
     * For each point inside the half-circle the circle equation
     * x^2 + y^2 < r^2 must hold.
     *
     *
     * The problem however is that there are sometimes not exactly
     * N particles inside the half-circle.
     */

    m_particles.clear();
    m_particles.reserve(m_numberOfParticles);

    qreal radiusSquared = m_radius * m_radius;
    qreal distance = std::sqrt(M_PI * radiusSquared / (2.0 * m_numberOfParticles));

    m_realNumberOfParticles = 0;
    for (qreal y = distance / 2.0; y < m_radius; y += distance) {
        for (qreal x = -m_radius + distance / 2.0; x < m_radius; x += distance) {
            if (x*x  + y*y < radiusSquared) {
                m_realNumberOfParticles++;
                m_particles.append(QPointF(x, y));
            }
        }
    }

    m_particlesForce.clear();
    m_particlesForce.resize(m_realNumberOfParticles);

    m_particlesVelocity.clear();
    m_particlesVelocity.resize(m_realNumberOfParticles);

    // Create the particles at the top
    m_fixedParticles.clear();
    m_fixedParticles.reserve(m_numberOfFixedParticles);
    qreal distanceTop = 2 * m_radius / m_numberOfFixedParticles;
    for (qreal x = -m_radius; x <= m_radius; x += distanceTop) {
        m_fixedParticles.append(QPointF(x, -distance/2.0));
    }

    /* Update the mass of a particle */

    // Water has a density of 1000 kg/m^3, volume of a half-sphere is 1/2 * 4/3 *PI * r^3
    m_mass = (1000.0 * 2.0 / 3.0 * M_PI * std::pow(m_radius, 3)) / m_realNumberOfParticles;
    m_mass /= 15.0; // Seems to provide better results for the simulation
}

void ParticleGrid::setNumberOfParticles(int particles)
{
    m_numberOfParticles = particles;
    reset();
}

void ParticleGrid::setNumberOfFixedParticles(int particles)
{
    m_numberOfFixedParticles = particles;
    reset();
}

void ParticleGrid::setRadius(qreal radius)
{
    m_radius = radius;
    reset();
}

void ParticleGrid::setGravity(qreal gravity)
{
    m_gravity = gravity;
    reset();
}

