#include <cmath>
#include <QGraphicsLineItem>
#include <QGraphicsEllipseItem>

#include "task1/pendulum.h"
#include "common/util.h"

Pendulum::Pendulum(qreal rodLength, qreal initialAngle, qreal gravity, qreal timestep,
                   QObject *parent)
    : QGraphicsScene(parent),
      m_symplecticIntegrator(initialAngle, 0.0, timestep),
      m_explicitIntegrator(initialAngle, 0.0, timestep),
      m_currentIntegrator(&m_symplecticIntegrator),
      m_anchor(new QGraphicsLineItem),
      m_rod(new QGraphicsLineItem),
      m_bob(new QGraphicsEllipseItem),
      m_rodLength(rodLength),
      m_angle(initialAngle),
      m_gravity(gravity),
      m_timestep(timestep),
      m_anchorPoint(0.0, 0.0),
      m_bobPosition(m_anchorPoint.x(), m_anchorPoint.y() + rodLength)
{
    m_bob->setBrush(QBrush(Qt::black, Qt::SolidPattern));

    addItem(m_anchor);
    addItem(m_rod);
    addItem(m_bob);

    calculateBobPosition();
    updateGraphicsItems();
    update();
}

QRectF Pendulum::sceneRect() const
{
    qreal size = m_rodLength*2 + 1;
    qreal pos = -size/2;
    return QRectF(pos, pos, size, size);
}

void Pendulum::calculateBobPosition()
{
    m_bobPosition.setX(m_rodLength * std::sin(m_angle));
    m_bobPosition.setY(m_rodLength * std::cos(m_angle));
}

void Pendulum::updateGraphicsItems()
{
    m_anchor->setLine(m_anchorPoint.x() - 0.2, m_anchorPoint.y(), m_anchorPoint.x() + 0.2, m_anchorPoint.y());
    m_rod->setLine(m_anchorPoint.x(), m_anchorPoint.y(), m_bobPosition.x(), m_bobPosition.y());
    m_bob->setRect(m_bobPosition.x() - 0.05, m_bobPosition.y() - 0.05, 0.1, 0.1);
}

void Pendulum::reset()
{
    m_currentIntegrator->reset(m_angle, 0.0, m_timestep);
    calculateBobPosition();
}

void Pendulum::useSymplecticEuler()
{
    m_symplecticIntegrator.reset(m_explicitIntegrator);
    m_currentIntegrator = &m_symplecticIntegrator;
}

void Pendulum::useExplicitEuler()
{
    m_explicitIntegrator.reset(m_symplecticIntegrator);
    m_currentIntegrator = &m_explicitIntegrator;
}

double Pendulum::calculateD2Angle(double x, double dx) const
{
    (void)dx;
    return -m_gravity / m_rodLength * std::sin(x);
}

void Pendulum::advance()
{
    m_angle = m_currentIntegrator->next(std::bind(&Pendulum::calculateD2Angle, this,
                                                  std::placeholders::_1, std::placeholders::_2));

    if (m_angle > M_PI) m_angle -= 2*M_PI;
    if (m_angle < -M_PI) m_angle += 2*M_PI;

    calculateBobPosition();
    QGraphicsScene::advance();
}

void Pendulum::update(const QRectF &rect)
{
    updateGraphicsItems();
    QGraphicsScene::update(rect);
}

void Pendulum::setRodLength(qreal rodLength)
{
    m_rodLength = rodLength;
    reset();
}

void Pendulum::setAngle(qreal angle)
{
    m_angle = angle;
    reset();
}

void Pendulum::setGravity(qreal gravity)
{
    m_gravity = gravity;
}

