#ifndef TASK1CONTROLLER_H
#define TASK1CONTROLLER_H

#include "common/taskcontroller.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"

class QLineEdit;
class Pendulum;

class Task1Controller : public TaskController
{
    Q_OBJECT
public:
    Task1Controller(Ui::MainWindow *ui, QObject *parent = 0);

public slots:
    virtual void reset();

protected:
    virtual void handleResize();

protected slots:
    virtual void advance();

private slots:
    void rodLengthFieldChanged();
    void angleFieldChanged();
    void gravityFieldChanged();
    void integratorChanged(int index);

private:
    void updateTextFields();

    QLineEdit *m_rodLengthField;
    QLineEdit *m_angleField;
    QLineEdit *m_gravityField;

    Pendulum *m_pendulum;
};

#endif // TASK1CONTROLLER_H
