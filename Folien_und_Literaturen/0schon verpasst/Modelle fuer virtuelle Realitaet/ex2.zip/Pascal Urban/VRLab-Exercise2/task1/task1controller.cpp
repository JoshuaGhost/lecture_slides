#include <QObject>
#include <QLineEdit>
#include <QPushButton>
#include <QGraphicsView>
#include <QTimer>

#include "task1/task1controller.h"
#include "task1/pendulum.h"
#include "common/util.h"
#include "ui_mainwindow.h"

#define DEFAULT_ROD_LENGTH 1.0
#define DEFAULT_ANGLE 45
#define DEFAULT_GRAVITY 9.8

Task1Controller::Task1Controller(Ui::MainWindow *ui, QObject *parent)
    : TaskController(ui->task1StartStopButton, ui->task1ResetButton, ui->task1GraphicsView, parent),
      m_rodLengthField(ui->task1RodLengthField),
      m_angleField(ui->task1AngleField),
      m_gravityField(ui->task1GravityField)
{
    m_pendulum = new Pendulum(DEFAULT_ROD_LENGTH,
                            util::toRadians(DEFAULT_ANGLE),
                            DEFAULT_GRAVITY,
                            TIMESTEP / 1000.0,
                            this);

    m_graphicsView->setScene(m_pendulum);
    m_graphicsView->setSceneRect(m_pendulum->sceneRect());

    connect(m_rodLengthField, SIGNAL(returnPressed()), this, SLOT(rodLengthFieldChanged()));
    connect(m_angleField, SIGNAL(returnPressed()), this, SLOT(angleFieldChanged()));
    connect(m_gravityField, SIGNAL(returnPressed()), this, SLOT(gravityFieldChanged()));
    connect(ui->task1IntegratorChooser, SIGNAL(currentIndexChanged(int)), this, SLOT(integratorChanged(int)));

    updateTextFields();
}

void Task1Controller::updateTextFields()
{
    setTextFieldToNumber(m_angleField, util::toDegrees(m_pendulum->angle()));
    setTextFieldToNumber(m_rodLengthField, m_pendulum->rodLength());
    setTextFieldToNumber(m_gravityField, m_pendulum->gravity());
}

void Task1Controller::handleResize()
{
    m_graphicsView->fitInView(m_pendulum->sceneRect(), Qt::KeepAspectRatio);
}

void Task1Controller::reset()
{
    m_pendulum->setAngle(util::toRadians(m_angleField->text().toDouble()));
    m_pendulum->setRodLength(m_rodLengthField->text().toDouble());
    m_pendulum->setGravity(m_gravityField->text().toDouble());
    m_pendulum->reset();
    m_pendulum->update();
}

void Task1Controller::advance()
{
    m_pendulum->advance();
    m_pendulum->update();
}

/***** Callbacks *****/

void Task1Controller::rodLengthFieldChanged()
{
    double length = m_rodLengthField->text().toDouble(); // TODO who needs input validation?!
    m_pendulum->setRodLength(length);
    m_pendulum->update();

    m_graphicsView->setSceneRect(m_pendulum->sceneRect());
    m_graphicsView->fitInView(m_pendulum->sceneRect(), Qt::KeepAspectRatio);
}

void Task1Controller::angleFieldChanged()
{
    double angle = m_angleField->text().toDouble();
    m_pendulum->setAngle(util::toRadians(angle));
    m_pendulum->update();
}

void Task1Controller::gravityFieldChanged()
{
    double gravity = m_gravityField->text().toDouble();
    m_pendulum->setGravity(gravity);
    m_pendulum->update();
}

void Task1Controller::integratorChanged(int index)
{
    if (index == 0) { // Symplectic
        m_pendulum->useSymplecticEuler();
    } else if (index == 1) { // Explicit
        m_pendulum->useExplicitEuler();
    }
}
