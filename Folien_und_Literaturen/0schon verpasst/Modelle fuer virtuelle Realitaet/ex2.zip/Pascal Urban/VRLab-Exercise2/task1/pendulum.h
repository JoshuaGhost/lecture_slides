#ifndef PENDULUM_H
#define PENDULUM_H

#include <QGraphicsScene>
#include "common/integrator.h"

class QGraphicsLineItem;
class QGraphicsEllipseItem;

class Pendulum : public QGraphicsScene
{
public:

    /*
     * rodLength: The length of the pendulums arm (in meters).
     * initialAngle: The start angle of the pendulum (in radians).
     * gravity: The gravity constant for the simulation (in m/s^2).
     * timestep: The timestep for the simulation (in seconds).
     */
    Pendulum(qreal rodLength, qreal initialAngle, qreal gravity, qreal timestep,
             QObject *parent = 0);

    virtual QRectF sceneRect() const;

    /*
     * For resetting internal values of the simulation.
     * Needs to be called if any value of the simulation changes.
     */
    void reset();

    void useSymplecticEuler();
    void useExplicitEuler();

    /*
     * Callback for Integrator.
     * Calculate the value of the second derivative of the angle.
     */
    double calculateD2Angle(double x, double dx) const;

    void setRodLength(qreal rodLength);
    void setAngle(qreal angle);
    void setGravity(qreal gravity);

    qreal rodLength() const { return m_rodLength; }
    qreal angle() const { return m_angle; }
    qreal gravity() const { return m_gravity; }

public slots:

    // Advances the simulation by one m_timestep.
    virtual void advance();

    // Updates the ui elements
    virtual void update(const QRectF &rect = QRectF());

private:
    void calculateBobPosition();
    void updateGraphicsItems();

    SymplecticEuler m_symplecticIntegrator;
    ExplicitEuler m_explicitIntegrator;
    Integrator *m_currentIntegrator;

    QGraphicsLineItem *m_anchor;
    QGraphicsLineItem *m_rod;
    QGraphicsEllipseItem *m_bob;

    // The length of the rod (in meters).
    qreal m_rodLength;

    // The current angle of the pendulum (in radians).
    qreal m_angle;

    // The gravity constant affecting the pendulum (in m/s^2).
    qreal m_gravity;

    // The timestep of the simulation (in seconds).
    qreal m_timestep;

    // Fixed position of pendulum.
    QPointF m_anchorPoint;

    // Current position of the bob.
    QPointF m_bobPosition;

};

#endif // PENDULUM_H
