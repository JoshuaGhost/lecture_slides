#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class Task1Controller;
class Task2Controller;
class Task3Controller;
class Task5Controller;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    Task1Controller *task1Controller;
    Task2Controller *task2Controller;
    Task3Controller *task3Controller;
    Task5Controller *task5Controller;
};

#endif // MAINWINDOW_H
