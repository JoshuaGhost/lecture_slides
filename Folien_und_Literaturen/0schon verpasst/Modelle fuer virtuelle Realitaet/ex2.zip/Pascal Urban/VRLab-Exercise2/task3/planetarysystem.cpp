#include "planetarysystem.h"
#include "astronomicalobjects.h"

static const qreal GRAVITATIONAL_CONSTANT = 6.673e-11;

static const qreal SUN_WEIGHT     = 1.98855e30;
static const qreal MERCURY_WEIGHT = 3.3022e23;
static const qreal VENUS_WEIGHT   = 4.8676e24;
static const qreal EARTH_WEIGHT   = 5.97219e24;
static const qreal MARS_WEIGHT    = 6.4185e23;

static const qreal JUPITER_WEIGHT = 1.8986e27;
static const qreal SATURN_WEIGHT  = 5.6846e26;
static const qreal URANUS_WEIGHT  = 8.681e25;
static const qreal NEPTUNE_WEIGHT = 1.0243e26;
static const qreal PLUTO_WEIGHT   = 1.305e22;

static const qreal MERCURY_SUN_DISTANCE = util::auToMeter(0.4);
static const qreal VENUS_SUN_DISTANCE   = util::auToMeter(0.7);
static const qreal EARTH_SUN_DISTANCE   = util::auToMeter(1);
static const qreal MARS_SUN_DISTANCE    = util::auToMeter(1.5);

static const qreal JUPITER_SUN_DISTANCE = util::auToMeter(5.2);
static const qreal SATURN_SUN_DISTANCE  = util::auToMeter(9.5);
static const qreal URANUS_SUN_DISTANCE  = util::auToMeter(19.2);
static const qreal NEPTUNE_SUN_DISTANCE = util::auToMeter(30.1);
static const qreal PLUTO_SUN_DISTANCE   = util::auToMeter(39);

PlanetarySystem::PlanetarySystem(QObject *parent)
    : QGraphicsScene(parent),
      m_radius(1.5),
      m_objects(),
      m_outerObjects(),
      m_days(0)
{
    setBackgroundBrush(QBrush(Qt::black, Qt::SolidPattern));
    setupAstronomicalBodies();
}

PlanetarySystem::~PlanetarySystem()
{
    // Free the objects that are not owned by a scene
    for (int i = 0; i < m_objects.size(); ++i) {
        if (m_objects.at(i)->scene() == nullptr) {
            delete m_objects.at(i);
        }
    }

    m_objects.clear();
    m_outerObjects.clear();
}

QRectF PlanetarySystem::sceneRect() const
{
    qreal left = util::meterToAU(m_sun->position().x()) - m_radius;
    qreal top = util::meterToAU(m_sun->position().y()) - m_radius;
    qreal width = m_radius*2;
    qreal height = m_radius*2;

    return QRectF(left, top, width, height);
}

void PlanetarySystem::reset()
{
    for (int i = 0; i < m_objects.size(); ++i) {
        m_objects.at(i)->reset();
    }
}

void PlanetarySystem::showOuterObjects()
{
    for (int i = 0; i < m_outerObjects.size(); ++i) {
        addItem(m_outerObjects.at(i));
    }

    m_radius = 39; // Pluto
    update();
}

void PlanetarySystem::hideOuterObjects()
{
    for (int i = 0; i < m_outerObjects.size(); ++i) {
        removeItem(m_outerObjects.at(i));
    }

    m_radius = 1.5; // Mars
    update();
}

/*
 * Calcaluates the mean orbital speed for an initial velocity
 * https://en.wikipedia.org/wiki/Orbital_speed#Mean_orbital_speed
 *
 * mass1: The mass of the first object (kg)
 * mass2: The mass of the second object (kg)
 * distance: The distance between mass1 and to mass2 (m)
 */
static inline qreal initialVelocity(qreal mass1, qreal mass2, qreal distance)
{
    return std::sqrt(GRAVITATIONAL_CONSTANT * (mass1 + mass2) / distance);
}

void PlanetarySystem::setupAstronomicalBodies()
{
    m_sun = new AstronomicalObject(QString("Sun"), SUN_WEIGHT, 0.0000046419719251336, Qt::yellow);
    AstronomicalObject *mercury = new AstronomicalObject(QString("Mercury"), MERCURY_WEIGHT, 0.0000000163065233957, Qt::gray);
    AstronomicalObject *venus = new AstronomicalObject(QString("Venus"), VENUS_WEIGHT, 0.0000000404532947860, Qt::green);
    AstronomicalObject *earth = new AstronomicalObject(QString("Earth"), EARTH_WEIGHT, 0.0000000425868983957, Qt::blue);
    AstronomicalObject *mars = new AstronomicalObject(QString("Mars"), MARS_WEIGHT, 0.0000000226562299465, Qt::red);

    AstronomicalObject *jupiter = new AstronomicalObject(QString("Jupiter"), JUPITER_WEIGHT, 0.0000004673060360962, QColor(0xE0, 0xC5, 0x9D));
    AstronomicalObject *saturn = new AstronomicalObject(QString("Saturn"), SATURN_WEIGHT, 0.0000003892442513368, QColor(0xDC, 0XC7, 0X90));
    AstronomicalObject *uranus = new AstronomicalObject(QString("Uranus"), URANUS_WEIGHT, 0.0000001695384425133, Qt::cyan);
    AstronomicalObject *neptune = new AstronomicalObject(QString("Neptune"), NEPTUNE_WEIGHT, 0.0000001645983622994, Qt::blue);
    AstronomicalObject *pluto = new AstronomicalObject(QString("Pluto"), PLUTO_WEIGHT, 0.0000000076656417112, Qt::gray);

    mercury->setPositionRelativeTo(m_sun, MERCURY_SUN_DISTANCE);
    venus->setPositionRelativeTo(m_sun, VENUS_SUN_DISTANCE);
    earth->setPositionRelativeTo(m_sun, EARTH_SUN_DISTANCE);
    mars->setPositionRelativeTo(m_sun, MARS_SUN_DISTANCE);
    jupiter->setPositionRelativeTo(m_sun, JUPITER_SUN_DISTANCE);
    saturn->setPositionRelativeTo(m_sun, SATURN_SUN_DISTANCE);
    uranus->setPositionRelativeTo(m_sun, URANUS_SUN_DISTANCE);
    neptune->setPositionRelativeTo(m_sun, NEPTUNE_SUN_DISTANCE);
    pluto->setPositionRelativeTo(m_sun, PLUTO_SUN_DISTANCE);

    // -y is up
    mercury->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, MERCURY_WEIGHT, MERCURY_SUN_DISTANCE)));
    venus->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, VENUS_WEIGHT, VENUS_SUN_DISTANCE)));
    earth->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, EARTH_WEIGHT, EARTH_SUN_DISTANCE)));
    mars->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, MARS_WEIGHT, MARS_SUN_DISTANCE)));
    jupiter->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, JUPITER_WEIGHT, JUPITER_SUN_DISTANCE)));
    saturn->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, SATURN_WEIGHT, SATURN_SUN_DISTANCE)));
    uranus->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, URANUS_WEIGHT, URANUS_SUN_DISTANCE)));
    neptune->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, NEPTUNE_WEIGHT, NEPTUNE_SUN_DISTANCE)));
    pluto->setInitialVelocity(QVector2D(0.0, -initialVelocity(SUN_WEIGHT, PLUTO_WEIGHT, PLUTO_SUN_DISTANCE)));

    m_sun->setDrawScale(0.01);
    pluto->setDrawScale(20);

    m_objects.append(m_sun);
    m_objects.append(mercury);
    m_objects.append(venus);
    m_objects.append(earth);
    m_objects.append(mars);
    m_objects.append(jupiter);
    m_objects.append(saturn);
    m_objects.append(uranus);
    m_objects.append(neptune);
    m_objects.append(pluto);

    m_outerObjects.append(jupiter);
    m_outerObjects.append(saturn);
    m_outerObjects.append(uranus);
    m_outerObjects.append(neptune);
    m_outerObjects.append(pluto);

    addItem(m_sun);
    addItem(mercury);
    addItem(venus);
    addItem(earth);
    addItem(mars);
}

void PlanetarySystem::advance()
{
    calculateForces();
    for (int i = 0; i < m_objects.size(); ++i) {
        m_objects.at(i)->advance(1);
    }

    m_days += 1; // The objects have a default timestep of 1 day
}

void PlanetarySystem::calculateForces()
{
    if (m_objects.size() < 2) return;

    int numObjects = m_objects.size();
    for (int i = 0; i < numObjects; ++i) {
        AstronomicalObject *object1 = m_objects[i];
        qreal m1 = object1->mass();
        const QVector2D &pos1 = object1->position();

        // previous forces are cleared by the object
        for (int j = i + 1; j < numObjects; ++j) {
            AstronomicalObject *object2 = m_objects[j];
            qreal m2 = object2->mass();
            const QVector2D &pos2 = object2->position();

            // QVector2D uses floats. Would probably be better to write a vector class with doubles
            QVector2D dirVector = pos2 - pos1;
            qreal rSquared = dirVector.lengthSquared();
            dirVector.normalize();

            QVector2D force = GRAVITATIONAL_CONSTANT * m1 * m2 / rSquared * dirVector;
            object1->forces += force;
            object2->forces -= force;
        }
    }
}
