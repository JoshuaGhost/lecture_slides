#ifndef PLANETARYSYSTEM_H
#define PLANETARYSYSTEM_H

#include <QGraphicsScene>
#include <QVector>

class AstronomicalObject;

class PlanetarySystem : public QGraphicsScene
{
public:
    PlanetarySystem(QObject *parent = 0);
    ~PlanetarySystem();

    virtual QRectF sceneRect() const;
    void reset();
    void addAstronomicalObject(AstronomicalObject *object);
    void showOuterObjects();
    void hideOuterObjects();

    int days() const { return m_days; }

public slots:
    virtual void advance();

private:
    void setupAstronomicalBodies();
    void calculateForces();
    void updateGraphicsItems();

    AstronomicalObject *m_sun;
    qreal m_radius; // The radius (in AU) of the outermost object currently displayed (either mars, or pluto)
    QVector<AstronomicalObject *> m_objects;
    QVector<AstronomicalObject *> m_outerObjects;

    int m_days;
};

#endif // PLANETARYSYSTEM_H
