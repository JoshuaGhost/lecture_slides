#include <QComboBox>
#include <QLabel>

#include "task3controller.h"
#include "planetarysystem.h"
#include "astronomicalobjects.h"
#include "common/util.h"


Task3Controller::Task3Controller(Ui::MainWindow *ui, QObject *parent)
    : TaskController(ui->task3StartStopButton, ui->task3ResetButton,
                     ui->task3GraphicsView, parent),
      m_daysLabel(ui->task3DayLabel),
      m_planetarySystem(new PlanetarySystem(this)),
      m_speedUp(1.0)
{
    m_graphicsView->setScene(m_planetarySystem);
    m_graphicsView->setRenderHint(QPainter::Antialiasing);

    connect(ui->task3SpeedUpComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(speedUpChanged(int)));
    connect(ui->task3OuterPlanetsCheckBox, SIGNAL(stateChanged(int)), this, SLOT(showOuterPlanets(int)));
}

void Task3Controller::handleResize()
{    
    m_graphicsView->setSceneRect(m_planetarySystem->sceneRect());
    m_graphicsView->fitInView(m_planetarySystem->sceneRect(), Qt::KeepAspectRatio);
}

void Task3Controller::reset()
{
    m_planetarySystem->reset();
}

void Task3Controller::advance()
{
    for (int i = 0; i < m_speedUp; ++i)
        m_planetarySystem->advance();

    m_planetarySystem->update();
    handleResize();

    if (m_ticks % 15 == 0) { // update the label every ~0.5 seconds
        QString number;
        number.setNum(m_planetarySystem->days());
        m_daysLabel->setText(number);
    }

    m_ticks++;
}

/***** Callbacks *****/

void Task3Controller::speedUpChanged(int index)
{
    switch (index) {
    case 0:
        m_speedUp = 1;
        break;
    case 1:
        m_speedUp = 2;
        break;
    case 2:
        m_speedUp = 5;
        break;
    case 3:
        m_speedUp = 10;
        break;
    case 4:
        m_speedUp = 20;
        break;
    case 5:
        m_speedUp = 30;
        break;
    default:
        m_speedUp = 1;
        break;
    }
}

void Task3Controller::showOuterPlanets(int state)
{
    if (state) {
        m_planetarySystem->showOuterObjects();
    } else {
        m_planetarySystem->hideOuterObjects();
    }
    handleResize();
}

