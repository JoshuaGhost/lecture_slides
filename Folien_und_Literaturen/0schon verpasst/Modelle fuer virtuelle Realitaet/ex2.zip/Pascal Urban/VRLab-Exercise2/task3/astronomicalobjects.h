#ifndef PLANET_H
#define PLANET_H

#include "common/util.h"

#include <QGraphicsEllipseItem>
#include <QVector2D>
#include <QVector>

class QPainterPath;



class AstronomicalObject : public QGraphicsEllipseItem
{
public:

    /*
     * For drawing purposes the position of an AstronomicalObject is in astronomical units.
     *
     * name: Name of the object
     * mass: Mass of the object in kg
     * radius: Radius of object in AU
     * color: Color of object
     * timestep: The timestep to use in seconds. Defaults to 1 Day.
     */
    AstronomicalObject(const QString &name, qreal mass,
                       qreal radius, const QColor &color,
                       qreal timestep = 3600 * 24);

    void reset();
    virtual void advance(int phase);
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    /*
     * other: The other object this object should be positioned relatively to.
     * distance: The distance to the other object (radius of the orbit around the other object) in meter.
     * angle: The position on the orbit relatively to the other object in radians. Defaults to 90 degrees.
     */
    void setPositionRelativeTo(const AstronomicalObject *other, qreal distance,
                               qreal angle = util::toRadians(90));

    const QString &name() const { return m_name; }
    const QVector2D &position() const { return m_position; }
    qreal radius() const { return m_radius; }
    qreal mass() const { return m_mass; }

    /*
     * Scale the object when drawing. Useful for extremely big (Sun) or small (Pluto) objects.
     */
    void setDrawScale(qreal scale);
    void setInitialVelocity(const QVector2D &velocity);

    // The forces affecting this object inside the PlanetarySystem
    QVector2D forces;
    QVector2D velocity;

private:
    void updateRect();

    QString m_name;
    QVector2D m_initialPosition;
    QVector2D m_position;
    qreal m_mass;
    qreal m_radius;
    QColor m_color;
    QVector2D m_initialVelocity;
    QVector2D m_velocity;
    qreal m_scale;
    qreal m_timestep;

    QVector<QPointF> m_pointHistory;
    int m_tick;
};

#endif // PLANET_H
