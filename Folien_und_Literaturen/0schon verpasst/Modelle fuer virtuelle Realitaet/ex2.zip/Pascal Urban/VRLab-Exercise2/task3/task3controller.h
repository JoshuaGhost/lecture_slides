#ifndef TASK3CONTROLLER_H
#define TASK3CONTROLLER_H

#include "common/taskcontroller.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"

class PlanetarySystem;
class QComboBox;
class QLabel;

class Task3Controller : public TaskController
{
    Q_OBJECT
public:
    Task3Controller(Ui::MainWindow *ui, QObject *paren = 0);

public slots:
    virtual void reset();

protected:
    virtual void handleResize();

protected slots:
    virtual void advance();

private slots:
    void speedUpChanged(int index);
    void showOuterPlanets(int state);

private:
    QLabel *m_daysLabel;

    PlanetarySystem *m_planetarySystem;
    int m_speedUp;

    int m_ticks;
};

#endif // TASK3CONTROLLER_H
