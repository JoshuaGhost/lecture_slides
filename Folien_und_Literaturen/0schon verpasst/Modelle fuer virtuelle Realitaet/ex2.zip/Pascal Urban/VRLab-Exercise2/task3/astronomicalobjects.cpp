#include <cmath>
#include <QPen>
#include <QBrush>
#include <QPainter>

#include "astronomicalobjects.h"

AstronomicalObject::AstronomicalObject(const QString &name, qreal mass,
                                       qreal radius, const QColor &color,
                                       qreal timestep)
    : QGraphicsEllipseItem(),
      m_name(name),
      m_initialPosition(0.0, 0.0),
      m_position(0.0, 0.0),
      m_mass(mass),
      m_radius(radius * 1000000.0), // The radii in AU are a tick to small, lets scale them a little
      m_color(color),
      m_scale(1.0),
      m_timestep(timestep)
{    
    setBrush(QBrush(m_color, Qt::SolidPattern));
    setPen(QPen(m_color));
    updateRect();
}

void AstronomicalObject::reset()
{
    forces[0] = 0.0;
    forces[1] = 0.0;

    m_position = m_initialPosition;
    m_velocity = m_initialVelocity;

    m_pointHistory.clear();

    updateRect();
}

void AstronomicalObject::setPositionRelativeTo(const AstronomicalObject *other, qreal distance, qreal angle)
{
    m_position = other->m_position;
    m_position += QVector2D(distance, distance);
    m_position *= QVector2D(std::sin(angle), std::cos(angle));

    m_initialPosition = m_position;

    updateRect();
}

void AstronomicalObject::setDrawScale(qreal scale)
{
    m_scale = scale;
    updateRect();
}

void AstronomicalObject::setInitialVelocity(const QVector2D &velocity)
{
    m_initialVelocity = velocity;
    m_velocity = velocity;
}

void AstronomicalObject::advance(int phase)
{
    // phase == 0: indicates that items on the scene are about to change
    // phase == 1: all items are allowed to move
    if (phase == 1) {
        qreal a_x = forces[0] / m_mass;
        qreal a_y = forces[1] / m_mass;

        m_velocity[0] += a_x * m_timestep;
        m_velocity[1] += a_y * m_timestep;

        m_position += m_velocity * m_timestep;

        if (++m_tick % 2 == 0) {
            // TODO Add some point some old values should be cleared... but hey we have enough memory!
            m_pointHistory.append((m_position / util::ASTRONOMICAL_UNIT).toPointF());
        }

        forces[0] = 0.0;
        forces[1] = 0.0;

        updateRect();
    }
}

void AstronomicalObject::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QGraphicsEllipseItem::paint(painter, option, widget);
    painter->drawLines(m_pointHistory);
}

void AstronomicalObject::updateRect()
{
    qreal scaled_radius = m_radius * m_scale;
    setRect(util::meterToAU(m_position.x()) - scaled_radius, util::meterToAU(m_position.y()) - scaled_radius, scaled_radius*2, scaled_radius*2);
}

