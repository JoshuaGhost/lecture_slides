#ifndef UTIL_H
#define UTIL_H

#include <cmath>

namespace util {

static const qreal ASTRONOMICAL_UNIT = 1.496e11;

inline double toRadians(double degrees) {
    return degrees * M_PI / 180.0;
}

inline double toDegrees(double radians) {
    return radians * 180.0 / M_PI;
}

inline double auToMeter(double au) {
    return au * ASTRONOMICAL_UNIT;
}

inline double meterToAU(double meter) {
    return meter / ASTRONOMICAL_UNIT;
}

}

#endif // UTIL_H

