#include "integrator.h"

Integrator::Integrator(double initialX, double initialDX, double timestep)
    : m_x(initialX),
      m_dx(initialDX),
      m_timestep(timestep)
{
}

Integrator::Integrator(const Integrator &other)
    : m_x(other.m_x),
      m_dx(other.m_dx),
      m_timestep(other.m_timestep)
{
}

void Integrator::reset(double x, double dx, double timestep)
{
    m_x = x;
    m_dx = dx;
    m_timestep = timestep;
}

void Integrator::reset(const Integrator &other)
{
    reset(other.m_x, other.m_dx, other.m_timestep);
}

/************************/

SymplecticEuler::SymplecticEuler(double initialX, double initialDX, double timestep)
    : Integrator(initialX, initialDX, timestep)
{
}

double SymplecticEuler::next(const std::function<double(double, double)> &func)
{
    m_dx = m_dx + func(m_x, m_dx) * m_timestep;
    m_x = m_x + m_dx * m_timestep;

    return m_x;
}

/************************/
ExplicitEuler::ExplicitEuler(double initialX, double initialDX, double timestep)
    : Integrator(initialX, initialDX, timestep)
{
}

double ExplicitEuler::next(const std::function<double(double, double)> &func)
{
    double dx_new = m_dx + func(m_x, m_dx) * m_timestep;
    m_x = m_x + m_dx * m_timestep;
    m_dx = dx_new;

    return m_x;
}
