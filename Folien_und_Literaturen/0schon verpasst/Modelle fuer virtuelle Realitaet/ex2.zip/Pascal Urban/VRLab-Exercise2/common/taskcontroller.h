#ifndef TASKCONTROLLER_H
#define TASKCONTROLLER_H

#include <QObject>

class QPushButton;
class QGraphicsView;
class QTimer;
class QLineEdit;
class QWheelEvent;

class TaskController : public QObject
{
    Q_OBJECT
public:
    // The timestep in milliseconds!
    static const double TIMESTEP;

    static void setTextFieldToNumber(QLineEdit *field, int number);
    static void setTextFieldToNumber(QLineEdit *field, double number);

    TaskController(QPushButton *startStopButton, QPushButton *resetButton,
                   QGraphicsView *graphicsView, QObject *parent = 0);

    virtual void start();
    virtual void stop();

public slots:
    virtual void toggleRunning();
    virtual void reset() = 0;

protected slots:
    // Called every time m_simulationTimer fires;
    virtual void advance() = 0;

protected:
    // Intercepting resize events of the graphics view for
    // updating the display parameters of the scene
    virtual bool eventFilter(QObject *object, QEvent *event);

    // Called if the graphics view was resized.
    virtual void handleResize() = 0;

    // Called if graphics view is not visible anymore.
    virtual void handleHide();

    QPushButton *m_startStopButton;
    QGraphicsView *m_graphicsView;
    QTimer *m_simulationTimer;

    bool m_running;
};

#endif // TASKCONTROLLER_H
