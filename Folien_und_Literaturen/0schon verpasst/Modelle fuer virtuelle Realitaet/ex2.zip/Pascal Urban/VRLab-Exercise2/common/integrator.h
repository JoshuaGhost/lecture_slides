#ifndef INTEGRATOR_H
#define INTEGRATOR_H

#include <functional>

class Integrator
{
public:
    /*
     * initalX: The start value of
     * initalDX: The start value of
     * timestep: The stepsize
     */
    Integrator(double initialX, double initialDX, double timestep);
    Integrator(const Integrator &other);

    /*
     * func is used for calculating the value of d2x.
     * The arguments of the function are:
     *    func(double x, double dx)
     */
    virtual double next(const std::function<double(double, double)> &func) = 0;

    double x() const { return m_x; }
    double dx() const { return m_dx; }

    void setX(double x) { m_x = x; }
    void setDX(double dx) { m_dx = dx; }

    void reset(double x, double dx, double timestep);
    void reset(const Integrator &other);

protected:
    double m_x;
    double m_dx;
    double m_timestep;
};

class SymplecticEuler : public Integrator
{
public:
    SymplecticEuler(double initialX, double initialDX, double timestep);

    virtual double next(const std::function<double(double, double)> &func);
};

class ExplicitEuler : public Integrator
{
public:
    ExplicitEuler(double initialX, double initialDX, double timestep);

    virtual double next(const std::function<double(double, double)> &func);
};

#endif // INTEGRATOR_H
