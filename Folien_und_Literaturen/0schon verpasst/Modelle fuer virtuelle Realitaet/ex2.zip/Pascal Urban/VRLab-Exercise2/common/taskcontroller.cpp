#include "taskcontroller.h"

#include <QEvent>
#include <QWheelEvent>
#include <QPushButton>
#include <QGraphicsView>
#include <QTimer>
#include <QLineEdit>

const double TaskController::TIMESTEP = 1000.0 / 30.0;

void TaskController::setTextFieldToNumber(QLineEdit *field, int number)
{
    QString numberOutputStr;
    numberOutputStr.setNum(number);
    field->setText(numberOutputStr);
}

void TaskController::setTextFieldToNumber(QLineEdit *field, double number)
{
    QString numberOutputStr;
    numberOutputStr.setNum(number);
    field->setText(numberOutputStr);
}

TaskController::TaskController(QPushButton *startStopButton, QPushButton *resetButton,
                               QGraphicsView *graphicsView, QObject *parent)
    : QObject(parent),
      m_startStopButton(startStopButton),
      m_graphicsView(graphicsView),
      m_simulationTimer(new QTimer(this)),
      m_running(false)
{
    m_graphicsView->installEventFilter(this);

    // TODO is there a better method than this?
    // TODO Only while using qt5!
    m_graphicsView->setRenderHint(QPainter::Qt4CompatiblePainting);

    connect(m_startStopButton, SIGNAL(released()), this, SLOT(toggleRunning()));
    connect(resetButton, SIGNAL(released()), this, SLOT(reset()));
    connect(m_simulationTimer, SIGNAL(timeout()), this, SLOT(advance()));
}

bool TaskController::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::WindowActivate || event->type() == QEvent::Show || event->type() == QEvent::Resize) {
        handleResize();
    } else if (event->type() == QEvent::Hide) {
        handleHide();;
    }

    return QObject::eventFilter(object, event);
}

void TaskController::handleHide()
{
    if (m_running) {
        m_running = false;
        m_startStopButton->setText(QString("Start"));
        stop();
    }
}

void TaskController::toggleRunning()
{
    m_running = !m_running;
    if (m_running) {
        m_startStopButton->setText(QString("Stop"));
        start();
    } else {
        m_startStopButton->setText(QString("Start"));
        stop();
    }
}

void TaskController::start()
{
    m_simulationTimer->start(TIMESTEP);
}

void TaskController::stop()
{
    m_simulationTimer->stop();
}
