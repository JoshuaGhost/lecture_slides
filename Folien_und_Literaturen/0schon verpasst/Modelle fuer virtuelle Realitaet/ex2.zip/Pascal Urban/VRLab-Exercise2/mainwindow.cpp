#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "task1/task1controller.h"
#include "task2/task2controller.h"
#include "task3/task3controller.h"
#include "task5/task5controller.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("VRLab - Exercise 2");
    task1Controller = new Task1Controller(ui, this);
    task2Controller = new Task2Controller(ui, this);
    task3Controller = new Task3Controller(ui, this);
    task5Controller = new Task5Controller(ui, this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
