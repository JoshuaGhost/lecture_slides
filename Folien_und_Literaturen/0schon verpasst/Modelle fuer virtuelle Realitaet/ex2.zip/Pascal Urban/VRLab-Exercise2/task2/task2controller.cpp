#include <QObject>
#include <QTimer>
#include <QRadioButton>

#include "task2controller.h"
#include "task2/doublependulum.h"
#include "common/util.h"

#define DEFAULT_LENGTH_1 1.0
#define DEFAULT_ANGLE_1  57.0
#define DEFAULT_MASS_1   1.0
#define DEFAULT_LENGTH_2 0.65
#define DEFAULT_ANGLE_2  34.0
#define DEFAULT_MASS_2   0.3

#define DEFAULT_GRAVITY 9.8

Task2Controller::Task2Controller(Ui::MainWindow *ui, QObject *parent)
    : TaskController(ui->task2StartStopButton, ui->task2ResetButton, ui->task2GraphicsView, parent),
      m_length1Field(ui->task2Length1Field),
      m_angle1Field(ui->task2Angle1Field),
      m_mass1Field(ui->task2Mass1Field),
      m_length2Field(ui->task2Length2Field),
      m_angle2Field(ui->task2Angle2Field),
      m_mass2Field(ui->task2Mass2Field),
      m_gravityField(ui->task2GravityField),
      m_springsRadio(ui->task2SpringsRadio),
      m_lagrangeRadio(ui->task2LagrangaRadio)

{
    m_pendulum = new DoublePendulum(DEFAULT_LENGTH_1, util::toRadians(DEFAULT_ANGLE_1), DEFAULT_MASS_1,
                                    DEFAULT_LENGTH_2, util::toRadians(DEFAULT_ANGLE_2), DEFAULT_MASS_2,
                                    DEFAULT_GRAVITY, TIMESTEP / 1000.0,
                                    this);
    m_graphicsView->setScene(m_pendulum);
    m_graphicsView->setSceneRect(m_pendulum->sceneRect());

    m_springsRadio->setChecked(true);

    connect(m_length1Field, SIGNAL(returnPressed()), this, SLOT(length1FieldChanged()));
    connect(m_angle1Field, SIGNAL(returnPressed()), this, SLOT(angle1FieldChanged()));
    connect(m_mass1Field, SIGNAL(returnPressed()), this, SLOT(mass1FieldChanged()));

    connect(m_length2Field, SIGNAL(returnPressed()), this, SLOT(length2FieldChanged()));
    connect(m_angle2Field, SIGNAL(returnPressed()), this, SLOT(angle2FieldChanged()));
    connect(m_mass2Field, SIGNAL(returnPressed()), this, SLOT(mass2FieldChanged()));

    connect(m_gravityField, SIGNAL(returnPressed()), this, SLOT(gravityFieldChanged()));

    connect(m_springsRadio, SIGNAL(clicked(bool)), this, SLOT(springsRadioPressed(bool)));
    connect(m_lagrangeRadio, SIGNAL(clicked(bool)), this, SLOT(lagrangeRadioPressed(bool)));

    updateTextFields();
}

void Task2Controller::updateTextFields()
{
    setTextFieldToNumber(m_length1Field, m_pendulum->length1());
    setTextFieldToNumber(m_angle1Field, util::toDegrees(m_pendulum->angle1()));
    setTextFieldToNumber(m_mass1Field, m_pendulum->mass1());

    setTextFieldToNumber(m_length2Field, m_pendulum->length2());
    setTextFieldToNumber(m_angle2Field, util::toDegrees(m_pendulum->angle2()));
    setTextFieldToNumber(m_mass2Field, m_pendulum->mass2());

    setTextFieldToNumber(m_gravityField, m_pendulum->gravity());
}

void Task2Controller::handleResize()
{
    m_graphicsView->fitInView(m_pendulum->sceneRect(), Qt::KeepAspectRatio);
}

void Task2Controller::reset()
{

    m_pendulum->setLength1(m_length1Field->text().toDouble());
    m_pendulum->setAngle1(util::toRadians(m_angle1Field->text().toDouble()));
    m_pendulum->setMass1(m_mass1Field->text().toDouble());
    m_pendulum->setLength2(m_length2Field->text().toDouble());
    m_pendulum->setAngle2(util::toRadians(m_angle2Field->text().toDouble()));
    m_pendulum->setMass2(m_mass2Field->text().toDouble());
    m_pendulum->setGravity(m_gravityField->text().toDouble());
    m_pendulum->reset();
    m_pendulum->update();
}

void Task2Controller::advance()
{
    m_pendulum->advance();
    m_pendulum->update();
}

/***** Callbacks *****/

void Task2Controller::length1FieldChanged()
{
    double length = m_length1Field->text().toDouble();
    m_pendulum->setLength1(length);
    m_pendulum->update();

    m_graphicsView->setSceneRect(m_pendulum->sceneRect());
    m_graphicsView->fitInView(m_pendulum->sceneRect(), Qt::KeepAspectRatio);
}

void Task2Controller::angle1FieldChanged()
{
    double angle = m_angle1Field->text().toDouble();
    m_pendulum->setAngle1(util::toRadians(angle));
    m_pendulum->update();
}

void Task2Controller::mass1FieldChanged()
{
    double mass = m_mass1Field->text().toDouble();
    m_pendulum->setMass1(mass);
    m_pendulum->update();
}

void Task2Controller::length2FieldChanged()
{
    double length = m_length2Field->text().toDouble();
    m_pendulum->setLength2(length);
    m_pendulum->update();

    m_graphicsView->setSceneRect(m_pendulum->sceneRect());
    m_graphicsView->fitInView(m_pendulum->sceneRect(), Qt::KeepAspectRatio);
}

void Task2Controller::angle2FieldChanged()
{
    double angle = m_angle2Field->text().toDouble();
    m_pendulum->setAngle2(util::toRadians(angle));
    m_pendulum->update();
}

void Task2Controller::mass2FieldChanged()
{
    double mass = m_mass2Field->text().toDouble();
    m_pendulum->setMass2(mass);
    m_pendulum->update();
}

void Task2Controller::gravityFieldChanged()
{
    double mass = m_gravityField->text().toDouble();
    m_pendulum->setGravity(mass);
    m_pendulum->update();
}

void Task2Controller::springsRadioPressed(bool checked)
{
    if (checked) {
        m_pendulum->useSprings(true);
        reset();
    }
}

void Task2Controller::lagrangeRadioPressed(bool checked)
{
    if (checked) {
        m_pendulum->useSprings(false);
        reset();
    }
}
