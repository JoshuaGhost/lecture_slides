#ifndef TASK2CONTROLLER_H
#define TASK2CONTROLLER_H

#include "common/taskcontroller.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"

class QRadioButton;
class QLineEdit;
class DoublePendulum;

class Task2Controller : public TaskController
{
    Q_OBJECT
public:
    Task2Controller(Ui::MainWindow *ui, QObject *parent = 0);

public slots:
    virtual void reset();

protected:
    virtual void handleResize();

protected slots:
    virtual void advance();

private slots:
    void length1FieldChanged();
    void angle1FieldChanged();
    void mass1FieldChanged();
    void length2FieldChanged();
    void angle2FieldChanged();
    void mass2FieldChanged();
    void gravityFieldChanged();

    void springsRadioPressed(bool checked);
    void lagrangeRadioPressed(bool checked);

private:
    void updateTextFields();

    QLineEdit *m_length1Field;
    QLineEdit *m_angle1Field;
    QLineEdit *m_mass1Field;
    QLineEdit *m_length2Field;
    QLineEdit *m_angle2Field;
    QLineEdit *m_mass2Field;
    QLineEdit *m_gravityField;

    QRadioButton *m_springsRadio;
    QRadioButton *m_lagrangeRadio;

    DoublePendulum *m_pendulum;
};

#endif // TASK2CONTROLLER_H
