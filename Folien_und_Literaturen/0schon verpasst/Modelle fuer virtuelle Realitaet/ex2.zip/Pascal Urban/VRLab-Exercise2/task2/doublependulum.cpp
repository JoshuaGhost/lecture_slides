#include <cmath>
#include <QGraphicsLineItem>
#include <QGraphicsEllipseItem>

#include "doublependulum.h"
#include "common/util.h"

DoublePendulum::DoublePendulum(qreal length1, qreal angle1, qreal mass1,
                               qreal length2, qreal angle2, qreal mass2,
                               qreal gravity, qreal timestep,
                               QObject *parent)
    : QGraphicsScene(parent),
      m_integrator1(angle1, 0.0, timestep),
      m_integrator2(angle2, 0.0, timestep),
      m_anchor(new QGraphicsLineItem),
      m_rod1(new QGraphicsLineItem),
      m_bob1(new QGraphicsEllipseItem),
      m_rod2(new QGraphicsLineItem),
      m_bob2(new QGraphicsEllipseItem),
      m_length1(length1),
      m_angle1(angle1),
      m_mass1(mass1),
      m_length2(length2),
      m_angle2(angle2),
      m_mass2(mass2),
      m_gravity(gravity),
      m_timestep(timestep),
      m_anchorPoint(0.0, 0.0),
      m_useSprings(true)
{
    m_bob1->setBrush(QBrush(Qt::black, Qt::SolidPattern));
    m_bob2->setBrush(QBrush(Qt::black, Qt::SolidPattern));

    addItem(m_anchor);
    addItem(m_rod1);
    addItem(m_bob1);
    addItem(m_rod2);
    addItem(m_bob2);

    calculateBobPositions();
    updateGraphicsItems();
    update();
}

QRectF DoublePendulum::sceneRect()
{
    qreal size = (m_length1 + m_length2) * 2 + 1;
    qreal pos = -size/2;
    return QRectF(pos, pos, size, size);
}

void DoublePendulum::calculateBobPositions()
{
    m_bob1Position.setX(m_length1 * std::sin(m_angle1));
    m_bob1Position.setY(m_length1 * std::cos(m_angle1));

    m_bob2Position.setX(m_length2 * std::sin(m_angle2));
    m_bob2Position.setY(m_length2 * std::cos(m_angle2));
    m_bob2Position += m_bob1Position;
}

void DoublePendulum::updateGraphicsItems()
{
    m_anchor->setLine(m_anchorPoint.x() - 0.2, m_anchorPoint.y(), m_anchorPoint.x() + 0.2, m_anchorPoint.y());
    m_rod1->setLine(m_anchorPoint.x(), m_anchorPoint.y(), m_bob1Position.x(), m_bob1Position.y());
    m_rod2->setLine(m_bob1Position.x(), m_bob1Position.y(), m_bob2Position.x(), m_bob2Position.y());

    qreal bob1Size = 0.1 * m_mass1;
    m_bob1->setRect(m_bob1Position.x() - bob1Size/2.0, m_bob1Position.y() - bob1Size/2.0, bob1Size, bob1Size);

    qreal bob2Size = 0.1 * m_mass2;
    m_bob2->setRect(m_bob2Position.x() - bob2Size/2.0, m_bob2Position.y() - bob2Size/2.0, bob2Size, bob2Size);
}

void DoublePendulum::reset()
{
    m_integrator1.reset(m_angle1, 0.0, m_timestep);
    m_integrator2.reset(m_angle2, 0.0, m_timestep);
    calculateBobPositions();
}

double DoublePendulum::calculateD2Angle1(double angle1, double dxOfAngle1, double dxOfAngle2)
{
    // This could be done better
    if (m_useSprings) {
        return - m_gravity / ( m_length1 *  m_mass1) * std::sin(m_angle1) + m_gravity / (m_length2 * m_mass1)  * std::sin(m_angle2 - m_angle1);
    }

    // http://www.myphysicslab.com/dbl_pendulum.html
    double d2x = -m_gravity * (2*m_mass1 + m_mass2) * std::sin(angle1);
    d2x -= m_mass2 * m_gravity * std::sin(angle1 - 2 * m_angle2);
    d2x -= 2 * std::sin(angle1 - m_angle2) * m_mass2 * (dxOfAngle2 * dxOfAngle2 * m_length2 + dxOfAngle1 * dxOfAngle1 * m_length1 * std::cos(angle1 - m_angle2));
    d2x /= m_length1 * (2 * m_mass1 + m_mass2 - m_mass2 * std::cos(2 * angle1 - 2 * m_angle2));

    return d2x;
}

double DoublePendulum::calculateD2Angle2(double angle2, double dxOfAngle2, double dxOfAngle1)
{
    if (m_useSprings) {
        return - m_gravity / (m_length2 * m_mass2) * std::sin(m_angle2 - m_angle1);
    }

    // http://www.myphysicslab.com/dbl_pendulum.html
    double d2x = 2 * std::sin(m_angle1 - angle2);
    d2x *= dxOfAngle1 * dxOfAngle1 * m_length1 * (m_mass1 + m_mass2) + m_gravity * (m_mass1 + m_mass2) * std::cos(m_angle1) + dxOfAngle2 * dxOfAngle2 * m_length2 * m_mass2 * std::cos(m_angle1 - angle2);
    d2x /= m_length2 * (2 * m_mass1 + m_mass2 - m_mass2 * std::cos(2 * m_angle1 - 2 * angle2));

    return d2x;
}

void DoublePendulum::advance()
{
    // need to capture the first derivatives for both angles before calculating
    // the next step with each integrator because these are changed in these steps!
    double dxOfAngle1 = m_integrator1.dx();
    double dxOfAngle2 = m_integrator2.dx();

    // This could also be done better, probably by removing the Integrator class...
    m_integrator1.next(std::bind(&DoublePendulum::calculateD2Angle1, this, std::placeholders::_1, std::placeholders::_2, dxOfAngle2));
    m_integrator2.next(std::bind(&DoublePendulum::calculateD2Angle2, this, std::placeholders::_1, std::placeholders::_2, dxOfAngle1));

    m_angle1 = m_integrator1.x();
    m_angle2 = m_integrator2.x();

    if (m_angle1 > M_PI) m_angle1 -= 2*M_PI;
    if (m_angle2 > M_PI) m_angle2 -= 2*M_PI;

    if (m_angle1 < -M_PI) m_angle1 += 2*M_PI;
    if (m_angle2 < -M_PI) m_angle2 += 2*M_PI;

    // update the integrator with the clamped values
    m_integrator1.setX(m_angle1);
    m_integrator2.setX(m_angle2);

    calculateBobPositions();
    QGraphicsScene::advance();
}

void DoublePendulum::update(const QRectF &rect)
{
    updateGraphicsItems();
    QGraphicsScene::update(rect);
}

void DoublePendulum::setLength1(qreal length)
{
    m_length1 = length;
    reset();
}

void DoublePendulum::setAngle1(qreal angle)
{
    m_angle1 = angle;
    reset();
}

void DoublePendulum::setMass1(qreal mass)
{
    m_mass1 = mass;
    reset();
}

void DoublePendulum::setLength2(qreal length)
{
    m_length2 = length;
    reset();
}

void DoublePendulum::setAngle2(qreal angle)
{
    m_angle2 = angle;
    reset();
}

void DoublePendulum::setMass2(qreal mass)
{
    m_mass2 = mass;
    reset();
}

void DoublePendulum::setGravity(qreal gravity)
{
    m_gravity = gravity;
}

void DoublePendulum::useSprings(bool use)
{
    m_useSprings = use;
    reset();
}
