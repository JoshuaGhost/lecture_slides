#ifndef DOUBLEPENDULUM_H
#define DOUBLEPENDULUM_H

#include <QGraphicsScene>

#include "common/integrator.h"

class QGraphicsLineItem;
class QGraphicsEllipseItem;

class DoublePendulum : public QGraphicsScene
{
public:
    DoublePendulum(qreal length1, qreal angle1, qreal mass1,
                   qreal length2, qreal angle2, qreal mass2,
                   qreal gravity, qreal timestep,
                   QObject *parent = 0);

    virtual QRectF sceneRect();
    void reset();

    // Calcualte the value of the second derivative of angle1.
    double calculateD2Angle1(double angle1, double dxOfAngle1, double dxOfAngle2);

    // Calcualte the value of the second derivative of angle2.
    double calculateD2Angle2(double angle2, double dxOfAngle2, double dxOfAngle1);

    qreal length1() const { return m_length1; }
    qreal angle1() const { return m_angle1; }
    qreal mass1() const { return m_mass1; }
    qreal length2() const { return m_length2; }
    qreal angle2() const { return m_angle2; }
    qreal mass2() const { return m_mass2; }
    qreal gravity() const { return m_gravity; }

    void setLength1(qreal length);
    void setAngle1(qreal angle);
    void setMass1(qreal mass);
    void setLength2(qreal length);
    void setAngle2(qreal angle);
    void setMass2(qreal mass);
    void setGravity(qreal gravity);

    void useSprings(bool use);

public slots:
    virtual void advance();
    virtual void update(const QRectF &rect = QRectF());

private:
    void calculateBobPositions();
    void updateGraphicsItems();

    SymplecticEuler m_integrator1;
    SymplecticEuler m_integrator2;

    QGraphicsLineItem *m_anchor;
    QGraphicsLineItem *m_rod1;
    QGraphicsEllipseItem *m_bob1;
    QGraphicsLineItem *m_rod2;
    QGraphicsEllipseItem *m_bob2;

    qreal m_length1;
    qreal m_angle1;
    qreal m_mass1;
    qreal m_length2;
    qreal m_angle2;
    qreal m_mass2;

    qreal m_gravity;
    qreal m_timestep;

    QPointF m_anchorPoint;
    QPointF m_bob1Position;
    QPointF m_bob2Position;

    bool m_useSprings;
};

#endif // DOUBLEPENDULUM_H
