package view;

public interface Simulatable {
	public void step(double dt);
}
