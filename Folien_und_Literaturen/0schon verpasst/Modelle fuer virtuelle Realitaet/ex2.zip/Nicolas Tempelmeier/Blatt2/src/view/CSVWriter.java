package view;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * 
 * Sehr einfache Klasse, die CSV Dateien erstellt.
 *
 */
public class CSVWriter {

	PrintWriter writer;
	
	public void newCsvFile(String name) {
		try {
			writer = new PrintWriter(name);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void writeLine(double... vals) {
		String line = "";
		
		for(int i=0; i < vals.length; i++) {
			if (i  < vals.length -1) {
				line += vals[i]+", ";
			} else {
				line +=vals[i];
			}
		}
		
		writer.println(line);
	}
	public void close() {
		writer.close();
	}
	
}
