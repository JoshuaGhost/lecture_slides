package view;
import view.Simulatable;


public class simThread extends Thread {

	Simulatable example;
	double dt;
	boolean run;
	double wait;
	
	public simThread(Simulatable example, double dt, double wait) {
		super();
		this.example = example;
		this.dt = dt;
		this.wait = wait;
	}
	
	public void kill() {
		run = false;
	}
	
	public void run() {
		run = true;
		while(run) {
			example.step(dt);
			try {
				sleep((long)(wait*1000));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}
