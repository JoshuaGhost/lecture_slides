package view;

import java.util.Vector;

import model.FluidParticle;
import model.Planet;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class MainView extends Application {

	Simulator sim = new Simulator();
	
	Pane pendelPane = new Pane();
	Pane doppelPendelPane = new Pane();
	Pane planetenPane = new Pane();
	Pane fluidPane = new Pane();
	
	public static void main(String[] args) {
		launch(args);

	 }
	
	@Override
	public void stop() {
		System.exit(0);
	}
	
	public void reset() {

		//FLuid
		fluidPane.getChildren().clear();
		fluidPane.setStyle("-fx-background-color: white");
		Vector<FluidParticle> particles = sim.getFluid().getParticles();
		Vector<Circle> partCircles = new Vector<Circle>();
		for (FluidParticle p: particles) {
			Circle circ = new Circle(p.getX(), p.getY(), 1);
			circ.centerXProperty().bind(p.getXProperty());
			circ.centerYProperty().bind(p.getYProperty());
			circ.setFill(p.getColor());
			fluidPane.getChildren().add(circ);
			partCircles.add(circ);
		}
		
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		BorderPane root = new BorderPane();
		Scene scene = new Scene(root, 800, 600);

		VBox rBox = new VBox();
		rBox.setAlignment(Pos.TOP_CENTER);
		
		Button startB = new Button("Start");	
		startB.setOnAction((event) -> {
			sim.run();
		});
		
		rBox.getChildren().add(startB);
		Button stopB = new Button("Stop");
		stopB.setOnAction((event) -> {
			sim.stop();
			this.reset();
		});
		
		rBox.getChildren().add(stopB);
		
		
		//Tabs
		TabPane rTabs = new TabPane();
		Tab tabPendel = new Tab();
		tabPendel.setClosable(false);
		tabPendel.setText("Pendel");
		rTabs.getTabs().add(tabPendel);
		Tab tabDoppelPendel = new Tab();
		tabDoppelPendel.setClosable(false);
		tabDoppelPendel.setText("Doppelpendel");
		rTabs.getTabs().add(tabDoppelPendel);
		Tab tabPlaneten = new Tab();
		tabPlaneten.setClosable(false);
		tabPlaneten.setText("Planeten");
		rTabs.getTabs().add(tabPlaneten);
		Tab tabFluid = new Tab();
		tabFluid.setClosable(false);
		tabFluid.setText("Fluid");
		rTabs.getTabs().add(tabFluid);
				
		
		rBox.getChildren().add(rTabs);
		
		//Pendel Control
		VBox vPendel = new VBox(8);
		vPendel.setPadding(new Insets(10, 5, 0, 5));
		Label pendLengthLabel = new Label("Kugel x:");
		vPendel.getChildren().add(pendLengthLabel);
		Slider pendXStart = new Slider();
		pendXStart.setShowTickLabels(true);
		pendXStart.setMin(0);
		pendXStart.setMax(600);
		pendXStart.setValue(sim.getPendel().getX1StartProperty().get());
		pendXStart.valueProperty().addListener((observable, oldValue, newValue) -> {
		    	sim.stop();
		    });
		
		sim.getPendel().getX1StartProperty().bind(pendXStart.valueProperty());
		vPendel.getChildren().add(pendXStart);
		vPendel.getChildren().add(new Label("Kugel y:"));
		Slider pendYStart = new Slider();
		pendYStart.setShowTickLabels(true);
		pendYStart.setMax(600);
		pendYStart.valueProperty().set(sim.getPendel().getY1StartProperty().get());
		pendYStart.setMin(0);
		pendYStart.valueProperty().addListener((observable, oldValue, newValue) -> {
	    	sim.stop();
	    });
		sim.getPendel().getY1StartProperty().bind(pendYStart.valueProperty());
		vPendel.getChildren().add(pendYStart);
		vPendel.getChildren().add(new Label("Federkonstante"));
		Slider pendD = new Slider();
		pendD.setShowTickLabels(true);

		pendD.setMin(0);
		pendD.setMax(1500);
		pendD.setValue(sim.getPendel().getDProperty().get());
		sim.getPendel().getDProperty().bind(pendD.valueProperty());
		vPendel.getChildren().add(pendD);
		
		tabPendel.setContent(vPendel);
		
		//Doppelpendel Control
		
		VBox vdPendel = new VBox(8);
		vdPendel.setPadding(new Insets(10, 5, 0, 5));
		vdPendel.getChildren().add(new Label("Kugel 1 x:"));
		Slider dPendX1Start = new Slider();
		dPendX1Start.setShowTickLabels(true);
		dPendX1Start.setMin(0);
		dPendX1Start.setMax(500);
		dPendX1Start.setValue(sim.getDpendel().getX1StartProperty().get());
		dPendX1Start.valueProperty().addListener((observable, oldValue, newValue) -> {
		    	sim.stop();
		    });
		sim.getDpendel().getX1StartProperty().bind(dPendX1Start.valueProperty());
		vdPendel.getChildren().add(dPendX1Start);
		
		vdPendel.getChildren().add(new Label("Kugel 1 y:"));
		Slider dPendY1Start = new Slider();
		dPendY1Start.setShowTickLabels(true);
		dPendY1Start.setMin(0);
		dPendY1Start.setMax(500);
		dPendY1Start.setValue(sim.getDpendel().getY1StartProperty().get());
		dPendY1Start.valueProperty().addListener((observable, oldValue, newValue) -> {
		    	sim.stop();
		    });
		sim.getDpendel().getY1StartProperty().bind(dPendY1Start.valueProperty());
		vdPendel.getChildren().add(dPendY1Start);
		
		vdPendel.getChildren().add(new Label("Kugel 2 x:"));
		Slider dPendX2Start = new Slider();
		dPendX2Start.setShowTickLabels(true);
		dPendX2Start.setMin(0);
		dPendX2Start.setMax(500);
		dPendX2Start.setValue(sim.getDpendel().getX2StartProperty().get());
		dPendX2Start.valueProperty().addListener((observable, oldValue, newValue) -> {
		    	sim.stop();
		    });
		sim.getDpendel().getX2StartProperty().bind(dPendX2Start.valueProperty());
		vdPendel.getChildren().add(dPendX2Start);
		
		vdPendel.getChildren().add(new Label("Kugel 2 y:"));
		Slider dPendY2Start = new Slider();
		dPendY2Start.setShowTickLabels(true);
		dPendY2Start.setMin(0);
		dPendY2Start.setMax(500);
		dPendY2Start.setValue(sim.getDpendel().getY2StartProperty().get());
		dPendY2Start.valueProperty().addListener((observable, oldValue, newValue) -> {
		    	sim.stop();
		    });
		sim.getDpendel().getY2StartProperty().bind(dPendY2Start.valueProperty());
		vdPendel.getChildren().add(dPendY2Start);
		
		vdPendel.getChildren().add(new Label("Federkonstante:"));
		Slider dPendD = new Slider();
		dPendD.setShowTickLabels(true);
		dPendD.setMin(0);
		dPendD.setMax(1500);
		dPendD.setValue(sim.getDpendel().getDProperty().get());
		sim.getDpendel().getDProperty().bind(dPendD.valueProperty());
		vdPendel.getChildren().add(dPendD);
		
		tabDoppelPendel.setContent(vdPendel);
		
		//Planeten Control
		VBox vPlanets = new VBox(8);
		vPlanets.setPadding(new Insets(10, 5, 0, 5));
		Vector<Planet> planets = sim.getpSystem().getPlanets();
		for (int i=0; i < planets.size(); i++) {
			vPlanets.getChildren().add(new Label("Startgeschwwindigkeit Planet "+i));
			Slider planSlider = new Slider();
			planSlider.setMin(0);
			planSlider.setMax(40);
			planSlider.setValue(planets.get(i).getVStartProperty().get());
			planets.get(i).getVStartProperty().bind(planSlider.valueProperty());
			vPlanets.getChildren().add(planSlider);
		}
		tabPlaneten.setContent(vPlanets);
		
		//Fluid Control
		VBox vFluid = new VBox(8);
		vFluid.setPadding(new Insets(10, 5, 0, 5));
		vFluid.getChildren().add(new Label("Radius"));
		Slider slidRadius = new Slider();
		slidRadius.setShowTickLabels(true);
		slidRadius.setMin(30);
		slidRadius.setMax(200);
		slidRadius.setValue(sim.getFluid().getRadiusProperty().get());
		sim.getFluid().getRadiusProperty().bind(slidRadius.valueProperty());	
		slidRadius.valueProperty().addListener((observable, oldValue, newValue) -> {
	    	sim.stop();
	    	reset();
	    });
		vFluid.getChildren().add(slidRadius);
		vFluid.getChildren().add(new Label("Anzahl Partikel"));
		Slider slidParticles = new Slider();
		slidParticles.setShowTickLabels(true);
		slidParticles.setMin(100);
		slidParticles.setMax(800);
		slidParticles.setValue(sim.getFluid().getNoParticlesProperty().get());
		sim.getFluid().getNoParticlesProperty().bind(slidParticles.valueProperty());
		slidParticles.valueProperty().addListener((observable, oldValue, newValue) -> {
	    	sim.stop();
	    	reset();
	    });
		vFluid.getChildren().add(slidParticles);
		vFluid.getChildren().add(new Label("Deckenabstand"));
		Slider slidCeilDist = new Slider();
		slidCeilDist.setShowTickLabels(true);
		slidCeilDist.setMin(1);
		slidCeilDist.setMax(20);
		slidCeilDist.setValue(sim.getFluid().getCeilDistProperty().get());
		sim.getFluid().getCeilDistProperty().bind(slidCeilDist.valueProperty());
		slidCeilDist.valueProperty().addListener((observable, oldValue, newValue) -> {
	    	sim.stop();
	    	reset();
	    });
		vFluid.getChildren().add(slidCeilDist);
		tabFluid.setContent(slidCeilDist);
		vFluid.getChildren().add(new Label("Deckenhoehe"));
		Slider slidCeiHeight = new Slider();
		slidCeiHeight.setShowTickLabels(true);
		slidCeiHeight.setMin(1);
		slidCeiHeight.setMax(20);
		slidCeiHeight.setValue(sim.getFluid().getCeilHeightProperty().get());
		sim.getFluid().getCeilHeightProperty().bind(slidCeiHeight.valueProperty());	
		slidCeiHeight.valueProperty().addListener((observable, oldValue, newValue) -> {
	    	sim.stop();
	    	reset();
	    });
		vFluid.getChildren().add(slidCeiHeight);
		tabFluid.setContent(vFluid);
		
		//Pendel View
		pendelPane.setStyle("-fx-background-color: white");
		Rectangle anchor = new Rectangle(10, 10);
		anchor.xProperty().bind(sim.getPendel().getX0Prop().subtract(5));
		anchor.yProperty().bind(sim.getPendel().getY0Prop().subtract(5));
		pendelPane.getChildren().add(anchor);
		Circle pendulum = new Circle(319, 200, 8);
		pendulum.centerXProperty().bind(sim.getPendel().getX1Prop());
		pendulum.centerYProperty().bind(sim.getPendel().getY1Prop());
		pendelPane.getChildren().add(pendulum);
		Line arm = new Line();
		arm.startXProperty().bind(anchor.xProperty().add(5));
		arm.startYProperty().bind(anchor.yProperty().add(5));
		arm.endXProperty().bind(pendulum.centerXProperty());
		arm.endYProperty().bind(pendulum.centerYProperty());
		pendelPane.getChildren().add(arm);
		
		//Doppelpendel View
		doppelPendelPane.setStyle("-fx-background-color: white");
		Rectangle p2anchor = new Rectangle(10, 10);
		p2anchor.xProperty().bind(sim.getPendel().getX0Prop().subtract(5));
		p2anchor.yProperty().bind(sim.getPendel().getY0Prop().subtract(5));
		
		Circle dp1 = new Circle(0, 0, 8);
		dp1.centerXProperty().bind(sim.getDpendel().getX1Prop());
		dp1.centerYProperty().bind(sim.getDpendel().getY1Prop());
		Line dpArm1 = new Line();
		dpArm1.startXProperty().bind(p2anchor.xProperty().add(5));
		dpArm1.startYProperty().bind(p2anchor.yProperty().add(5));
		dpArm1.endXProperty().bind(dp1.centerXProperty());
		dpArm1.endYProperty().bind(dp1.centerYProperty());
		Circle dp2 = new Circle(0, 0, 8);
		dp2.centerXProperty().bind(sim.getDpendel().getX2Prop());
		dp2.centerYProperty().bind(sim.getDpendel().getY2Prop());
		Line dpArm2 = new Line();
		dpArm2.startXProperty().bind(dp1.centerXProperty());
		dpArm2.startYProperty().bind(dp1.centerYProperty());
		dpArm2.endXProperty().bind(dp2.centerXProperty());
		dpArm2.endYProperty().bind(dp2.centerYProperty());

		
		doppelPendelPane.getChildren().add(p2anchor);
		doppelPendelPane.getChildren().add(dp1);
		doppelPendelPane.getChildren().add(dp2);
		doppelPendelPane.getChildren().add(dpArm1);
		doppelPendelPane.getChildren().add(dpArm2);
		
		
		//Planeten view
		planetenPane.setStyle("-fx-background-color: white");
		Vector<Planet> psys = sim.getpSystem().getPlanets();
		Vector<Circle> planCircles = new Vector<Circle>();
		for (Planet p: psys) {
			Circle circ = new Circle(p.getX(), p.getY(), p.getMass()/100);
			circ.centerXProperty().bind(p.xProp());
			circ.centerYProperty().bind(p.yProp());
			planCircles.add(circ);
			planetenPane.getChildren().add(circ);
		}
		
		
		
		
		this.reset();

	
		
		root.setCenter(pendelPane);
		root.setRight(rBox);
		primaryStage.setTitle("Blatt 2");
		primaryStage.setScene(scene);
		
		
		rTabs.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
		    @Override
		    public void changed(ObservableValue<? extends Number> ov, Number oldValue, Number newValue) {
		    	sim.stop();
		    	switch(newValue.intValue()) {
		    		case 0:
		    			root.setCenter(pendelPane);
		    			sim.setExample("pendel");
		    			break;
		    		case 1:
		    			root.setCenter(doppelPendelPane);
		    			sim.setExample("doppelPendel");

		    			break;
		    		case 2:
		    			root.setCenter(planetenPane);
		    			sim.setExample("planeten");
		    			break;
		    		case 3:
		    			root.setCenter(fluidPane);
		    			sim.setExample("fluid");
		    			break;
		    	}
		    	reset();
		    }
		}); 
		
		
		primaryStage.show();
		
	}

	
	
}
