package view;

import model.DoublePendulum;
import model.Fluid;
import model.Pendulum;
import model.Planet;
import model.PlanetSystem;

public class Simulator {


	String example;
	Pendulum pendel = new Pendulum(246, 300, 446, 300);
	DoublePendulum dpendel = new DoublePendulum(246, 300, 376, 300, 446, 300); ;
	boolean running;
	simThread pThread;
	
	PlanetSystem pSystem = new PlanetSystem();
	Fluid fluid;
	
	public Simulator() {
		example = "pendel";
		pSystem = new PlanetSystem();
		pSystem.addPlanet(new Planet(pSystem, 400, 500, -1, -3, 1000));
		pSystem.addPlanet(new Planet(pSystem, 450, 500, 0, -10, 100));	
		
		pSystem.addPlanet(new Planet(pSystem, 100, 50, 1, 3, 1000));
		pSystem.addPlanet(new Planet(pSystem, 150, 50, 0, 10, 100));	
		
		pSystem.addPlanet(new Planet(pSystem, 400, 50, -1, 3, 1000));
		pSystem.addPlanet(new Planet(pSystem, 450, 50, 0, 10, 100));	
		
		pSystem.addPlanet(new Planet(pSystem, 100, 500, 1, -3, 1000));
		pSystem.addPlanet(new Planet(pSystem, 150, 500, 0, -10, 100));	
		
		pSystem.addPlanet(new Planet(pSystem, 250, 500, -1, -5, 100));	
		pSystem.addPlanet(new Planet(pSystem, 250, 50, -1, 5, 100));	
		pSystem.addPlanet(new Planet(pSystem, 100, 275, 0, 0, 2000));	
		
		fluid = new Fluid(60, 551, 4.398, 1);
		
		
		this.reset();
	}
	
	public void reset() {
		running = false;

		pendel.reset();
		pSystem.reset();
		dpendel.reset();	
		fluid.reset();
	}
	
	
	public void setExample(String example) {
		this.example = example;
	}

	public PlanetSystem getpSystem() {
		return pSystem;
	}

	
	
	public Fluid getFluid() {
		return fluid;
	}

	
	
	public DoublePendulum getDpendel() {
		return dpendel;
	}

	public void run() {
		if (running) return;
		if (example.compareTo("pendel") == 0) {
			pThread = new simThread(pendel, 0.05, 0.04);
		} else if (example.compareTo("planeten") == 0) {
			pThread = new simThread(pSystem, 0.08, 0.04);
		} else if (example.compareTo("fluid") == 0) {
			pThread = new simThread(fluid, 0.05, 0.1);
		} else if (example.compareTo("doppelPendel") == 0) {
			pThread = new simThread(dpendel, 0.02, 0.04);

		}

		pThread.start();
		running = true;
	}

	public void stop() {
		if (!running) {
			this.reset();
			return;
		}
		pThread.kill();
		try {
			pThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		running=false;
		this.reset();
	}

	public Pendulum getPendel() {
		return pendel;
	}
}
