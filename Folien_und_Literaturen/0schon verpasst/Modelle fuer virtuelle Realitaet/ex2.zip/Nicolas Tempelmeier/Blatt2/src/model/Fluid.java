package model;

import java.util.Vector;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import view.Simulatable;

public class Fluid implements Simulatable {

	Vector<FluidParticle> particles;

	//Variables
	DoubleProperty radius;
	DoubleProperty noParticles;
	
	double xcenter = 246;
	double ycenter = 25;
	
	DoubleProperty ceilDist;
	DoubleProperty ceilHeight;
	
	public Fluid(double r, double no, double dist, double height) {
		particles = new Vector<FluidParticle>();
		radius = new SimpleDoubleProperty(r);
		noParticles = new SimpleDoubleProperty(no);
		ceilDist = new SimpleDoubleProperty(dist);
		ceilHeight = new SimpleDoubleProperty(height);
		
		this.reset();
	}
	
	public Vector<FluidParticle> getParticles() {
		return particles;
	}
	
	public void reset() {
		particles.clear();
				
		double stepWidth = Math.sqrt((Math.PI * Math.pow(radius.get(), 2) * 0.5) / noParticles.get());
		double length = 2*radius.get() - ((2 * radius.get()) % stepWidth);
		for (double x=xcenter-(length/2); x < xcenter+(length/2); x+=1) {
			for (double i=1; i <= ceilHeight.get(); i++) {
				particles.add(new FixedFluidParticle(x, ycenter-i-ceilDist.get()));
			}
		}
		
		for (double y=0; y <= radius.get(); y+=stepWidth) {
			double phi = Math.acos(y/radius.get());
			double width = Math.sin(phi) * radius.get();
			double rest = width % stepWidth;
			width -= rest;
			for(double x=xcenter-width; x <= xcenter+width-stepWidth; x+=stepWidth) {
				FluidParticle p = new FluidParticle(x, y+ycenter);
				p.setFluid(this);
				particles.add(p);
			}
		}
	}
	
	public void step(double dt) {
		for (FluidParticle p: particles) {
			p.stepFirst(dt);
		}
		particles.stream().forEach((p)->{
			p.stepSecond(dt);
		});
	}

	public DoubleProperty getRadiusProperty() {
		return radius;
	}

	public DoubleProperty getNoParticlesProperty() {
		return noParticles;
	}

	public DoubleProperty getCeilDistProperty() {
		return ceilDist;
	}

	public DoubleProperty getCeilHeightProperty() {
		return ceilHeight;
	}

	public void setParticles(Vector<FluidParticle> particles) {
		this.particles = particles;
	}
	
}
