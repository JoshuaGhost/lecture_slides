package model;

import javafx.scene.paint.Color;

public class FixedFluidParticle extends FluidParticle {
	
	private static Color color = Color.RED;
	
	public FixedFluidParticle(double x, double y) {
		super(x, y);
	}
	
	@Override
	public void stepFirst(double dt) {
		return;
	}
	
	@Override
	public void stepSecond(double dt) {
		return;
	}
	
	@Override
	public Color getColor() {
		return color;
	}	
	
	
}
