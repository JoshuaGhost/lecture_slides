package model;

import java.util.Vector;

import view.Simulatable;

public class PlanetSystem implements Simulatable {
	
	Vector<Planet> planets;

	public Vector<Planet> getPlanets() {
		return planets;
	}

	public PlanetSystem() {
		planets = new Vector<Planet>();
	}
	
	public void reset() {
		for(Planet p: planets) {
			p.reset();
		}
	}
	
	public void step(double  dt){
		for (Planet p: planets) {
			p.stepFirst(dt);
		}
		for (Planet p: planets) {
			p.stepSecond(dt);
		}
	}
	
	public void addPlanet(Planet p) {
		planets.addElement(p);
	}
	
}