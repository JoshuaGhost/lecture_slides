package model;

import java.util.function.*;

public class SymplecticEuler {

	static double integrateFirstPart(double x0, double xprime0, double dt) {
		return x0 + dt * xprime0;
	}
	
	static double integrateSecondPart(Function<Double, Double> dgl, double x1, double xprime0, double dt) {
		return xprime0 + dt * dgl.apply(x1);
	}

	static double integrateSecondPart(double a, double x1, double xprime0, double dt) {
		return xprime0 + dt * a;
	}
	
	static double[] integrate(Function<Double, Double> dgl, double x0, double xprime0, double dt) {
		double[] result = new double[2];
		
		double x1 = x0 + dt * xprime0;
		double xprime1 = xprime0 + dt * dgl.apply(x1);
		
		result[0] = x1;
		result[1] = xprime1;
		
		return result;
	}
}
