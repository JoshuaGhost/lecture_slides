package model;

import java.util.Vector;
import java.util.function.Function;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.paint.Color;

public class FluidParticle {

	static Function<Double, Double> ljPot = (Double r) -> {
		return (20.0 / Math.pow(r, 3)) - (8.0 / Math.pow(r, 5));
	};
	
	static double gravitation = 1.5;

	private static Color color = Color.BLUE;

	
	//Position
	SimpleDoubleProperty x;
	SimpleDoubleProperty y;
	
	double vx=0;
	double vy=0;
	
	double Fx=0;
	double Fy=0;
	
	Fluid fluid;
	double mass=1;

	
	public FluidParticle(double x, double y) {
		this.x = new SimpleDoubleProperty(x);
		this.y = new SimpleDoubleProperty(y);
	}
	
	Function<Double, Double> dglx = (Double x) -> {
		return (Fx / mass);
	};
	Function<Double, Double> dgly = (Double x) -> {
		return (Fy / mass);
	};
	
	
	public void stepFirst(double dt) {
		x.set(SymplecticEuler.integrateFirstPart(x.get(), vx, dt));
		y.set(SymplecticEuler.integrateFirstPart(y.get(), vy, dt));
	}
	
	public void stepSecond(double dt) {
		calculateForce();
		
		vx = SymplecticEuler.integrateSecondPart(dglx, x.get(), vx, dt);
		vy = SymplecticEuler.integrateSecondPart(dgly, y.get(), vy, dt);
	}
	
	public void calculateForce() {
		Vector<FluidParticle> particles =  fluid.getParticles();	
		Fx =0;
		Fy = 0;	

		for (FluidParticle p: particles) {
			if (!this.equals(p)) {
				double f = getForcePart(p);

				double xp =  p.getX() - getX();
				double yp =  p.getY() - getY();
				
				Fx += f *xp;
				Fy += f * yp;
			}
		}
		Fy +=gravitation;
		
		double sideLimit = 2*gravitation;
		double downLimit = 2*gravitation;
		double upLimit = -0.0*gravitation;
		if (Fy < upLimit)  Fy = upLimit;
		if (Fx > sideLimit) Fx = sideLimit;
		if (Fx < -sideLimit) Fx = -sideLimit;
		if (Fy > downLimit) Fy = downLimit;

	
	}
	
	
	public double getForcePart(FluidParticle other) {
		double dist = dist(other)/1.8;
		if (dist==0) return 0;
		
		double f = ljPot.apply(dist) / dist;
		
		if (other instanceof FixedFluidParticle) {
			f *= 1.75;
		}
		return f;
	}
	
	private double dist(FluidParticle other) {
		return Math.sqrt(Math.pow(this.x.get() - other.getX(), 2) + Math.pow(this.y.get() - other.getY(), 2));
	}

	public double getX() {
		return x.get();
	}

	public double getY() {
		return y.get();
	}

	public SimpleDoubleProperty getXProperty() {
		return x;
	}

	public SimpleDoubleProperty getYProperty() {
		return y;
	}

	public Color getColor() {
		return color;
	}

	public void setFluid(Fluid fluid) {
		this.fluid = fluid;
	}	
	
	
}
