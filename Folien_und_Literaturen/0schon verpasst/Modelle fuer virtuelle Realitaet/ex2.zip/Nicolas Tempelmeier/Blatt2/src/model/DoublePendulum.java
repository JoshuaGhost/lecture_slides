package model;

import java.util.function.Function;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import view.Simulatable;
import model.SymplecticEuler;

public class DoublePendulum implements Simulatable {
	
	//Observables
	DoubleProperty x0;
	DoubleProperty y0;
	DoubleProperty x1;
	DoubleProperty y1;
	DoubleProperty x2;
	DoubleProperty y2;
	DoubleProperty x1Start;
	DoubleProperty y1Start;
	DoubleProperty x2Start;
	DoubleProperty y2Start;
	DoubleProperty D = new SimpleDoubleProperty(1000);
		
	//Interne Variablen
	double l1;
	double l2;
	double vx1=0;
	double vy1=0;
	double Fx1;
	double Fy1;
	
	double vx2=0;
	double vy2=0;
	double Fx2;
	double Fy2;
	
	 Function<Double, Double> springEq = (Double x) -> {
		return (-D.get() * x);
	 };
	
	public DoublePendulum(double x0, double y0, double x1, double y1, double x2, double y2) {
		this.x0 = new SimpleDoubleProperty(x0);
		this.y0 = new SimpleDoubleProperty(y0);
		
		this.x1Start = new SimpleDoubleProperty(x1);
		this.y1Start = new SimpleDoubleProperty(y1);
		this.x2Start = new SimpleDoubleProperty(x2);
		this.y2Start = new SimpleDoubleProperty(y2);
		this.x1 = new SimpleDoubleProperty();
		this.y1 = new SimpleDoubleProperty();
		this.x2 = new SimpleDoubleProperty();
		this.y2 = new SimpleDoubleProperty();
		
		
		this.reset();



	}
	
	public void reset() {
		x1.set(x1Start.get());
		y1.set(y1Start.get());
		x2.set(x2Start.get());
		y2.set(y2Start.get());
		l1 = Math.sqrt(Math.pow(x0.get()-x1.get(), 2) + Math.pow(y0.get()-y1.get(), 2));
		l2 = Math.sqrt(Math.pow(x1.get()-x2.get(), 2) + Math.pow(y1.get()-y2.get(), 2));
		Fx1=0;
		Fx2=0;
		Fy1=0;
		Fy2=2;
		vx1=0;
		vx2=0;
		vy1=0;
		vy2=0;
	}
	
	
	public void calculateForce() {
		//Federkraft
		double dist1 = Math.sqrt(Math.pow(x0.get()- x1.get(), 2) + Math.pow(y0.get() - y1.get(), 2));
		double f1 = springEq.apply(dist1-l1);
		Fx1 = (x1.get()- x0.get()) / dist1 * f1;
		Fy1 = (y1.get() - y0.get()) / dist1 * f1;
		
		double dist2 = Math.sqrt(Math.pow(x1.get()- x2.get(), 2) + Math.pow(y1.get() - y2.get(), 2));
		double f2 = springEq.apply(dist2-l2);
		Fx2 = (x2.get()- x1.get()) / dist2 * (f2 / 2);
		Fy2 = (y2.get() - y1.get()) / dist2 * (f2 / 2);
		
		Fx1 += (x1.get()- x2.get()) / dist2 * (f2 / 2);
		Fy1 += (y1.get()- y2.get()) / dist2 * (f2 / 2);

		
		//Schwerkraft
		Fy1 += 20;
		Fy2 += 20;
	}
	
	
	public void step(double dt) {
		x1.setValue(SymplecticEuler.integrateFirstPart(x1.get(), vx1, dt));
		y1.setValue(SymplecticEuler.integrateFirstPart(y1.get(), vy1, dt));
		x2.setValue(SymplecticEuler.integrateFirstPart(x2.get(), vx2, dt));
		y2.setValue(SymplecticEuler.integrateFirstPart(y2.get(), vy2, dt));

		calculateForce();
		
		vx1 = SymplecticEuler.integrateSecondPart(Fx1, x1.get(), vx1, dt);
		vy1 = SymplecticEuler.integrateSecondPart(Fy1, y1.get(), vy1, dt);
		vx2 = SymplecticEuler.integrateSecondPart(Fx2, x2.get(), vx2, dt);
		vy2 = SymplecticEuler.integrateSecondPart(Fy2, y2.get(), vy2, dt);
	}


	public DoubleProperty getX0Prop() {
		return x0;
	}


	public DoubleProperty getY0Prop() {
		return y0;
	}


	public DoubleProperty getX1StartProperty() {
		return x1Start;
	}


	public DoubleProperty getY1StartProperty() {
		return y1Start;
	}


	public DoubleProperty getX2StartProperty() {
		return x2Start;
	}


	public DoubleProperty getY2StartProperty() {
		return y2Start;
	}
	
	public DoubleProperty getDProperty() {
		return D;
	}
	
	public DoubleProperty getX1Prop() {
		return x1;
	}


	public DoubleProperty getY1Prop() {
		return y1;
	}


	public DoubleProperty getX2Prop() {
		return x2;
	}


	public DoubleProperty getY2Prop() {
		return y2;
	}
	
	
}
