package model;

import java.util.function.Function;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import view.Simulatable;
import model.SymplecticEuler;

public class Pendulum implements Simulatable {


	
	//Observables
	DoubleProperty x0;
	DoubleProperty y0;
	DoubleProperty x1;
	DoubleProperty y1;
	DoubleProperty x1Start;
	DoubleProperty y1Start;
	DoubleProperty D = new SimpleDoubleProperty(1300);
	
	//interne Werte	
	double l1;
	double vx1=0;
	double vy1=0;
	double Fx1;
	double Fy1;
	
	Function<Double, Double> springEq = (Double x) -> {
		return (-D.get() * x);
};
	
	public Pendulum(double x0, double y0, double x1, double y1) {
		this.x0 = new SimpleDoubleProperty(x0);
		this.y0 = new SimpleDoubleProperty(y0);
		this.x1 = new SimpleDoubleProperty();
		this.y1 = new SimpleDoubleProperty();
		this.x1Start  = new SimpleDoubleProperty(x1);
		this.y1Start  = new SimpleDoubleProperty(y1);
		this.reset();
	}
	
	public void reset() {
		x1.set(x1Start.get());
		y1.set(y1Start.get());
		vx1=0;
		vy1=0;
		Fx1=0;
		Fy1=0;
		l1 = Math.sqrt(Math.pow(x0.get()-x1.get(), 2) + Math.pow(y0.get()-y1.get(), 2));

	}
	
	
	public void calculateForce() {
		//Federkraft
		double dist1 = Math.sqrt(Math.pow(x0.get()- x1.get(), 2) + Math.pow(y0.get() - y1.get(), 2));
		double f1 = springEq.apply(dist1-l1);
		Fx1 = (x1.get()- x0.get()) / dist1 * f1;
		Fy1 = (y1.get() - y0.get()) / dist1 * f1;
		
		//Schwerkraft
		Fy1 += 20;
	}
	
	
	public void step(double dt) {
		x1.setValue(SymplecticEuler.integrateFirstPart(x1.get(), vx1, dt));
		y1.setValue(SymplecticEuler.integrateFirstPart(y1.get(), vy1, dt));

		calculateForce();
		
		vx1 = SymplecticEuler.integrateSecondPart(Fx1, x1.get(), vx1, dt);
		vy1 = SymplecticEuler.integrateSecondPart(Fy1, y1.get(), vy1, dt);
	}


	public DoubleProperty getX0Prop() {
		return x0;
	}


	public DoubleProperty getY0Prop() {
		return y0;
	}


	public DoubleProperty getX1Prop() {
		return x1;
	}


	public DoubleProperty getY1Prop() {
		return y1;
	}

	public DoubleProperty getX1StartProperty() {
		return x1Start;
	}
	
	public DoubleProperty getY1StartProperty() {
		return y1Start;
	}
	public DoubleProperty getDProperty() {
		return D;
	}
}

	
	