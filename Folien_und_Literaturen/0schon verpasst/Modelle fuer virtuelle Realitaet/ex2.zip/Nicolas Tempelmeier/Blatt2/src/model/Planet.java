package model;

import java.util.Vector;
import java.util.function.Function;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

public class Planet {
	
	//Gravitationskonstante
	static double G = 3.189;
	
	PlanetSystem pSystem;
	
	//Observable
	SimpleDoubleProperty x;
	SimpleDoubleProperty y;
	SimpleDoubleProperty vStart;
	
	//Geschwindigkeit
	double vx;
	double vy;
	
	//Gravitation
	double Fx;
	double Fy;
	
	double mass;
	
	
	//Startwerte
	double xStart;
	double yStart;
	double vxStart;
	double vyStart;
	double massStart;
	
	// DGL fuer die Beschleunigung
	Function<Double, Double> dglx = (Double x) -> {
		return (Fx / mass);
	};
	Function<Double, Double> dgly = (Double x) -> {
		return (Fy / mass);
	};
	
	
	public Planet(PlanetSystem pSystem, double x, double y, double vx,
			double vy, double mass) {
		super();
		this.pSystem = pSystem;
		this.x = new SimpleDoubleProperty();
		this.y = new SimpleDoubleProperty();
		this.vStart = new SimpleDoubleProperty();
		xStart=x;
		yStart=y;
		vxStart=vx;
		vyStart=vy;
		vStart.set(Math.sqrt(Math.pow(vx, 2) + Math.pow(vy, 2)));
		massStart=mass;
				
		this.reset();

	}

	
	public void reset() {
		x.set(xStart);
		y.set(yStart);
		vx=vxStart;
		vy=vyStart;
		calcPartVelocities();
		mass=massStart;
		Fx=0;
		Fy=0;
	}
	

	public void stepFirst(double dt) {
		x.set(SymplecticEuler.integrateFirstPart(x.get(), vx, dt));
		y.set(SymplecticEuler.integrateFirstPart(y.get(), vy, dt));

	}

	public void stepSecond(double dt) {
		calculateGravitation();
		
		vx  = SymplecticEuler.integrateSecondPart(dglx, x.get(), vx, dt);
		vy  = SymplecticEuler.integrateSecondPart(dgly, y.get(), vy, dt);

	}
	
	public void step(double dt) {
		calculateGravitation();
		double[] newX = SymplecticEuler.integrate(dglx, x.get(), vx, dt);
		double[] newY = SymplecticEuler.integrate(dgly, y.get(), vy, dt);
		
		x.set(newX[0]);
		vx = newX[1];
		y.set(newY[0]);
		vy = newY[1];
	}
	
	private void calculateGravitation() {
		Vector<Planet> planets = pSystem.getPlanets();
		
		double[] result = {0, 0};
		
		for (Planet p: planets) {
			if (!p.equals(this)) {
				double[] grav = getGravitationPart(p);
				result[0] = result[0] + grav[0];
				result[1] = result[1] + grav[1];
			}
		}
		Fx = result[0];
		Fy = result[1];
		
		
		double limit = 20 * G;
		if (Fx > 10*G)  Fx = limit;
		if (Fx < -10*G)  Fx = -limit;
		if (Fy > 10*G)  Fy = limit;
		if (Fy < -10*G)  Fy = -limit;



	}
	
	private double dist(Planet other) {
		return Math.sqrt(Math.pow(this.x.get() - other.getX(), 2) + Math.pow(this.y.get() - other.getY(), 2));
	}


	private double[] getGravitationPart(Planet other) {
		double dist = this.dist(other);
		double F = G * this.mass * other.getMass() / Math.pow(dist, 2);
		
		double xpart = (other.getX() - this.x.get()) / dist;
		double ypart = (other.getY() - this.y.get()) /dist;
		
		double[] result = {F*xpart, F*ypart};

		return result;
		
	}
	
	//Nur nach GUI-updates genutzt
	public void calcPartVelocities() {
		double sum = Math.sqrt(Math.pow(vx, 2) + Math.pow(vy, 2));
		if (sum !=0) { 
			double xpart = vx/sum;
			double ypart = vy/sum;
			
			vx = vStart.get()*xpart;
			vy = vStart.get()*ypart;		
		}
		

	}
	
	
	public double getX() {
		return x.get();
	}


	public double getY() {
		return y.get();
	}
	
	public DoubleProperty xProp() {
		return x;
	}
	
	public DoubleProperty yProp() {
		return y;
	}
	
	public double getMass() {
		return mass;
	}


	public void setMass(double mass) {
		this.mass = mass;
	}
	
	public DoubleProperty getVStartProperty() {
		return vStart;
	}
}
