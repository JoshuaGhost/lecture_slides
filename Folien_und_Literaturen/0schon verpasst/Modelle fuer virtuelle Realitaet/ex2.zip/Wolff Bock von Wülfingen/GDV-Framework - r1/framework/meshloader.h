#ifndef MESHLOADER_H
#define MESHLOADER_H
/**
 ** meshloader.h - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/


#include <QString>
#include <QVector>
#include "interfaces/Tuple3.h"


/**
 * @brief Die MeshLoader Klasse
 *
 * Ein (sehr einfacher) PLY-Datei Parser. Unterstüzt momentan NUR Dateien,
 * die mit Blender exportiert wurden und Vertex-Farben UND UV-Koordinaten
 * besitzen.
 *
 * Die Face / VertexInfo Structs werden der RendererBase-Instanz im meshChanged
 * Aufruf übergeben.
 *
 * Interne Klasse, bitte nicht direkt einbinden und/oder verändern!
 */
class MeshLoader
{
public:
    struct VertexInfo
    {
        float x, y, z;      // Position des Vertex
        float nx, ny, nz;   // Normale
        float u, v;         // UV-Coordinaten (Texturkoordinaten)
        float r, g, b;      // Farbe (Bereich: 0.0 ... 1.0)
    };

    typedef Tuple3<VertexInfo> Face;

    MeshLoader();
    MeshLoader(const QString& fileName);

    void parseFile();
    bool isValid() const;

    const QVector<Face>& faces() const;

private:
    QVector<Face> _faces;
    bool _valid;
    QString fileName;
};

#endif // MESHLOADER_H
