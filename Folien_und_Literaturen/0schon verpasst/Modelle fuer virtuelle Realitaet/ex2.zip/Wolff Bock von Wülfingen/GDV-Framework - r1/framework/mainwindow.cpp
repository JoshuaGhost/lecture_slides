/**
 ** mainwindow.cpp - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "slotmapper.h"

#include <QCheckBox>
#include <QSlider>
#include <QLabel>
#include <QFrame>

#include <QDebug>
#include "interfaces/RendererBase.h"
#include "framework/gdvcanvas2d.h"
#include "framework/gdvcanvas3d.h"

#include <QDir>
#include <QGLWidget>
#include <QColorDialog>
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    perfCount(0.025f)
{
    ui->setupUi(this);
    this->setWindowTitle(qApp->applicationName() + " - " + qApp->applicationVersion());

    guiUpdate.setInterval(50);
    guiUpdate.start();

    connect(ui->comboClass, SIGNAL(activated(int)), this, SLOT(activateLecture(int)));
    connect(ui->comboMesh, SIGNAL(activated(int)), this, SLOT(activateMesh(int)));
    connect(ui->comboTexture, SIGNAL(activated(int)), this, SLOT(activateTexture(int)));

    redrawUpdate.setInterval(0);
    redrawUpdate.start();
    connect(&redrawUpdate, SIGNAL(timeout()), this, SLOT(redraw()));

    currentLecture = 0;
    enableGL = false;

    scrollBase = new QWidget();
    scrollBase->setLayout(&userWidgets);
    ui->scrollArea->setWidgetResizable(true);
    ui->scrollArea->setWidget(scrollBase);

    canvas2D = new GdvCanvas2D();
    ui->splitter->addWidget(canvas2D);
    canvas2D->hide();

    QGLFormat glFormat;
    glFormat.setVersion( 3, 2 );
    glFormat.setProfile( QGLFormat::CoreProfile ); // Requires >=Qt-4.8.0

    canvas3D = new GdvCanvas3D(glFormat);
    ui->splitter->addWidget(canvas3D);
    canvas3D->hide();

    ui->scrollArea->setMaximumWidth(400);
    ui->scrollArea->setMinimumWidth(200);



    connect(canvas2D, SIGNAL(sizeChanged(int,int)), this, SLOT(resized(int,int)));
    connect(canvas3D, SIGNAL(sizeChanged(int,int)), this, SLOT(resized(int,int)));
    connect(&guiUpdate, SIGNAL(timeout()), this, SLOT(showFPS()));

    connect(canvas2D, SIGNAL(mouseMoved(int,int)), this, SLOT(mouseMoved(int,int)));
    connect(canvas2D, SIGNAL(mousePressed(int,int)), this, SLOT(mousePressed(int,int)));
    connect(canvas2D, SIGNAL(mouseReleased(int,int)), this, SLOT(mouseReleased(int,int)));
    connect(canvas2D, SIGNAL(wheelMoved(int)), this, SLOT(wheelMoved(int)));

    connect(canvas3D, SIGNAL(mouseMoved(int,int)), this, SLOT(mouseMoved(int,int)));
    connect(canvas3D, SIGNAL(mousePressed(int,int)), this, SLOT(mousePressed(int,int)));
    connect(canvas3D, SIGNAL(mouseReleased(int,int)), this, SLOT(mouseReleased(int,int)));
    connect(canvas3D, SIGNAL(wheelMoved(int)), this, SLOT(wheelMoved(int)));

    populateMeshList();
    populateTextureList();
}

MainWindow::~MainWindow()
{
    clearElements();

    if(currentLecture)
        currentLecture->deinitialize();

    currentLecture = 0;

    foreach(RendererBase* r, allLectures)
    {
        delete r;
    }
    delete ui;
}

void MainWindow::addCheckBox(QString label, bool defaultValue, bool& mappedValue)
{
    mappedValue = defaultValue;
    QCheckBox* element = new QCheckBox(label);
    element->setChecked(defaultValue);
    SlotMapper* map = new SlotMapper(mappedValue);
    connect(element, SIGNAL(toggled(bool)), map, SLOT(mapBool(bool)));
    connect(map, SIGNAL(boolChanged(bool)), element, SLOT(setChecked(bool)));
    connect(&guiUpdate, SIGNAL(timeout()), map, SLOT(mapToWidget()));

    activeUserWidgets.append(element);
    qObjectMappings.append(map);

    userWidgets.addWidget(element);
}

void MainWindow::addColorSelector(QString label, QVector3D defaultValue, QVector3D& mappedValue)
{
    mappedValue = defaultValue;
    QPushButton* element = new QPushButton(label);
    SlotMapper* map = new SlotMapper(mappedValue);
    QColorDialog* dialog = new QColorDialog();
    dialog->setWindowTitle(QString("Change color: ") + label);

    connect(element, SIGNAL(clicked()), dialog, SLOT(show()));
    connect(dialog, SIGNAL(currentColorChanged(QColor)), map, SLOT(mapColor(QColor)));
    connect(map, SIGNAL(styleSheetChanged(QString)), element, SLOT(setStyleSheet(QString)));
    connect(&guiUpdate, SIGNAL(timeout()), map, SLOT(mapToWidget()));

    activeUserWidgets.append(element);
    activeUserWidgets.append(dialog);
    qObjectMappings.append(map);

    userWidgets.addWidget(element);

    map->mapColor(QColor::fromRgb(mappedValue.x()*255, mappedValue.y()*255, mappedValue.z()*255));
}

void MainWindow::addSlider(QString label, int minimalValue, int maximalValue, int defaultValue, int& mappedValue)
{
    mappedValue = defaultValue;
    addLabel(label, "");
    QSlider* element = new QSlider(Qt::Horizontal);
    element->setMinimum(minimalValue);
    element->setMaximum(maximalValue);
    element->setValue(defaultValue);
    SlotMapper* map = new SlotMapper(mappedValue);
    connect(element, SIGNAL(valueChanged(int)), map, SLOT(mapInteger(int)));
    connect(map, SIGNAL(intChanged(int)), element, SLOT(setValue(int)));
    connect(&guiUpdate, SIGNAL(timeout()), map, SLOT(mapToWidget()));

    activeUserWidgets.append(element);
    qObjectMappings.append(map);

    userWidgets.addWidget(element);
}

void MainWindow::addLabel(QString defaultValue, QString& mappedValue, QString styleSheet)
{
    mappedValue = defaultValue;
    QLabel* element = new QLabel(defaultValue);
    SlotMapper* map = new SlotMapper(mappedValue);
    connect(map, SIGNAL(stringChanged(QString)), element, SLOT(setText(QString)));
    connect(&guiUpdate, SIGNAL(timeout()), map, SLOT(mapToWidget()));

    activeUserWidgets.append(element);
    qObjectMappings.append(map);

    userWidgets.addWidget(element);
    element->setStyleSheet(styleSheet);
}

void MainWindow::addLabel(QString value, QString styleSheet)
{
    QLabel* element = new QLabel(value);
    activeUserWidgets.append(element);
    userWidgets.addWidget(element);
    element->setStyleSheet(styleSheet);
}

void MainWindow::addSeparator()
{
    QFrame* element = new QFrame();
    element->setFrameShape(QFrame::HLine);
    element->setFrameShadow(QFrame::Sunken);

    activeUserWidgets.append(element);
    userWidgets.addWidget(element);
}

void MainWindow::clearElements()
{
    foreach(SlotMapper* s, qObjectMappings)
    {
        s->deleteLater();
    }

    qObjectMappings.clear();

    foreach(QWidget* w, activeUserWidgets)
    {
        w->deleteLater();
    }

    activeUserWidgets.clear();

    qApp->processEvents();

    QLayoutItem* item;
    while((item = userWidgets.takeAt(0)) != 0)
    {
        delete item;
    }
}

void MainWindow::addLecture(QString identifier, RendererBase *renderer)
{
    allLectures.append(renderer);
    ui->comboClass->addItem(identifier);
}

void MainWindow::setDefaultIndices(unsigned int lecture, unsigned int mesh, unsigned int texture)
{
    ui->comboClass->setCurrentIndex(lecture);
    ui->comboMesh->setCurrentIndex(mesh);
    ui->comboTexture->setCurrentIndex(texture);

    activateLecture(ui->comboClass->currentIndex());
}

void MainWindow::activateLecture(int index)
{
    if(index < 0)
    {
        qWarning() << "Invalid lecture-index specified. No class activated.";
        return;
    }

    qDebug() << "Activated lecture no." << index;

    if(currentLecture)
    {
        clearElements();
        currentLecture->deinitialize();
    }

    currentLecture = allLectures.at(index);

    if(currentLecture->usesOpenGL())
    {
        canvas2D->hide();
        canvas3D->show();
    }
    else
    {
        canvas2D->show();
        canvas3D->hide();
    }


    enableGL = currentLecture->usesOpenGL();
    currentLecture->setupGUI(*this);
    currentLecture->initialize();
    userWidgets.addStretch();

    if(currentLecture->usesOpenGL())
        currentLecture->sizeChanged(canvas3D->width(), canvas3D->height());
    else
        currentLecture->sizeChanged(canvas2D->width(), canvas2D->height());

    // Reload the current mesh
    activateMesh(ui->comboMesh->currentIndex());
    activateTexture(ui->comboTexture->currentIndex());
    perfCount.reset();
}

void MainWindow::redraw()
{
    if(currentLecture && !currentLecture->usesOpenGL())
    {
        perfCount.startFrame();
        currentLecture->render(*canvas2D);
        perfCount.stopFrame();

        canvas2D->repaint();
    }

    if(currentLecture && currentLecture->usesOpenGL())
    {
        perfCount.startFrame();
        currentLecture->render(*canvas3D);
        perfCount.stopFrame();

        canvas3D->repaint();
    }
}

void MainWindow::resized(int width, int height)
{
    if(width > 0 && height > 0)
    {
    if(currentLecture)
        currentLecture->sizeChanged(width, height);

    perfCount.reset();
    }
}

void MainWindow::mousePressed(int x, int y)
{
    if(currentLecture)
        currentLecture->mousePressed(x, y);
}

void MainWindow::mouseReleased(int x, int y)
{
    if(currentLecture)
        currentLecture->mouseReleased(x, y);
}

void MainWindow::mouseMoved(int x, int y)
{
    if(currentLecture)
        currentLecture->mouseMoved(x, y);
}

void MainWindow::wheelMoved(int delta)
{
    if(currentLecture)
        currentLecture->wheelMoved(delta);
}

void MainWindow::activateMesh(int index)
{
    if(index < 0)
    {
        qWarning() << "Invalid mesh-index specified. No mesh activated.";
        return;
    }

    if(meshes.count() == 0)
    {
        qCritical() << "Error: No meshes were found. Please make sure you copied the 'meshes' folder to the location of the binary.";
        return;
    }

    if(index > meshes.count())
    {
        qCritical() << "Internal Error: Mesh-Index out of range. Please report to <atarnows@welfenlab.de>";
        return;
    }

    if(!meshes.at(index).isValid())
        meshes[index].parseFile();

    if(currentLecture)
    {
        qDebug() << "Changing mesh to" << ui->comboMesh->itemText(index)
                 << "containing" << meshes[index].faces().size() << "faces.";
        currentLecture->meshChanged(meshes[index].faces());
    }

}

void MainWindow::activateTexture(int index)
{
    if(index < 0)
    {
        qWarning() << "Invalid texture-index specified. No texture activated.";
        return;
    }

    if(textures.count() == 0)
    {
        qCritical() << "Error: No textures were found. Please make sure you copied the 'textures' folder to the location of the binary.";
        return;
    }

    if(index > textures.count())
    {
        qCritical() << "Internal Error: Texture-Index out of range. Please report to <atarnows@welfenlab.de>";
        return;
    }

    if(currentLecture)
    {
        qDebug() << "Changing texture to" << ui->comboTexture->itemText(index) << ".";
        if(currentLecture->usesOpenGL())
            currentLecture->textureChanged(QGLWidget::convertToGLFormat(textures[index]));
        else
            currentLecture->textureChanged(textures[index]);
    }
}

void MainWindow::populateMeshList()
{
    // We will search in the actual
    qDebug() << "Populating mesh-list...";
    meshes.clear();
    ui->comboMesh->clear();

    QDir searchDir("meshes/");
    QStringList nameFilters;
    nameFilters << "*.ply" << "*.PLY";
    searchDir.setNameFilters(nameFilters);
    QStringList allMeshFiles = searchDir.entryList(QDir::Files | QDir::NoDotAndDotDot | QDir::Readable, QDir::Name | QDir::IgnoreCase);

    foreach(QString file, allMeshFiles)
    {
        meshes.append(MeshLoader(QString("meshes/") + file));
        qDebug() << "Added" << file;
        file.truncate(file.length()-4);
        ui->comboMesh->addItem(file);
    }

}

void MainWindow::populateTextureList()
{
    qDebug() << "Populating texture-list...";
    textures.clear();
    ui->comboTexture->clear();

    QDir searchDir("textures/");
    QStringList nameFilters;
    nameFilters << "*.png" << "*.jpg" << "*.jpeg" << "*.bmp";
    searchDir.setNameFilters(nameFilters);
    QStringList allTextureFiles = searchDir.entryList(QDir::Files | QDir::NoDotAndDotDot | QDir::Readable, QDir::Name | QDir::IgnoreCase);

    foreach(QString file, allTextureFiles)
    {
        QImage t(QString("textures/") + file);
        t = t.convertToFormat(QImage::Format_RGB32);
        textures.append(t);
        qDebug() << "Added" << file;
        file.truncate(file.length()-4);
        ui->comboTexture->addItem(file);
    }
}

void MainWindow::showFPS()
{
    ui->labelFPS->setText(QString("FPS:\t") + QString::number(perfCount.currentFPS(), 'f', 2)
                                     + "\t" + QString::number(perfCount.totalAverageFPS(), 'f', 2));
}

void MainWindow::drawGLCall()
{
    if(currentLecture && currentLecture->usesOpenGL())
        currentLecture->render(*canvas3D);
}
