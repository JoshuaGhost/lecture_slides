#ifndef POTENTIALFLUID_H
#define POTENTIALFLUID_H

#include "../vrbase.h"

class Potentialfluid : public VRBase
{
public:
    Potentialfluid();
    virtual ~Potentialfluid();

    virtual void setupGUI(GdvGui& userInterface);
    virtual void render(GdvCanvas& canvas);
    virtual void initialize();
    virtual void deinitialize();

    virtual void mousePressed(int x, int y);
    virtual void drawBig(GdvCanvas& canvas, int x, int y,QVector3D color);

    float damping = 0.0f;
    float gravitation;

    QList<QVector2D> position;
    QList<QVector2D> velocity;
    QList<QVector2D> currentForce;
    QList<QVector2D> connections;

    int fixedParticles = 0;

    void recalcSystem(float tpf);
    float timeRemainder = 0;
    bool hasStarted = false;

    QVector3D adhesionColor;

    float LennardJones(float r);
};

#endif // POTENTIALFLUID_H
