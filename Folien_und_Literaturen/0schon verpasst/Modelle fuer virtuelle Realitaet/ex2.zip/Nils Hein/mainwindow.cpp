#include "doppelpendelsim.h"
#include "fluid.h"
#include "mainwindow.h"
#include "vergleichspendelsim.h"
#include "planeten.h"
#include "ui_mainwindow.h"
#include "federpendel.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    simList.append(new FederPendel());
    ui->cmbSim->addItem("Pendel");

    simList.append(new VergleichsPendelSim());
    ui->cmbSim->addItem("VPendel");

    simList.append(new DoppelPendelSim());
    ui->cmbSim->addItem("Doppelpendel");

    simList.append(new Planeten());
    ui->cmbSim->addItem("Planete");

    simList.append(new Fluid());
    ui->cmbSim->addItem("Fluid");

    connect(ui->btnStart,SIGNAL(clicked()), this, SLOT(Start()));
    connect(ui->btnStop,SIGNAL(clicked()), this, SLOT(Stop()));
    connect(ui->btnReset,SIGNAL(clicked()), this, SLOT(Reset()));

    ui->graphicsView->scale(2,2);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::upd()
{
    simList.at(ui->cmbSim->currentIndex())->Upd(dt);
    ui->graphicsView->centerOn(0,0);
}

void MainWindow::Start()
{
    if(timer == 0){
        Reset();
    }
    if(!timer->isActive()){
        dt = ui->sbDt->value();
        timer->start(1);
    }
}

void MainWindow::Stop()
{
    if(timer != 0){
        timer->stop();
    }
}

void MainWindow::Reset()
{
    Stop();
    int index = ui->cmbSim->currentIndex();
    simList.clear();
    ui->cmbSim->clear();

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(upd()));

    simList.append(new FederPendel());
    ui->cmbSim->addItem("Pendel");

    simList.append(new VergleichsPendelSim());
    ui->cmbSim->addItem("VPendel");

    simList.append(new DoppelPendelSim());
    ui->cmbSim->addItem("Doppelpendel");

    simList.append(new Planeten());
    ui->cmbSim->addItem("Planete");

    simList.append(new Fluid());
    ui->cmbSim->addItem("Fluid");

    ui->cmbSim->setCurrentIndex(index);
    simList.at(ui->cmbSim->currentIndex())->Init();
    //simList.at(0)->getScene()->setSceneRect(ui->graphicsView->geometry());

    ui->graphicsView->setScene(simList.at(ui->cmbSim->currentIndex())->getScene());
    //ui->graphicsView->setSceneRect(0);
}
