#include "doppelpendelsim.h"
#include "math.h"
DoppelPendelSim::DoppelPendelSim()
{

}

DoppelPendelSim::~DoppelPendelSim()
{

}

void DoppelPendelSim::Init()
{
    QBrush brush;
    brush.setColor(Qt::black);
    brush.setStyle(Qt::SolidPattern);

    scene = new QGraphicsScene();
    scene->setSceneRect(-50,-50,100,100);
    kreis->setBrush(brush);
    kreis2->setBrush(brush);

    scene->addItem(kreis);
    scene->addItem(line);
    scene->addItem(kreis2);
    scene->addItem(line2);

    curv = 0.0;
    curx = M_PI_2;
    t.append(0.0);
    y.append(curx);
}

void DoppelPendelSim::Upd(double dt)
{
    double g = 9.798;
    double l = 50;
    double k = g/l;

    double newv = ((-k*sin(curx)))*dt + curv;
    double newx = curx+(newv)*dt;
    curv = newv;
    curx = newx;

    t.append(t.last()+dt);
    y.append(newx);

//    ui->customPlot->graph(0)->setData(t,y);
//    ui->customPlot->replot();

    kreis->setPos(l*sin(curx)-5,l*cos(curx)-5);
    kreis2->setPos((l*sin(curx)-5)+kreis->pos().x(),(l*cos(curx)-5)+kreis->pos().y());
    QPointF p = kreis->pos();
    line->setLine(0,0,p.x()+5,p.y()+5);
}

QGraphicsScene *DoppelPendelSim::getScene()
{
    return scene;
}

