#ifndef FEDERPENDEL_H
#define FEDERPENDEL_H

#include "isimbase.h"

#include <QGraphicsEllipseItem>
#include <QVector2D>



class FederPendel : public ISimBase
{
public:
    FederPendel();
    ~FederPendel();

    // ISimBase interface
public:
    void Init();
    void Upd(double dt);
    QGraphicsScene *getScene();

    QGraphicsScene *scene;

    QGraphicsEllipseItem* kreis = new QGraphicsEllipseItem(0,0,10,10);
    QGraphicsLineItem* line = new QGraphicsLineItem(0,0,0,0);

    QVector2D vel = QVector2D(0,0);
    QVector2D force = QVector2D(0,0);
    QVector2D pos = QVector2D(50,0);
};

#endif // FEDERPENDEL_H
