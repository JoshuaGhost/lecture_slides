#ifndef DOPPELPENDELSIM_H
#define DOPPELPENDELSIM_H

#include "isimbase.h"

#include <QGraphicsItem>


class DoppelPendelSim : public ISimBase
{
public:
    DoppelPendelSim();
    ~DoppelPendelSim();

    // ISimBase interface
public:
    void Init();
    void Upd(double dt);
    QGraphicsScene *getScene();
protected:
    QGraphicsScene *scene;

    QGraphicsEllipseItem* kreis = new QGraphicsEllipseItem(0,0,10,10);
    QGraphicsLineItem* line = new QGraphicsLineItem(0,0,0,0);

    QVector<double> t,y;

    double curx;
    double curv;

    QGraphicsEllipseItem* kreis2 = new QGraphicsEllipseItem(0,0,10,10);
    QGraphicsLineItem* line2 = new QGraphicsLineItem(0,0,0,0);
};

#endif // DOPPELPENDELSIM_H
