#ifndef FLUID_H
#define FLUID_H

#include "isimbase.h"

#include <QGraphicsEllipseItem>
#include <QVector2D>


class Particle{
public:
    Particle(double x, double y, double mass){
        img = new QGraphicsEllipseItem(x-(mass*0.5),y-(mass*0.5),mass,mass);
        pos = QVector2D(x,y);
        img->setPos(pos.x()-(mass*0.5),pos.y()-(mass*0.5));
        this->mass = mass;
        this->vel = QVector2D(0,0);
        this ->force = QVector2D(0,0);
        this->fix = false;
    }
    void upd(double dt){
        vel = (force*dt)+vel;
        pos = (vel*dt)+pos;
        img->setPos(pos.x()-(mass*0.5),pos.y()-(mass*0.5));
    }
    QGraphicsEllipseItem *img;
    QVector2D pos;
    double mass;
    QVector2D force;
    QVector2D vel;
    bool fix;
};
class Fluid : public ISimBase
{
public:
    Fluid();
    ~Fluid();

    // ISimBase interface
public:
    void Init();
    void Upd(double dt);
    QGraphicsScene *getScene();
    double lenn(double r);

protected:
    QGraphicsScene *scene;

    QVector<Particle*> particles;

    QVector<double> t,y;

    double curx;
    double curv;
};

#endif // FLUID_H
