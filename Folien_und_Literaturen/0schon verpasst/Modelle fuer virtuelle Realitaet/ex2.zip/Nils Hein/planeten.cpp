#include "planeten.h"
Planeten::Planeten()
{

}

Planeten::~Planeten()
{

}

void Planeten::Init()
{
//    Planet * a = new Planet(0,0,2);
//    Planet * b = new Planet(50,50,20);
//    a->vel = QVector2D(0,10.0);
//    planeten.append(a);
//    planeten.append(b);
    for (int i = 0; i < 20; ++i) {
       double x = ((rand()/(RAND_MAX+1.0))*200)-150;
       double y = ((rand()/(RAND_MAX+1.0))*200)-150;
       double mass = 1+((rand()/(RAND_MAX+1.0))*10);
       Planet*t = new Planet(x,y,mass);
       t->vel = QVector2D(x,y).normalized()*(rand()/(RAND_MAX+1.0));
       planeten.append(t);
    }

    scene = new QGraphicsScene();
    scene->setSceneRect(-50,-50,100,100);
    for(int i = 0;i<planeten.size();i++){
        scene->addItem(planeten.at(i)->img);
    }
}

void Planeten::Upd(double dt)
{
    double G = 1.0;
    for (int i = 0; i < planeten.size(); ++i) {
        for (int j = 0; j < planeten.size(); ++j) {
            if(i==j)
                continue;
            double dist = (planeten.at(i)->pos - (planeten.at(j)->pos)).length();

            QVector2D e = (planeten.at(j)->pos-planeten.at(i)->pos).normalized();

            QVector2D f = G*planeten.at(i)->mass*planeten.at(j)->mass/(dist*dist)*(-e);
            planeten.at(j)->force += f;
//            if(dist < ((planeten.at(i)->mass*0.5)+(planeten.at(j)->mass*0.5)))
//                planeten.at(j)->vel = -planeten.at(j)->vel;
        }
    }
    foreach (Planet* p, planeten){
         p->upd(dt);
    }

}

QGraphicsScene *Planeten::getScene()
{
    return scene;
}

