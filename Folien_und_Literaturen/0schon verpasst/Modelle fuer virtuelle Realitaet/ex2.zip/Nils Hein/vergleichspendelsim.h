#ifndef PENDELSIM_H
#define PENDELSIM_H

#include "isimbase.h"

#include <QGraphicsLineItem>



class VergleichsPendelSim : public ISimBase
{
public:
    VergleichsPendelSim();
    ~VergleichsPendelSim();

    // ISimBase interface
public:
    void Init();
    void Upd(double dt);
    QGraphicsScene *getScene();

protected:
    QGraphicsScene *scene;

    QGraphicsEllipseItem* kreis = new QGraphicsEllipseItem(0,0,10,10);
    QGraphicsLineItem* line = new QGraphicsLineItem(0,0,0,0);

    QVector<double> t,y;

    double curx;
    double curv;
};

#endif // PENDELSIM_H
