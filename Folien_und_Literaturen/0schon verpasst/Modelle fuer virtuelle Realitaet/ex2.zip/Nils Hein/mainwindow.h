#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "isimbase.h"

#include <QGraphicsScene>
#include <QMainWindow>
#include <QGraphicsItem>
#include <QGraphicsLineItem>
#include <QTimer>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:
    void upd();
    void Start();
    void Stop();
    void Reset();

private:
    QTimer *timer = 0;
    QVector<ISimBase*> simList;
    Ui::MainWindow *ui;
    double dt = 0.001;
};

#endif // MAINWINDOW_H
