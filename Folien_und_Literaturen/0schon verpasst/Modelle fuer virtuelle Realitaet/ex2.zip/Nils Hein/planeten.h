#ifndef PLANETEN_H
#define PLANETEN_H

#include "isimbase.h"

#include <QGraphicsEllipseItem>
#include <QVector2D>


class Planet{
public:
    Planet(double x, double y, double mass){
        img = new QGraphicsEllipseItem(x,y,mass,mass);
        pos.setX(x);
        pos.setY(y);
        this->mass = mass;
    }
    void upd(double dt){

        vel += (force/mass)*dt;
        pos += vel*dt;
        img->setPos(pos.x()-(mass*0.5),pos.y()-(mass*0.5));
    }
    QGraphicsEllipseItem *img;
    QVector2D pos;
    double mass;
    QVector2D force;
    QVector2D vel;
};
class Planeten : public ISimBase
{
public:
    Planeten();
    ~Planeten();

    // ISimBase interface
public:
    void Init();
    void Upd(double dt);
    QGraphicsScene *getScene();

protected:
    QGraphicsScene *scene;

    QVector<Planet*> planeten;

    QVector<double> t,y;

    double curx;
    double curv;
};

#endif // PLANETEN_H
