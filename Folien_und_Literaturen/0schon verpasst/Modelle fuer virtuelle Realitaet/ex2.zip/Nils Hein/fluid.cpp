#include "fluid.h"
#include <math.h>

Fluid::Fluid()
{

}

Fluid::~Fluid()
{

}

void Fluid::Init()
{
    for (int i = -50; i < 50; ++i) {
        for (int j = -10; j < 50; ++j) {

            if((i*i)+(j*j)<=500 || j<0){
            double x = i;
            double y = j;
            if(j<0){
                x = i;
                y= j;
            }
            Particle*t = new Particle(x,y,1.0);
            if(j<0)
                t->fix=true;

            particles.append(t);
            }
        }
    }


    scene = new QGraphicsScene();
    scene->setSceneRect(-50,-50,100,100);
    scene->setBackgroundBrush(QBrush(Qt::white, Qt::SolidPattern));
    for(int i = 0;i<particles.size();i++){
        scene->addItem(particles.at(i)->img);
    }
}

void Fluid::Upd(double dt)
{
    for (int i = 0; i < particles.size(); ++i) {
        Particle* pi = particles.at(i);
        pi->force = QVector2D(0,0);
        if(pi->fix)continue;
        for (int j = 0; j < particles.size(); ++j) {
            if(i==j)continue;
            Particle* pj = particles.at(j);
            double dist = (pi->pos-pj->pos).length();
                if(pj->fix)
                    pi->force = 1.75*((lenn(dist)*(pj->pos-pi->pos))/dist)+ pi->force;
                else
                    pi->force =((lenn(dist)*(pj->pos-pi->pos))/dist) + pi->force;
        }
        pi->force += QVector2D(0,9);
    }
    foreach (Particle* p, particles){
        if(!p->fix)
            p->upd(dt);
    }
}

QGraphicsScene *Fluid::getScene()
{
    return scene;
}

double Fluid::lenn(double r)
{
    return (20.0/(r*r*r))-(8.0/(r*r*r*r*r));
}

