#ifndef ISIMBASE_H
#define ISIMBASE_H

#include <QGraphicsScene>



class ISimBase
{
public:
    virtual void Init() = 0;
    virtual void Upd(double dt) = 0;
    virtual QGraphicsScene* getScene() = 0;
};

#endif // ISIMBASE_H
