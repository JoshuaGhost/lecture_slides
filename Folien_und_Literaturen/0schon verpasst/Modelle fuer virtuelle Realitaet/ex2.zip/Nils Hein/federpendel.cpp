#include "federpendel.h"

FederPendel::FederPendel()
{

}

FederPendel::~FederPendel()
{

}

void FederPendel::Init()
{
    QBrush brush;
    brush.setColor(Qt::black);
    brush.setStyle(Qt::SolidPattern);

    scene = new QGraphicsScene();
    scene->setSceneRect(-50,-50,100,100);
    kreis->setBrush(brush);

    scene->addItem(kreis);
    scene->addItem(line);
}

void FederPendel::Upd(double dt)
{
    QVector2D null = QVector2D(0,0);
    double k = 1;
    force = QVector2D(0,9.87);
    force += -k*((pos-null).length()+50)*(pos-null).normalized();

    vel += force*dt;
    pos += vel*dt;

    kreis->setPos(pos.x(),pos.y());
}

QGraphicsScene *FederPendel::getScene()
{
    return scene;
}

