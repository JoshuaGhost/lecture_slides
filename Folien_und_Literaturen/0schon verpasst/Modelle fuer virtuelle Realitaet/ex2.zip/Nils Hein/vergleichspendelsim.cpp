#include "vergleichspendelsim.h"
#include <math.h>
VergleichsPendelSim::VergleichsPendelSim()
{

}

VergleichsPendelSim::~VergleichsPendelSim()
{

}

void VergleichsPendelSim::Init()
{
    QBrush redBrush;
    redBrush.setColor(Qt::black);
    redBrush.setStyle(Qt::SolidPattern);

    scene = new QGraphicsScene();
    scene->setSceneRect(-50,-50,100,100);
    kreis->setBrush(redBrush);

    scene->addItem(kreis);
    scene->addItem(line);

    curv = 0.0;
    curx = M_PI_2;
    t.append(0.0);
    y.append(curx);
}

void VergleichsPendelSim::Upd(double dt)
{
    double g = 9.798;
    double l = 50;
    double k = g/l;

    double newv = ((-k*sin(curx)))*dt + curv;
    double newx = curx+(newv)*dt;
    curv = newv;
    curx = newx;

    t.append(t.last()+dt);
    y.append(newx);

//    ui->customPlot->graph(0)->setData(t,y);
//    ui->customPlot->replot();

    kreis->setPos(l*sin(curx)-5,l*cos(curx)-5);
    QPointF p = kreis->pos();
    line->setLine(0,0,p.x()+5,p.y()+5);
}

QGraphicsScene* VergleichsPendelSim::getScene()
{
    return scene;
}

