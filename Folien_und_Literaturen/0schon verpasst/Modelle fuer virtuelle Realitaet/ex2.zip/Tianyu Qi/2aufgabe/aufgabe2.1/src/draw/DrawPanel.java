package draw;

import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class DrawPanel extends javax.swing.JPanel {
	float x = -20, v = 0;
	float k = 3;
	int xoffset = 150;
	int yoffset =150;
	float a;
	float dx = (float) 0.01;
	int h=100;
	double l=Math.sqrt((h*h+400));
	double y=Math.sqrt(l*l-x*x)-h;
	@Override
	public void paint(Graphics g){
		super.paint(g);
		
		a=-k*x;
		v=v+a*dx;
		x=x+v*dx;
		y=Math.sqrt(l*l-x*x)-h;
		g.setColor(Color.black);
		System.out.println(x);
		g.fillOval((int)x + xoffset-10,(int)y+yoffset-10, 20, 20);
		g.drawLine(xoffset, yoffset-h,(int)x+xoffset,(int)y+yoffset);
		}
	}