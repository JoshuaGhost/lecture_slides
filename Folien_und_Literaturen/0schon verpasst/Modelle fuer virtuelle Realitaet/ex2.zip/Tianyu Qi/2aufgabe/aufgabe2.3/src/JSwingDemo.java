import javax.swing.*;

import java.awt.*;

import draw.*;

@SuppressWarnings("serial")
public class JSwingDemo extends JFrame {
	Color color;
	JPanel jp1;
	
	public JSwingDemo() throws InterruptedException {
		
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e){
			e.printStackTrace();
		}

		DrawPanel pl = new DrawPanel();
		Container ctn = this.getContentPane();
		ctn.add(pl);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Aufgabe 2.3");
		//repaint();
		//this.setLocationRelativeTo(null);
		int xscale=600, yscale =600;
		this.setSize(xscale, yscale);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		while(true)
		{
			pl.repaint();
			//java.lang.Thread.sleep(10);
		}
		
	}
	
	public static void main(String[] args) throws InterruptedException{
		JSwingDemo jsd = new JSwingDemo();
	}
}