package draw;

import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class DrawPanel extends javax.swing.JPanel {
	int xoffset=300,yoffset=300;
	double x1=-100,x2=100,y1=0,y2=0;
	double r,G=100000,m=1,M=1,ax1=0,ax2=0,ay1=0,ay2=0,dt=0.01;
	double f;
	double sin1, cos1, sin2, cos2;
	double fx1,fy1,fx2,fy2,vx1=0,vx2=0,vy1=-10,vy2=10;
	public void paint(Graphics g){
		r=(float) Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		f=G*m*M/(r*r);
		sin1=(x2-x1)/r;
		cos1=(y2-y1)/r;
		sin2=-sin1;
		cos2=-cos1;
		fx1=f*sin1;
		fy1=f*cos1;
		fx2=-fx1;
		fy2=-fy1;
		ax1=fx1/m;
		ay1=fy1/m;
		vx1=vx1+ax1*dt;
		vy1=vy1+ay1*dt;
		ax2=fx2/M;
		ay2=fy2/M;
		vx2=vx2+ax2*dt;
		vy2=vy2+ay2*dt;
		x1=x1+vx1*dt;
		y1=y1+vy1*dt;
		x2=x2+vx2*dt;
		y2=y2+vy2*dt;
		super.paint(g);
		g.setColor(Color.black);
		//System.out.println(x);
		g.fillOval((int)x1+xoffset,(int)y1+yoffset,20, 20);
		g.fillOval((int)x2+xoffset,(int)y2+yoffset,20, 20);
		
		}
	}