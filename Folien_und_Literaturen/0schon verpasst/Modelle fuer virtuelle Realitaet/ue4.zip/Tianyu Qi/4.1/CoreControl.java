	package test;

	import java.awt.Color;
	import java.awt.EventQueue;
	import java.awt.Graphics;
	import java.awt.Point;
	import java.awt.TextField;
	import java.awt.Window;
	import java.awt.event.WindowAdapter;
	import java.awt.event.WindowEvent;
	import java.util.ArrayList;
	import java.util.List;

	import javax.swing.JFrame;
	import javax.swing.JPanel;
	import javax.swing.UIManager;
	import javax.swing.UnsupportedLookAndFeelException;

	//import com.sun.java.swing.plaf.windows.resources.windows;

	import java.awt.event.MouseEvent;
	import java.awt.event.MouseListener;
	import java.awt.event.MouseMotionListener;
	import java.awt.event.WindowAdapter;
	import java.awt.event.WindowEvent;
	import java.awt.Container;

	public class CoreControl {

		static TextField tField = new TextField(30);
		public static class Grid extends JPanel {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			private List<Point> fillCells;

			public Grid() {
				fillCells = new ArrayList<Point>(25);
			}

			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				for (Point fillCell : fillCells) {
					int cellX = 10 + (fillCell.x * 10);
					int cellY = 10 + (fillCell.y * 10);
					g.setColor(Color.BLUE);
					g.fillRect(cellX, cellY, 10, 10);
				}
				g.setColor(Color.BLACK);
				// g.drawRect(10, 10, 100, 500);

				for (int i = 10; i <= 800; i += 10) {
					g.drawLine(i, 10, i, 510);
				}

				for (int i = 10; i <= 500; i += 10) {
					g.drawLine(10, i, 810, i);
				}
			}

			public void fillCell(int x, int y) {
				fillCells.add(new Point(x, y));
				repaint();
			}

		}

		static class MouseMotionEvents extends JPanel implements MouseListener,
				MouseMotionListener {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			Point p;

			public MouseMotionEvents() {
				addMouseListener(this);
				addMouseMotionListener(this);
			}

			@Override
			public void mouseDragged(MouseEvent arg0) {
				// TODO Auto-generated method stub
//				TextField tField = new TextField(30);
				String string = "(" + arg0.getX() + "," + arg0.getY() + ")\n";
				tField.setText(string);

			}

			@Override
			public void mouseMoved(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
//				TextField tField = new TextField(30);
				String string = "(" + e.getX() + "," + e.getY() + ")\n";
				tField.setText(string);

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				System.out.println("(");
				System.out.println(e.getX());
				System.out.println(",");
				System.out.println(e.getY());
				System.out.println(")/n");

			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		}
		public static void main(String[] args) {
//			new MouseMotionEvents();
			
			EventQueue.invokeLater(new Runnable() {
				@Override
				public void run() {
					try {
						UIManager.setLookAndFeel(UIManager
								.getSystemLookAndFeelClassName());
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InstantiationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (UnsupportedLookAndFeelException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					Grid grid = new Grid();
					JFrame window = new JFrame("please click");
					window.setSize(840, 560);
					window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

					Container content = window.getContentPane();
					content.add(new MouseMotionEvents());
					content.add(grid);
					window.add(tField, "South");
					window.setVisible(true);
					// window.add
					window.addMouseMotionListener(new MouseMotionEvents() );
					window.addMouseListener(new MouseMotionEvents());

					/*
					 * window.addWindowListener(new WindowAdapter() {
					 * 
					 * @Override public void windowClosing(WindowEvent e) { // TODO
					 * Auto-generated method stub System.exit(0); } }
					 */
					int x, y;
					for (x = 0; x < 80; x++)
						for (y = 29; y < 50; y++) {
							grid.fillCell(x, y);
						}// INITIAL
				}
			});
		}
	}

