deltah=0.1;
deltat=0.5;
c=0.002;
delta=(c*deltat)/(deltah.^2);
u=zeros(1000,101,101);


 hold on;
for i=1:99
  for j=1:99
      u(2,i,j)=sin(i*deltah)+(i*deltah)*cos(j*deltah);
    end
end
Z=u(2,:,:);
Z=reshape(Z,[101,101]);
h=surf(Z);
pause(0.0001);

for t=3:1000
    delete(h);
  for i=2:100
    for j=2:100
         u(t,i,j)=u(t-1,i,j)+delta*(u(t-1,i-1,j)+u(t-1,i+1,j)+u(t-1,i,j-1)+u(t-1,i,j+1)-4*u(t-1,i,j));
      end
    end
 
Z=u(t,:,:);
Z=reshape(Z,[101,101]);
h=surf(Z);
pause(0.0001);

end
