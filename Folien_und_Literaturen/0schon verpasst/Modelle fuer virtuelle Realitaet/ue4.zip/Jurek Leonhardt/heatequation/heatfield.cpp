#include "heatfield.h"

HeatField::HeatField(int dom_x, int dom_y, int res_x, int res_y, double h, double spd, QObject *parent) : QObject(parent)
{
    this->dom_x = dom_x;
    this->dom_y = dom_y;
    this->res_x = res_x;
    this->res_y = res_y;
    this->spd = spd;
    this->h = h;

    // initialize
    t_vals = QVector<double>(res_x * res_y);
    for (int x = 0; x < res_x; x++) {
        double x2 = (double) x / dom_x;
        for (int y = 0; y < res_y; y++) {
            t_vals[index(x, y)] = sin(x2) + x2 * sin((double) y / dom_y);
        }
    }
}

void HeatField::simulate(double dt) {
    QVector<double> clone(t_vals);

    for (int x = 0; x < res_x; x++) {
        for (int y = 0; y < res_y; y++) {
            double c = get(x, y);
            double newval = 0;
            if (x > 0) {
                newval += get(x - 1, y);
                newval -= c;
            }
            if (x < res_x - 1) {
                newval += get(x + 1, y);
                newval -= c;
            }
            if (y > 0) {
                newval += get(x, y - 1);
                newval -= c;
            }
            if (y < res_y - 1) {
                newval += get(x, y + 1);
                newval -= c;
            }
            clone[index(x, y)] += newval * spd * spd / (h * h) * dt;
        }
    }
    t_vals = clone;
}

double HeatField::get(int x, int y) {
    return t_vals[index(x, y)];
}

int HeatField::index(int x, int y) {
    return x + res_x * y;
}

QVector<double> HeatField::getTVals() {
    return t_vals;
}

int HeatField::getDomX() {
    return dom_x;
}

int HeatField::getDomY() {
    return dom_y;
}

int HeatField::getResX() {
    return res_x;
}

int HeatField::getResY() {
    return res_y;
}
