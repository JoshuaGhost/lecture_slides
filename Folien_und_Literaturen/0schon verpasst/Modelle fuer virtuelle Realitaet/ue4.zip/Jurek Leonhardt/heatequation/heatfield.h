#ifndef HEATFIELD_H
#define HEATFIELD_H

#include <QObject>
#include <QVector>
#include <QtMath>

class HeatField : public QObject
{
    Q_OBJECT
public:
    explicit HeatField(const int dom_x, const int dom_y, const int res_x, const int res_y, const double h, const double spd, QObject *parent = 0);

    QVector<double> getTVals();
    double get(int x, int y);
    void simulate(double dt);

    int getDomX();
    int getDomY();
    int getResX();
    int getResY();

private:
    QVector<double> t_vals;
    int index(int x, int y);
    int dom_x, dom_y, res_x, res_y;
    double h, spd;

signals:

public slots:
};

#endif // HEATFIELD_H
