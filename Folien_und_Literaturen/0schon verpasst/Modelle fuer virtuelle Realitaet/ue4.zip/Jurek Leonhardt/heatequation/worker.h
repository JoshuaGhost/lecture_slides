#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include "heatfield.h"
#include "qcustomplot.h"

class Worker : public QThread
{
    Q_OBJECT
public:
    explicit Worker(HeatField *hf, double dt, QObject *parent = 0);

private:
    HeatField *hf;
    double dt;

signals:
    void loopDone();

public slots:
    void run() Q_DECL_OVERRIDE;
};

#endif // WORKER_H
