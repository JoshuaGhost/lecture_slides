#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "heatfield.h"
#include "worker.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void refresh();

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    static const double DT = 0.01;

private:
    Ui::MainWindow *ui;
    QCustomPlot *plot;
    HeatField *hf;
    QCPColorMap *colorMap;
};

#endif // MAINWINDOW_H
