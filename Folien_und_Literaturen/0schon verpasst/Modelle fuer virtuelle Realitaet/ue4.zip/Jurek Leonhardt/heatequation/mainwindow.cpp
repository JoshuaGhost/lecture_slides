#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    plot = ui->plot;

    hf = new HeatField(10, 10, 100, 100, 1, 5);

    plot->axisRect()->setupFullAxesBox(true);
    colorMap = new QCPColorMap(plot->xAxis, plot->yAxis);
    plot->addPlottable(colorMap);
    colorMap->data()->setSize(hf->getResX(), hf->getResY());
    colorMap->data()->setRange(QCPRange(0, hf->getDomX()), QCPRange(0, hf->getDomY()));
    colorMap->setGradient(QCPColorGradient::gpPolar);
    plot->rescaleAxes();

    refresh();
    colorMap->rescaleDataRange();

    Worker *wrk = new Worker(hf, DT);
    connect(wrk, SIGNAL(loopDone()), this, SLOT(refresh()));
    connect(wrk, SIGNAL(finished()), wrk, SLOT(deleteLater()));
    wrk->start();
}

void MainWindow::refresh() {
    for (int x = 0; x < hf->getResX(); x++) {
        for (int y = 0; y < hf->getResY(); y++) {
            colorMap->data()->setCell(x, y, hf->get(x, y));
        }
    }
    plot->replot();
}

MainWindow::~MainWindow()
{
    delete ui;
    delete hf;
}
