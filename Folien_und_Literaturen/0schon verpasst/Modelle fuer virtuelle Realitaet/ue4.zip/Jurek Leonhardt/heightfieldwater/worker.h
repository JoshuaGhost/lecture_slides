#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include "heightfield.h"
#include "qcustomplot.h"

class Worker : public QThread
{
    Q_OBJECT
public:
    explicit Worker(HeightField *hf, double dt, QObject *parent = 0);

private:
    HeightField *hf;
    double dt;

signals:
    void loopDone();

public slots:
    void run() Q_DECL_OVERRIDE;
};

#endif // WORKER_H
