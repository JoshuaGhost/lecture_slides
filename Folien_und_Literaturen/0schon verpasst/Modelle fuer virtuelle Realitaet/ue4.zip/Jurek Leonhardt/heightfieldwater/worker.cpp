#include "worker.h"

Worker::Worker(HeightField *hf, double dt, QObject *parent) : QThread(parent)
{
    this->hf = hf;
    this->dt = dt;
}

void Worker::run() {
    while(true) {
        hf->simulate(dt);

        emit loopDone();
        msleep(dt * 1000);
    }
}
