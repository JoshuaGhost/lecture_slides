#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    plot = ui->customPlot;

    // mouse click
    connect(plot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(onMousePress(QMouseEvent*)));

    hf = new HeightField(10, 1, 0.01, 100, 100);

    plot->xAxis->setRange(0, hf->getXMax() - 1);
    plot->yAxis->setRange(0, hf->getYMax() - 1);
    plot->xAxis->setVisible(false);
    plot->yAxis->setVisible(false);

    bars = new QCPBars(plot->xAxis, plot->yAxis);
    plot->addPlottable(bars);
    bars->setData(hf->getXVals(), hf->getUVals());
    bars->setPen(Qt::NoPen);
    bars->setBrush(QColor(10, 10, 200, 150));

    Worker *wrk = new Worker(hf, DT);
    connect(wrk, SIGNAL(loopDone()), this, SLOT(refresh()));
    connect(wrk, SIGNAL(finished()), wrk, SLOT(deleteLater()));
    wrk->start();
}

void MainWindow::refresh() {
    bars->setData(hf->getXVals(), hf->getUVals());
    plot->replot();
}

void MainWindow::onMousePress(QMouseEvent *event)
{
    int x = plot->xAxis->pixelToCoord(event->pos().x());
    int r = 6;
    int h = 12;

    // avoid waves too close to edge
    x = qMax(x, 2 * r);
    x = qMin(x, hf->getXMax() - 2 * r);

    // waves cancel each other out
    hf->createWave(x, r, h);
    hf->createWave(x + r / 2 * 3, r / 2, -h);
    hf->createWave(x - r / 2 * 3, r / 2, -h);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete hf;
}
