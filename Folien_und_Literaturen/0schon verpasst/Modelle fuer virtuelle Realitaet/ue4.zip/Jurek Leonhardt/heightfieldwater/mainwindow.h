#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "qcustomplot.h"
#include "heightfield.h"
#include "worker.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    static const double DT = 0.01;

signals:

public slots:
    void refresh();

private slots:
    void onMousePress(QMouseEvent *event);

private:
    Ui::MainWindow *ui;
    HeightField *hf;
    QCustomPlot *plot;
    QCPBars *bars;
};

#endif // MAINWINDOW_H
