#include "heightfield.h"

HeightField::HeightField(int c, int h, double damp, int x_max, int y_max, QObject *parent) : QObject(parent)
{
    this->c = c;
    this->h = h;
    this->damp = damp;

    this->x_max = x_max;
    this->y_max = y_max;

    // initialize
    x_vals = QVector<double>(x_max);
    u_vals = QVector<double>(y_max);
    v_vals = QVector<double>(y_max);
    for (int i = 0; i < x_max; i++) {
        x_vals[i] = i;
        u_vals[i] = (int) (y_max / 3.0);
        v_vals[i] = 0;
    }
    createWave(33, 5, 20);
    createWave(66, 10, 30);
}

void HeightField::createWave(int x, int radius, int height) {
    int r_sqr = radius * radius;
    for (int i = qMax(x - radius, 0); i <= qMin(x + radius, x_max - 1); i++) {
        int pos = i - x;
        int pos_sqr = pos * pos;
        u_vals[i] += height * pos_sqr * pos_sqr / (r_sqr * r_sqr) - 2 * height * pos_sqr / r_sqr + height;
    }
}

void HeightField::simulate(double dt) {
    foreach (int x, x_vals) {

        // update v
        if (x == 0) {
            v_vals[x] += u_vals[x + 1] - u_vals[x];
        } else if (x == x_max - 1) {
            v_vals[x] += u_vals[x - 1] - u_vals[x];
        } else {
            v_vals[x] += u_vals[x - 1] - 2 * u_vals[x] + u_vals[x + 1];
        }

        v_vals[x] *= (1 - damp) * c * c * dt / (h * h);

        // update u
        u_vals[x] += v_vals[x] * dt;
    }
}

QVector<double> HeightField::getUVals() {
    return u_vals;
}

QVector<double> HeightField::getXVals() {
    return x_vals;
}

int HeightField::getXMax() {
    return x_max;
}

int HeightField::getYMax() {
    return y_max;
}
