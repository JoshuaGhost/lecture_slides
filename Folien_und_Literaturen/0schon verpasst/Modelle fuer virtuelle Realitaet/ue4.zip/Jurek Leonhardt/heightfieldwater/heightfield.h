#ifndef HEIGHTFIELD_H
#define HEIGHTFIELD_H

#include <QObject>
#include <QVector>
#include <qcustomplot.h>

class HeightField : public QObject
{
    Q_OBJECT
public:
    explicit HeightField(int c, int h, double damp, int x_max, int y_max, QObject *parent = 0);
    void createWave(int index, int radius, int height);
    void simulate(double dt);
    QVector<double> getXVals();
    QVector<double> getUVals();
    int getXMax();
    int getYMax();

private:
    QCustomPlot *plot;
    QVector<double> x_vals, u_vals, v_vals;
    int c, h, x_max, y_max;
    double damp;

signals:

public slots:
};

#endif // HEIGHTFIELD_H
