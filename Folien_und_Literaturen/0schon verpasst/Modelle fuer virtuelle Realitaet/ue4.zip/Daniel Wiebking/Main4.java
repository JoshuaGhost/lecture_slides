package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

public class Main4 extends JFrame{

	BufferedImage image;
    Graphics buffer;
    double water[];
	double[] vwater;
	double[][] grid;
	
	public Main4(){
		//gui kram
		super();
		this.setSize(500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.setVisible(true);
        image = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_ARGB);
        buffer = image.getGraphics();
        water = new double[502];
        vwater = new double[502];

        //Aufgabe 4.1
        //startkonfiguration des wassers
        for(int k = 0; k < water.length; k++) {
        	water[k] = 100;
        }
        //startkonfiguration der wellen
        for(int k = 0; k<50; k++) {
        	water[k+200]+=k*(50-k)/10;
        }
        for(int k = 0; k<30; k++) {
        	water[k+300]+=k*(30-k)/10;
        }
        for(int k = 0; k<20; k++) {
        	water[k+400]+=k*(20-k)/5;
        }
        //parameter
        double dt=0.01;
        int h = 1;
        double c=0.02*h/dt;
        //starten der simulation
        for(double t=0; t<250; t+=dt) {
        	for(int k = 1; k < water.length-1; k++) {
        		vwater[k] += dt*c*c/h/h*(water[k-h]-2*water[k]+water[k+h]);
        	}
        	for(int k = 1; k < water.length-1; k++) {
        		water[k] += dt*vwater[k];
        	}
        	//rand angleichen
        	water[0]=water[1];
        	water[501]=water[500];
        	//zeichnen
        	if (((int)(t/dt))%((int)(1/dt))==0) {
        		draw();
        	}

        }
        //Aufgabe 4.2
        //parameter
        double c2=2;
        grid = new double[100][100];
        //starttemperatur setzen
        for (int xx = 0; xx<grid.length; xx++) {
        	for (int yy = 0; yy<grid.length; yy++) {
        		double x = 0.1*xx;
        		double y = 0.1*yy;
        		grid[xx][yy] = Math.sin(x) + x*Math.cos(y);
        	}
        }
      //starten der simulation
        for(double t=0; t<200; t+=dt) {
        	//inetgrieren
        	for (int xx = 1; xx<grid.length-1; xx++) {
            	for (int yy = 1; yy<grid.length-1; yy++) {
            		grid[xx][yy] += dt*c2*(-4*grid[xx][yy]
            						+grid[xx+1][yy]+grid[xx-1][yy]
            						+grid[xx][yy+1]+grid[xx][yy-1]);
            	}
        	}
        	//rand angleichen an nachbarn
        	for (int xx = 0; xx<grid.length; xx++) {
        		grid[xx][0]=grid[xx][1];
        		grid[xx][99]=grid[xx][98];
        	}
        	for (int yy = 0; yy<grid.length; yy++) {
        		grid[0][yy]=grid[1][yy];
        		grid[99][yy]=grid[98][yy];
        	}
        	//zeichnen
        	if (((int)(t/dt))%((int)(1/dt))==0) {
        	drawTemp();
        	}
        }
        //zeichnen
        buffer.setColor(Color.black);
        buffer.drawString("Ende", 250, 250);
        this.repaint();
        
        /*
         * Aufgabe 4.3)
         * kräfte lassen sich addieren.
         * wenn man zwei steine zusammenbindet,
         * dann addiert sich die kraft die nach unten wirkt.
         * das ist einfach zu berechnen.
         * 
         * bei beschleunigungen ist es komplizierter.
         * angenommen ich habe ein zwei autos, die veknotet sind
         * und das auto1 bescheunigt in die eine richtung mit 7m/s²
         * und das auto2 beschleunigt mit 10m/s²
         * dann ist die resultierende bescheunigung nicht 3m/s²
         * sonderen es müssen die massen der autos berückstigt werden
         * 
         * ich denke es würde sowas wie (10*m2 - 7*m1)/(m1+m2) herauskommen
         * also schwieriger zu berechnen.
         */
	}

	
	//Gui stuff...
	public static void main(String[] args) {
		Main4 main = new Main4();
	}
	@Override
	public void paint( Graphics g )
	{
		g.drawImage(image, 0, 0, null);
	}
	public void draw() {

		buffer.setColor(Color.blue);
		for(int k = 0; k < 500; k++) {
			buffer.drawLine(k, 500, k, (int) (500-water[k+1]));
		}
		clear();
	}
	
	public void drawTemp() {

		for (int xx = 0; xx<grid.length; xx++) {
        	for (int yy = 0; yy<grid.length; yy++) {
        		int temp = (int) (grid[xx][yy]*10);
        		buffer.setColor(new Color(120-temp,120+temp,0));
        		buffer.drawLine(xx, yy, xx, yy);
        	}
        }
		clear();
	}
		public void clear() {	
		this.repaint();
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		buffer.setColor(Color.WHITE);
		buffer.clearRect(0, 0, image.getWidth(), image.getHeight());
		buffer.fillRect(0, 0, image.getWidth(), image.getHeight());

	}
	public void update(Graphics g)
	{
		paint(g);
	}



}
