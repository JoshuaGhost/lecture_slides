#include <cmath>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>

#include "temperaturefield.h"
#include "grid2dgraphicsitem.h"

TemperatureField::TemperatureField(double timestep, QObject *parent)
    : QGraphicsScene(parent),
      m_grid(64, 64),
      m_gridTmp(m_grid),
      m_gridItem(new Grid2DGraphicsItem(&m_grid)),
      m_timestep(timestep),
      m_thermalDiffusivity(2.0),
      m_damping(0.0),
      m_TemperatureAtMousePosition(0.0)
{
    reset();
    addItem(m_gridItem);
}

QRectF TemperatureField::sceneRect() const
{
    return m_gridItem->boundingRect();
}

void TemperatureField::reset()
{
    for (std::size_t i = 0; i < m_heatElements.size(); ++i) {
        removeItem(m_heatElements[i]->rectItem);
        delete m_heatElements[i];
    }
    m_heatElements.clear();

    for (int r = 0; r < m_grid.rows(); ++r) {
        for (int c = 0; c < m_grid.columns(); ++c) {
            double x = c / (double)m_grid.columns() * 10.0;
            double y = r / (double)m_grid.rows() * 10.0;
            m_grid.set(r, c, std::sin(x) + x * std::cos(y));
        }
    }
}

void TemperatureField::advance()
{
    m_gridTmp = m_grid;

    double constFactor = m_timestep * m_thermalDiffusivity; // grid distance is 1
    double dampingFactor = 1 - m_damping;
    for (int r = 0; r < m_grid.rows(); ++r) {
        for (int c = 0; c < m_grid.columns(); ++c) {
            double der = constFactor * (m_grid.get(r - 1, c) + m_grid.get(r, c - 1) - 4 * m_grid.get(r, c) + m_grid.get(r, c + 1) + m_grid.get(r + 1, c));
            m_gridTmp.set(r, c, m_grid.get(r, c) * dampingFactor + der);
        }
    }

    for (std::size_t i = 0; i < m_heatElements.size(); ++i) {
        const QRectF &rect = m_heatElements[i]->rectItem->rect();
        double temperature = m_heatElements[i]->temperature;
        for (int r = rect.top(); r < rect.bottom(); ++r) {
            for (int c = rect.left(); c < rect.right(); ++c) {
                m_gridTmp.set(r, c, temperature);
            }
        }
    }

    m_grid = m_gridTmp;
    m_gridItem->update();
}

void TemperatureField::mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    int x = mouseEvent->scenePos().x();
    int y = mouseEvent->scenePos().y();
    m_TemperatureAtMousePosition = m_grid.get(y, x);

    if (m_currentlyAddingHeatElement) {
        int sizeHalf = std::round(m_currentHeatElement.size / 2.0);
        int rectCenterX = x;
        int rectCenterY = y;

        if (x - sizeHalf < 0) {
            rectCenterX = sizeHalf;
        }
        else if (x + sizeHalf >= m_grid.columns()) {
            rectCenterX = m_grid.columns() - sizeHalf;
        }

        if (y - sizeHalf < 0) {
            rectCenterY = sizeHalf;
        }
        else if (y + sizeHalf >= m_grid.rows()) {
            rectCenterY = m_grid.rows() - sizeHalf;
        }

        m_currentHeatElement.updatePosition(rectCenterX, rectCenterY);
    }
}

void TemperatureField::mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    (void)mouseEvent;

    if (!m_currentlyAddingHeatElement)
        return;

    m_currentlyAddingHeatElement = false;

    removeItem(m_currentHeatElement.rectItem);
    m_heatElements.push_back(new HeatElement(m_currentHeatElement));
    addItem(m_heatElements.back()->rectItem);
}

void TemperatureField::addHeatElement(double temperature, int size)
{
    if (m_currentlyAddingHeatElement)
        return;

    m_currentlyAddingHeatElement = true;

    double xCenter = m_grid.columns() / 2;
    double yCenter = m_grid.rows() / 2;
    m_currentHeatElement.temperature = temperature;
    m_currentHeatElement.size = size;
    m_currentHeatElement.updatePosition(xCenter, yCenter);

    addItem(m_currentHeatElement.rectItem);
}

void TemperatureField::setRows(int rows)
{
    m_grid.setRows(rows);
    m_gridTmp.setRows(rows);
    reset();
    update();
}

void TemperatureField::setColumns(int columns)
{
    m_grid.setColumns(columns);
    m_gridTmp.setColumns(columns);
    reset();
    update();
}

void TemperatureField::setThermalDiffusivity(double thermalDiffusivity)
{
    m_thermalDiffusivity = thermalDiffusivity;
}

void TemperatureField::setDamping(double damping)
{
    m_damping = damping;
}
