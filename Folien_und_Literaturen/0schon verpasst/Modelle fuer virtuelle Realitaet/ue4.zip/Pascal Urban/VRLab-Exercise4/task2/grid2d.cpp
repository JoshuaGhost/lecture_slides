#include "grid2d.h"

Grid2D::Grid2D(int rows, int columns)
    : m_rows(rows),
      m_columns(columns),
      m_values(rows * columns)
{
}

Grid2D::Grid2D(const Grid2D &other)
    : m_rows(other.m_rows),
      m_columns(other.m_columns),
      m_values(other.m_values)
{
}

void Grid2D::set(int r, int c, double value)
{
    m_values[c * m_rows + r] = value;
}

double Grid2D::get(int r, int c) const
{
    if (r < 0) {
        r = 0;
    } else if (r >= m_rows) {
        r = m_rows - 1;
    }

    if (c < 0) {
        c = 0;
    } else if (c >= m_columns) {
        c = m_columns - 1;
    }

    return m_values[c * m_rows + r];
}

Grid2D &Grid2D::operator=(const Grid2D &other)
{
    if (this != &other) {
        m_rows = other.m_rows;
        m_columns = other.m_columns;
        m_values = other.m_values;
    }

    return *this;
}

void Grid2D::setRows(int rows)
{
    m_rows = rows;
    m_values.clear();
    m_values.resize(m_rows * m_columns);
}

void Grid2D::setColumns(int columns)
{
    m_columns = columns;
    m_values.clear();
    m_values.resize(m_rows * m_columns);
}
