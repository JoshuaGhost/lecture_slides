#ifndef TASK2CONTROLLER_H
#define TASK2CONTROLLER_H

#include "common/taskcontroller.h"
#include "ui_mainwindow.h"

class TemperatureField;
class QLineEdit;
class QDoubleSpinBox;
class QSpinBox;

class Task2Controller : public TaskController
{
    Q_OBJECT
public:
    Task2Controller(Ui::MainWindow *main, QObject *parent = 0);

public slots:
    virtual void reset();

protected slots:
    virtual void advance();

protected:
    virtual void handleResize();

private slots:
    void rowsFieldChanged();
    void columnsFieldChanged();
    void thermalDiffusivityFieldChanged();
    void dampingFieldChanged();

    void addHeatSource();

private:
    void updateTextfields();

    TemperatureField *m_temperatureField;

    QLineEdit *m_rowsField;
    QLineEdit *m_columnsField;
    QLineEdit *m_thermalDiffusivityField;
    QLineEdit *m_dampingField;

    QDoubleSpinBox *m_tempSpinner;
    QSpinBox *m_sizeSpinner;
};

#endif // TASK2CONTROLLER_H
