#ifndef TEMPERATUREFIELD_H
#define TEMPERATUREFIELD_H

#include <QGraphicsScene>
#include <QGraphicsRectItem>

#include "grid2d.h"

class Grid2DGraphicsItem;

class HeatElement {
public:
    HeatElement()
        : rectItem(new QGraphicsRectItem()),
          temperature(0.0),
          size(1)
    {
    }

    HeatElement(const HeatElement &other)
        : rectItem(new QGraphicsRectItem(other.rectItem->rect())),
          temperature(other.temperature),
          size(other.size)
    {
    }

    ~HeatElement()
    {
        if (rectItem->scene() == nullptr)
            delete rectItem;
    }

    inline void updatePosition(double centerX, double centerY)
    {
        rectItem->setRect(centerX - size / 2, centerY - size / 2, size, size);
    }

    QGraphicsRectItem *rectItem;
    double temperature;
    int size;
};

class TemperatureField : public QGraphicsScene
{
public:
    TemperatureField(double timestep, QObject *parent = 0);
    QRectF sceneRect() const;
    void reset();
    void advance();

    int rows() const { return m_grid.rows(); }
    int columns() const { return m_grid.columns(); }
    double thermalDiffusivity() const { return m_thermalDiffusivity; }
    double damping() const { return m_damping; }
    double temperatureAtMousePosition() const { return m_TemperatureAtMousePosition; }

    void setRows(int rows);
    void setColumns(int columns);
    void setThermalDiffusivity(double thermalDiffusivity);
    void setDamping(double damping);

    void addHeatElement(double temperature, int size);

protected:
    virtual void mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent);
    virtual void mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent);

private:
    Grid2D m_grid;
    Grid2D m_gridTmp;
    Grid2DGraphicsItem * m_gridItem;

    double m_timestep;
    double m_thermalDiffusivity;
    double m_damping;

    double m_TemperatureAtMousePosition;
    std::vector<HeatElement*> m_heatElements;
    bool m_currentlyAddingHeatElement;
    HeatElement m_currentHeatElement;
};

#endif // TEMPERATUREFIELD_H
