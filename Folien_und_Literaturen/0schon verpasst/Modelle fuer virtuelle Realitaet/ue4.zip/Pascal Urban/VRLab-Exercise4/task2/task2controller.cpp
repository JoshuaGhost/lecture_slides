#include <QLineEdit>
#include <QDebug>

#include "task2controller.h"
#include "temperaturefield.h"

Task2Controller::Task2Controller(Ui::MainWindow *main, QObject *parent)
    : TaskController(main->task2StartButton, main->task2ResetButton,
                    main->task2GraphicsView, parent),
      m_temperatureField(new TemperatureField(TIMESTEP / 1000.0, this)),
      m_rowsField(main->task2RowsField),
      m_columnsField(main->task2ColumsField),
      m_thermalDiffusivityField(main->task2ThermalDiffusivityField),
      m_dampingField(main->task2DampingField),
      m_tempSpinner(main->task2TempSpinner),
      m_sizeSpinner(main->task2SizeSpinner)
{
    m_graphicsView->setScene(m_temperatureField);
    m_graphicsView->scale(1, -1); // invert y axis
    m_graphicsView->setMouseTracking(true);

    connect(m_rowsField, SIGNAL(returnPressed()), this, SLOT(rowsFieldChanged()));
    connect(m_columnsField, SIGNAL(returnPressed()), this, SLOT(columnsFieldChanged()));
    connect(m_thermalDiffusivityField, SIGNAL(returnPressed()), this, SLOT(thermalDiffusivityFieldChanged()));
    connect(m_dampingField, SIGNAL(returnPressed()), this, SLOT(dampingFieldChanged()));

    connect(main->task2AddButton, SIGNAL(released()), this, SLOT(addHeatSource()));

    updateTextfields();
}

void Task2Controller::handleResize()
{
    m_graphicsView->setSceneRect(m_temperatureField->sceneRect());
    m_graphicsView->fitInView(m_temperatureField->sceneRect(), Qt::KeepAspectRatio);
}

void Task2Controller::updateTextfields()
{
    setTextFieldToNumber(m_rowsField, m_temperatureField->rows());
    setTextFieldToNumber(m_columnsField, m_temperatureField->columns());
    setTextFieldToNumber(m_thermalDiffusivityField, m_temperatureField->thermalDiffusivity());
    setTextFieldToNumber(m_dampingField, m_temperatureField->damping());
}

void Task2Controller::reset()
{
    m_temperatureField->reset();
    m_temperatureField->update();
}

void Task2Controller::advance()
{
    m_temperatureField->advance();
}

/***** Callbacks *****/

void Task2Controller::rowsFieldChanged()
{
    int rows = m_rowsField->text().toInt();
    m_temperatureField->setRows(rows);
    handleResize();
}

void Task2Controller::columnsFieldChanged()
{
    int columns = m_columnsField->text().toInt();
    m_temperatureField->setColumns(columns);
    handleResize();
}

void Task2Controller::thermalDiffusivityFieldChanged()
{
    int thermalDiffusivity = m_thermalDiffusivityField->text().toInt();
    m_temperatureField->setThermalDiffusivity(thermalDiffusivity);
}

void Task2Controller::dampingFieldChanged()
{
    int damping = m_dampingField->text().toInt();
    m_temperatureField->setDamping(damping);
}

void Task2Controller::addHeatSource()
{
    m_temperatureField->addHeatElement(m_tempSpinner->value(), m_sizeSpinner->value());
}
