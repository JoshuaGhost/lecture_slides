#ifndef GRID2DGRAPHICSITEM_H
#define GRID2DGRAPHICSITEM_H

#include <QGraphicsItem>

class Grid2D;

class Grid2DGraphicsItem : public QGraphicsItem
{
public:
    Grid2DGraphicsItem(Grid2D *grid);

    virtual QRectF boundingRect() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = 0);

private:
    Grid2D *m_grid;
};

#endif // GRID2DGRAPHICSITEM_H
