#include <QPainter>
#include <QDebug>

#include "grid2dgraphicsitem.h"
#include "grid2d.h"

Grid2DGraphicsItem::Grid2DGraphicsItem(Grid2D *grid)
    : m_grid(grid)
{
}

QRectF Grid2DGraphicsItem::boundingRect() const
{
    return QRectF(0.0, 0.0, m_grid->columns(), m_grid->rows());
}

void Grid2DGraphicsItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    (void)option, (void)widget;

    QPen pen(painter->pen());
    pen.setCosmetic(true);
    pen.setColor(Qt::black);
    painter->setPen(pen);

    QColor color = Qt::blue;
    QBrush brush(color, Qt::SolidPattern);
    painter->setBrush(brush);

    for (int r = 0; r < m_grid->rows(); ++r) {
        for (int c = 0; c < m_grid->columns(); ++c) {

            // scaling from {cold -10, hot 10} to {blue 0.7, red 0}
            // TODO maybe these shouldn't be hardcoded...
            double value = m_grid->get(r, c);
            // clamp the values
            if (value > 10)
                value = 10.0;
            else if (value < -10)
                value = -10;

            color.setHsvF(0.7 - 0.7*(value + 10.0) / 20.0, 1.0, 1.0);
            brush.setColor(color);
            painter->setBrush(brush);

            painter->fillRect(QRectF(c, r, 1, 1), brush);
        }
    }
}
