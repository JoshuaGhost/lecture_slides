#ifndef GRID2D_H
#define GRID2D_H

#include <vector>

/*
 * Replicates the values on the edges for indices outside the
 * ranges.
 */
class Grid2D
{
public:
    Grid2D(int rows, int columns);
    Grid2D(const Grid2D &other);

    void setRows(int rows);
    void setColumns(int columns);
    void set(int r, int c, double value);

    double rows() const { return m_rows; }
    double columns() const { return m_columns; }
    double get(int r, int c) const;

    Grid2D &operator=(const Grid2D &other);

private:

    int m_rows;
    int m_columns;
    std::vector<double> m_values;
};

#endif // GRID2D_H
