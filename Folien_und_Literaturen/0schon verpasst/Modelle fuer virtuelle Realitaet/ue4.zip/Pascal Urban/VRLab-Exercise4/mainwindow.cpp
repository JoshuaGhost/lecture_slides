#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "task1/task1controller.h"
#include "task2/task2controller.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("VRLab - Exercise 4");
    m_task1Controller = new Task1Controller(ui, this);
    m_task2Controller = new Task2Controller(ui, this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
