#include <QPainter>
#include <QDebug>
#include <limits>

#include "grid1dgraphicsitem.h"
#include "grid1d.h"

Grid1DGraphicsItem::Grid1DGraphicsItem(Grid1D *grid)
    : m_grid(grid),
      m_max(std::numeric_limits<double>::lowest())
{
    for (int i = 0; i < m_grid->numberOfCells(); ++i) {
        if ((*m_grid)[i] > m_max) {
            m_max = (*m_grid)[i];
        }
    }
}

QRectF Grid1DGraphicsItem::boundingRect() const
{
    return QRectF(-1.0, 0.0, m_grid->numberOfCells() * m_grid->cellWidth() + 2, m_max*2);
}

void Grid1DGraphicsItem::setMaxHeight(double height)
{
    m_max = height;
}

void Grid1DGraphicsItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    (void)option, (void)widget;

    QPen pen(painter->pen());
    pen.setCosmetic(true);
    pen.setColor(Qt::black);
    painter->setPen(pen);
    painter->setBrush(QBrush(Qt::blue, Qt::SolidPattern));

    double cellWidth = m_grid->cellWidth();
    for (int i = 0; i < m_grid->numberOfCells(); ++i) {
        painter->drawRect(QRectF(i * cellWidth, 0, cellWidth, (*m_grid)[i]));
    }

    pen.setColor(Qt::gray);
    painter->setPen(pen);
    painter->setBrush(QBrush(Qt::gray, Qt::SolidPattern));
    painter->drawRect(QRectF(-cellWidth, 0, cellWidth, m_max * 1.2));
    painter->drawRect(QRectF(-cellWidth, -cellWidth, m_grid->numberOfCells() * cellWidth + 2*cellWidth, cellWidth));
    painter->drawRect(QRectF(m_grid->numberOfCells() * cellWidth, 0, cellWidth, m_max * 1.2));
}
