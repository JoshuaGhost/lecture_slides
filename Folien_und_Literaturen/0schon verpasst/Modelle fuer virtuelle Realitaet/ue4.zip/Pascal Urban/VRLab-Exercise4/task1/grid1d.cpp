#include "grid1d.h"

Grid1D::Grid1D(int length, double cellWidth, double initialHeight)
    : m_width(cellWidth),
      m_length(length),
      m_values(length)
{
    for (int i = 0; i < m_length; ++i) {
        m_values[i] = initialHeight;
    }
}

Grid1D::Grid1D(const Grid1D &other)
    : m_width(cellWidth()),
      m_length(other.m_length),
      m_values(other.m_values)
{
}

Grid1D::~Grid1D()
{
    m_values.clear();
}

void Grid1D::setNumberOfCells(int cells)
{
    m_length = cells;
    m_values.clear();
    m_values.resize(m_length);
    for (int i = 0; i < m_length; ++i) {
        m_values[i] = 0;
    }
}

double &Grid1D::operator[](int index)
{
    if (index < 0) {
        return m_values[0];
    } else if (index >= m_length) {
        return m_values[m_length - 1];
    }

    return m_values[index];
}

const double &Grid1D::operator[](int index) const
{
    return this->operator[](index);
}

Grid1D &Grid1D::operator=(const Grid1D &other)
{
    if (this != &other) {
        m_width = other.m_width;
        m_length = other.m_length;
        m_values = other.m_values;
    }

    return *this;
}
