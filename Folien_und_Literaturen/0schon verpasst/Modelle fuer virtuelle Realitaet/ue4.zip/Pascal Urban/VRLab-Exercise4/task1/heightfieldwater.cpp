#include <functional>
#include <cmath>
#include <limits>

#include <QGraphicsSceneMouseEvent>
#include <QDebug>

#include "grid1dgraphicsitem.h"
#include "heightfieldwater.h"

Heightfieldwater::Heightfieldwater(double timestep, QObject *parent)
    : QGraphicsScene(parent),
      m_grid(100, 0.25, 1.0),
      m_timestep(timestep),
      m_waveVelocity(m_grid.cellWidth() * 1.0 / timestep * 1.0 / 3.0),
      m_waveHeight(2.0),
      m_damping(0.01),
      m_template("Wave Left"),
      m_gridTmp(m_grid),
      m_gridItem(new Grid1DGraphicsItem(&m_grid)),
      m_velocities(m_grid.numberOfCells()),
      m_velocitiesTmp(m_grid.numberOfCells())
{
    enforceWaveVelocityConstraint();
    reset();
    addItem(m_gridItem);
}

QRectF Heightfieldwater::sceneRect() const
{
    return m_gridItem->boundingRect();
}

static inline double gaussDistribution(double x, double s)
{
    return 1 / (s*s * 2 * M_PI) * std::exp(-0.5 * x*x / (s*s));
}

void Heightfieldwater::applyTemplate()
{
    // 25 scales the gauss distribution with sigma 2 to a maximum of roughly 1
    double gaussScaling = 25.0 * m_waveHeight;

    std::function<double(double)> func = [](double x) -> double { (void)x; return 0.0; };

    if (m_template.compare(QString("Wave Left"), Qt::CaseInsensitive) == 0) {
        func = [=](double x) -> double { return gaussScaling * gaussDistribution(x, 2); };
    }
    else if (m_template.compare(QString("Wave Right"), Qt::CaseInsensitive) == 0) {
        double nCells = m_grid.numberOfCells() * m_grid.cellWidth();
        func = [=](double x) -> double { return gaussScaling * gaussDistribution(x - nCells, 2); };
    }
    else if (m_template.compare(QString("Wave Left & Right"), Qt::CaseInsensitive) == 0) {
        double nCells = m_grid.numberOfCells() * m_grid.cellWidth();
        func = [=](double x) -> double { return gaussScaling * (gaussDistribution(x, 2) + gaussDistribution(x - nCells, 2)); };
    }
    else if (m_template.compare(QString("Wave Middle"), Qt::CaseInsensitive) == 0) {
        double nCells = m_grid.numberOfCells() * m_grid.cellWidth() * 0.5;
        func = [=](double x) -> double { return gaussScaling * gaussDistribution(x - nCells, 2); };
    }
    else if (m_template.compare(QString("Sine"), Qt::CaseInsensitive) == 0) {
        func = [=](double x) -> double { return (std::sin(x) + 2) * m_waveHeight; };
    }

    for (int i = 0; i < m_grid.numberOfCells(); ++i) {
        m_grid[i] = func(i * m_grid.cellWidth()) + 10.0;
    }

    update();
}

void Heightfieldwater::reset()
{
    m_velocities.clear();
    m_velocitiesTmp.clear();

    m_velocities.resize(m_grid.numberOfCells());
    m_velocitiesTmp.resize(m_grid.numberOfCells());

    applyTemplate();

    double max = std::numeric_limits<double>::lowest();
    for (int i = 0; i < m_grid.numberOfCells(); ++i) {
        if (m_grid[i] > max) {
            max = m_grid[i];
        }
    }

    m_gridItem->setMaxHeight(max);
}

void Heightfieldwater::advance()
{
    m_gridTmp = m_grid;
    m_velocitiesTmp = m_velocities;

    double constFactor =  m_timestep * m_waveVelocity * m_waveVelocity / (m_grid.cellWidth() * m_grid.cellWidth());
    double dampingFactor = (1 - m_damping);
    for (int i = 0; i < m_grid.numberOfCells(); ++i) {
        m_velocitiesTmp[i] = m_velocities[i] * dampingFactor  + constFactor * (m_grid[i - 1] - 2 * m_grid[i] + m_grid[i + 1]);
        m_gridTmp[i] = m_grid[i] + m_timestep * m_velocitiesTmp[i];
    }

    m_velocities = m_velocitiesTmp;
    m_grid = m_gridTmp;

    m_gridItem->update();
}

void Heightfieldwater::mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    int clickColumn = mouseEvent->scenePos().x() / m_grid.cellWidth();

    int radiusInColumns = m_rainDropRadius / m_grid.cellWidth();
    if (clickColumn - radiusInColumns - radiusInColumns < 0) {
        clickColumn = 2 *radiusInColumns;
    }
    if (clickColumn + radiusInColumns + radiusInColumns >= m_grid.numberOfCells()) {
        clickColumn = m_grid.numberOfCells() - 1 - 2 *radiusInColumns;
    }

    double area = 0;
    for (int i = -radiusInColumns; i <= radiusInColumns; ++i) {
        int col = clickColumn + i;

        // ellipse equation: (a*x)^2 + (b*y)^2 = r^2
        // => y = b * sqrt(r^2 - (a*x)^2)
        double x = (double)i * m_grid.cellWidth();
        double areaRemove = m_rainDropDepth * std::sqrt(1 - std::pow(x / m_rainDropRadius, 2));
        m_grid[col] -= areaRemove;
        area += areaRemove;
    }

    int leftMiddle = clickColumn - radiusInColumns - radiusInColumns * 0.5;
    int rightMiddle = clickColumn + radiusInColumns + radiusInColumns * 0.5;

    for (int i = -radiusInColumns * 0.5; i <= radiusInColumns * 0.5; ++i) {
        double x = (double)i * m_grid.cellWidth();
        double areaAdd = m_rainDropDepth * std::sqrt(1 - std::pow(x / (m_rainDropRadius* 0.5), 2));
        m_grid[leftMiddle + i] += areaAdd;
        m_grid[rightMiddle + i] += areaAdd;
        area -= 2*areaAdd;
    }

    // the above does not necessarily distribute all of the remaining are (or sometimes to much)
    // we need to take care of it
    double remainingAreaToDistribute = 0.5 * area / (radiusInColumns+1);
    for (int i = -radiusInColumns * 0.5; i <= radiusInColumns * 0.5; ++i) {
        m_grid[leftMiddle + i] += remainingAreaToDistribute;
        m_grid[rightMiddle + i] += remainingAreaToDistribute;

        area -= 2*remainingAreaToDistribute;
    }

    update();
}

void Heightfieldwater::enforceWaveVelocityConstraint()
{
    if (m_waveVelocity >= m_grid.cellWidth() / m_timestep) {
        m_waveVelocity = m_grid.cellWidth() / m_timestep * 1.0 / 3.0;
    }
}

/***** Setter *****/

void Heightfieldwater::setWaveVelocity(double velocity)
{
    m_waveVelocity = velocity;
    enforceWaveVelocityConstraint();
}

void Heightfieldwater::setWaveHeight(double height)
{
    m_waveHeight = height;
    reset();

    m_gridItem->update();
}

void Heightfieldwater::setDamping(double damping)
{
    m_damping = damping;
}

void Heightfieldwater::setCellWidth(double width)
{
    m_grid.setCellWidth(width);
    enforceWaveVelocityConstraint();
    reset();

    m_gridItem->update();
}

void Heightfieldwater::setNumberOfCells(int cells)
{
    m_grid.setNumberOfCells(cells);
    reset();

    m_gridItem->update();
}

void Heightfieldwater::setTemplate(QString newTemplate)
{
    m_template = newTemplate;
    reset();

    m_gridItem->update();
}
