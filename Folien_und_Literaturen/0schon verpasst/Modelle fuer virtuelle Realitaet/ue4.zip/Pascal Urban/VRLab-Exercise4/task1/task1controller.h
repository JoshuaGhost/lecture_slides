#ifndef TASK1CONTROLLER_H
#define TASK1CONTROLLER_H

#include "common/taskcontroller.h"
#include "ui_mainwindow.h"

class Heightfieldwater;
class QLineEdit;
class QDoubleSpinBox;

class Task1Controller : public TaskController
{
    Q_OBJECT
public:
    Task1Controller(Ui::MainWindow *main, QObject *parent = 0);

public slots:
    virtual void reset();

protected slots:
    virtual void advance();

protected:
    virtual void handleResize();

private slots:
    void cellWidthFieldChanged();
    void numberOfCellsFieldChanged();
    void velocityFieldChanged();
    void dampingFieldChanged();
    void waveHeightFieldChanged();
    void templateBoxChanged(QString string);

    void rainDropRadiusChanged();
    void rainDropDepthChanged();

private:
    void updateTextfields();

    Heightfieldwater *m_heightfieldwater;

    QLineEdit *m_cellWidthField;
    QLineEdit *m_numberOfCellsField;
    QLineEdit *m_velocityField;
    QLineEdit *m_dampingField;
    QLineEdit *m_waveHeightField;

    QDoubleSpinBox *m_rainDropRadiusSpinner;
    QDoubleSpinBox *m_rainDropDepthSpinner;
};

#endif // TASK1CONTROLLER_H
