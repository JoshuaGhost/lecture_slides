#ifndef HEIGHTFIELDWATER_H
#define HEIGHTFIELDWATER_H

#include <QVector>
#include <QGraphicsScene>

#include "task1/grid1d.h"

class Grid1DGraphicsItem;
class QGraphicsSceneMouseEvent;

class Heightfieldwater : public QGraphicsScene
{
public:
    Heightfieldwater(double timestep, QObject *parent = 0);

    QRectF sceneRect() const;
    void reset();
    void advance();

    void setWaveVelocity(double velocity);
    void setWaveHeight(double height);
    void setDamping(double damping);
    void setCellWidth(double width);
    void setNumberOfCells(int cells);
    void setTemplate(QString newTemplate);

    double waveVelocity() const { return m_waveVelocity; }
    double waveHeight() const { return m_waveHeight; }
    double damping() const { return m_damping; }
    double cellWidth() const { return m_grid.cellWidth(); }
    double numberOfCells() const { return m_grid.numberOfCells(); }

    void mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent);

    void setRainDropRadius(double radius) { m_rainDropRadius = radius; }
    void setRainDropDepth(double depth) { m_rainDropDepth = depth; }

private:
    void enforceWaveVelocityConstraint();
    void applyTemplate();

    Grid1D m_grid;

    double m_timestep;
    double m_waveVelocity;
    double m_waveHeight;
    double m_damping;
    QString m_template;

    Grid1D m_gridTmp;
    Grid1DGraphicsItem *m_gridItem;
    QVector<double> m_velocities;
    QVector<double> m_velocitiesTmp;

    double m_rainDropRadius;
    double m_rainDropDepth;
};

#endif // HEIGHTFIELDWATER_H
