#ifndef GRID1DGRAPHICSITEM_H
#define GRID1DGRAPHICSITEM_H

#include <QGraphicsItem>

class Grid1D;

class Grid1DGraphicsItem : public QGraphicsItem
{
public:
    Grid1DGraphicsItem(Grid1D *grid);

    virtual QRectF boundingRect() const;
    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = 0);

    void setMaxHeight(double height);

private:
    Grid1D *m_grid;
    double m_max;
};

#endif // GRID1DGRAPHICSITEM_H
