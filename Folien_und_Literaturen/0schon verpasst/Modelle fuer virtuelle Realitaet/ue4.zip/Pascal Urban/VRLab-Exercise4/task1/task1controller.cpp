#include <QLineEdit>
#include <QDebug>

#include "task1controller.h"
#include "heightfieldwater.h"

Task1Controller::Task1Controller(Ui::MainWindow *main, QObject *parent)
    : TaskController(main->task1StartButton, main->task1ResetButton,
                     main->task1GraphicsView, parent),
      m_cellWidthField(main->task1CellWidthField),
      m_numberOfCellsField(main->task1NumberOfCellsField),
      m_velocityField(main->task1VelocityField),
      m_dampingField(main->task1DampingField),
      m_waveHeightField(main->task1TemplateHeightField),
      m_rainDropRadiusSpinner(main->task1RainDropRadiusSpinner),
      m_rainDropDepthSpinner(main->task1RainDropDepthSpinner)
{
    m_heightfieldwater = new Heightfieldwater(TIMESTEP / 1000, this);
    m_heightfieldwater->setRainDropRadius(m_rainDropRadiusSpinner->value());
    m_heightfieldwater->setRainDropDepth(m_rainDropDepthSpinner->value());

    m_graphicsView->setScene(m_heightfieldwater);
    m_graphicsView->setMouseTracking(true);
    m_graphicsView->scale(1, -1); // invert y-axis

    connect(m_cellWidthField, SIGNAL(returnPressed()), this, SLOT(cellWidthFieldChanged()));
    connect(m_numberOfCellsField, SIGNAL(returnPressed()), this, SLOT(numberOfCellsFieldChanged()));
    connect(m_velocityField, SIGNAL(returnPressed()), this, SLOT(velocityFieldChanged()));
    connect(m_dampingField, SIGNAL(returnPressed()), this, SLOT(dampingFieldChanged()));
    connect(m_waveHeightField, SIGNAL(returnPressed()), this, SLOT(waveHeightFieldChanged()));

    connect(main->task1TemplateCombo, SIGNAL(currentIndexChanged(QString)), this, SLOT(templateBoxChanged(QString)));

    connect(m_rainDropRadiusSpinner, SIGNAL(valueChanged(double)), this, SLOT(rainDropRadiusChanged()));
    connect(m_rainDropDepthSpinner, SIGNAL(valueChanged(double)), this, SLOT(rainDropDepthChanged()));

    updateTextfields();
}

void Task1Controller::handleResize()
{
    m_graphicsView->setSceneRect(m_heightfieldwater->sceneRect());
    m_graphicsView->fitInView(m_heightfieldwater->sceneRect(), Qt::KeepAspectRatio);
}

void Task1Controller::updateTextfields()
{
    setTextFieldToNumber(m_cellWidthField, m_heightfieldwater->cellWidth());
    setTextFieldToNumber(m_numberOfCellsField, m_heightfieldwater->numberOfCells());
    setTextFieldToNumber(m_velocityField, m_heightfieldwater->waveVelocity());
    setTextFieldToNumber(m_dampingField, m_heightfieldwater->damping());
    setTextFieldToNumber(m_waveHeightField, m_heightfieldwater->waveHeight());
}

void Task1Controller::reset()
{
    m_heightfieldwater->reset();
}

void Task1Controller::advance()
{
    m_heightfieldwater->advance();
}

/***** Callbacks *****/

void Task1Controller::cellWidthFieldChanged()
{
    double value = m_cellWidthField->text().toDouble();
    m_heightfieldwater->setCellWidth(value);

    updateTextfields(); // velocity can updated due to constraints
    handleResize();
}

void Task1Controller::numberOfCellsFieldChanged()
{
    int value = m_numberOfCellsField->text().toInt();
    m_heightfieldwater->setNumberOfCells(value);

    handleResize();
}

void Task1Controller::velocityFieldChanged()
{
    double value = m_velocityField->text().toDouble();
    m_heightfieldwater->setWaveVelocity(value);
    updateTextfields(); // velocity can updated due to constraints
}

void Task1Controller::dampingFieldChanged()
{
    double value = m_dampingField->text().toDouble();
    m_heightfieldwater->setDamping(value);
}

void Task1Controller::waveHeightFieldChanged()
{
    double value = m_waveHeightField->text().toDouble();
    m_heightfieldwater->setWaveHeight(value);
    handleResize();
}

void Task1Controller::templateBoxChanged(QString string)
{
    m_heightfieldwater->setTemplate(string);
    handleResize();
}

void Task1Controller::rainDropRadiusChanged()
{
    m_heightfieldwater->setRainDropRadius(m_rainDropRadiusSpinner->value());
}

void Task1Controller::rainDropDepthChanged()
{
    m_heightfieldwater->setRainDropDepth(m_rainDropDepthSpinner->value());
}
