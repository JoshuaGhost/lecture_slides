#ifndef GRID1D_H
#define GRID1D_H

#include <vector>

/*
 * Replicates the values of 0 and max for values outside of 0 and max
 */
class Grid1D
{
public:
    friend class Stencil1D;

    Grid1D(int length, double cellWidth, double initialHeight);
    Grid1D(const Grid1D &other);
    ~Grid1D();

    double &operator[](int index);
    const double &operator[](int index) const;
    Grid1D &operator=(const Grid1D &other);

    void setCellWidth(double width) { m_width = width; }
    void setNumberOfCells(int cells);

    double cellWidth() const { return m_width; }
    int numberOfCells() const { return m_length; }

private:
    double m_width;
    int m_length;
    std::vector<double> m_values;
};

#endif // GRID1D_H
