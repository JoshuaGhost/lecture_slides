import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;


@SuppressWarnings("serial")
public class HeatEquation extends SimulationBase {
	
	double aufl�sung = 100;
	double dom�ne = 10;
	int colorFactor = 70;
	double deltaT = 0.01;
	double c = 5;
	
	
	ArrayList<ArrayList<Double>> heat = new ArrayList<>(); 
	
	public class Canvas extends JPanel {
		public Canvas() {
			this.setBackground(Color.white);			
		}
		
		public void paint(Graphics g) {
			super.paintComponent(g);
			
			Graphics2D g2d = (Graphics2D) g;
			g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

			int scaling = (int) (Math.min(getHeight(), getWidth()) / aufl�sung);
			
			for(int x = 0; x < heat.size(); x++) {
				ArrayList<Double> yList = heat.get(x);
				for(int y = 0; y < yList.size(); y++) {
					//g2d.setPaint((y % 2)  == 0 || (x%2) == 0 ? color0 : color1);
					g2d.setPaint(calculateColorFromHeat(yList.get(y)));
					g2d.fill(new Rectangle2D.Double(x*scaling, y*scaling, scaling, scaling));
				}
			}
			

		}		
	}
	
	private void calculateHeat() {
		ArrayList<ArrayList<Double>> heatNew = new ArrayList<>();
		
		//double schrittweite = Double.valueOf(dom�ne)/aufl�sung;
		double schrittweite = 1;
				
		for(int x = 0; x < heat.size(); x++) {
			ArrayList<Double> tempHeatNew = new ArrayList<>();
			for(int y = 0; y < heat.get(x).size(); y++) {
				double temperatur = heat.get(x).get(y);
				double newTemp = 0;
				
				if(x>0) {
					newTemp += heat.get(x-1).get(y);
					newTemp -= temperatur;
				}
				
				if(y>0) {
					newTemp += heat.get(x).get(y-1);
					newTemp -= temperatur;
				}
				
				if(x<heat.size()-1) {
					newTemp += heat.get(x+1).get(y);
					newTemp -= temperatur;
				}
				
				if(y<heat.get(x).size()-1) {
					newTemp += heat.get(x).get(y+1);
					newTemp -= temperatur;
				}
				
				tempHeatNew.add(temperatur + newTemp * Math.pow(c, 2)/Math.pow(schrittweite, 2) * deltaT);
			}			
			heatNew.add(tempHeatNew);
		}
		
		heat = heatNew;
	}
	
	private Color calculateColorFromHeat(double heat) {
		int scaledColor = (int) Math.abs(heat*colorFactor);
		if(scaledColor > 255) scaledColor = 255;
		
		if(heat < 0) {
			return new Color(0,0,  scaledColor);
		}
		return new Color(scaledColor,0, 0);
	}

	
	private Canvas canvas;
	
	public HeatEquation() {			
		this.setLayout(new BorderLayout());
		
		canvas = new Canvas();
		this.add(canvas, BorderLayout.CENTER);
		this.add(this.initControlComponents(), BorderLayout.WEST);
		
		init();
		
		dtTimer = new Timer((int) (dt*1000), (ActionListener) this);
		dtTimer.start();
		
		repaintTimer = new Timer(1000 / REPAINT_RATE, (ActionListener) this);
		repaintTimer.start();
	}
	
	private void init() {
		double schrittweite = Double.valueOf(dom�ne)/aufl�sung;
		
		for(double x = 0; x<dom�ne;x+=schrittweite) {
			ArrayList<Double> tempList = new ArrayList<>();
			for(double y = 0; y<dom�ne;y+=schrittweite) {
				tempList.add(Math.sin(x)+x*Math.cos(y));
			}
			heat.add(tempList);
		}
	}
	
	private JPanel initControlComponents() {
		JPanel panel = new JPanel();
		
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		panel.add(Box.createVerticalGlue());
				
		panel.add(Box.createRigidArea(new Dimension(0,5)));
				
		panel.add(Box.createRigidArea(new Dimension(0,5)));
		
		btnConfirm = new JButton("Restart");
		btnConfirm.setMnemonic(KeyEvent.VK_C);
		btnConfirm.addActionListener(this);
		panel.add(btnConfirm);

		panel.add(Box.createVerticalGlue());
		
		return panel;		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dtTimer) {
			calculateHeat();
		}
		
		if(e.getSource() == repaintTimer) {
			canvas.repaint();
		}
		
		if(e.getSource() == btnConfirm) {
			repaintTimer.stop();
			dtTimer.stop();
			heat.clear();
			init();
			repaintTimer.start();
			dtTimer.start();
		}
	}
}
