import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;


@SuppressWarnings("serial")
public class Heightfieldwater extends SimulationBase {
	

	private ArrayList<Double> heights = new ArrayList<>();
	private ArrayList<Double> geschwindigkeiten = new ArrayList<>();
	private double deltaT = 1;
	private int initWaveSize = 10;
	private int addWaveSize = 10;
	private int spalten = 100;
	
	private double nullHeight = 100.0;
	
	public class Canvas extends JPanel {
		public Canvas() {
			this.setBackground(Color.white);			
		}
		
		public void paint(Graphics g) {
			super.paintComponent(g);
			
			Graphics2D g2d = (Graphics2D) g;
			g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

			int breite = getWidth() / heights.size();
			int position = -breite;
			Color color0 = new Color(0,0,155);
			Color color1 = new Color(0,0,100);
			for(int i = 0; i< heights.size(); i++) {
				g2d.setPaint(i % 2 == 0 ? color0 : color1);
				g2d.fill(new Rectangle2D.Double(position+=breite, getHeight() - (nullHeight + heights.get(i)),breite, getHeight()));
			}
		}		
	}
	
	
	private void calculateHeights() {
		ArrayList<Double> heightsNew = new ArrayList<>();
		ArrayList<Double> geschwindigkeitenNew = new ArrayList<>();
		
		//first
		heightsNew.add(heights.get(1));
		geschwindigkeitenNew.add(0.0);
		
		int breite = getWidth() / heights.size();
		for(int i = 1; i+1 < heights.size(); i++) {
			double fStrichStrich = heights.get(i-1) - 2*heights.get(i) + heights.get(i+1);			
			fStrichStrich /= Math.pow(breite, 2);
			double newGeschw = geschwindigkeiten.get(i) + fStrichStrich*deltaT;
			geschwindigkeitenNew.add(newGeschw);
			heightsNew.add(heights.get(i) + newGeschw*deltaT);
		}
		
		//last
		heightsNew.add(heights.get(heights.size()-2));
		geschwindigkeitenNew.add(0.0);
		
		heights = heightsNew;
		geschwindigkeiten = geschwindigkeitenNew;
	}	
	
	private Canvas canvas;
	private JButton btnAdd;
	
	public Heightfieldwater() {			
		this.setLayout(new BorderLayout());
		
		canvas = new Canvas();
		this.add(canvas, BorderLayout.CENTER);
		this.add(this.initControlComponents(), BorderLayout.WEST);
		
		initWave();
		
		dtTimer = new Timer((int) (dt*1000), (ActionListener) this);
		dtTimer.start();
		
		repaintTimer = new Timer(1000 / REPAINT_RATE, (ActionListener) this);
		repaintTimer.start();
	}
	
	
	
	private void initWave() {
		int nullSpalten = (spalten - initWaveSize) / 2;
		
		for(int i = 0; i<nullSpalten;i++) {
			heights.add(0.0);
			geschwindigkeiten.add(0.0);
		}
		
		for(int i = 0; i<initWaveSize; i++) {
			heights.add(10.0*i);
			geschwindigkeiten.add(0.0);
		}
		
		for(int i = 0; i<initWaveSize; i++) {
			heights.add(10.0*(initWaveSize-i));
			geschwindigkeiten.add(0.0);
		}
				
		for(int i = 0; i<nullSpalten;i++) {
			heights.add(0.0);
			geschwindigkeiten.add(0.0);
		}
	}
	
	private void addWave() {
		for(int i = 0; i < spalten; i++) {
			heights.set(i ,heights.get(i) - (10*(addWaveSize/2)*addWaveSize/spalten));
		}
		
		int start = new Random().nextInt(spalten - addWaveSize);
		for(int i = 0; i<addWaveSize;i++) {
			heights.set(i+start ,heights.get(i+start) + 10*i);
		}
		for(int i = 0; i<addWaveSize;i++) {
			heights.set(i+start+addWaveSize ,heights.get(i+start+addWaveSize) + 10*(addWaveSize-i));
		}
	}
	
	private JPanel initControlComponents() {
		JPanel panel = new JPanel();
		
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		panel.add(Box.createVerticalGlue());
		
		btnAdd = new JButton("Add");
		btnAdd.addActionListener(this);
		panel.add(btnAdd);
		
		panel.add(Box.createRigidArea(new Dimension(0,5)));
				
		panel.add(Box.createRigidArea(new Dimension(0,5)));
		
		btnConfirm = new JButton("Restart");
		btnConfirm.setMnemonic(KeyEvent.VK_C);
		btnConfirm.addActionListener(this);
		panel.add(btnConfirm);

		panel.add(Box.createVerticalGlue());
		
		return panel;		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dtTimer) {
			calculateHeights();
		}
		
		if(e.getSource() == repaintTimer) {
			canvas.repaint();
		}
		
		if(e.getSource() == btnConfirm) {
			repaintTimer.stop();
			dtTimer.stop();
			heights.clear();
			geschwindigkeiten.clear();
			initWave();
			repaintTimer.start();
			dtTimer.start();
		}
		if(e.getSource() == btnAdd) {
			repaintTimer.stop();
			dtTimer.stop();
			addWave();
			repaintTimer.start();
			dtTimer.start();
		}
	}
}
