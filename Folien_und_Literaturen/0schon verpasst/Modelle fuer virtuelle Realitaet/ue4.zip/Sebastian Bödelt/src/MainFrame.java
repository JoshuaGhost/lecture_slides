import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

@SuppressWarnings("serial")
public class MainFrame extends JFrame implements ActionListener {

	// radio buttons
	JRadioButton btnHeightfieldwater;
	JRadioButton btnHeat;

	
	public MainFrame() {
		this.setTitle("Second Exercise");
		this.setSize(800, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        Container pane = this.getContentPane();
        
        pane.setLayout(new BorderLayout());

        btnHeightfieldwater = new JRadioButton("Heightfiedlwater");
        btnHeightfieldwater.addActionListener(this);
        btnHeightfieldwater.setSelected(true);

        btnHeat = new JRadioButton("Heat Equation");
        btnHeat.addActionListener(this);
        btnHeat.setSelected(true);
        

        //Group the radio buttons.
        ButtonGroup group = new ButtonGroup();
        group.add(btnHeightfieldwater);
        group.add(btnHeat);

        
        // panel for radio buttons
        JPanel northPanel = new JPanel();
        northPanel.setLayout(new FlowLayout());
        
        northPanel.add(btnHeightfieldwater);
        northPanel.add(btnHeat);  

        
        pane.add(northPanel, BorderLayout.NORTH);

        pane.add(new Heightfieldwater());
        
        pane.setSize(800,600);
        this.setVisible(true);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
	        
            @Override
            public void run() {
            	MainFrame ex = new MainFrame();
                ex.setVisible(true);
            }
        });

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.getContentPane().remove(((BorderLayout) this.getContentPane().getLayout()).getLayoutComponent(BorderLayout.CENTER));
		
		if (e.getSource() == this.btnHeightfieldwater) {
			this.getContentPane().add(new Heightfieldwater());
		} else if (e.getSource() == this.btnHeat) {
			this.getContentPane().add(new HeatEquation());
		}
		
		this.revalidate();		
	}

}
