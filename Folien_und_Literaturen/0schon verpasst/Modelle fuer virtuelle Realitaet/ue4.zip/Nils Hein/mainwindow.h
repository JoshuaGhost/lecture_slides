#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>



namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:
    void updHF();
    void startHF();
    void resetHF();
    void click(QMouseEvent*e);
    void move(QMouseEvent*e);
    void click2(QMouseEvent*e);
    void move2(QMouseEvent*e);
    void change(double height);

    //Heat
    void initHeat();
    void updHeat();
    void startHeat();
    void resetHeat();

private:

    bool isRunning = false;
    bool isRunningHeat = false;
    int size = 50;
    QTimer *timerHeightfield;
    QTimer *timerHeat;
    Ui::MainWindow *ui;
    QVector<double> t,v,h,d,mousex,mousey;

    QVector<double> tHeat;
    double uHeat[66][66];
    double f[66][66];
};

#endif // MAINWINDOW_H
