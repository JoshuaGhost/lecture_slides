#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <math.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    timerHeightfield = new QTimer();
    timerHeat = new QTimer();
    connect(timerHeightfield,SIGNAL(timeout()),this,SLOT(updHF()));
    connect(timerHeat,SIGNAL(timeout()),this,SLOT(updHeat()));
    connect(ui->btnStart,SIGNAL(clicked()),this,SLOT(startHF()));
    connect(ui->btnReset,SIGNAL(clicked()),this,SLOT(resetHF()));
    connect(ui->btnStart_2,SIGNAL(clicked()),this,SLOT(startHeat()));
    connect(ui->btnReset_2,SIGNAL(clicked()),this,SLOT(resetHeat()));
    connect(ui->Plot,SIGNAL(mouseRelease(QMouseEvent*)),this,SLOT(click(QMouseEvent*)));
    connect(ui->Plot,SIGNAL(mouseMove(QMouseEvent*)),this,SLOT(move(QMouseEvent*)));
    connect(ui->Plot_2,SIGNAL(mouseRelease(QMouseEvent*)),this,SLOT(click2(QMouseEvent*)));
    connect(ui->Plot_2,SIGNAL(mouseMove(QMouseEvent*)),this,SLOT(move2(QMouseEvent*)));

    connect(ui->sbHeight,SIGNAL(valueChanged(double)),this,SLOT(change(double)));

    timerHeightfield->setInterval(0);
    timerHeat->setInterval(0);

    mousex << 0.0;
    mousex << size*0.5;
    mousex << size;

    mousey << 5.0;
    mousey << 8.0;
    mousey << 5.0;



    //    ui->Plot->setInteraction(QCP::iRangeDrag, true);
    //    ui->Plot->setInteraction(QCP::iRangeZoom, true);

    resetHF();
    initHeat();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updHF()
{
    ui->Plot->clearPlottables();
    double dt = ui->sbDT->value();
    double diff = 2.0;
    double c = 0.1;
    h[0] = h[1];
    h[size-1] = h[size-2];

    for (int i = 1; i < size-1; ++i) {
        v[i] = v[i]+(((dt*(c*c))/(diff*diff))*(h[i-1]-(2*h[i])+h[i+1]));
    }
    for (int i = 1; i < size-1; ++i) {
        h[i] = h[i]+(dt*v[i]);
    }
    //    ui->Plot->clearPlottables();
    //    QCPCurve *heightwater = new QCPCurve(ui->Plot->xAxis,ui->Plot->yAxis);
    //    ui->Plot->addPlottable(heightwater);
    //    heightwater->setData(d,h);
    //    heightwater->setPen(QPen(Qt::blue));
    //    heightwater->setBrush(QBrush(Qt::blue));

    ui->Plot->addGraph();
    ui->Plot->addGraph();

    ui->Plot->graph(0)->setPen(QPen(Qt::red));
    ui->Plot->graph(0)->setData(d,h);
    ui->Plot->graph(0)->setPen(QPen(Qt::blue));
    ui->Plot->graph(0)->setBrush(QBrush(QColor(0, 0, 255, 20)));

    ui->Plot->graph(1)->setPen(QPen(Qt::red));
    ui->Plot->graph(1)->setData(mousex,mousey);
    ui->Plot->graph(1)->setBrush(QBrush(QColor(255, 0, 0, 20)));
    //ui->Plot->axisRect()->setupFullAxesBox();
    ui->Plot->xAxis->setTickLength(0,1);
    ui->Plot->xAxis->setRange(0,size);
    ui->Plot->yAxis->setRange(0,size);
    ui->Plot->replot();
}

void MainWindow::updHeat()
{
    ui->Plot_2->clearPlottables();
    double dt = ui->sbDT_2->value();
    double diff = 1.0;
    double c = 1.0;

    QCPColorMap *colorMap = new QCPColorMap(ui->Plot_2->xAxis, ui->Plot_2->yAxis);
    ui->Plot_2->addPlottable(colorMap);
    int nx = 64;
    int ny = 64;
    colorMap->data()->setSize(nx, ny);
    colorMap->data()->setRange(QCPRange(0, 64), QCPRange(0,64));
    double newHeat[66][66];
    for (int x = 1; x < 65; ++x) {
        for (int y = 1; y < 65; ++y) {
            double du = (uHeat[x-1][y]-(4*uHeat[x][y])+uHeat[x+1][y]+uHeat[x][y-1]+uHeat[x][y+1])+f[x][y];
            newHeat[x][y] = uHeat[x][y]+((dt*c)/(diff*diff))*du;
        }
    }
    for (int x = 1; x < 65; ++x) {
        for (int y = 1; y < 65; ++y) {
            uHeat[x][y] = newHeat[x][y];
            colorMap->data()->setCell(x-1, y-1, uHeat[x][y]);
        }
    }

    colorMap->setGradient(QCPColorGradient::gpSpectrum);
    colorMap->setDataRange(QCPRange(-70,70));
    ui->Plot_2->replot();
}

void MainWindow::startHeat()
{
    if(isRunning){
        ui->btnStart_2->setText("Start");
        timerHeat->stop();
        isRunningHeat = false;
        return;
    }
    ui->btnStart_2->setText("Stop");
    timerHeat->start();
    isRunningHeat = true;
}

void MainWindow::resetHeat()
{
    timerHeat->stop();
    ui->btnStart_2->setText("Start");
    initHeat();
}

void MainWindow::startHF()
{
    if(isRunning){
        ui->btnStart->setText("Start");
        timerHeightfield->stop();
        isRunning = false;
        return;
    }
    ui->btnStart->setText("Stop");
    timerHeightfield->start();
    isRunning = true;
}

void MainWindow::resetHF()
{
    timerHeightfield->stop();
    ui->btnStart->setText("Start");
    t.clear();
    h.clear();
    d.clear();
    v.clear();

    for (int i = 0; i < size; ++i) {
        h << 5.0;
        v << 0.0;
        d << i;
    }

}

void MainWindow::click(QMouseEvent *e)
{
    if(e->button() == Qt::RightButton){
        double y = mousey[1];//ui->Plot->height()-(e->pos().y()-ui->Plot->pos().y()+50);
        if(y > 5){
            int x =mousex[1];
            //            for (int i = 0; i < size; ++i) {
            //                if(i == x)
            //                    h[i] += y;
            //                else if(i>x)
            //                    h[i] +=fabs(y/(i-x));
            //            }
            for (int i = x-10; i < x+10; ++i) {
                if(i == x)
                    h[i] = y;
                else
                    h[i] =(y-fabs(i-x));
            }
        }
    }
}

void MainWindow::move(QMouseEvent *e)
{
    mousex[1] = size*((double)(e->x())/ui->Plot->width());
    mousey[1] = size*((double)(ui->Plot->height()-e->y())/ui->Plot->height());
}

void MainWindow::click2(QMouseEvent *e)
{
    int mx = 66.0*((double)(e->x())/ui->Plot_2->width());
    int my = 66.0*((double)(ui->Plot_2->height()-e->y())/ui->Plot_2->height());
    int max = ui->sbFSize->value();
    for (int x = mx-(max/2); x <mx+(max/2) ; ++x) {
        for (int y = my-(max/2); y < my+(max/2); ++y) {
            if(true){
                if(e->button() == Qt::RightButton)
                    f[x][y] = -64;
                if(e->button() == Qt::LeftButton)
                    f[x][y] = 64;
            }
        }
    }
}

void MainWindow::move2(QMouseEvent *e)
{
}

void MainWindow::change(double height)
{
    for (int i = 0; i < h.size(); ++i) {
       h[i] += height;
    }
    ui->sbHeight->setValue(0.0);
}

void MainWindow::initHeat()
{
    QCPColorMap *colorMap = new QCPColorMap(ui->Plot_2->xAxis, ui->Plot_2->yAxis);
    ui->Plot_2->addPlottable(colorMap);
    int nx = 64;
    int ny = 64;
    colorMap->data()->setSize(nx, ny);
    colorMap->data()->setRange(QCPRange(0, 64), QCPRange(0,64));

    double dx = 0;
    double dy = 0;
    for (int x = 0; x < 66; ++x) {
        for (int y = 0; y < 66; ++y) {
            dx = x;
            dy = y;
            f[x][y] = 0.0;
            if(x>0&&y>0&&x<65&&y<65){
                uHeat[x][y] = sin(x)+x*cos(y);
                colorMap->data()->cellToCoord(x, y,&dx,&dy);
                colorMap->data()->setCell(x, y, uHeat[x][y]);
            }else{
                uHeat[x][y] = 0.0;
            }
        }
    }

    colorMap->setGradient(QCPColorGradient::gpSpectrum);
    colorMap->setDataRange(QCPRange(-70,70));

    ui->Plot_2->rescaleAxes();
    ui->Plot_2->replot();
}
