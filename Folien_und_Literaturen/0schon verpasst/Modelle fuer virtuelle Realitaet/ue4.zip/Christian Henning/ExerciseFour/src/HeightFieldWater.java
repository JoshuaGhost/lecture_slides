import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.NumberFormat;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


@SuppressWarnings("serial")
public class HeightFieldWater extends SimulationBase {
	
	// initial number of bars
	static private int INITIAL_BAR_NUM = 100;
	
	// initial bar width in m
	static private double INITIAL_BAR_WIDTH = 0.01;
	
	// initial bar height in m
	static private double INITIAL_BAR_HEIGHT = 1;
	
	// initial wave velocity in m/s
	static private double INITIAL_VELOCITY = 0.05*(INITIAL_BAR_WIDTH/INITIAL_TIMESTEP);
	
	// width of the water basin/tank
//	private double basinWidth = 10;
	
	private int numOfBars;
	// bar width in m
	private double h;
	// wave velocity in m/s
	private double c;
	
	private double[] barHeights;
	// derivative of bar height with respect to time
	private double[] barVelocities;
	
	private boolean waveAdded;
	private double[] wavePreview;
	private int previewWidth = 10;
	private double previewHeight = 0.2 * INITIAL_BAR_HEIGHT;
	private int addedWaveCenter;
	
	private double damping = 0.01;
	
	// necessary to draw all waves within canvas
	private double maxHeight;
	
	private JFormattedTextField txtNumOfBars;
	private JFormattedTextField txth;
	private JFormattedTextField txtc;
	private JFormattedTextField txtPreviewWidth;
	private JFormattedTextField txtPreviewHeight;
	
	public class Canvas extends JPanel implements MouseListener, MouseMotionListener {
		private int mousePosX = -1;
		private boolean checkCenter;
		
		public Canvas() {
			this.setBackground(Color.white);	
			
			this.addMouseListener(this);
			this.addMouseMotionListener(this);
		}
		
		public void paint(Graphics g) {
			super.paintComponent(g);
			
			Graphics2D g2d = (Graphics2D) g;
			g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
			
			int w = getWidth();
	        int h = getHeight();
	        
	        // find maximum height
//	        double maxHeight = 0;
//	        for (double he : barHeights) {
//	        	if (he > maxHeight) {
//	        		maxHeight = he;
//	        	}
//	        }
	        // scale bars to 80% of the window height
	        double scale = (0.8*h) / maxHeight;

	        
	        int offset = (int) (0.05 * w);
	        double barWidth = (w - 2.0 * offset) / numOfBars;
	        
	        int ground = (int) (0.9 * h);
	        int barOffset; // y offset
	        int scaledHeight;
	        	        
	        // draw wave preview
	        g2d.setPaint(new Color(1.0f,0.0f,0.0f, 0.5f));
	        if (mousePosX != -1) {
	        	int center = (int) ((mousePosX - offset) / barWidth);
	        	
	        	if (center >= 0 && center < numOfBars) {
	        		if (checkCenter) {
		        		addedWaveCenter = center;
		        		waveAdded = true;
		        		checkCenter = false;
	        		}
	        		
	        		int index;
		        	for (int i = 0; i < wavePreview.length; i++) {
		        		index = center - wavePreview.length/2 + i;
		        		if (index < 0 || index >= numOfBars) {
		        			continue;
		        		}
		        		scaledHeight = (int) (wavePreview[i] * scale);
			        	scaledHeight = scaledHeight < 0 ? 0 : scaledHeight;
			        	barOffset = ground - scaledHeight;
			        	g2d.fill(new Rectangle.Double(offset + index*barWidth, barOffset, barWidth, scaledHeight));
		        	}
	        	}
	        }
	        
	        // draw waves
	        g2d.setPaint(Color.blue);
	        for (int i = 0; i < numOfBars; i++) {
	        	scaledHeight = (int) (barHeights[i] * scale);
	        	scaledHeight = scaledHeight < 0 ? 0 : scaledHeight;
	        	barOffset = ground - scaledHeight;
	        	g2d.fill(new Rectangle.Double(offset + i*barWidth, barOffset, barWidth, scaledHeight));
	        }
	        
		}

		@Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			mousePosX = -1;		
		}

		@Override
		public void mousePressed(MouseEvent e) {
			checkCenter = true;
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			mousePosX = e.getX();
		}		
	}
	
	private Canvas canvas;

	public HeightFieldWater(JFrame parent) {
		super(parent);
		
		this.numOfBars = INITIAL_BAR_NUM;
		this.h = INITIAL_BAR_WIDTH;
		this.c = INITIAL_VELOCITY;
		resetWaves();
				
		this.setLayout(new BorderLayout());
		
		canvas = new Canvas();
		this.add(canvas, BorderLayout.CENTER);
		this.add(this.initControlComponents(), BorderLayout.WEST);
		
		dtTimer = new Timer((int) (dt*1000), (ActionListener) this);
		dtTimer.start();
		
		repaintTimer = new Timer(1000 / REPAINT_RATE, (ActionListener) this);
		repaintTimer.start();
	}
	
	private void resetWaves() {
		this.barHeights = new double[numOfBars];
		this.barVelocities = new double[numOfBars];
		for (int i = 0; i< numOfBars; i++) {
			barHeights[i] = 0.99*INITIAL_BAR_HEIGHT + 0.01*Math.sin(i*20*Math.PI/numOfBars)*INITIAL_BAR_HEIGHT;
//			barVelocities[i] = 0;
		}
		calculatePreview();
	}
	
	private void calculatePreview() {
		this.wavePreview = new double[this.previewWidth];
		
		// average height
		double avg = 0;
		for (int i = 0; i < numOfBars; i++) {
			avg += barHeights[i];			
		}
		avg /= numOfBars;
		
		for (int i = 0; i < previewWidth; i++) {
			wavePreview[i] = avg + Math.sin(i * Math.PI / previewWidth) * this.previewHeight;
		}
		if (previewWidth > 0) {
			wavePreview[previewWidth/2] = avg + this.previewHeight;
		}
		
		this.maxHeight = avg + this.previewHeight;
	}
	
	private void addWave() {
		dtTimer.stop();
		
		int index;		
		double totalAddedVolume = 0;
		double addedVolume;
    	for (int i = 0; i < wavePreview.length; i++) {
    		index = addedWaveCenter - wavePreview.length/2 + i;
    		if (index < 0 || index >= numOfBars) {
    			continue;
    		}
    		addedVolume = Math.max(0, wavePreview[i] - barHeights[index]);
    		totalAddedVolume += addedVolume;
    		barHeights[index] += addedVolume;
//    		if (index+wavePreview.length < numOfBars) {
//    			totalAddedVolume -= addedVolume;
//        		barHeights[index+wavePreview.length] -= addedVolume;
//    		}
    	}
    	
    	// FIXME: weird code
    	// smoothing transitions
    	index = addedWaveCenter - wavePreview.length/2 -1;
    	double j;
    	while (index >= 0) {
    		j = (index-(addedWaveCenter - wavePreview.length/2));
    		double temp = this.maxHeight - this.previewHeight + Math.sin(j * Math.PI / previewWidth) * this.previewHeight;
    		addedVolume = Math.max(0, temp - barHeights[index]);
    		totalAddedVolume += addedVolume;
    		barHeights[index] += addedVolume;
    		if (addedVolume == 0) break;
    		index--;
    	}
    	
    	index = addedWaveCenter + wavePreview.length/2 +1;
    	while (index < numOfBars) {
    		j = previewWidth + index-(addedWaveCenter + wavePreview.length/2);
    		double temp = this.maxHeight - this.previewHeight + Math.sin(j * Math.PI / previewWidth) * this.previewHeight;
    		addedVolume = Math.max(0, temp - barHeights[index]);
    		totalAddedVolume += addedVolume;
    		barHeights[index] += addedVolume;
    		if (addedVolume == 0) break;
    		index++;
    	}
    	
    	// we have to conserve the amount of water in the system
    	double diff = totalAddedVolume / numOfBars;
    	for (int i = 0; i < numOfBars; i++) {
			barHeights[i] -= diff;			
		}
    	
		dtTimer.start();
	}
	
	private void updateVelocities() {		
		// second derivative with respect to time multiplied by dt
		double secDeriv;
		double factor = (c)/(h*h) * dt;
		// i = j-1 and k = j+1
		int i, k;
		for (int j = 0; j < numOfBars; j++) {
			i = j == 0 ? j : j-1;
			k = j == numOfBars-1 ? j : j+1;
			
			secDeriv = factor*(barHeights[i] - 2*barHeights[j] + barHeights[k]);
			
			barVelocities[j] = (1-damping) * barVelocities[j] + secDeriv;			
		}
	}
	
	private void updateHeights() {
		for (int i = 0; i < numOfBars; i++) {
			barHeights[i] += dt * barVelocities[i];
		}
	}
	
	private JPanel initControlComponents() {
		JPanel panel = new JPanel();
		
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		panel.add(Box.createVerticalGlue());
		
		txtStepSize = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtDamping = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtNumOfBars = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txth = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtc = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtPreviewWidth = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtPreviewHeight = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
//		txtLengthFactor = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
//		txtLengthFactor.setToolTipText(LENGTH_FACTOR_TOOL_TIP);
		
		this.addTextField(panel, "Step size (dt) in s:", txtStepSize, dt);
		this.addTextField(panel, "Damping:", txtDamping, damping);
		this.addTextField(panel, "Number of bars:", txtNumOfBars, (double) numOfBars);
		this.addTextField(panel, "Width of a bar (h) in m:", txth, h);
		this.addTextField(panel, "Wave velocity (c) in m/s:", txtc, c);
		this.addTextField(panel, "Width of wave preview:", txtPreviewWidth, (double) previewWidth);
		this.addTextField(panel, "Height of wave preview in m:", txtPreviewHeight, previewHeight);

//		this.addTextField(panel, "Length factor:", txtLengthFactor, (double) LENGTH_FACTOR);
		
		panel.add(Box.createRigidArea(new Dimension(0,5)));
		
		btnConfirm = new JButton("Confirm");
		btnConfirm.setMnemonic(KeyEvent.VK_C);
		btnConfirm.addActionListener(this);
		panel.add(btnConfirm);

		panel.add(Box.createVerticalGlue());
		
		this.parent.getRootPane().setDefaultButton(btnConfirm);
		
		return panel;		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dtTimer) {
			if (waveAdded) {
				addWave();
				waveAdded = false;
			}
			this.updateVelocities();
			this.updateHeights();
		}
		
		if(e.getSource() == repaintTimer) {
			canvas.repaint();
		}
		
		if(e.getSource() == btnConfirm) {
			try {
				dtTimer.stop();
				
				this.dt = Double.parseDouble(this.txtStepSize.getText().replace(",", ""));		
				dtTimer = new Timer((int) (dt*1000), (ActionListener) this);
				
				this.numOfBars = (int) Double.parseDouble(this.txtNumOfBars.getText().replace(",", ""));
				this.h = Double.parseDouble(this.txth.getText().replace(",", ""));
				this.c = Double.parseDouble(this.txtc.getText().replace(",", ""));	
				this.previewWidth = (int) Double.parseDouble(this.txtPreviewWidth.getText().replace(",", ""));
				this.previewHeight = Double.parseDouble(this.txtPreviewHeight.getText().replace(",", ""));	
				
				this.damping = Double.parseDouble(this.txtDamping.getText().replace(",", ""));
				if(this.damping < 0 || this.damping > 1) {
					this.damping = 0;
					txtDamping.setValue(damping);
					System.out.println("damping has to be a number between 0 and 1");
				}
				
//				LENGTH_FACTOR = (int) Double.parseDouble(this.txtLengthFactor.getText().replace(",", ""));	
				
				this.resetWaves();

				dtTimer.start();
				
			} catch (Exception except) {
				except.printStackTrace();
			}
		}
		
	}

}
