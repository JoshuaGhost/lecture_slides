import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class MainFrame extends JFrame implements ChangeListener {

	public JTabbedPane tabs;
	
	public MainFrame() {
		this.setTitle("Second Exercise");
//		this.setSize(300, 200);		
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        Container pane = this.getContentPane();
        
        pane.setLayout(new BorderLayout());
        
        tabs = new JTabbedPane();
        
        pane.add(tabs);

        tabs.add("Heightfieldwater", new HeightFieldWater(this));
        tabs.add("Heat Evolution", new HeatEvolution(this));
        tabs.add("Heat Evolution Bonus", new HeatEvolution2(this));
        
        SimulationBase tab;
        for (int i = 1; i < tabs.getTabCount(); i++) {
        	tab = (SimulationBase) tabs.getComponentAt(i);
        	tab.setActive(false);
        }
        
        tabs.addChangeListener(this);
        
        this.pack();
        this.setVisible(true);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
	        
            @Override
            public void run() {
            	MainFrame ex = new MainFrame();
                ex.setVisible(true);
            }
        });

	}

	@Override
	public void stateChanged(ChangeEvent e) {
		if(e.getSource() == tabs) {
			SimulationBase tab;
	        for (int i = 0; i < tabs.getTabCount(); i++) {
	        	tab = (SimulationBase) tabs.getComponentAt(i);
	        	if (i == tabs.getSelectedIndex()) {
	        		tab.setActive(true);
	        	} else {
	        		tab.setActive(false);
	        	}
	        }
		}
		
	}


}
