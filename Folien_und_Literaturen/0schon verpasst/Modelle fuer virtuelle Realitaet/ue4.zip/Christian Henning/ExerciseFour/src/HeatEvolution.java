import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


@SuppressWarnings("serial")
public class HeatEvolution extends SimulationBase {
	
	// grid size in one dimension
	static private int INITIAL_GRID_SIZE = 64;
	
	// grid domain
	static private int GRID_MIN = 0;
	static private int GRID_MAX = 10;
	
	static private double INITIAL_THERMAL_DIFFUSIVITY = 0.001; // 1.27 * Math.pow(10, -4);
	
	// cell width
	private double h;
	// thermal diffusivity
	private double c;
	
	private int gridSize;
	
	private double[][] grid;
	
//	private JFormattedTextField txth;
	private JFormattedTextField txtc;
	private JFormattedTextField txtGridSize;
	
	public class Canvas extends JPanel {
		
		double min;
		double max;
		
		public Canvas() {
			this.setBackground(Color.white);	
			
			min = Double.MAX_VALUE;
	        max = Double.MIN_VALUE;
		}
		
		public void paint(Graphics gr) {
			super.paintComponent(gr);
			
			Graphics2D g2d = (Graphics2D) gr;
			g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
			
			if (min == Double.MAX_VALUE) {
				return;
			}
			
			int w = getWidth();
	        int h = getHeight();
	        
	        int offset = (int) (0.05 * ((w+h)/2.0));
	        double cellW = (w - 2.0*offset) / gridSize;
	        double cellH = (h - 2.0*offset) / gridSize;
	        
	        double cellX = offset;
	        double cellY = offset;
	        
	        double ratio;
	        int r, g, b;
	        
	        for (int x = 0; x < gridSize; x++) {		        		        	
				for (int y = 0; y < gridSize; y++) {
					ratio = 2* (grid[x][y] - min)/(max - min);
					ratio = Math.min(ratio, 2);
					ratio = Math.max(ratio, 0);
					b = (int) Math.max(0, 255*(1-ratio));
					r = (int) Math.max(0, 255*(ratio - 1));
					g = 255 - b - r;
					
					g2d.setPaint(new Color(r,g,b));
					
					g2d.fill(new Rectangle.Double(cellX,cellY,cellW,cellH));
					
					cellY += cellH;
				}
				
				cellY = offset;
				cellX += cellW;
			}	        
		}
		
		public void configureColorScale() {
			min = Double.MAX_VALUE;
	        max = Double.MIN_VALUE;
	        
	        for (int x = 0; x < gridSize; x++) {				
				for (int y = 0; y < gridSize; y++) {
					if (grid[x][y] < min) {
						min = grid[x][y];
					} else if(grid[x][y] > max) {
						max = grid[x][y];
					}						
				}
			}	
		}
	}
	
	private Canvas canvas;

	public HeatEvolution(JFrame parent) {
		super(parent);
		
		canvas = new Canvas();
		
		c = INITIAL_THERMAL_DIFFUSIVITY;
		gridSize = INITIAL_GRID_SIZE;
		initGrid();
				
		this.setLayout(new BorderLayout());
		
		this.add(canvas, BorderLayout.CENTER);
		this.add(this.initControlComponents(), BorderLayout.WEST);
		
		dtTimer = new Timer((int) (dt*1000), (ActionListener) this);
		dtTimer.start();
		
		repaintTimer = new Timer(1000 / REPAINT_RATE, (ActionListener) this);
		repaintTimer.start();
	}
	
	private void initGrid() {
		this.grid = new double[gridSize][gridSize];
		
		// start values
		double x = GRID_MIN;
		double y = GRID_MIN;
		
		h = (GRID_MAX - x) / Math.max(1, gridSize-1);
		
		for (int i = 0; i < gridSize; i++) {
			for (int j = 0; j < gridSize; j++) {
				grid[i][j] = Math.sin(x) + x * Math.cos(y);
								
				y += h;
			}
			x += h;
			y = GRID_MIN;
		}
		
		canvas.configureColorScale();
	}
	
	private void updateGrid() {
		// first derivative with respect to time multiplied by dt
		double firstDeriv;
		double factor = (c)/(h*h) * dt;
		// i = j-1 and k = j+1
		int xp, xn, yp, yn;
		
		double[][] tempGrid = new double[gridSize][gridSize];	
		System.arraycopy( grid, 0, tempGrid, 0, grid.length );
		
		for (int x = 0; x < gridSize; x++) {
			xp = x == 0 ? x : x-1;
			xn = x == gridSize-1 ? x : x+1;
			
			for (int y = 0; y < gridSize; y++) {
				yp = y == 0 ? y : y-1;
				yn = y == gridSize-1 ? y : y+1;
				
				firstDeriv = factor*(-4*tempGrid[x][y] + tempGrid[xp][y] + tempGrid[xn][y] + tempGrid[x][yp] + tempGrid[x][yn]);
				
				grid[x][y] = (1-damping) * grid[x][y] + firstDeriv;			
			}
		}
	}
	
	private JPanel initControlComponents() {
		JPanel panel = new JPanel();
		
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		panel.add(Box.createVerticalGlue());
		
		txtStepSize = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtDamping = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
//		txth = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtc = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
		txtGridSize = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
//		txtLengthFactor = new JFormattedTextField(NumberFormat.getNumberInstance(Locale.US));
//		txtLengthFactor.setToolTipText(LENGTH_FACTOR_TOOL_TIP);
		
		this.addTextField(panel, "Step size (dt) in s:", txtStepSize, dt);
		this.addTextField(panel, "Damping:", txtDamping, damping);
//		this.addTextField(panel, "Width of a grid cell (h) in m:", txth, h);
		this.addTextField(panel, "Thermal diffusivity (c):", txtc, c);
		this.addTextField(panel, "Grid Size:", txtGridSize, (double) gridSize);

//		this.addTextField(panel, "Length factor:", txtLengthFactor, (double) LENGTH_FACTOR);
		
		panel.add(Box.createRigidArea(new Dimension(0,5)));
		
		btnConfirm = new JButton("Confirm");
		btnConfirm.setMnemonic(KeyEvent.VK_C);
		btnConfirm.addActionListener(this);
		panel.add(btnConfirm);

		panel.add(Box.createVerticalGlue());
		
		this.parent.getRootPane().setDefaultButton(btnConfirm);
		
		return panel;		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dtTimer) {
			this.updateGrid();
		}
		
		if(e.getSource() == repaintTimer) {
			canvas.repaint();
		}
		
		if(e.getSource() == btnConfirm) {
			try {
				dtTimer.stop();
				
				this.dt = Double.parseDouble(this.txtStepSize.getText().replace(",", ""));		
				dtTimer = new Timer((int) (dt*1000), (ActionListener) this);

//				this.h = Double.parseDouble(this.txth.getText().replace(",", ""));
				this.c = Double.parseDouble(this.txtc.getText().replace(",", ""));	
				this.gridSize = (int) Double.parseDouble(this.txtGridSize.getText().replace(",", ""));	
				
				this.damping = Double.parseDouble(this.txtDamping.getText().replace(",", ""));
				if(this.damping < 0 || this.damping > 1) {
					this.damping = 0;
					txtDamping.setValue(damping);
					System.out.println("damping has to be a number between 0 and 1");
				}
				
//				LENGTH_FACTOR = (int) Double.parseDouble(this.txtLengthFactor.getText().replace(",", ""));	
				
				this.initGrid();

				dtTimer.start();
				
			} catch (Exception except) {
				except.printStackTrace();
			}
		}
		
	}

}
