#ifndef VRBASE_H
#define VRBASE_H

#include "../interfaces/RendererBase.h"
#include <QList>
#include <cmath>

class VRBase : public RendererBase
{
public:
    VRBase();
    virtual ~VRBase();

    virtual void setupGUI(GdvGui& userInterface) = 0;
    virtual void render(GdvCanvas& canvas) = 0;
    virtual void initialize() = 0;
    virtual void deinitialize() = 0;
    virtual void sizeChanged(unsigned int width, unsigned int height);
    virtual bool usesOpenGL();
    virtual void mousePressed(int x, int y) = 0;

    int viewWidth, viewHeight;
    int xMin = -5;
    int xMax = 5;
    int yMin = -4;
    int yMax = 4;

    void drawLine(GdvCanvas &canvas, int xLeft, int xRight, int yLeft, int yRight, QVector3D color);
    void drawBigLine(GdvCanvas &canvas, int xLeft, int xRight, int yLeft, int yRight, QVector3D color);
    void drawPixel(GdvCanvas& canvas, int x, int y, QVector3D color);
    virtual void drawBig(GdvCanvas& canvas, int x, int y,QVector3D color);
    int getRealX(float x);
    int getRealY(float y);
    QVector3D color;


    float currentTime = 0.0f;
    float startTime = 0.0f;
    float endTime = 200.0f;
    float timeStep = 0.001f;

    bool singleRendering = false;
    float singleRenderTime = 0.0f;
    int singleRenderFactor;

    bool bigPixels = false;

    QElapsedTimer timer;
};

#endif // VRBASE_H
