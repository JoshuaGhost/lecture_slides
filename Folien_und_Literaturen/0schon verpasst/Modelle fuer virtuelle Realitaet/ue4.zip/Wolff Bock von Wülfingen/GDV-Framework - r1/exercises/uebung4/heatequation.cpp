#include "heatequation.h"

HeatEquation::HeatEquation(){
    heatmap = QVector<QVector<double>>(gridSize);
    heatVelocity = QVector<QVector<double>>(gridSize);
    for(int i = 0; i < gridSize; i++) {
        heatmap[i].resize(gridSize);
        heatVelocity[i].resize(gridSize);
    }
}

HeatEquation::~HeatEquation() {

}

void HeatEquation::setupGUI(GdvGui &userInterface) {

}

void HeatEquation::initialize() {
    int range = upperLimit - lowerLimit;
    h = range*1.0f/gridSize;

    for(int i = 0; i < gridSize; i++) {
        for(int j = 0; j < gridSize; j++) {
            heatmap[i][j] = initialTemperature(lowerLimit + i*h,lowerLimit + j*h);
            heatVelocity[i][j] = 0;

        }
    }
}

double HeatEquation::initialTemperature(double x, double y) {
    return sin(x) + x * cos(y);
}

void HeatEquation::deinitialize() {
}

void HeatEquation::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));
    if(hasStarted) {
        qint64 timeElapsed = timer.elapsed();
        double tpf = timeElapsed/1000.0f;
        timer.restart();

        //calc values
        recalcSystem(tpf);
    }

    double lowestValue = 0;
    QVector2D lowest = QVector2D(0,0);
    double highestValue = 2;
    QVector2D highest = QVector2D(0,0);

    for(int row = 0; row < gridSize; row++) {
        for(int col = 0; col < gridSize; col++) {
            if(heatmap[row][col]>highestValue) {
                highestValue = heatmap[row][col];
                highest = QVector2D(row,col);
            }
            if(heatmap[row][col] < lowestValue) {
                lowestValue = heatmap[row][col];
                lowest = QVector2D(row,col);
            }
        }
    }
    double range = highestValue-lowestValue;

    double heatSum = 0;
    for(int row = 0; row < gridSize; row++) {
        for(int col = 0; col < gridSize; col++) {
            double p = (heatmap[row][col]-lowestValue)/range;
            QVector3D color = p*red + (1-p)*blue;
            drawBig(canvas,row*3,col*3,color);
            heatSum+=heatmap[row][col];
        }
    }
//    qDebug() << heatSum;
//    qDebug() << "highest: " << highestValue;
//    qDebug() << highest;
//    qDebug() << "lowest: " << lowestValue;
//    qDebug() << lowest;
    canvas.flipBuffer();
}

void HeatEquation::recalcSystem(double tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }

    double prefactor = (timeStep*c)/(h*h);

    for(int t = 0; t < iterations;t++) {
        //adjust velocities first
        heatVelocity[0][0] = prefactor*(-2*heatmap[0][0]+heatmap[0][1]+heatmap[1][0]);
        heatVelocity[gridSize-1][0] = prefactor*(-2*heatmap[gridSize-1][0]+heatmap[gridSize-1][1]+heatmap[gridSize-2][0]);
        heatVelocity[gridSize-1][gridSize-1] = prefactor*(-2*heatmap[gridSize-1][gridSize-1]+heatmap[gridSize-2][gridSize-1]+heatmap[gridSize-1][gridSize-2]);
        heatVelocity[0][gridSize-1] = prefactor*(-2*heatmap[0][gridSize-1] + heatmap[1][gridSize-1] + heatmap[0][gridSize-2]);

        for(int row = 1; row < gridSize-1; row++) {
            heatVelocity[row][0] = prefactor*(-3*heatmap[row][0]+heatmap[row][1]+heatmap[row-1][0]+heatmap[row+1][0]);
        }
        for(int col = 1; col < gridSize-1; col++) {
            heatVelocity[0][col] = prefactor*(-3*heatmap[0][col]+heatmap[0][col+1]+heatmap[0][col-1]+heatmap[1][col]);
        }
        for(int row = 1; row < gridSize-1; row++) {
            heatVelocity[row][gridSize-1] = prefactor*(-3*heatmap[row][gridSize-1]+heatmap[row][gridSize-2]+heatmap[row-1][gridSize-1]+heatmap[row+1][gridSize-1]);
        }
        for(int col = 1; col < gridSize-1; col++) {
            heatVelocity[gridSize-1][col] = prefactor*(-3*heatmap[gridSize-1][col]+heatmap[gridSize-1][col+1]+heatmap[gridSize-1][col-1]+heatmap[gridSize-2][col]);
        }

        for(int row = 1; row < gridSize-1; row++) {
            for(int col = 1; col < gridSize-1; col++) {
                double stencil = -4*heatmap[row][col] + heatmap[row-1][col] + heatmap[row+1][col] + heatmap[row][col-1] + heatmap[row][col+1];
                heatVelocity[row][col] = prefactor*stencil;
            }
        }

        //adjust heatlevels second
        for(int row = 0; row < gridSize; row++) {
            for(int col = 0; col < gridSize; col++) {
                heatmap[row][col] = heatmap[row][col] + heatVelocity[row][col];
            }
        }
    }
}

void HeatEquation::mousePressed(int x, int y) {
    if(hasStarted) {

    } else {
        hasStarted = true;
        timer.start();
    }
}
