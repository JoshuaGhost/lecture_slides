#include "heightfieldwater.h"

HeightFieldWater::HeightFieldWater() {
    waterLevel = QList<float>();
    waveVelocity = QList<float>();
}

HeightFieldWater::~HeightFieldWater() {

}

void HeightFieldWater::setupGUI(GdvGui &userInterface) {
    userInterface.addCheckBox("Energieerhaltender Regen",true,energyConservingRain);
    userInterface.addSlider("Regenmenge",0,100,4,rainAmount);
}

void HeightFieldWater::initialize() {

}

void HeightFieldWater::deinitialize() {
    waterLevel.clear();
    waveVelocity.clear();
    hasStarted = false;
}

void HeightFieldWater::sizeChanged(unsigned int width, unsigned int height) {
    viewWidth = width;
    viewHeight = height;

    while(width > waterLevel.length()) {
        waterLevel.append(startWaterLevel);//+((float) rand() / (RAND_MAX))*0.5);
        waveVelocity.append(startWaterVelocity);
    }
    while(width < waterLevel.length() && !waterLevel.isEmpty()) {
        waterLevel.removeLast();
    }
}

void HeightFieldWater::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));
    if(hasStarted) {
        qint64 timeElapsed = timer.elapsed();
        float tpf = timeElapsed/1000.0f;
        timer.restart();

        //calc values
        recalcSystem(tpf);
    }

    QVector3D waterColor = QVector3D(0.0f,0.0f,1.0f);
    float massSum = 0;
    for(int i = 0; i < waterLevel.length(); i++) {
        massSum += waterLevel[i];
        drawLine(canvas,i,i,viewHeight-120,viewHeight-50-waterLevel[i]*10,waterColor);
    }
    qDebug() << massSum;

    canvas.flipBuffer();
}

void HeightFieldWater::recalcSystem(float tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }

    for(int t = 0; t < iterations;t++) {
        //adjust velocities first
        waveVelocity[0] = waveVelocity[0] + (timeStep*c*c)*(waterLevel[0] - 2*waterLevel[0] + waterLevel[1]);
        for(int i = 1; i < waterLevel.length()-1; i++) {
            waveVelocity[i] = waveVelocity[i] + (timeStep*c*c)*(waterLevel[i-1] - 2*waterLevel[i] + waterLevel[i+1]);
        }
        waveVelocity[waterLevel.length()-1] = waveVelocity[waterLevel.length()-1] + (timeStep*c*c)*(waterLevel[waterLevel.length()-2] - 2*waterLevel[waterLevel.length()-1] + waterLevel[waterLevel.length()-1]);

        //adjust waterlevels second
        for(int i = 0; i < waterLevel.length(); i++) {
            waterLevel[i] = waterLevel[i] + timeStep*waveVelocity[i];
        }
    }
}

void HeightFieldWater::mousePressed(int x, int y) {
    if(hasStarted) {
        if(x > 0 && x < waterLevel.length()) {
            if(energyConservingRain) {
                float amountPerCell = rainAmount*1.0f/waterLevel.length();
                for(int i = 0; i < waterLevel.length(); i++) {
                    waterLevel[i] -= amountPerCell;
                }
                waterLevel[x] +=rainAmount;
            } else {
                waterLevel[x] +=rainAmount;
            }
        }
    } else {
        hasStarted = true;
        timer.start();
    }
}
