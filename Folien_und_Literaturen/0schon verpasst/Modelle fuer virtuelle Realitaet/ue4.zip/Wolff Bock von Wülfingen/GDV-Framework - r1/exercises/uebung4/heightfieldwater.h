#ifndef HEIGHTFIELDWATER_H
#define HEIGHTFIELDWATER_H
#include <functional>
#include "../vrbase.h"

class HeightFieldWater : public VRBase
{
public:
    HeightFieldWater();
    virtual ~HeightFieldWater();

    virtual void setupGUI(GdvGui& userInterface);
    virtual void render(GdvCanvas& canvas);
    virtual void initialize();
    virtual void deinitialize();

    virtual void mousePressed(int x, int y);

    void recalcSystem(float tpf);
    float timeRemainder = 0;
    bool hasStarted = false;

    QList<float> waterLevel;
    QList<float> waveVelocity;
    float c = 10;

    float energyloss = 0.0001f;

    float startWaterLevel = 10;
    float startWaterVelocity = 0;

    bool energyConservingRain = true;
    int rainAmount = 4;

    virtual void sizeChanged(unsigned int width, unsigned int height);
};

#endif // HEIGHTFIELDWATER_H
