#ifndef HEATEQUATION_H
#define HEATEQUATION_H
#include <functional>
#include "../vrbase.h"

class HeatEquation : public VRBase
{
public:
    HeatEquation();
    virtual ~HeatEquation();

    virtual void setupGUI(GdvGui& userInterface);
    virtual void render(GdvCanvas& canvas);
    virtual void initialize();
    virtual void deinitialize();

    virtual void mousePressed(int x, int y);

    void recalcSystem(double tpf);
    double timeRemainder = 0;
    bool hasStarted = false;

    int gridSize = 64;
    int lowerLimit = 0;
    int upperLimit = 10;

    double initialTemperature(double x, double y);

    QVector<QVector<double>> heatmap;
    QVector<QVector<double>> heatVelocity;
    double c = 1;
    double h = 0;

    QVector3D blue = QVector3D(0.0f,0.0f,1.0f);
    QVector3D red = QVector3D(1.0f,0.0f,0.0f);
};

#endif // HEATEQUATION_H
