#ifndef PENDEL_H
#define PENDEL_H

#include "../vrbase.h"

class Pendel : public VRBase {
public:
    Pendel();
    virtual ~Pendel();

    virtual void setupGUI(GdvGui& userInterface);
    virtual void render(GdvCanvas& canvas);
    virtual void initialize();
    virtual void deinitialize();

    virtual void mousePressed(int x, int y);

    float damping = 0.0f;
    int dampingInt = 0;
    float gravitation = 0.0f;
    int gravitationInt = 0;

    bool singleRendering = false;
    float singleRenderTime = 0.0f;
    int singleRenderFactor;

    //pendel
    float mass = 1.0f;
    int springConstantInt = 10;
    float springConstant = 1.0f;
    QList<float> t;
    QList<QVector2D> position;
    QList<QVector2D> v;

    QVector2D acceleration(QVector2D pos);

    //initialwerte
    float ankerPunktX;
    int ankerPunktXInt;
    float ankerPunktY;
    int ankerPunktYInt;
    QVector2D ankerPunkt;

    float endPunktX;
    int endPunktXInt;
    float endPunktY;
    int endPunktYInt;
    QVector2D endPunkt;

    float v0x;
    int v0xInt;
    float v0y;
    int v0yInt;


    void recalcPendelProperties();
    void recalcPendel();

    void recalcPendel(float tpf);
    float timeRemainder = 0;
    bool hasStarted = false;

    bool printOnce = false;
};

#endif // PENDEL_H
