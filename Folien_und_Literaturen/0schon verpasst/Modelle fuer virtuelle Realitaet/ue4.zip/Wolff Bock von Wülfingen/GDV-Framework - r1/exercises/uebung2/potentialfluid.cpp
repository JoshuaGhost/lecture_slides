#include "potentialfluid.h"

Potentialfluid::Potentialfluid(){
    position = QList<QVector2D>();
    velocity = QList<QVector2D>();
    connections = QList<QVector2D>();
    currentForce = QList<QVector2D>();
    adhesionColor = QVector3D(0.0f,0.0f,0.0f);
    color = QVector3D(0.0f,0.0f,1.0f);
}

Potentialfluid::~Potentialfluid() {
}

void Potentialfluid::setupGUI(GdvGui &userInterface) {
}


void Potentialfluid::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));

    if(hasStarted) {
        qint64 timeElapsed = timer.elapsed();
        float tpf = timeElapsed/5000.0f;
        timer.restart();

        //calc values
        recalcSystem(tpf);
    }

    //draw
    for(int i = 0; i < fixedParticles; i++) {
        drawBig(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),adhesionColor);
    }

    for(int i = fixedParticles; i < position.length(); i++) {
        drawBig(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),color);
    }

    canvas.flipBuffer();
}

void Potentialfluid::recalcSystem(float tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }
    for(int t = 0; t < iterations;t++) {
        //calc forces
        for(int i = 0; i < connections.length(); i++) {
            QVector2D curCon = connections.at(i);
            QVector2D left = position.at(curCon.x());
            QVector2D right = position.at(curCon.y());
            QVector2D thisCon = right-left;
            float r = thisCon.length();

            QVector2D forceLeft = LennardJones(r)/r * thisCon;
            if(left.y() == 0) { //check if ceiling particles - crude but works
                forceLeft *= 1.75f;
            }

            currentForce[curCon.x()] += forceLeft;
            currentForce[curCon.y()] -= forceLeft;
        }
        //apply gravity
        QVector2D gravity = QVector2D(0,-gravitation);
        for(int i = fixedParticles; i < currentForce.length(); i++) {
            currentForce[i] += gravity;
        }


        //apply forces - starting after fixed particles
        for(int i = 0; i < fixedParticles; i++) {
            currentForce[i] = QVector2D(0,0);
        }
        for(int i = fixedParticles; i < position.length(); i++) {
            QVector2D vNew = velocity.at(i) * (1-damping) + currentForce.at(i) * timeStep; //mass omitted, all masses are 1
            QVector2D posNew = position.at(i) + vNew * timeStep;

            velocity[i] = vNew;
            position[i] = posNew;

            //resetting force
            currentForce[i] = QVector2D(0,0);
        }
    }
}

float Potentialfluid::LennardJones(float r) {
    return (20/std::pow(r,3)) - (8/std::pow(r,5));
}

void Potentialfluid::initialize() {
    //adjusting view
    xMin = -10;
    xMax = 10;
    yMin = -14;
    yMax = 2;
    //parameters
    int radius = 5;
    float gap = 0.5;
    gravitation = 10;
    fixedParticles = 2*radius/gap;

    //adhesion particles
    for(float i = -radius; i < radius; i+=gap) {
        position.append(QVector2D(i,0));
        velocity.append(QVector2D(0,0));
        currentForce.append(QVector2D(0,0));
    }

    //normal particles
    QVector2D origin = QVector2D(0,0);
    for(float i = -radius; i < radius; i+=gap) {
        for(float j = gap; j < radius; j+=gap) {
            QVector2D point = QVector2D(i,-j);
            if(origin.distanceToPoint(point) < radius) {
                position.append(point);
                velocity.append(QVector2D(0,0));
                currentForce.append(QVector2D(0,0));
            }
        }
    }

    //connect all the things! except adhesion particles to each other
    for(int i = 0; i < position.length(); i++) {
        for(int j = fixedParticles; j < position.length(); j++) {
            if(i!=j) {
                connections.append(QVector2D(i,j));
            }
        }
    }
}

void Potentialfluid::deinitialize() {
    hasStarted = false;
    position.clear();
    velocity.clear();
    connections.clear();
    currentForce.clear();
    fixedParticles = 0;

    xMin = -5;
    xMax = 5;
    yMin = -4;
    yMax = 4;
}

void Potentialfluid::mousePressed(int x, int y) {
    hasStarted = true;
    timer.start();
}


void Potentialfluid::drawBig(GdvCanvas& canvas, int x, int y, QVector3D color) {
    for(int r = x-3; r <= x+3; r++) {
        for(int h = y-3; h <= y+3; h++) {
            if(r > 0 && r < viewWidth && h > 0 && h < viewHeight) {
                canvas.setPixel(r,h, color);
            }
        }
    }
}
