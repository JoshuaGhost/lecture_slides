#include "pendel.h"

Pendel::Pendel() {
    //pendel
    t = QList<float>();
    position = QList<QVector2D>();
    v = QList<QVector2D>();
}

Pendel::~Pendel() {

}

void Pendel::setupGUI(GdvGui &userInterface) {

    userInterface.addSlider("Federkonstante",0,1000,200,springConstantInt);
    userInterface.addSlider("Dämpfung",0,100,0,dampingInt);
    userInterface.addSlider("Gravitation",-100,100,10,gravitationInt);

    userInterface.addSlider("ankerPunkt X",-100,100,0,ankerPunktXInt);
    userInterface.addSlider("ankerPunkt Y",-100,100,0,ankerPunktYInt);
    userInterface.addSlider("endPunkt X",-100,100,10,endPunktXInt);
    userInterface.addSlider("endPunkt Y",-100,100,0,endPunktYInt);
    userInterface.addSlider("v0x",-100,100,0,v0xInt);
    userInterface.addSlider("v0y",-100,100,-5,v0yInt);

    //userInterface.addColorSelector("Plotfarbe", QVector3D(0, 0, 0), color);
    userInterface.addCheckBox("Große Pixel",false, bigPixels);

    userInterface.addCheckBox("Timestepping", false, singleRendering);
    userInterface.addSlider("TimestepFactor", 2,1000,100,singleRenderFactor);

    recalcPendelProperties();
    t.append(0);
    position.append(QVector2D(endPunktX-ankerPunktX,endPunktY-ankerPunktY));
    v.append(QVector2D(v0x,v0y));
}

void Pendel::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));
    if(hasStarted) {
    qint64 timeElapsed = timer.elapsed();
    float tpf = timeElapsed/1000.0f;
    timer.restart();

    //calc values
    recalcPendelProperties();
    //recalcPendel();
    recalcPendel(tpf);
    }

    drawLine(canvas,viewWidth/2,getRealX(position.last().x())+1,viewHeight/2,getRealY(position.last().y()),color);
    drawBig(canvas,getRealX(position.last().x()),getRealY(position.last().y()),color);

    //draw values
    float xLength = std::abs(xMax - xMin);
    float yLength = std::abs(yMax - yMin);

    //x axis
    drawLine(canvas,0,viewWidth,viewHeight-((-yMin)/yLength)*viewHeight,viewHeight-((-yMin)/yLength)*viewHeight,color);
    //y axis
    drawLine(canvas,((-xMin)/xLength)*viewWidth,((-xMin)/xLength)*viewWidth+1,0,viewHeight,color);

    /*
    if(singleRendering) {
        int index = singleRenderTime / timeStep;
        for(int i = 1; i < singleRenderFactor;i++) {
            if(bigPixels) {
                drawBig(canvas,getRealX(position.at(index).x()),getRealY(position.at(index).y()),color);
            } else {
                drawPixel(canvas,getRealX(position.at(index).x()),getRealY(position.at(index).y()),color);
            }

            index++;
            if(index>= position.length()) {
                index = index % position.length();
            }
        }
    } else {
        for(int i = 0; i < position.length(); i++) {
            if(bigPixels) {
                drawBig(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),color);
            } else {
                drawPixel(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),color);
            }

        }
    }
    */

    canvas.flipBuffer();
}

void Pendel::initialize() {
}

void Pendel::deinitialize() {
}

void Pendel::mousePressed(int x, int y) {
    singleRenderTime+=timeStep*singleRenderFactor;
    if(singleRenderTime>=endTime) {
        singleRenderTime = std::fmod(singleRenderTime, endTime);
        qDebug() << "endTime reached, restarting";
    }

    hasStarted = true;
    timer.start();
}

////////////OWN METHODS

QVector2D Pendel::acceleration(QVector2D pos) {
    float lengthDifference = (pos-ankerPunkt).length() - (endPunkt-ankerPunkt).length();
    QVector2D springForce = springConstant * -lengthDifference * (pos-ankerPunkt).normalized();

    QVector2D gravitationalForce = QVector2D(0,-gravitation);

    return (springForce+gravitationalForce*mass)/mass;
}

void Pendel::recalcPendel() {
    //pendel
    t = QList<float>();
    position = QList<QVector2D>();
    v = QList<QVector2D>();

    t.append(0);
    position.append(QVector2D(endPunktX-ankerPunktX,endPunktY-ankerPunktY));
    v.append(QVector2D(v0x,v0y));

    int iterations = (endTime-startTime)/timeStep;
    for(int i = 1; i < iterations; i++) {
        QVector2D vNew = v.at(i-1)*(1-damping) + acceleration(position.at(i-1)) * timeStep;
        QVector2D posNew = position.at(i-1) + vNew * timeStep;
        t.append(t.at(i-1)+timeStep);
        v.append(vNew);
        position.append(posNew);
        if(printOnce) {
            qDebug() << "t: " << timeStep*i;
            qDebug() << "pos: " << posNew;
            qDebug() << "v: " << vNew;
        }
    }
    printOnce = false;
}

void Pendel::recalcPendel(float tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }
    int endLoop = iterations+t.length();
    for(int i = t.length();i < endLoop;i++) {
        QVector2D vNew = v.at(i-1)*(1-damping) + acceleration(position.at(i-1)) * timeStep;
        QVector2D posNew = position.at(i-1) + vNew * timeStep;
        t.append(t.at(i-1)+timeStep);
        v.append(vNew);
        position.append(posNew);
    }
}

void Pendel::recalcPendelProperties() {
    damping = dampingInt/1000.0f;
    springConstant = springConstantInt/10.0f;
    gravitation = gravitationInt/10.0f;

    ankerPunktX = ankerPunktXInt/10.0f;
    ankerPunktY = ankerPunktYInt/10.0f;
    ankerPunkt = QVector2D(ankerPunktX,ankerPunktY);

    endPunktX = endPunktXInt/10.0f;
    endPunktY = endPunktYInt/10.0f;
    endPunkt = QVector2D(endPunktX,endPunktY);

    v0x = v0xInt/10.0f;
    v0y = v0yInt/10.0f;

//        qDebug() << "Dämpfung: " << damping;
//        qDebug() << "Federkonstante: " << springConstant;
//        qDebug() << "pos0: " << QVector2D(endPunktX-ankerPunktX,endPunktY-ankerPunktY);
//        qDebug() << "v0: " << QVector2D(v0x,v0y);
}
