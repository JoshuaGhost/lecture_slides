#include "doppelpendel.h"

DoppelPendel::DoppelPendel() {
    secColor = QVector3D(0.0f,0.0f,1.0f);

    //pendel
    t = QList<float>();
    position = QList<QVector2D>();
    position2 = QList<QVector2D>();
    v = QList<QVector2D>();
    v2 = QList<QVector2D>();
}

DoppelPendel::~DoppelPendel() {

}

void DoppelPendel::setupGUI(GdvGui &userInterface) {

    userInterface.addSlider("Federkonstante",0,1000,200,springConstantInt);
    userInterface.addSlider("Dämpfung",0,100,10,dampingInt);
    userInterface.addSlider("Gravitation",-100,100,10,gravitationInt);

    userInterface.addSlider("ankerPunkt X",-100,100,0,ankerPunktXInt);
    userInterface.addSlider("ankerPunkt Y",-100,100,0,ankerPunktYInt);
    userInterface.addSlider("endPunkt X",-100,100,10,endPunktXInt);
    userInterface.addSlider("endPunkt Y",-100,100,0,endPunktYInt);
    userInterface.addSlider("endPunkt2 X",-100,100,20,endPunkt2XInt);
    userInterface.addSlider("endPunkt2 Y",-100,100,0,endPunkt2YInt);
    userInterface.addSlider("v0x",-100,100,0,v0xInt);
    userInterface.addSlider("v0y",-100,100,0,v0yInt);

    //userInterface.addColorSelector("Plotfarbe", QVector3D(0, 0, 0), color);
    userInterface.addCheckBox("Große Pixel",false, bigPixels);

    userInterface.addCheckBox("Timestepping", false, singleRendering);
    userInterface.addSlider("TimestepFactor", 2,1000,100,singleRenderFactor);

    recalcPendelProperties();
    t.append(0);
    position.append(QVector2D(endPunktX-ankerPunktX,endPunktY-ankerPunktY));
    v.append(QVector2D(v0x,v0y/2));
    position2.append(QVector2D(endPunkt2X-endPunktX,endPunkt2Y-endPunktY));
    v2.append(QVector2D(v0x,v0y));
}

void DoppelPendel::render(GdvCanvas &canvas) {
    canvas.clearBuffer(QVector3D(1,1,1));
    if(hasStarted) {
    qint64 timeElapsed = timer.elapsed();
    float tpf = timeElapsed/1000.0f;
    timer.restart();

    //calc values
    recalcPendelProperties();
    //recalcPendel();
    recalcPendel(tpf);
    }

    drawLine(canvas,viewWidth/2,getRealX(position.last().x())+1,viewHeight/2,getRealY(position.last().y()),color);
    drawLine(canvas,getRealX(position.last().x()),getRealX(position2.last().x())+1,getRealY(position.last().y()),getRealY(position2.last().y()),secColor);
    drawBig(canvas,getRealX(position.last().x()),getRealY(position.last().y()),color);
    drawBig(canvas,getRealX(position2.last().x()),getRealY(position2.last().y()),secColor);

    //draw values
    float xLength = std::abs(xMax - xMin);
    float yLength = std::abs(yMax - yMin);

    //x axis
    drawLine(canvas,0,viewWidth,viewHeight-((-yMin)/yLength)*viewHeight,viewHeight-((-yMin)/yLength)*viewHeight,color);
    //y axis
    drawLine(canvas,((-xMin)/xLength)*viewWidth,((-xMin)/xLength)*viewWidth+1,0,viewHeight,color);


/*
    if(singleRendering) {
        int index = singleRenderTime / timeStep;
        for(int i = 1; i < singleRenderFactor;i++) {
            if(bigPixels) {
                drawBig(canvas,getRealX(position.at(index).x()),getRealY(position.at(index).y()),color);
                drawBig(canvas,getRealX(position2.at(index).x()),getRealY(position2.at(index).y()),secColor);
            } else {
                drawPixel(canvas,getRealX(position.at(index).x()),getRealY(position.at(index).y()),color);
                drawPixel(canvas,getRealX(position2.at(index).x()),getRealY(position2.at(index).y()),secColor);
            }

            index++;
            if(index>= position.length()) {
                index = index % position.length();
            }
        }
    } else {
        for(int i = 0; i+4 < position.length(); i+=4) {
            if(bigPixels) {
                drawBig(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),color);
                drawBig(canvas,getRealX(position2.at(i).x()),getRealY(position2.at(i).y()),secColor);
            } else {
                drawPixel(canvas,getRealX(position.at(i).x()),getRealY(position.at(i).y()),color);
                drawPixel(canvas,getRealX(position2.at(i).x()),getRealY(position2.at(i).y()),secColor);
            }

        }
    }
*/
    canvas.flipBuffer();
}

void DoppelPendel::initialize() {
}

void DoppelPendel::deinitialize() {
}

void DoppelPendel::mousePressed(int x, int y) {
    singleRenderTime+=timeStep*singleRenderFactor;
    if(singleRenderTime>=endTime) {
        singleRenderTime = std::fmod(singleRenderTime, endTime);
        qDebug() << "endTime reached, restarting";
    }

    hasStarted = true;
    timer.start();
}

////////////OWN METHODS

QVector2D DoppelPendel::acceleration(QVector2D pos, QVector2D pos2) {
    QVector2D gravitationalForce = QVector2D(0,-gravitation);

    return (getSpringForce(pos)-getSpringForce2(pos,pos2)+gravitationalForce*mass) / mass;
}

QVector2D DoppelPendel::acceleration2(QVector2D pos, QVector2D pos2) {
    QVector2D gravitationalForce = QVector2D(0,-gravitation);

    return (getSpringForce2(pos,pos2)+gravitationalForce*mass) / mass;
}

QVector2D DoppelPendel::getSpringForce(QVector2D pos) {
    float lengthDifference = (pos-ankerPunkt).length() - (endPunkt-ankerPunkt).length();
    QVector2D springForce = springConstant * -lengthDifference* (pos-ankerPunkt).normalized();
return springForce;
}

QVector2D DoppelPendel::getSpringForce2(QVector2D pos, QVector2D pos2) {
    float lengthDifference = (pos-pos2).length() - (endPunkt-endPunkt2).length();
    QVector2D springForce = springConstant * -lengthDifference * (pos2-pos).normalized();
    return springForce;
}

void DoppelPendel::recalcPendel() {
    //pendel
    t = QList<float>();
    position = QList<QVector2D>();
    position2 = QList<QVector2D>();
    v = QList<QVector2D>();
    v2 = QList<QVector2D>();

    t.append(0);
    position.append(QVector2D(endPunktX-ankerPunktX,endPunktY-ankerPunktY));
    v.append(QVector2D(v0x,v0y/2));
    position2.append(QVector2D(endPunkt2X-endPunktX,endPunkt2Y-endPunktY));
    v2.append(QVector2D(v0x,v0y));

    int iterations = (endTime-startTime)/timeStep;
    for(int i = 1; i < iterations; i++) {
        //calc lower pendulum velocity first
        QVector2D vNew2 = v2.at(i-1)*(1-damping) + acceleration2(position.at(i-1),position2.at(i-1)) * timeStep;

        //upper pendulum velocity now
        QVector2D vNew = v.at(i-1)*(1-damping) + acceleration(position.at(i-1),position2.at(i-1)) * timeStep;

        //apply positions now
        QVector2D posNew = position.at(i-1) + vNew * timeStep;
        QVector2D posNew2 = position2.at(i-1) + vNew2 * timeStep;

        t.append(t.at(i-1)+timeStep);
        v.append(vNew);
        v2.append(vNew2);
        position.append(posNew);
        position2.append(posNew2);
        if(printOnce) {
            qDebug() << "t: " << timeStep*i;
            qDebug() << "pos: " << posNew;
            qDebug() << "v: " << vNew;
        }
    }

    printOnce = false;
}

void DoppelPendel::recalcPendel(float tpf) {
    int iterations = (tpf/timeStep);
    timeRemainder+= fmod(tpf,timeStep);
    if(timeRemainder>timeStep) {
        iterations++;
        timeRemainder-=timeStep;
    }
    int endLoop = iterations+t.length();
    for(int i = t.length();i < endLoop;i++) {
        //calc lower pendulum velocity first
        QVector2D vNew2 = v2.at(i-1)*(1-damping) + acceleration2(position.at(i-1),position2.at(i-1)) * timeStep;

        //upper pendulum velocity now
        QVector2D vNew = v.at(i-1)*(1-damping) + acceleration(position.at(i-1),position2.at(i-1)) * timeStep;

        //apply positions now
        QVector2D posNew = position.at(i-1) + vNew * timeStep;
        QVector2D posNew2 = position2.at(i-1) + vNew2 * timeStep;

        t.append(t.at(i-1)+timeStep);
        v.append(vNew);
        v2.append(vNew2);
        position.append(posNew);
        position2.append(posNew2);
    }
}

void DoppelPendel::recalcPendelProperties() {
    damping = dampingInt/1000.0f;
    springConstant = springConstantInt/10.0f;
    gravitation = gravitationInt/10.0f;

    ankerPunktX = ankerPunktXInt/10.0f;
    ankerPunktY = ankerPunktYInt/10.0f;
    ankerPunkt = QVector2D(ankerPunktX,ankerPunktY);

    endPunktX = endPunktXInt/10.0f;
    endPunktY = endPunktYInt/10.0f;
    endPunkt = QVector2D(endPunktX,endPunktY);

    endPunkt2X = endPunkt2XInt/10.0f;
    endPunkt2Y = endPunkt2YInt/10.0f;
    endPunkt2 = QVector2D(endPunkt2X,endPunkt2Y);

    v0x = v0xInt/10.0f;
    v0y = v0yInt/10.0f;

//        qDebug() << "Dämpfung: " << damping;
//        qDebug() << "Federkonstante: " << springConstant;
//        qDebug() << "pos0: " << QVector2D(endPunktX-ankerPunktX,endPunktY-ankerPunktY);
//        qDebug() << "v0: " << QVector2D(v0x,v0y);
}
