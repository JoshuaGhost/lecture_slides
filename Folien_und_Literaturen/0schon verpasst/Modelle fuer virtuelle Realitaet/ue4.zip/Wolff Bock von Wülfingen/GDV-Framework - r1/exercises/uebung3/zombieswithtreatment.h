#ifndef ZOMBIESWITHTREATMENT_H
#define ZOMBIESWITHTREATMENT_H
#include <functional>
#include "../vrbase.h"

using namespace std::placeholders;

class ZombiesWithTreatment : public VRBase
{
public:
    ZombiesWithTreatment();
    virtual ~ZombiesWithTreatment();

    virtual void setupGUI(GdvGui& userInterface);
    virtual void render(GdvCanvas& canvas);
    virtual void initialize();
    virtual void deinitialize();

    virtual void mousePressed(int x, int y);

    float susceptibleChange(float S, float I, float Z, float R);
    float infectedChange(float S, float I, float Z, float R);
    float zombiesChange(float S, float I, float Z, float R);
    float removedChange(float S, float I, float Z, float R);

    float heunMethod(std::function<float(float,float,float,float)> fun, float value, int index);

    float susceptibles; //S
    float infected; //I
    float zombies; //Z
    float removed; //R
    float birthRate; //PI - also not a real rate
    float naturalDeathRate; //delta *I       delta *S
    float biteRate; //beta *S*Z
    float turnRate; //rho *I
    float cureRate; //c *Z
    float resurrectRate; //zeta *R
    float zombieKillRate; //alpha *S*Z

    void recalcSystem(float tpf);
    float timeRemainder = 0;
    bool hasStarted = false;
};

#endif // ZOMBIESWITHTREATMENT_H
