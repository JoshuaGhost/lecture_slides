/**
 ** main.cpp - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/

#include "framework/mainwindow.h"
#include <QApplication>

#include "examples/frameworkexample.h"
#include "exercises/uebung2/pendel.h"
#include "exercises/uebung2/doppelpendel.h"
#include "exercises/uebung2/planetensystem.h"
#include "exercises/uebung2/potentialfluid.h"
#include "exercises/uebung3/zombieswithtreatment.h"
#include "exercises/uebung4/heightfieldwater.h"
#include "exercises/uebung4/heatequation.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setApplicationName("GDV-Framework");
    a.setApplicationVersion("r1");
    a.setOrganizationName("Leibniz Universität Hannover - Welfenlab");
    MainWindow w;

    //w.addLecture("Beispielprojekt", new FrameworkExample());
    w.addLecture("Pendel", new Pendel());
    w.addLecture("DoppelPendel",new DoppelPendel());
    w.addLecture("Planetensystem", new Planetensystem());
    w.addLecture("Potentialfluid", new Potentialfluid());
    w.addLecture("Zombies with Treatment", new ZombiesWithTreatment());
    w.addLecture("HeightFieldWater",new HeightFieldWater());
    w.addLecture("HeatEquation", new HeatEquation());
    // ...
    // Hier können eigene Abgaben eingetragen werden.

    w.setDefaultIndices(0,0,0);

    w.show();
    return a.exec();
}
