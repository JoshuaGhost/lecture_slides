/**
 ** performancemonitor.cpp - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/

#include "performancemonitor.h"

PerformanceMonitor::PerformanceMonitor(float sensitivity) :
    sensitivity(sensitivity)
{
    reset();
    timer.start();
    timerTotal.start();
}

void PerformanceMonitor::startFrame()
{
    timer.restart();
    if(frameCounter == 0)
        timerTotal.restart();
}

void PerformanceMonitor::stopFrame()
{
    int msecs = timer.elapsed();

    _currentFPS = 1.0 / (msecs/1000.0);
    if(frameCounter == 0)
        _averageFPS = _currentFPS;

    _averageFPS = sensitivity * _currentFPS + (1.0 - sensitivity) * _averageFPS;
    frameCounter++;
}

void PerformanceMonitor::reset()
{
    _averageFPS = 0.0;
    _currentFPS = 0.0;
    frameCounter = 0;
}

float PerformanceMonitor::currentFPS()
{
    return _currentFPS;
}

float PerformanceMonitor::totalAverageFPS()
{
    return frameCounter / (timerTotal.elapsed() / 1000.0);
}

float PerformanceMonitor::movingAverageFPS()
{
    return _averageFPS;
}
