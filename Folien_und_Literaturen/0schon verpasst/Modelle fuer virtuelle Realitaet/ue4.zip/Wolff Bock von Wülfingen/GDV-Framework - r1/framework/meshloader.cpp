/**
 ** meshloader.cpp - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/

#include "meshloader.h"
#include <QDebug>

#include <QFile>
#include <QStringList>

struct FaceOrder
{
    int a, b, c;
};

inline static QString prep(const QString& str)
{
    return str.trimmed().toLower();
}

inline static QString nextLine(QFile& file)
{
    QString line = prep(QString(file.readLine()));
    while(line.contains("comment") || line.contains("property")) // Skip comments and unsupported lines
    {
        line = prep(QString(file.readLine()));
    }

    return line;
}

inline static QStringList nextTuple(QFile& file)
{
    QString line = nextLine(file);
    return line.split(' ', QString::SkipEmptyParts);
}

inline static bool parseVertexLine(const QStringList& line, MeshLoader::VertexInfo& v)
{
    if(line.size() != 11)
    {
        qWarning() << "Malformed PLY File. Expecting a tuple of 11 elements containing vertex data. Got a" << line.size() << "tuple. Skipping entry.";
        return false;
    }

    v.x = line.at(0).toFloat();
    v.y = line.at(1).toFloat();
    v.z = line.at(2).toFloat();

    v.nx = line.at(3).toFloat();
    v.ny = line.at(4).toFloat();
    v.nz = line.at(5).toFloat();

    v.u = line.at(6).toFloat();
    v.v = line.at(7).toFloat();

    v.r  = line.at(8).toInt() / 255.0f;
    v.g  = line.at(9).toInt() / 255.0f;
    v.b  = line.at(10).toInt() / 255.0f;

    return true;
}



MeshLoader::MeshLoader(const QString& fileName) : fileName(fileName)
{
    _valid = false;
}

MeshLoader::MeshLoader()
{
    _valid = false;
}

void MeshLoader::parseFile()
{
    _valid = false;
    _faces.clear();

    QFile file(fileName);

    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qCritical() << "File " << fileName << " does not exist or is not readable.";
        return;
    }


    QString firstLine = nextLine(file);
    if(firstLine != "ply")
    {
        qCritical() << "File " << fileName << " is not a PLY file.";
        return;
    }

    QStringList format = nextTuple(file);
    if(format.size() != 3 &&
       format.at(0).startsWith("format") &&
       format.at(1).startsWith("ascii"))
    {
        qCritical() << "PLY-Format not supported.";
        return;
    }

    int numberOfVertices = 0;
    QStringList elementVertex = nextTuple(file);
    if(elementVertex.size() != 3 &&
       elementVertex.at(0).startsWith("element") &&
       elementVertex.at(1).startsWith("vertex"))
    {
        qCritical() << "Malformed PLY File. Expecting 'element' after 'format' statement. Sorry, this parser is quite //simple//";
        return;
    }

    numberOfVertices = elementVertex.at(2).toInt(/* TODO: Check return value */);

    // At this point, we assume that the format of the properties is
    // x    y   z   nx  ny  nz  u   v   r   g   b
    // like it is exported by Blender...


    int numberOfFaces = 0;
    QStringList elementFaces = nextTuple(file);
    if(elementFaces.size() != 3 &&
       elementFaces.at(0).startsWith("element") &&
       elementFaces.at(1).startsWith("face"))
    {
        qCritical() << "Malformed PLY File. Expecting 'element' after 'property' block. Sorry, this parser is quite //simple//";
        return;
    }

    numberOfFaces = elementFaces.at(2).toInt(/* TODO: Check return value */);

    // Same here, we assume the format is "list uchar uint vertex_indices" which is pretty standard

    // Now we skip everything left in the header. Did I mention this is an almost brain-dead PLY-Parser?

    QString line = prep(QString(file.readLine()));
    while(!line.contains("end_header"))
    {
        line = prep(QString(file.readLine()));
    } // Hopefully, there is such a line...

    QVector<VertexInfo> allVertices;
    for(int n = 0; n < numberOfVertices; n++)
    {
        VertexInfo nextVertex;
        if(parseVertexLine(nextTuple(file), nextVertex))
        {
            allVertices.append(nextVertex);
        }
    }

    if(allVertices.size() != numberOfVertices)
    {
        qWarning() << "Looks like something went wrong... A total of" << allVertices.size() << "vertices were found, but there should be" << numberOfVertices << ". I'll try my best, but you should check the file format!";
    }


    // Next: Faces
    QVector<FaceOrder> faceReferences;
    for(int n = 0; n < numberOfFaces; n++)
    {
        FaceOrder f;
        QStringList line = nextTuple(file);

        if(line.size() == 4 && line.at(0).toInt() == 3)
        {
            f.a = line.at(1).toInt();
            f.b = line.at(2).toInt();
            f.c = line.at(3).toInt();

            if(f.a < numberOfVertices && f.b < numberOfVertices && f.c < numberOfVertices)
            {
                faceReferences.append(f);
            }
            else
            {
                qWarning() << "Malformed PLY File. Vertex index out of bounds. Skipping face.";
            }
        }
        else
        {
            qWarning() << "Malformed PLY File. Expecting a tuple of 4 elements containing vertex references. Got a" << line.size() << "tuple. Skipping entry.";
        }
    }

    if(faceReferences.size() != numberOfFaces)
    {
        qWarning() << "Looks like something went wrong... A total of " << allVertices.size() << " vertices were found, but there should be " << numberOfVertices << ". I'll try my best, but you should check the file format!";
    }


    // Convert to internal format

    foreach (FaceOrder f, faceReferences)
    {
        Face face;

        face[0] = allVertices.at(f.a);
        face[1] = allVertices.at(f.b);
        face[2] = allVertices.at(f.c);

        _faces.append(face);
    }

    _valid = true;
}

bool MeshLoader::isValid() const
{
    return _valid;
}

const QVector<MeshLoader::Face>& MeshLoader::faces() const
{
    return _faces;
}
