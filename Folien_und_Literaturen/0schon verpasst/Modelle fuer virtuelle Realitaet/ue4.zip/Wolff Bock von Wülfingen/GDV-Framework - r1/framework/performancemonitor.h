#ifndef PERFORMANCEMONITOR_H
#define PERFORMANCEMONITOR_H
/**
 ** performancemonitor.h - Teil des Labors "Grafikprogrammierung"
 **
 ** Leibniz Universität Hannover - Institut für Mensch-Maschine-Kommunikation
 ** (c)2013 Andreas Tarnowsky <atarnows@welfenlab.de>
 **
 ** Die Weitergabe dieser Datei ist nur im Umfeld der Leibniz Universität
 ** Hannover gestattet.
 **
 **/

#include <QTime>

/**
 * @brief Die PerformanceMonitor Klasse
 *
 * Wird verwendet, um die Framerate des aktiven Renderers zu ermitteln
 * Interne Klasse, bitte nicht direkt einbinden und/oder verändern!
 */
class PerformanceMonitor
{
public:
    PerformanceMonitor(float sensitivity);

    void startFrame();
    void stopFrame();

    void reset();

    float currentFPS();
    float totalAverageFPS();
    float movingAverageFPS();

private:
    long frameCounter;
    QTime timer, timerTotal;
    float _averageFPS;
    float _currentFPS;

    float sensitivity;
};

#endif // PERFORMANCEMONITOR_H
