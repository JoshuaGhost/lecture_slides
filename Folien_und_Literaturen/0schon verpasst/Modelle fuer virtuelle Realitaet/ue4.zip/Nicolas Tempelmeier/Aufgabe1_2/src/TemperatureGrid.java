import java.util.ArrayList;
import java.util.List;


public class TemperatureGrid {
	
	private int size=64;
	private double minValue = 0;
	private double maxValue= 10;
	private double dt = 0.1;
	
	List<List<TemperatureCell>> cells;
	
	private boolean coolBorders = false;
	
	
	public TemperatureGrid(int size, double minValue, double maxValue) {
		this.size = size;
		this.minValue = minValue;
		this.maxValue = maxValue;
		
		cells = new ArrayList<List<TemperatureCell>>();
		
		double step = (maxValue-minValue) / ((double) (size-1));
		
		
		//Initialize cells with values
		for (int i=0; i < size; i++) {
			List<TemperatureCell> col = new ArrayList<TemperatureCell>();
			for (int j=0; j < size; j++) {
				double x = i*step + minValue;
				double y = j*step + minValue;
				col.add(new TemperatureCell(Math.sin(x)+x*Math.cos(y)));
				//col.add(new TemperatureCell(10));

			}
			cells.add(col);
		}
		
		
		//set neighbours
		for (int x=0; x < size; x++) {
			for (int y=0; y < size; y++) {
				TemperatureCell left = null;
				TemperatureCell right = null;
				TemperatureCell top = null;
				TemperatureCell bottom = null;

				if (x!=0) left = cells.get(x-1).get(y);
				if (x!=(size-1)) right = cells.get(x+1).get(y);
				if (y!=0) top = cells.get(x).get(y-1);
				if (y!=(size-1)) bottom = cells.get(x).get(y+1);
				
				cells.get(x).get(y).setNeighbours(top, left, right, bottom, this);
				
			}
		}	
	}

	public void step() {
		cells.stream().parallel().forEach((col) -> {
			col.stream().parallel().forEach((cell) -> {
				cell.explicitEulerStep(dt);
			});
		});
		cells.stream().parallel().forEach((col) -> {
			col.stream().parallel().forEach((cell) -> {
				cell.heatNextValue();
			});
		});
	}
	
	public double[][] getHeats() {
		double[][] result = new double[size][size];
		
		for (int x=0; x < size; ++x) {
			for(int y=0; y < size; ++y) {
				result[x][y] = cells.get(x).get(y).getHeat();
			}
		}
		return result;
	}
	
	public void reset() {
		double step = (maxValue-minValue) / ((double) (size-1));
		for (int i=0; i < size; i++) {
			for (int j=0; j < size; j++) {
				double x = i*step + minValue;
				double y = j*step + minValue;
				cells.get(i).get(j).setHeat((Math.sin(x)+x*Math.cos(y)));
			}
		}
		
	}
	
	public int getSize() {
		return size;
	}
	
	
	public double getMinValue() {
		return minValue;
	}


	public double getMaxValue() {
		return maxValue;
	}


	public TemperatureCell getCell(int x, int y) {
		return cells.get(x).get(y);
	}

	public boolean getCoolBorders() {
		return coolBorders;
	}

	public void setCoolBorders(boolean coolBorders) {
		this.coolBorders = coolBorders;
	}
	
	
}
