import java.util.ArrayList;
import java.util.List;


public class HFWater {
	
	List<WaterCell> cells = new ArrayList<WaterCell>();
	double spacing; 
	double dt= 0.4;
	double neutralHeight =100;
	double damping = 0.005;
	double heigth;
	
	public HFWater(int nr, double spacing) {
		this.spacing = spacing;
		
		for (int i=0; i < nr; ++i) {
			WaterCell cell = new WaterCell(neutralHeight, spacing, this);
			cells.add(cell);
		}
		for (int i=0; i < nr; ++i) {
			WaterCell left;
			WaterCell right;
			WaterCell current = cells.get(i);
			
			if (i==0) {
				left = null;
			} else {
				left = cells.get(i-1);
			}
			if (i==(cells.size()-1)){
				right= null;
			} else {
				right = cells.get(i+1);
			}		
			current.setNeighbours(left, right);
		}
		
	}


	public void step() {
		cells.stream().parallel().forEach((c)-> {
			c.symplecticStepPartOne(dt);
		});
		cells.stream().parallel().forEach((c)-> {
			c.symplecticStepPartTwo(dt);
		});
	}
	
	
	//Erstellt eine Welle an der gewaehlten Position. 
	//Die dafuer erfordliche Hoehe wird gleichmaesig von
	//nicht beteiligten Zellen genommen. Au�erdem wird die Geschwindigkeit
	//der Wellenzellen zunaechst auf 0 gesetzt. Die verlorene Geschwindigkeit
	//wird gleichmaesig auf die anderen Zellen aufgeteilt. 
	//Die Masse/Energie des Systems sollte also erhalten bleiben
	public void createWave(int position, int width, double height) {
		int start = position - width/2;
		//Raender bestimmen
		int offsetLeft=0;
		int offsetRight=0;
		if (start < 0) {
			offsetLeft = -start;
		}
		
		if((position + width/2) > cells.size()) {
			offsetRight = (position + width/2) - cells.size() +1; 
		}

		double deltaHeight =0;
		double deltaVelocity = 0;
		int numberChangedCells = 0;
		
		//Welle erzeugen und Aenderung erfassen
		for (int i=0+offsetLeft; i < width- offsetRight; ++i) {
			double frac = ((double) i) / ((double) (width-1));
			double curHeight = neutralHeight + height * Math.sin(Math.PI * frac);
			WaterCell currentCell = cells.get(start+i);
			
			deltaHeight += curHeight - currentCell.getHeight();
			deltaVelocity += currentCell.getVelocity();
			currentCell.setHeigth(curHeight);
			currentCell.setVelocity(0);
			numberChangedCells++;
		}

		
		//Aenderung durch andere Zellen kompensieren
		double numberOtherCells = cells.size() - numberChangedCells;
		deltaHeight /= numberOtherCells;
		deltaVelocity /= numberOtherCells;
		
		for (int i=0; i < cells.size(); ++i) {
			//Zellen, die nicht Teil der Welle sind
			if ((i< start-offsetLeft) || (i >= (start + width))) {
				WaterCell current = cells.get(i);
				current.setHeigth(current.getHeight()-deltaHeight);
				current.setVelocity(current.getVelocity()-deltaVelocity);
			}
			
		}

		
	}
	
	
	public double[] getHeights() {
		double[] result = new double[cells.size()];
		for (int i=0; i < cells.size(); ++i) {
			result[i] = cells.get(i).getHeight();
		}
		return result;
	}

	public void reset() {
		for (WaterCell c: cells) {
			c.setHeigth(neutralHeight);
			c.setVelocity(0);
		}
	}
	
	public List<WaterCell> getCells() {
		return cells;
	}

	public double getSpacing() {
		return spacing;
	}
	
	public void setDamping(double damping) {
		this.damping = damping;
	}


	public double getDamping() {
		return damping;
	}

	

	public double getNeutralHeight() {
		return neutralHeight;
	}


	public void setSpacing(double spacing) {
		this.spacing = spacing;
	}
	
	
}
