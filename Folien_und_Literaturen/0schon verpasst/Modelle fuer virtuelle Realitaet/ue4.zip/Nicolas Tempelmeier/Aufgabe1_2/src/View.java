import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class View extends Application {

	HFWater hfWater;
	List<Rectangle> waterRects = new ArrayList<Rectangle>();
	Pane waterPane;
	double waterWidth;
	double waterSpace;
	int waveWidth = 15;
	double waveHeigth=100;
	Rectangle waveRect;
	
	Pane temperaturePane;
	TemperatureGrid temperature;
	Rectangle[][] tempRects;

	Thread runThread;
	double spacing;

	Button start;
	String example = "water";
	boolean running = false;

	
	public View() {
		super();

		// init water
		hfWater = new HFWater(100, 1);
		waterPane = new Pane();
		waterPane.setPrefWidth(600);
		waterPane.setPrefHeight(600);
		waterPane.setTranslateX(0);
		waterSpace = hfWater.getSpacing();

		waterWidth = (waterPane.getPrefWidth())
				/ ((double) hfWater.getCells().size()) - waterSpace;
		for (int i = 0; i < hfWater.getCells().size(); ++i) {
			Rectangle rect = new Rectangle(waterWidth, hfWater.getCells()
					.get(i).getHeight(), Color.BLUE);
			waterRects.add(rect);
			rect.setTranslateX(((double) i) * (waterWidth + waterSpace));
			rect.setTranslateY(waterPane.getPrefHeight() - rect.getHeight());
			waterPane.getChildren().add(rect);
		}
		waterPane.setMaxWidth(((double) hfWater.getCells().size())
				* (waterWidth + spacing) - spacing);

		waveRect = new Rectangle(waterWidth, waveHeigth);
		waveRect.setFill(Color.RED);
		waveRect.setVisible(false);
		waveRect.setTranslateY(waterPane.getPrefHeight() -  hfWater.getNeutralHeight() - waveRect.getHeight());
		waterPane.getChildren().add(waveRect);
		
		waterPane.setOnMouseMoved((e) -> {
			waveRect.setVisible(true);
			double mouseX = e.getX();
			int middle = (int)Math.floor(mouseX / (waterWidth + waterSpace));
			waveRect.setTranslateX(((double)middle) *(waterWidth + waterSpace));
			
		});
		
		waterPane.setOnMouseExited((e) -> {
			waveRect.setVisible(false);
		});
		
		waterPane.setOnMouseClicked((e) -> {
			if (running) return;
			double mouseX = e.getX();
			int middle = (int)Math.floor(mouseX / (waterWidth + waterSpace));
			hfWater.createWave(middle, waveWidth, waveHeigth);
			
			if (!running) {
				updateWater(hfWater.getHeights());
			}

		});
		
		// init temperatureGrid
		temperaturePane = new Pane();
		int size = 128;
		temperature = new TemperatureGrid(size, 0, 10);
		tempRects = new Rectangle[size][size];
		temperaturePane.setPrefWidth(600);
		temperaturePane.setPrefHeight(600);

		double rectW = temperaturePane.getPrefWidth() / ((double) size);
		double rectH = temperaturePane.getPrefHeight() / ((double) size);

		boolean alt = true;
		for (int x = 0; x < size; ++x) {
			for (int y = 0; y < size; ++y) {

				Rectangle current = new Rectangle(rectW, rectH);
				current.setTranslateX(((double) x) * rectW);
				current.setTranslateY(((double) y) * rectH);

				current.setFill(heatToColor(temperature.getCell(x, y).getHeat()));

				alt = !alt;
				temperaturePane.getChildren().add(current);
				tempRects[x][y] = current;
			}
			alt = !alt;
		}

	}


	
	
	private void updateWater(double[] cells) {
		for (int i = 0; i < cells.length; ++i) {
			Rectangle rect = waterRects.get(i);
			rect.setHeight(cells[i]);
			rect.setTranslateY(waterPane.getPrefHeight() - rect.getHeight());
		}
	}

	private void updateTemperature(double[][] cells) {
		for (int x = 0; x < cells.length; ++x) {
			double[] col = cells[x];
			for (int y = 0; y < col.length; ++y) {
				tempRects[x][y].setFill(heatToColor(col[y]));
			}
		}
	}

	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void stop() {
		System.exit(0);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Blatt 4");

		BorderPane bPane = new BorderPane();

		Scene scene = new Scene(bPane, 800, 600);
		primaryStage.setScene(scene);

		bPane.setLeft(waterPane);
		
		
		VBox controls = new VBox();
		controls.setAlignment(Pos.TOP_CENTER);
		start = new Button("Start");
		controls.getChildren().add(start);	
		start.setPrefWidth(70);
		
		start.setOnAction((event) -> {
			if (running) return;
			running = true;
			
			Task<Void> updateTask;

			if (example.compareTo("water") == 0) {

				updateTask = new Task<Void>() {
					protected Void call() throws Exception {
						while (true) {
							if (Thread.currentThread().isInterrupted()) {
								return null;
							}
							hfWater.step();
							final double[] heights = hfWater.getHeights();
							Platform.runLater(new Runnable() {
								public void run() {
									updateWater(heights);
								}
							});
							Thread.sleep(15);
						}
					}

				};
			} else {
				updateTask = new Task<Void>() {
					protected Void call() throws Exception {
						while (true) {
							if (Thread.currentThread().isInterrupted()) {
								return null;
							}
							temperature.step();
							final double[][] cells = temperature.getHeats();
							Platform.runLater(new Runnable() {
								public void run() {
									updateTemperature(cells);
								}
							});
							Thread.sleep(10);
						}
					}

				};
			}
			runThread = new Thread(updateTask);
			runThread.start();
		});

		Button stop = new Button("Pause");
		controls.getChildren().add(stop);
		stop.setPrefWidth(70);
		
		stop.setOnAction((event) -> {
			if (!running) return;
			running = false;
			
			runThread.interrupt();
		});
		
		Button reset = new Button("Reset");
		controls.getChildren().add(reset);
		reset.setPrefWidth(70);
		
		reset.setOnAction((event) -> {
			stop.fire();
			if (example.compareTo("water") == 0) {
				hfWater.reset();
				updateWater(hfWater.getHeights());
				
			} else {
				temperature.reset();
				updateTemperature(temperature.getHeats());
			}
		});
		
		
		TabPane rTabs = new TabPane();
		controls.getChildren().add(rTabs);
		
		Tab wTab = new Tab("Wasser");
		wTab.setClosable(false);
		rTabs.getTabs().add(wTab);
		VBox vWater = new VBox();
		vWater.setPadding(new Insets(5,5,5,5));
		wTab.setContent(vWater);
		
		
		Slider wDamping = new Slider();
		wDamping.setMin(0);
		wDamping.setMax(0.01);
		wDamping.setValue(0.005);
		wDamping.valueProperty().addListener((v, o, n) -> {
			hfWater.setDamping(n.doubleValue());
		});
	
		Slider waveHeigthSlider = new Slider();
		waveHeigthSlider.setMin(10);
		waveHeigthSlider.setMax(200);
		waveHeigthSlider.setValue(100);
		vWater.getChildren().add(new Label("Wellen Hoehe"));
		vWater.getChildren().add(waveHeigthSlider);
		waveHeigthSlider.valueProperty().addListener((v, o, n) -> {
			waveHeigth = n.doubleValue();
			waveRect.setHeight(n.doubleValue());
			waveRect.setTranslateY(waterPane.getPrefHeight() -  hfWater.getNeutralHeight() - waveRect.getHeight());
		});
		
		
		
		
		vWater.getChildren().add(new Label("Daempfung"));
		vWater.getChildren().add(wDamping);
		
		Tab hTab = new Tab("Hitze");
		hTab.setClosable(false);
		rTabs.getTabs().add(hTab);
		VBox vHeat = new VBox();
		vHeat.setPadding(new Insets(5,5,5,5));
		hTab.setContent(vHeat);
		
		vHeat.getChildren().add(new Label("Kalte Raender"));
		CheckBox coolCheck = new CheckBox();
		vHeat.getChildren().add(coolCheck);
		coolCheck.selectedProperty().addListener((v, o, n) -> {
			temperature.setCoolBorders(n.booleanValue());
		});
		
		
		rTabs.getSelectionModel().selectedItemProperty().addListener((v, o, n) -> {
			if (n.getText().compareTo("Wasser")==0) {
				example="water";
				bPane.setLeft(waterPane);
			} else {
				example="heat";
				bPane.setLeft(temperaturePane);
			}
			stop.fire();
		});
		
		bPane.setRight(controls);
		controls.setPrefWidth(200);
		primaryStage.show();
	}

	private Color heatToColor(double heat) {
		double maxValue = 11;
		double minValue = -11;
		
		
		double m = 280 / (minValue - maxValue);
		double b = 280 / (1 - (minValue/maxValue));
		
		double hue = m * heat + b;
		
		return Color.hsb(hue, 1, 1);
		
		
	}

}
