
public class TemperatureCell {

	private double heat;
	private double nextValue;
	private double distance =1;
	private double c=1;
	
	private TemperatureGrid system;
	private TemperatureCell top;
	private TemperatureCell left;
	private TemperatureCell right;
	private TemperatureCell bottom;
	
	
	public TemperatureCell(double heat) {
		super();
		this.heat = heat;
	}
	
	public void setNeighbours(TemperatureCell top, TemperatureCell left, TemperatureCell right, TemperatureCell bottom, TemperatureGrid system) {
		this.top = top;
		this.left = left;
		this.right = right;
		this.bottom = bottom;
		this.system = system;
	}

	public double getHeat() {
		return heat;
	}
	
	public void setHeat(double heat) {
		this.heat = heat;
	}

	private double calcDeviation() {
		double th, lh, rh, bh;
		boolean coolBorders = system.getCoolBorders();
		
		if (top == null) {
			if (coolBorders) {
				th = -11;
			} else {
				th = heat;
			}
		} else {
			th = top.getHeat();
		}
		if (left == null) {
			if (coolBorders) {
				lh = -11;
			} else {
				lh = heat;
			}
		} else {
			lh = left.getHeat();
		}
		if (right == null) {
			if (coolBorders) {
				rh = -11;
			} else {
				rh = heat;
			}
		} else {
			rh = right.getHeat();
		}
		if (bottom == null) {
			if (coolBorders) {
				bh = -11;
			} else {
				bh = heat;
			}
		} else {
			bh = bottom.getHeat();
		}
		
		
		
		return  c*((th + lh + rh + bh - (4*heat)) / Math.pow(distance, 2));
	}

	public void explicitEulerStep(double dt) {
		nextValue = heat + dt*calcDeviation();
		
	}
	
	public void heatNextValue() {
		heat = nextValue;
	}
}
