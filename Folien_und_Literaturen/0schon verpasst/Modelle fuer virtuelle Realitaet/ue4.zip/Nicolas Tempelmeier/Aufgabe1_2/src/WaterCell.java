
public class WaterCell {

	
	private WaterCell left;
	private WaterCell right;
	private double height;
	private double velocity = 0;
	private double c = 1;
	
	private double spacing;
	private HFWater system;
	
	
	public WaterCell(double heigth, double spacing, HFWater system) {
		super();
		this.height = heigth;
		this.spacing = spacing;
		this.system = system;
	}

	private double calcAccelaration() {
		double fl;
		double fr;
		if (left != null) {
			fl = left.getHeight();
		} else {
			fl = this.height;
		}
		if (right != null) {
			fr = right.getHeight();
		} else {
			fr = this.height;
		}
		
		return c* ((fl - 2 *this.height + fr) / Math.pow(spacing, 2));
	}
	
	public void symplecticStepPartOne(double dt) {
		double a = calcAccelaration();
		velocity = velocity * (1.0 - system.getDamping()) + (a * dt);
	}
	
	public void symplecticStepPartTwo(double dt) {
		height = height + (velocity * dt);
	}
	
	public void setNeighbours(WaterCell left, WaterCell right) {
		this.left = left;
		this.right = right;
	}

	public double getHeight() {
		return height;
	}
	


	public void setHeigth(double heigth) {
		this.height = heigth;
	}

	public double getVelocity() {
		return velocity;
	}

	public void setVelocity(double velocity) {
		this.velocity = velocity;
	}
	
	
}
