#ifndef HEATEQUATION_H
#define HEATEQUATION_H
#include <vector>
#include <cmath>


class HeatEquation{
private:

    std::vector<std::vector<double> > particles;
    std::vector<std::vector<double> > velocities;
    double h,dt,waveVelocity;

public:
    HeatEquation(double h, double dt, double waveVelocity){
        this->dt=dt;
        this->h=h;
        this->waveVelocity=waveVelocity;
        for(int i=0;i<64;i++){
            std::vector<double> a;
            std::vector<double> b;
            for(int j=0;j<64;j++){
                a.push_back(sin(i)+i*cos(j));
                b.push_back(0.0);
            }
            particles.push_back(a);
            velocities.push_back(b);
        }
    }

    std::vector<std::vector<double> > getParticles(){
        return particles;
    }

    double getH(){
        return h;
    }

    void simulateStep(){
        std::vector<std::vector<double> > newParticles;
        for(int i=0; i<particles.size();i++){
            std::vector<double> a;
            for(int j=0;j<particles[i].size();j++){
                double f=0;
                if(i==0 && j==0){
                    f=pow(waveVelocity,2)*(particles[i+1][j]+particles[i][j]+particles[i][j+1]+particles[i][j]-4*particles[i][j])/pow(h,2);
                    velocities[i][j]=velocities[i][j]+f*dt;
                    a.push_back(particles[i][j]+velocities[i][j]*dt);
                }else if(i==particles.size()-1 && j==particles[i].size()-1){
                    f=pow(waveVelocity,2)*(particles[i][j]+particles[i-1][j]+particles[i][j]+particles[i][j-1]-4*particles[i][j])/pow(h,2);
                    velocities[i][j]=velocities[i][j]+f*dt;
                    a.push_back(particles[i][j]+velocities[i][j]*dt);
                }else if(i==0){
                    f=pow(waveVelocity,2)*(particles[i+1][j]+particles[i][j]+particles[i][j+1]+particles[i][j-1]-4*particles[i][j])/pow(h,2);
                    velocities[i][j]=velocities[i][j]+f*dt;
                    a.push_back(particles[i][j]+velocities[i][j]*dt);
                }else if(i==particles.size()-1){
                    f=pow(waveVelocity,2)*(particles[i][j]+particles[i-1][j]+particles[i][j+1]+particles[i][j-1]-4*particles[i][j])/pow(h,2);
                    velocities[i][j]=velocities[i][j]+f*dt;
                    a.push_back(particles[i][j]+velocities[i][j]*dt);
                }else if(j==0){
                    f=pow(waveVelocity,2)*(particles[i+1][j]+particles[i-1][j]+particles[i][j+1]+particles[i][j]-4*particles[i][j])/pow(h,2);
                    velocities[i][j]=velocities[i][j]+f*dt;
                    a.push_back(particles[i][j]+velocities[i][j]*dt);
                }else if(j==particles[i].size()-1){
                    f=pow(waveVelocity,2)*(particles[i+1][j]+particles[i-1][j]+particles[i][j]+particles[i][j-1]-4*particles[i][j])/pow(h,2);
                    velocities[i][j]=velocities[i][j]+f*dt;
                    a.push_back(particles[i][j]+velocities[i][j]*dt);
                }else{
                     f=pow(waveVelocity,2)*(particles[i+1][j]+particles[i-1][j]+particles[i][j+1]+particles[i][j-1]-4*particles[i][j])/pow(h,2);
                     velocities[i][j]=velocities[i][j]+f*dt;
                     a.push_back(particles[i][j]+velocities[i][j]*dt);
                }

            }
            newParticles.push_back(a);
        }
        particles=newParticles;
    }

};

#endif // HEATEQUATION_H
