#ifndef CANVAS_H
#define CANVAS_H

#include <QGLViewer/qglviewer.h>
#include "SpringPendulum.h"
#include "PlanetarySystem.h"
#include "Liquid.h"
#include "doublePendulum.h"
#include "HeightFieldWater.h"
#include "HeatEquation.h"

class Canvas: public QGLViewer
{
    Q_OBJECT


public:
    Canvas(QWidget *parent);
private:
    QString selection;
    QString oldSelection;
    SpringPendulum springpendulum=SpringPendulum(1.0,0.1,0.01);
    PlanetarySystem planetarySystem=PlanetarySystem(0.01);
    Liquid liquid=Liquid(0.005);
    bool animationRunning=false;
    doublePendulum doubleP=doublePendulum(0.01,0.03,0.1);
    HeightFieldWater heightFieldWater=HeightFieldWater(0.5,0.1,1);
    HeatEquation heatEquation=HeatEquation(0.5,0.1,1);

signals:

public slots:
    void draw();
    void drawPendulum();
    void drawPlanetarySystem();
    void simulateAStep();
    void animate();
    void drawLiquid();
    void drawDoublePendulum();
    void startSimulation();
    void setSelection(QString newSelection);
    void drawHeightFieldWater();
    void drawHeatEquation();

};

#endif // CANVAS_H
