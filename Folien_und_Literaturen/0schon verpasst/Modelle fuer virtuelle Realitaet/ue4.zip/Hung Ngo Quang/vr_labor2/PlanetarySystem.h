#ifndef PLANETARYSYSTEM_H
#define PLANETARYSYSTEM_H
#include <vector>
#include <math.h>


class PlanetarySystem{

private:
    std::vector<double>masses;
    std::vector<std::vector<double> > planets;
    std::vector<std::vector<double> > velocities;
    double dt;
    double gravitationConst;

public:

    PlanetarySystem(double dt){
        std::vector<double> planet1;
        planet1.push_back(0.0);
        planet1.push_back(0.0);
        planet1.push_back(0.0);
        std::vector<double> planet2;
        planet2.push_back(7.0);
        planet2.push_back(4.0);
        planet2.push_back(7.0);
        std::vector<double> planet3;
        planet3.push_back(9.0);
        planet3.push_back(12.0);
        planet3.push_back(17.0);
        std::vector<double> planet4;
        planet4.push_back(-14.0);
        planet4.push_back(1.0);
        planet4.push_back(4.0);
        std::vector<double> planet5;
        planet5.push_back(11.0);
        planet5.push_back(-20.0);
        planet5.push_back(-9.0);
        planets.push_back(planet1);
        planets.push_back(planet2);
        planets.push_back(planet3);
        planets.push_back(planet4);
        planets.push_back(planet5);
        double mass1=14;
        double mass2=12;
        double mass3=29;
        double mass4=9;
        double mass5=17;
        masses.push_back(mass1);
        masses.push_back(mass2);
        masses.push_back(mass3);
        masses.push_back(mass4);
        masses.push_back(mass5);
        std::vector<double>startingVelocity;
        startingVelocity.push_back(0.0);
        startingVelocity.push_back(0.0);
        startingVelocity.push_back(0.0);
        velocities.clear();
        for(int i=0;i<5;i++){
            velocities.push_back(startingVelocity);
        }
        this->dt=dt;
        gravitationConst=6,67384*pow(10,-11);

    }

    std::vector<double> computateAcceleration(int planet){
        std::vector<double> acceleration;
        acceleration.push_back(0.0);
        acceleration.push_back(0.0);
        acceleration.push_back(0.0);
        std::vector<double> planetPosition= planets[planet];
        for(int i=0;i<planets.size();i++){
            if(i!=planet){
                std::vector<double> distance =sub(planets[i],planetPosition);
                std::vector<double> normalizedDistance=mult(distance,(1/length(distance)));
                std::vector<double> force = (mult(normalizedDistance, gravitationConst*((masses[planet]*masses[i])/pow(length(distance),2))));
                acceleration =add(acceleration,mult(force,(1/masses[planet])));
            }
        }
        return acceleration;

    }

    std:: vector<double> mult(std::vector<double> a, double c){
        std::vector<double> result;
        for(int i=0; i<a.size(); i++){
            result.push_back(a[i]*c);
        }
        return result;
    }

    std:: vector <double> add(std::vector<double> a, std::vector<double> b){
        std::vector<double> result;
        if(a.size()==b.size()){
            for(int i=0; i<a.size(); i++){
                result.push_back(a[i]+b[i]);
            }
            return result;
        }
    }
    std:: vector <double> sub(std::vector<double> a, std::vector<double> b){
        std::vector<double> result;
        if(a.size()==b.size()){
            for(int i=0; i<a.size(); i++){
                result.push_back(a[i]-b[i]);
            }
            return result;
        }
    }

    double length(std::vector<double> vector){
        double lsg=0;
        for(int i=0;i<vector.size();i++){
            lsg=lsg+pow(vector[i],2);
        }
        return sqrt(lsg);
    }

    void simulateStep(){
        for(int i=0;i<velocities.size();i++){
             velocities[i] = add(velocities[i], mult(computateAcceleration(i),dt));
        }
        for(int i=0;i<planets.size();i++){
            planets[i]=add(planets[i],mult(velocities[i],dt));
        }

    }

    std::vector<std::vector<double> > getPlanets(){
        return planets;
    }


};

#endif // PLANETARYSYSTEM_H
