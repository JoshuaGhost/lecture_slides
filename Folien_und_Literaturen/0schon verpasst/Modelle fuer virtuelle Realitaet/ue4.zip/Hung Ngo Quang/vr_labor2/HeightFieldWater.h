#ifndef HEIGHTFIELDWATER_H
#define HEIGHTFIELDWATER_H

#include <vector>
#include <cmath>


class HeightFieldWater{

private:

    std::vector<double> heights;
    std::vector<double> velocities;
    double h, dt;
    double waveVelocity;

public:


    HeightFieldWater(double h, double dt, double waveVelocity){
        this->h=h;
        this->dt=dt;
        this->waveVelocity=waveVelocity;
        for(int i=0;i<20;i++){
            heights.push_back(1.0);
        }
        for(int i=0;i<20;i++){
            velocities.push_back(0.0);
        }
        heights[10]=2.0;
    }


    void simulateStep(){
        std::vector<double> newHeights;
        for(int i=0; i<heights.size();i++){
            double f=0;
            if(i>0 && i<heights.size()-1){
                f = pow(waveVelocity,2)*(heights[i-1]+heights[i+1]-2*heights[i])/pow(h,2);
            }else if(i==0){
                f = pow(waveVelocity,2)*(heights[i]+heights[i+1]-2*heights[i])/pow(h,2);
            }else if(i==heights.size()-1){
                f = pow(waveVelocity,2)*(heights[i]+heights[i]-2*heights[i])/pow(h,2);
            }
            velocities[i]=velocities[i]+f*dt;
            newHeights.push_back(heights[i]+velocities[i]*dt);
        }
        heights=newHeights;
    }

    std::vector<double> getHeights(){
        return heights;
    }

    double getH(){
        return h;
    }

};



#endif // HEIGHTFIELDWATER_H
