package view;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;

import simulation.WaterSimulation;




public class WaterPanel extends JPanel implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6585700087162879923L;
	
	private final WaterSimulation simulation;
	
	private int padding;
	private double sizeFactor;
	
	private int bottomLevel;
	

	public WaterPanel(){
		this.setLayout(null);
		JButton button = new JButton("Add Water");
		this.add(button);
		button.setBounds(50, 250, 100, 100);
		
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				simulation.addHeight(0, 10, 150.0);
			}
		});
		
		this.setBackground(Color.WHITE);
		
		double distance = 0.1;
		double[] heights = generateHeights(60, distance);
		double[] velocities = generateVelocities(heights);
		this.simulation = new WaterSimulation(heights, velocities, distance, 1.0);
		
		Timer timer = new Timer(10, this);
		timer.start();
		
		this.padding = 0;
		this.bottomLevel = 200;
		this.sizeFactor = 10;
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		double[] heights = simulation.getHeights();
		
		g.setColor(Color.BLUE);
		
		int currentX = 0;
		int xDistance = (int)(simulation.getH()*this.sizeFactor);
		
		
		for(int i = 0; i < heights.length; i++){
			g.fillRect(currentX, bottomLevel - (int)(heights[i]), xDistance, (int)(heights[i]));
			
			currentX += xDistance + padding;
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.simulation.nextSimulationStep(10*0.001);
		repaint();
		
		//debug
		System.out.println(simulation.heightDifference());
	}
	
	public double[] generateHeights(double length, double distance){
		int n = (int)(length/distance);
		double[] newHeights = new double[n];
		
		for(int i = 0; i < n; i++){
			if(i < n/4.0){
				newHeights[i] = 100.0 + 50*Math.abs(Math.sin(0.5*i*distance));
			} else {
				newHeights[i] = 100.0;
			}
			
			//newHeights[i] = 100.0 + 50*Math.sin(i*distance);
		}
		
		return newHeights;
	}
	
	public double[] generateVelocities(double[] heights){
		double[] newVelocities = new double[heights.length];
		
		for(int i = 0; i < heights.length; i++){
			newVelocities[i] = 0.0;
		}
		
		return newVelocities;
	}
	

}
