package view;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;

import simulation.HeatSimulation;





public class HeatPanel extends JPanel implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6585700087162879923L;
	
	private HeatSimulation simulation;
	
	private int padding;
	private int width;
	
	private int size;
	private double distance;
	private double c;
	
	private double maxHeat;

	public HeatPanel(){
		this.setBackground(Color.WHITE);
		
		this.distance = 0.1;
		this.size = (int)(10.0 / distance);
		double[][] heats = generateHeat();
		c = 0.3;
		this.simulation = new HeatSimulation(heats, distance, c);
		
		this.width = 400/size;
		this.maxHeat = 15.0;
		
		Timer timer = new Timer(10, this);
		timer.start();
		
		this.padding = 0;
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		for(int x = 0; x < size; x++){
			for(int y = 0; y < size; y++){
				g.setColor(getColor(simulation.getHeatAt(x, y))); 
				g.fillRect(x*(width+padding), y*(width+padding), width, width);
			}
		}

	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.simulation.nextSimulationStep(10*0.001);
		repaint();
	}
	
	public double[][] generateHeat(){
		
		double[][] result = new double[size][size];
		
		for(int x = 0; x < size; x++){
			for(int y = 0; y < size; y++){
				result[x][y] = Math.sin(x*distance) + x*distance*Math.cos(y*distance);
				//result[x][y] = 10.0 * (double)x/(double)size;
			}
		}
		
		return result;
	}
	
	public Color getColor(double heat){
		//double p = Math.max(-1.0, Math.min(1.0, heat/maxHeat));
		
		double p = Math.max(Math.min(heat, maxHeat),-maxHeat);
		p = p/(2.0*maxHeat);
		p += 0.5;
		
		p = Math.min(1.0, Math.max(p, 0.0));
		
		if(Math.abs(p) > 1.0){
			System.out.println("Alarm!");
		}
		//152,245,255
		int r = (int)(255.0 * p);
		int g = (int)(245.0*(1.0-p)*(1.0-p));
		int b = (int)(255.0*(1.0-p));
		Color c = new Color(r,g,b);
		
		return c;
	}
	
}
