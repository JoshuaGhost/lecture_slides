package simulation;

public class HeatSimulation {
	private double[][] heat;
	
	private double distance;
	private double c;
	
	public HeatSimulation(double[][] heat, double distance, double c){
		this.heat = heat;
		this.distance = distance;
		this.c = c;
	}
	
	public double[][] getHeat(){
		return heat.clone();
	}
	
	public void nextSimulationStep(double dt){
		//calculate new heat values
		
		double[][] temp = heat.clone();
		for(int x = 0; x < temp.length; x++){
			for(int y = 0; y < temp.length; y++){
				double left, middle, right, top, bottom;
			
				middle = heat[x][y];
			
				if(x == 0){
					left = middle;
				} else {
					left = heat[x-1][y];
				}
				
				if(x == heat.length-1){
					right = middle;
				} else {
					right = heat[x+1][y];
				}
				
				if(y == 0){
					top = middle;
				} else {
					top = heat[x][y-1];
				}
			
				if(y == heat.length-1){
					bottom = middle;
				} else {
					bottom = heat[x][y+1];
				}
			
				double deriv = (c/(distance*distance))*(left+right+top+bottom-4*middle);
				temp[x][y] += dt*deriv;
			}
		}
		
		heat = temp.clone();
	}
	
	public double getHeatAt(int x, int y){
		return heat[x][y];
	}
}
