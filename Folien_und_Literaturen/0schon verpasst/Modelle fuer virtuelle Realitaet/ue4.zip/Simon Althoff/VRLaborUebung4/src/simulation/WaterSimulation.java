package simulation;

public class WaterSimulation {

	private double[] heights;
	private double[] velocities;
	
	private double h;
	private double speed;
	
	//debug
	public double startingHeights;
	
	public WaterSimulation(double[] heights, double velocities[], double h, double speed) {
		super();
		this.heights = heights;
		this.velocities = velocities;
		this.h = h;
		this.speed = speed;
		
		this.startingHeights = 0.0;
		for(int i = 0; i < heights.length; i++){
			this.startingHeights += heights[i];
		}
	}

	public void nextSimulationStep(double dt){
		//calculate new Velocities
		for(int i = 0; i < heights.length; i++){
			double left, middle, right;
			
			middle = heights[i];
			
			if(i == 0){
				left = middle;
			} else {
				left = heights[i-1];
			}
			
			if(i == heights.length-1){
				right = middle;
			} else {
				right = heights[i+1];
			}
			
			velocities[i] += (dt*speed*speed/h/h)*((1)*left+(-2)*middle+(1)*right); 
		}
		
		//Calculate new Heigths
		for(int i = 0; i < heights.length; i++){
			heights[i] += dt*velocities[i];
		}
	}
	
	public double[] getHeights(){
		return heights.clone();
	}
	
	public double getH(){
		return h;
	}
	
	public double heightDifference(){
		double currentHeight = 0.0;
		for(int i = 0; i < heights.length; i++){
			currentHeight += heights[i];
		}
		
		return startingHeights - currentHeight;
	}
	
	public double getTotalVelocity(){
		double sum = 0.0;
		
		for(double v : velocities){
			sum += v;
		}
		
		return sum;
	}
	
	public double getTotalHeight(){
		double sum = 0.0;
		
		for(double h : heights){
			sum += h;
		}
		
		return sum;
	}
	
	public void addHeight(int start, int end, double toAdd){
		
		double totalHeight = getTotalHeight();
		double currentAcceleration = getTotalAcceleration();
		
		int intervalLength = (end-start+1);
		double toAddPerHeight = toAdd/intervalLength;
		
		for(int i = 0; i < heights.length; i++){
			heights[i] -= (heights[i]/totalHeight)*toAdd;
		}
		
		for(int i = start; i <= end; i++){
			heights[i] += toAddPerHeight;
		}
		
		System.out.println("Diff:" + (currentAcceleration - getTotalAcceleration()));
	}
	
	
	public double[] getAcceleration(){
		
		double[] result = new double[heights.length];
		
		for(int i = 0; i < heights.length; i++){
			double left, middle, right;
			
			middle = heights[i];
			
			if(i == 0){
				left = middle;
			} else {
				left = heights[i-1];
			}
			
			if(i == heights.length-1){
				right = middle;
			} else {
				right = heights[i+1];
			}
			
			result[i] += (speed*speed/h/h)*((1)*left+(-2)*middle+(1)*right); 
		}
		
		return result;
	}
	
	public double getTotalAcceleration(){
		double result = 0.0;
		for(double a : getAcceleration()){
			result += a;
		}
		return result;
	}
}
