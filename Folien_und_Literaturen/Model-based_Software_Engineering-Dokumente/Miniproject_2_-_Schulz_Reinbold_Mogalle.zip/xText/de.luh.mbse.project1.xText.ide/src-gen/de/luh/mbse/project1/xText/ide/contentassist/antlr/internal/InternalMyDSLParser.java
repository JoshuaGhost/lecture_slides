package de.luh.mbse.project1.xText.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import de.luh.mbse.project1.xText.services.MyDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'send'", "'receive'", "'Network'", "'{'", "'}'", "'stateMachine'", "','", "'channel'", "'StateMachine'", "'initialState'", "'state'", "'transition'", "'Channel'", "'State'", "'Transition'", "'sendReceive'", "'source'", "'target'", "'synchronous'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDSL.g"; }


    	private MyDSLGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyDSLGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleNetwork"
    // InternalMyDSL.g:53:1: entryRuleNetwork : ruleNetwork EOF ;
    public final void entryRuleNetwork() throws RecognitionException {
        try {
            // InternalMyDSL.g:54:1: ( ruleNetwork EOF )
            // InternalMyDSL.g:55:1: ruleNetwork EOF
            {
             before(grammarAccess.getNetworkRule()); 
            pushFollow(FOLLOW_1);
            ruleNetwork();

            state._fsp--;

             after(grammarAccess.getNetworkRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNetwork"


    // $ANTLR start "ruleNetwork"
    // InternalMyDSL.g:62:1: ruleNetwork : ( ( rule__Network__Group__0 ) ) ;
    public final void ruleNetwork() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:66:2: ( ( ( rule__Network__Group__0 ) ) )
            // InternalMyDSL.g:67:2: ( ( rule__Network__Group__0 ) )
            {
            // InternalMyDSL.g:67:2: ( ( rule__Network__Group__0 ) )
            // InternalMyDSL.g:68:3: ( rule__Network__Group__0 )
            {
             before(grammarAccess.getNetworkAccess().getGroup()); 
            // InternalMyDSL.g:69:3: ( rule__Network__Group__0 )
            // InternalMyDSL.g:69:4: rule__Network__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNetwork"


    // $ANTLR start "entryRuleEString"
    // InternalMyDSL.g:78:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalMyDSL.g:79:1: ( ruleEString EOF )
            // InternalMyDSL.g:80:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDSL.g:87:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:91:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalMyDSL.g:92:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalMyDSL.g:92:2: ( ( rule__EString__Alternatives ) )
            // InternalMyDSL.g:93:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalMyDSL.g:94:3: ( rule__EString__Alternatives )
            // InternalMyDSL.g:94:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleStateMachine"
    // InternalMyDSL.g:103:1: entryRuleStateMachine : ruleStateMachine EOF ;
    public final void entryRuleStateMachine() throws RecognitionException {
        try {
            // InternalMyDSL.g:104:1: ( ruleStateMachine EOF )
            // InternalMyDSL.g:105:1: ruleStateMachine EOF
            {
             before(grammarAccess.getStateMachineRule()); 
            pushFollow(FOLLOW_1);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getStateMachineRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStateMachine"


    // $ANTLR start "ruleStateMachine"
    // InternalMyDSL.g:112:1: ruleStateMachine : ( ( rule__StateMachine__Group__0 ) ) ;
    public final void ruleStateMachine() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:116:2: ( ( ( rule__StateMachine__Group__0 ) ) )
            // InternalMyDSL.g:117:2: ( ( rule__StateMachine__Group__0 ) )
            {
            // InternalMyDSL.g:117:2: ( ( rule__StateMachine__Group__0 ) )
            // InternalMyDSL.g:118:3: ( rule__StateMachine__Group__0 )
            {
             before(grammarAccess.getStateMachineAccess().getGroup()); 
            // InternalMyDSL.g:119:3: ( rule__StateMachine__Group__0 )
            // InternalMyDSL.g:119:4: rule__StateMachine__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStateMachine"


    // $ANTLR start "entryRuleChannel"
    // InternalMyDSL.g:128:1: entryRuleChannel : ruleChannel EOF ;
    public final void entryRuleChannel() throws RecognitionException {
        try {
            // InternalMyDSL.g:129:1: ( ruleChannel EOF )
            // InternalMyDSL.g:130:1: ruleChannel EOF
            {
             before(grammarAccess.getChannelRule()); 
            pushFollow(FOLLOW_1);
            ruleChannel();

            state._fsp--;

             after(grammarAccess.getChannelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleChannel"


    // $ANTLR start "ruleChannel"
    // InternalMyDSL.g:137:1: ruleChannel : ( ( rule__Channel__Group__0 ) ) ;
    public final void ruleChannel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:141:2: ( ( ( rule__Channel__Group__0 ) ) )
            // InternalMyDSL.g:142:2: ( ( rule__Channel__Group__0 ) )
            {
            // InternalMyDSL.g:142:2: ( ( rule__Channel__Group__0 ) )
            // InternalMyDSL.g:143:3: ( rule__Channel__Group__0 )
            {
             before(grammarAccess.getChannelAccess().getGroup()); 
            // InternalMyDSL.g:144:3: ( rule__Channel__Group__0 )
            // InternalMyDSL.g:144:4: rule__Channel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Channel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getChannelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleChannel"


    // $ANTLR start "entryRuleState"
    // InternalMyDSL.g:153:1: entryRuleState : ruleState EOF ;
    public final void entryRuleState() throws RecognitionException {
        try {
            // InternalMyDSL.g:154:1: ( ruleState EOF )
            // InternalMyDSL.g:155:1: ruleState EOF
            {
             before(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalMyDSL.g:162:1: ruleState : ( ( rule__State__Group__0 ) ) ;
    public final void ruleState() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:166:2: ( ( ( rule__State__Group__0 ) ) )
            // InternalMyDSL.g:167:2: ( ( rule__State__Group__0 ) )
            {
            // InternalMyDSL.g:167:2: ( ( rule__State__Group__0 ) )
            // InternalMyDSL.g:168:3: ( rule__State__Group__0 )
            {
             before(grammarAccess.getStateAccess().getGroup()); 
            // InternalMyDSL.g:169:3: ( rule__State__Group__0 )
            // InternalMyDSL.g:169:4: rule__State__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleTransition"
    // InternalMyDSL.g:178:1: entryRuleTransition : ruleTransition EOF ;
    public final void entryRuleTransition() throws RecognitionException {
        try {
            // InternalMyDSL.g:179:1: ( ruleTransition EOF )
            // InternalMyDSL.g:180:1: ruleTransition EOF
            {
             before(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getTransitionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalMyDSL.g:187:1: ruleTransition : ( ( rule__Transition__Group__0 ) ) ;
    public final void ruleTransition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:191:2: ( ( ( rule__Transition__Group__0 ) ) )
            // InternalMyDSL.g:192:2: ( ( rule__Transition__Group__0 ) )
            {
            // InternalMyDSL.g:192:2: ( ( rule__Transition__Group__0 ) )
            // InternalMyDSL.g:193:3: ( rule__Transition__Group__0 )
            {
             before(grammarAccess.getTransitionAccess().getGroup()); 
            // InternalMyDSL.g:194:3: ( rule__Transition__Group__0 )
            // InternalMyDSL.g:194:4: rule__Transition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTransition"


    // $ANTLR start "ruleSendReceive"
    // InternalMyDSL.g:203:1: ruleSendReceive : ( ( rule__SendReceive__Alternatives ) ) ;
    public final void ruleSendReceive() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:207:1: ( ( ( rule__SendReceive__Alternatives ) ) )
            // InternalMyDSL.g:208:2: ( ( rule__SendReceive__Alternatives ) )
            {
            // InternalMyDSL.g:208:2: ( ( rule__SendReceive__Alternatives ) )
            // InternalMyDSL.g:209:3: ( rule__SendReceive__Alternatives )
            {
             before(grammarAccess.getSendReceiveAccess().getAlternatives()); 
            // InternalMyDSL.g:210:3: ( rule__SendReceive__Alternatives )
            // InternalMyDSL.g:210:4: rule__SendReceive__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SendReceive__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSendReceiveAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSendReceive"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalMyDSL.g:218:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:222:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_ID) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDSL.g:223:2: ( RULE_STRING )
                    {
                    // InternalMyDSL.g:223:2: ( RULE_STRING )
                    // InternalMyDSL.g:224:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDSL.g:229:2: ( RULE_ID )
                    {
                    // InternalMyDSL.g:229:2: ( RULE_ID )
                    // InternalMyDSL.g:230:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__SendReceive__Alternatives"
    // InternalMyDSL.g:239:1: rule__SendReceive__Alternatives : ( ( ( 'send' ) ) | ( ( 'receive' ) ) );
    public final void rule__SendReceive__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:243:1: ( ( ( 'send' ) ) | ( ( 'receive' ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==11) ) {
                alt2=1;
            }
            else if ( (LA2_0==12) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyDSL.g:244:2: ( ( 'send' ) )
                    {
                    // InternalMyDSL.g:244:2: ( ( 'send' ) )
                    // InternalMyDSL.g:245:3: ( 'send' )
                    {
                     before(grammarAccess.getSendReceiveAccess().getSendEnumLiteralDeclaration_0()); 
                    // InternalMyDSL.g:246:3: ( 'send' )
                    // InternalMyDSL.g:246:4: 'send'
                    {
                    match(input,11,FOLLOW_2); 

                    }

                     after(grammarAccess.getSendReceiveAccess().getSendEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDSL.g:250:2: ( ( 'receive' ) )
                    {
                    // InternalMyDSL.g:250:2: ( ( 'receive' ) )
                    // InternalMyDSL.g:251:3: ( 'receive' )
                    {
                     before(grammarAccess.getSendReceiveAccess().getReceiveEnumLiteralDeclaration_1()); 
                    // InternalMyDSL.g:252:3: ( 'receive' )
                    // InternalMyDSL.g:252:4: 'receive'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getSendReceiveAccess().getReceiveEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SendReceive__Alternatives"


    // $ANTLR start "rule__Network__Group__0"
    // InternalMyDSL.g:260:1: rule__Network__Group__0 : rule__Network__Group__0__Impl rule__Network__Group__1 ;
    public final void rule__Network__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:264:1: ( rule__Network__Group__0__Impl rule__Network__Group__1 )
            // InternalMyDSL.g:265:2: rule__Network__Group__0__Impl rule__Network__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Network__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__0"


    // $ANTLR start "rule__Network__Group__0__Impl"
    // InternalMyDSL.g:272:1: rule__Network__Group__0__Impl : ( () ) ;
    public final void rule__Network__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:276:1: ( ( () ) )
            // InternalMyDSL.g:277:1: ( () )
            {
            // InternalMyDSL.g:277:1: ( () )
            // InternalMyDSL.g:278:2: ()
            {
             before(grammarAccess.getNetworkAccess().getNetworkAction_0()); 
            // InternalMyDSL.g:279:2: ()
            // InternalMyDSL.g:279:3: 
            {
            }

             after(grammarAccess.getNetworkAccess().getNetworkAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__0__Impl"


    // $ANTLR start "rule__Network__Group__1"
    // InternalMyDSL.g:287:1: rule__Network__Group__1 : rule__Network__Group__1__Impl rule__Network__Group__2 ;
    public final void rule__Network__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:291:1: ( rule__Network__Group__1__Impl rule__Network__Group__2 )
            // InternalMyDSL.g:292:2: rule__Network__Group__1__Impl rule__Network__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Network__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__1"


    // $ANTLR start "rule__Network__Group__1__Impl"
    // InternalMyDSL.g:299:1: rule__Network__Group__1__Impl : ( 'Network' ) ;
    public final void rule__Network__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:303:1: ( ( 'Network' ) )
            // InternalMyDSL.g:304:1: ( 'Network' )
            {
            // InternalMyDSL.g:304:1: ( 'Network' )
            // InternalMyDSL.g:305:2: 'Network'
            {
             before(grammarAccess.getNetworkAccess().getNetworkKeyword_1()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getNetworkKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__1__Impl"


    // $ANTLR start "rule__Network__Group__2"
    // InternalMyDSL.g:314:1: rule__Network__Group__2 : rule__Network__Group__2__Impl rule__Network__Group__3 ;
    public final void rule__Network__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:318:1: ( rule__Network__Group__2__Impl rule__Network__Group__3 )
            // InternalMyDSL.g:319:2: rule__Network__Group__2__Impl rule__Network__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Network__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__2"


    // $ANTLR start "rule__Network__Group__2__Impl"
    // InternalMyDSL.g:326:1: rule__Network__Group__2__Impl : ( ( rule__Network__NameAssignment_2 ) ) ;
    public final void rule__Network__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:330:1: ( ( ( rule__Network__NameAssignment_2 ) ) )
            // InternalMyDSL.g:331:1: ( ( rule__Network__NameAssignment_2 ) )
            {
            // InternalMyDSL.g:331:1: ( ( rule__Network__NameAssignment_2 ) )
            // InternalMyDSL.g:332:2: ( rule__Network__NameAssignment_2 )
            {
             before(grammarAccess.getNetworkAccess().getNameAssignment_2()); 
            // InternalMyDSL.g:333:2: ( rule__Network__NameAssignment_2 )
            // InternalMyDSL.g:333:3: rule__Network__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Network__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__2__Impl"


    // $ANTLR start "rule__Network__Group__3"
    // InternalMyDSL.g:341:1: rule__Network__Group__3 : rule__Network__Group__3__Impl rule__Network__Group__4 ;
    public final void rule__Network__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:345:1: ( rule__Network__Group__3__Impl rule__Network__Group__4 )
            // InternalMyDSL.g:346:2: rule__Network__Group__3__Impl rule__Network__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Network__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__3"


    // $ANTLR start "rule__Network__Group__3__Impl"
    // InternalMyDSL.g:353:1: rule__Network__Group__3__Impl : ( '{' ) ;
    public final void rule__Network__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:357:1: ( ( '{' ) )
            // InternalMyDSL.g:358:1: ( '{' )
            {
            // InternalMyDSL.g:358:1: ( '{' )
            // InternalMyDSL.g:359:2: '{'
            {
             before(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__3__Impl"


    // $ANTLR start "rule__Network__Group__4"
    // InternalMyDSL.g:368:1: rule__Network__Group__4 : rule__Network__Group__4__Impl rule__Network__Group__5 ;
    public final void rule__Network__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:372:1: ( rule__Network__Group__4__Impl rule__Network__Group__5 )
            // InternalMyDSL.g:373:2: rule__Network__Group__4__Impl rule__Network__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__Network__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__4"


    // $ANTLR start "rule__Network__Group__4__Impl"
    // InternalMyDSL.g:380:1: rule__Network__Group__4__Impl : ( ( rule__Network__Group_4__0 )? ) ;
    public final void rule__Network__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:384:1: ( ( ( rule__Network__Group_4__0 )? ) )
            // InternalMyDSL.g:385:1: ( ( rule__Network__Group_4__0 )? )
            {
            // InternalMyDSL.g:385:1: ( ( rule__Network__Group_4__0 )? )
            // InternalMyDSL.g:386:2: ( rule__Network__Group_4__0 )?
            {
             before(grammarAccess.getNetworkAccess().getGroup_4()); 
            // InternalMyDSL.g:387:2: ( rule__Network__Group_4__0 )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==16) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalMyDSL.g:387:3: rule__Network__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Network__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getNetworkAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__4__Impl"


    // $ANTLR start "rule__Network__Group__5"
    // InternalMyDSL.g:395:1: rule__Network__Group__5 : rule__Network__Group__5__Impl rule__Network__Group__6 ;
    public final void rule__Network__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:399:1: ( rule__Network__Group__5__Impl rule__Network__Group__6 )
            // InternalMyDSL.g:400:2: rule__Network__Group__5__Impl rule__Network__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__Network__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__5"


    // $ANTLR start "rule__Network__Group__5__Impl"
    // InternalMyDSL.g:407:1: rule__Network__Group__5__Impl : ( ( rule__Network__Group_5__0 )? ) ;
    public final void rule__Network__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:411:1: ( ( ( rule__Network__Group_5__0 )? ) )
            // InternalMyDSL.g:412:1: ( ( rule__Network__Group_5__0 )? )
            {
            // InternalMyDSL.g:412:1: ( ( rule__Network__Group_5__0 )? )
            // InternalMyDSL.g:413:2: ( rule__Network__Group_5__0 )?
            {
             before(grammarAccess.getNetworkAccess().getGroup_5()); 
            // InternalMyDSL.g:414:2: ( rule__Network__Group_5__0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==18) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDSL.g:414:3: rule__Network__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Network__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getNetworkAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__5__Impl"


    // $ANTLR start "rule__Network__Group__6"
    // InternalMyDSL.g:422:1: rule__Network__Group__6 : rule__Network__Group__6__Impl ;
    public final void rule__Network__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:426:1: ( rule__Network__Group__6__Impl )
            // InternalMyDSL.g:427:2: rule__Network__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__6"


    // $ANTLR start "rule__Network__Group__6__Impl"
    // InternalMyDSL.g:433:1: rule__Network__Group__6__Impl : ( '}' ) ;
    public final void rule__Network__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:437:1: ( ( '}' ) )
            // InternalMyDSL.g:438:1: ( '}' )
            {
            // InternalMyDSL.g:438:1: ( '}' )
            // InternalMyDSL.g:439:2: '}'
            {
             before(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_6()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__6__Impl"


    // $ANTLR start "rule__Network__Group_4__0"
    // InternalMyDSL.g:449:1: rule__Network__Group_4__0 : rule__Network__Group_4__0__Impl rule__Network__Group_4__1 ;
    public final void rule__Network__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:453:1: ( rule__Network__Group_4__0__Impl rule__Network__Group_4__1 )
            // InternalMyDSL.g:454:2: rule__Network__Group_4__0__Impl rule__Network__Group_4__1
            {
            pushFollow(FOLLOW_5);
            rule__Network__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__0"


    // $ANTLR start "rule__Network__Group_4__0__Impl"
    // InternalMyDSL.g:461:1: rule__Network__Group_4__0__Impl : ( 'stateMachine' ) ;
    public final void rule__Network__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:465:1: ( ( 'stateMachine' ) )
            // InternalMyDSL.g:466:1: ( 'stateMachine' )
            {
            // InternalMyDSL.g:466:1: ( 'stateMachine' )
            // InternalMyDSL.g:467:2: 'stateMachine'
            {
             before(grammarAccess.getNetworkAccess().getStateMachineKeyword_4_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getStateMachineKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__0__Impl"


    // $ANTLR start "rule__Network__Group_4__1"
    // InternalMyDSL.g:476:1: rule__Network__Group_4__1 : rule__Network__Group_4__1__Impl rule__Network__Group_4__2 ;
    public final void rule__Network__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:480:1: ( rule__Network__Group_4__1__Impl rule__Network__Group_4__2 )
            // InternalMyDSL.g:481:2: rule__Network__Group_4__1__Impl rule__Network__Group_4__2
            {
            pushFollow(FOLLOW_7);
            rule__Network__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__1"


    // $ANTLR start "rule__Network__Group_4__1__Impl"
    // InternalMyDSL.g:488:1: rule__Network__Group_4__1__Impl : ( '{' ) ;
    public final void rule__Network__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:492:1: ( ( '{' ) )
            // InternalMyDSL.g:493:1: ( '{' )
            {
            // InternalMyDSL.g:493:1: ( '{' )
            // InternalMyDSL.g:494:2: '{'
            {
             before(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_4_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__1__Impl"


    // $ANTLR start "rule__Network__Group_4__2"
    // InternalMyDSL.g:503:1: rule__Network__Group_4__2 : rule__Network__Group_4__2__Impl rule__Network__Group_4__3 ;
    public final void rule__Network__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:507:1: ( rule__Network__Group_4__2__Impl rule__Network__Group_4__3 )
            // InternalMyDSL.g:508:2: rule__Network__Group_4__2__Impl rule__Network__Group_4__3
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_4__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__2"


    // $ANTLR start "rule__Network__Group_4__2__Impl"
    // InternalMyDSL.g:515:1: rule__Network__Group_4__2__Impl : ( ( rule__Network__StateMachineAssignment_4_2 ) ) ;
    public final void rule__Network__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:519:1: ( ( ( rule__Network__StateMachineAssignment_4_2 ) ) )
            // InternalMyDSL.g:520:1: ( ( rule__Network__StateMachineAssignment_4_2 ) )
            {
            // InternalMyDSL.g:520:1: ( ( rule__Network__StateMachineAssignment_4_2 ) )
            // InternalMyDSL.g:521:2: ( rule__Network__StateMachineAssignment_4_2 )
            {
             before(grammarAccess.getNetworkAccess().getStateMachineAssignment_4_2()); 
            // InternalMyDSL.g:522:2: ( rule__Network__StateMachineAssignment_4_2 )
            // InternalMyDSL.g:522:3: rule__Network__StateMachineAssignment_4_2
            {
            pushFollow(FOLLOW_2);
            rule__Network__StateMachineAssignment_4_2();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getStateMachineAssignment_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__2__Impl"


    // $ANTLR start "rule__Network__Group_4__3"
    // InternalMyDSL.g:530:1: rule__Network__Group_4__3 : rule__Network__Group_4__3__Impl rule__Network__Group_4__4 ;
    public final void rule__Network__Group_4__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:534:1: ( rule__Network__Group_4__3__Impl rule__Network__Group_4__4 )
            // InternalMyDSL.g:535:2: rule__Network__Group_4__3__Impl rule__Network__Group_4__4
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_4__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__3"


    // $ANTLR start "rule__Network__Group_4__3__Impl"
    // InternalMyDSL.g:542:1: rule__Network__Group_4__3__Impl : ( ( rule__Network__Group_4_3__0 )* ) ;
    public final void rule__Network__Group_4__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:546:1: ( ( ( rule__Network__Group_4_3__0 )* ) )
            // InternalMyDSL.g:547:1: ( ( rule__Network__Group_4_3__0 )* )
            {
            // InternalMyDSL.g:547:1: ( ( rule__Network__Group_4_3__0 )* )
            // InternalMyDSL.g:548:2: ( rule__Network__Group_4_3__0 )*
            {
             before(grammarAccess.getNetworkAccess().getGroup_4_3()); 
            // InternalMyDSL.g:549:2: ( rule__Network__Group_4_3__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==17) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalMyDSL.g:549:3: rule__Network__Group_4_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Network__Group_4_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getNetworkAccess().getGroup_4_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__3__Impl"


    // $ANTLR start "rule__Network__Group_4__4"
    // InternalMyDSL.g:557:1: rule__Network__Group_4__4 : rule__Network__Group_4__4__Impl ;
    public final void rule__Network__Group_4__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:561:1: ( rule__Network__Group_4__4__Impl )
            // InternalMyDSL.g:562:2: rule__Network__Group_4__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_4__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__4"


    // $ANTLR start "rule__Network__Group_4__4__Impl"
    // InternalMyDSL.g:568:1: rule__Network__Group_4__4__Impl : ( '}' ) ;
    public final void rule__Network__Group_4__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:572:1: ( ( '}' ) )
            // InternalMyDSL.g:573:1: ( '}' )
            {
            // InternalMyDSL.g:573:1: ( '}' )
            // InternalMyDSL.g:574:2: '}'
            {
             before(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_4_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_4_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__4__Impl"


    // $ANTLR start "rule__Network__Group_4_3__0"
    // InternalMyDSL.g:584:1: rule__Network__Group_4_3__0 : rule__Network__Group_4_3__0__Impl rule__Network__Group_4_3__1 ;
    public final void rule__Network__Group_4_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:588:1: ( rule__Network__Group_4_3__0__Impl rule__Network__Group_4_3__1 )
            // InternalMyDSL.g:589:2: rule__Network__Group_4_3__0__Impl rule__Network__Group_4_3__1
            {
            pushFollow(FOLLOW_7);
            rule__Network__Group_4_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__0"


    // $ANTLR start "rule__Network__Group_4_3__0__Impl"
    // InternalMyDSL.g:596:1: rule__Network__Group_4_3__0__Impl : ( ',' ) ;
    public final void rule__Network__Group_4_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:600:1: ( ( ',' ) )
            // InternalMyDSL.g:601:1: ( ',' )
            {
            // InternalMyDSL.g:601:1: ( ',' )
            // InternalMyDSL.g:602:2: ','
            {
             before(grammarAccess.getNetworkAccess().getCommaKeyword_4_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getCommaKeyword_4_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__0__Impl"


    // $ANTLR start "rule__Network__Group_4_3__1"
    // InternalMyDSL.g:611:1: rule__Network__Group_4_3__1 : rule__Network__Group_4_3__1__Impl ;
    public final void rule__Network__Group_4_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:615:1: ( rule__Network__Group_4_3__1__Impl )
            // InternalMyDSL.g:616:2: rule__Network__Group_4_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_4_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__1"


    // $ANTLR start "rule__Network__Group_4_3__1__Impl"
    // InternalMyDSL.g:622:1: rule__Network__Group_4_3__1__Impl : ( ( rule__Network__StateMachineAssignment_4_3_1 ) ) ;
    public final void rule__Network__Group_4_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:626:1: ( ( ( rule__Network__StateMachineAssignment_4_3_1 ) ) )
            // InternalMyDSL.g:627:1: ( ( rule__Network__StateMachineAssignment_4_3_1 ) )
            {
            // InternalMyDSL.g:627:1: ( ( rule__Network__StateMachineAssignment_4_3_1 ) )
            // InternalMyDSL.g:628:2: ( rule__Network__StateMachineAssignment_4_3_1 )
            {
             before(grammarAccess.getNetworkAccess().getStateMachineAssignment_4_3_1()); 
            // InternalMyDSL.g:629:2: ( rule__Network__StateMachineAssignment_4_3_1 )
            // InternalMyDSL.g:629:3: rule__Network__StateMachineAssignment_4_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Network__StateMachineAssignment_4_3_1();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getStateMachineAssignment_4_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__1__Impl"


    // $ANTLR start "rule__Network__Group_5__0"
    // InternalMyDSL.g:638:1: rule__Network__Group_5__0 : rule__Network__Group_5__0__Impl rule__Network__Group_5__1 ;
    public final void rule__Network__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:642:1: ( rule__Network__Group_5__0__Impl rule__Network__Group_5__1 )
            // InternalMyDSL.g:643:2: rule__Network__Group_5__0__Impl rule__Network__Group_5__1
            {
            pushFollow(FOLLOW_5);
            rule__Network__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__0"


    // $ANTLR start "rule__Network__Group_5__0__Impl"
    // InternalMyDSL.g:650:1: rule__Network__Group_5__0__Impl : ( 'channel' ) ;
    public final void rule__Network__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:654:1: ( ( 'channel' ) )
            // InternalMyDSL.g:655:1: ( 'channel' )
            {
            // InternalMyDSL.g:655:1: ( 'channel' )
            // InternalMyDSL.g:656:2: 'channel'
            {
             before(grammarAccess.getNetworkAccess().getChannelKeyword_5_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getChannelKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__0__Impl"


    // $ANTLR start "rule__Network__Group_5__1"
    // InternalMyDSL.g:665:1: rule__Network__Group_5__1 : rule__Network__Group_5__1__Impl rule__Network__Group_5__2 ;
    public final void rule__Network__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:669:1: ( rule__Network__Group_5__1__Impl rule__Network__Group_5__2 )
            // InternalMyDSL.g:670:2: rule__Network__Group_5__1__Impl rule__Network__Group_5__2
            {
            pushFollow(FOLLOW_10);
            rule__Network__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__1"


    // $ANTLR start "rule__Network__Group_5__1__Impl"
    // InternalMyDSL.g:677:1: rule__Network__Group_5__1__Impl : ( '{' ) ;
    public final void rule__Network__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:681:1: ( ( '{' ) )
            // InternalMyDSL.g:682:1: ( '{' )
            {
            // InternalMyDSL.g:682:1: ( '{' )
            // InternalMyDSL.g:683:2: '{'
            {
             before(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__1__Impl"


    // $ANTLR start "rule__Network__Group_5__2"
    // InternalMyDSL.g:692:1: rule__Network__Group_5__2 : rule__Network__Group_5__2__Impl rule__Network__Group_5__3 ;
    public final void rule__Network__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:696:1: ( rule__Network__Group_5__2__Impl rule__Network__Group_5__3 )
            // InternalMyDSL.g:697:2: rule__Network__Group_5__2__Impl rule__Network__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__2"


    // $ANTLR start "rule__Network__Group_5__2__Impl"
    // InternalMyDSL.g:704:1: rule__Network__Group_5__2__Impl : ( ( rule__Network__ChannelAssignment_5_2 ) ) ;
    public final void rule__Network__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:708:1: ( ( ( rule__Network__ChannelAssignment_5_2 ) ) )
            // InternalMyDSL.g:709:1: ( ( rule__Network__ChannelAssignment_5_2 ) )
            {
            // InternalMyDSL.g:709:1: ( ( rule__Network__ChannelAssignment_5_2 ) )
            // InternalMyDSL.g:710:2: ( rule__Network__ChannelAssignment_5_2 )
            {
             before(grammarAccess.getNetworkAccess().getChannelAssignment_5_2()); 
            // InternalMyDSL.g:711:2: ( rule__Network__ChannelAssignment_5_2 )
            // InternalMyDSL.g:711:3: rule__Network__ChannelAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__Network__ChannelAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getChannelAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__2__Impl"


    // $ANTLR start "rule__Network__Group_5__3"
    // InternalMyDSL.g:719:1: rule__Network__Group_5__3 : rule__Network__Group_5__3__Impl rule__Network__Group_5__4 ;
    public final void rule__Network__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:723:1: ( rule__Network__Group_5__3__Impl rule__Network__Group_5__4 )
            // InternalMyDSL.g:724:2: rule__Network__Group_5__3__Impl rule__Network__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__3"


    // $ANTLR start "rule__Network__Group_5__3__Impl"
    // InternalMyDSL.g:731:1: rule__Network__Group_5__3__Impl : ( ( rule__Network__Group_5_3__0 )* ) ;
    public final void rule__Network__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:735:1: ( ( ( rule__Network__Group_5_3__0 )* ) )
            // InternalMyDSL.g:736:1: ( ( rule__Network__Group_5_3__0 )* )
            {
            // InternalMyDSL.g:736:1: ( ( rule__Network__Group_5_3__0 )* )
            // InternalMyDSL.g:737:2: ( rule__Network__Group_5_3__0 )*
            {
             before(grammarAccess.getNetworkAccess().getGroup_5_3()); 
            // InternalMyDSL.g:738:2: ( rule__Network__Group_5_3__0 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==17) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMyDSL.g:738:3: rule__Network__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Network__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getNetworkAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__3__Impl"


    // $ANTLR start "rule__Network__Group_5__4"
    // InternalMyDSL.g:746:1: rule__Network__Group_5__4 : rule__Network__Group_5__4__Impl ;
    public final void rule__Network__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:750:1: ( rule__Network__Group_5__4__Impl )
            // InternalMyDSL.g:751:2: rule__Network__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__4"


    // $ANTLR start "rule__Network__Group_5__4__Impl"
    // InternalMyDSL.g:757:1: rule__Network__Group_5__4__Impl : ( '}' ) ;
    public final void rule__Network__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:761:1: ( ( '}' ) )
            // InternalMyDSL.g:762:1: ( '}' )
            {
            // InternalMyDSL.g:762:1: ( '}' )
            // InternalMyDSL.g:763:2: '}'
            {
             before(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__4__Impl"


    // $ANTLR start "rule__Network__Group_5_3__0"
    // InternalMyDSL.g:773:1: rule__Network__Group_5_3__0 : rule__Network__Group_5_3__0__Impl rule__Network__Group_5_3__1 ;
    public final void rule__Network__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:777:1: ( rule__Network__Group_5_3__0__Impl rule__Network__Group_5_3__1 )
            // InternalMyDSL.g:778:2: rule__Network__Group_5_3__0__Impl rule__Network__Group_5_3__1
            {
            pushFollow(FOLLOW_10);
            rule__Network__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__0"


    // $ANTLR start "rule__Network__Group_5_3__0__Impl"
    // InternalMyDSL.g:785:1: rule__Network__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__Network__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:789:1: ( ( ',' ) )
            // InternalMyDSL.g:790:1: ( ',' )
            {
            // InternalMyDSL.g:790:1: ( ',' )
            // InternalMyDSL.g:791:2: ','
            {
             before(grammarAccess.getNetworkAccess().getCommaKeyword_5_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__0__Impl"


    // $ANTLR start "rule__Network__Group_5_3__1"
    // InternalMyDSL.g:800:1: rule__Network__Group_5_3__1 : rule__Network__Group_5_3__1__Impl ;
    public final void rule__Network__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:804:1: ( rule__Network__Group_5_3__1__Impl )
            // InternalMyDSL.g:805:2: rule__Network__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__1"


    // $ANTLR start "rule__Network__Group_5_3__1__Impl"
    // InternalMyDSL.g:811:1: rule__Network__Group_5_3__1__Impl : ( ( rule__Network__ChannelAssignment_5_3_1 ) ) ;
    public final void rule__Network__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:815:1: ( ( ( rule__Network__ChannelAssignment_5_3_1 ) ) )
            // InternalMyDSL.g:816:1: ( ( rule__Network__ChannelAssignment_5_3_1 ) )
            {
            // InternalMyDSL.g:816:1: ( ( rule__Network__ChannelAssignment_5_3_1 ) )
            // InternalMyDSL.g:817:2: ( rule__Network__ChannelAssignment_5_3_1 )
            {
             before(grammarAccess.getNetworkAccess().getChannelAssignment_5_3_1()); 
            // InternalMyDSL.g:818:2: ( rule__Network__ChannelAssignment_5_3_1 )
            // InternalMyDSL.g:818:3: rule__Network__ChannelAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Network__ChannelAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getChannelAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__1__Impl"


    // $ANTLR start "rule__StateMachine__Group__0"
    // InternalMyDSL.g:827:1: rule__StateMachine__Group__0 : rule__StateMachine__Group__0__Impl rule__StateMachine__Group__1 ;
    public final void rule__StateMachine__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:831:1: ( rule__StateMachine__Group__0__Impl rule__StateMachine__Group__1 )
            // InternalMyDSL.g:832:2: rule__StateMachine__Group__0__Impl rule__StateMachine__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__StateMachine__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__0"


    // $ANTLR start "rule__StateMachine__Group__0__Impl"
    // InternalMyDSL.g:839:1: rule__StateMachine__Group__0__Impl : ( () ) ;
    public final void rule__StateMachine__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:843:1: ( ( () ) )
            // InternalMyDSL.g:844:1: ( () )
            {
            // InternalMyDSL.g:844:1: ( () )
            // InternalMyDSL.g:845:2: ()
            {
             before(grammarAccess.getStateMachineAccess().getStateMachineAction_0()); 
            // InternalMyDSL.g:846:2: ()
            // InternalMyDSL.g:846:3: 
            {
            }

             after(grammarAccess.getStateMachineAccess().getStateMachineAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__0__Impl"


    // $ANTLR start "rule__StateMachine__Group__1"
    // InternalMyDSL.g:854:1: rule__StateMachine__Group__1 : rule__StateMachine__Group__1__Impl rule__StateMachine__Group__2 ;
    public final void rule__StateMachine__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:858:1: ( rule__StateMachine__Group__1__Impl rule__StateMachine__Group__2 )
            // InternalMyDSL.g:859:2: rule__StateMachine__Group__1__Impl rule__StateMachine__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__StateMachine__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__1"


    // $ANTLR start "rule__StateMachine__Group__1__Impl"
    // InternalMyDSL.g:866:1: rule__StateMachine__Group__1__Impl : ( 'StateMachine' ) ;
    public final void rule__StateMachine__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:870:1: ( ( 'StateMachine' ) )
            // InternalMyDSL.g:871:1: ( 'StateMachine' )
            {
            // InternalMyDSL.g:871:1: ( 'StateMachine' )
            // InternalMyDSL.g:872:2: 'StateMachine'
            {
             before(grammarAccess.getStateMachineAccess().getStateMachineKeyword_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getStateMachineKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__1__Impl"


    // $ANTLR start "rule__StateMachine__Group__2"
    // InternalMyDSL.g:881:1: rule__StateMachine__Group__2 : rule__StateMachine__Group__2__Impl rule__StateMachine__Group__3 ;
    public final void rule__StateMachine__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:885:1: ( rule__StateMachine__Group__2__Impl rule__StateMachine__Group__3 )
            // InternalMyDSL.g:886:2: rule__StateMachine__Group__2__Impl rule__StateMachine__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__StateMachine__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__2"


    // $ANTLR start "rule__StateMachine__Group__2__Impl"
    // InternalMyDSL.g:893:1: rule__StateMachine__Group__2__Impl : ( ( rule__StateMachine__NameAssignment_2 ) ) ;
    public final void rule__StateMachine__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:897:1: ( ( ( rule__StateMachine__NameAssignment_2 ) ) )
            // InternalMyDSL.g:898:1: ( ( rule__StateMachine__NameAssignment_2 ) )
            {
            // InternalMyDSL.g:898:1: ( ( rule__StateMachine__NameAssignment_2 ) )
            // InternalMyDSL.g:899:2: ( rule__StateMachine__NameAssignment_2 )
            {
             before(grammarAccess.getStateMachineAccess().getNameAssignment_2()); 
            // InternalMyDSL.g:900:2: ( rule__StateMachine__NameAssignment_2 )
            // InternalMyDSL.g:900:3: rule__StateMachine__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__2__Impl"


    // $ANTLR start "rule__StateMachine__Group__3"
    // InternalMyDSL.g:908:1: rule__StateMachine__Group__3 : rule__StateMachine__Group__3__Impl rule__StateMachine__Group__4 ;
    public final void rule__StateMachine__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:912:1: ( rule__StateMachine__Group__3__Impl rule__StateMachine__Group__4 )
            // InternalMyDSL.g:913:2: rule__StateMachine__Group__3__Impl rule__StateMachine__Group__4
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__3"


    // $ANTLR start "rule__StateMachine__Group__3__Impl"
    // InternalMyDSL.g:920:1: rule__StateMachine__Group__3__Impl : ( '{' ) ;
    public final void rule__StateMachine__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:924:1: ( ( '{' ) )
            // InternalMyDSL.g:925:1: ( '{' )
            {
            // InternalMyDSL.g:925:1: ( '{' )
            // InternalMyDSL.g:926:2: '{'
            {
             before(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__3__Impl"


    // $ANTLR start "rule__StateMachine__Group__4"
    // InternalMyDSL.g:935:1: rule__StateMachine__Group__4 : rule__StateMachine__Group__4__Impl rule__StateMachine__Group__5 ;
    public final void rule__StateMachine__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:939:1: ( rule__StateMachine__Group__4__Impl rule__StateMachine__Group__5 )
            // InternalMyDSL.g:940:2: rule__StateMachine__Group__4__Impl rule__StateMachine__Group__5
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__4"


    // $ANTLR start "rule__StateMachine__Group__4__Impl"
    // InternalMyDSL.g:947:1: rule__StateMachine__Group__4__Impl : ( ( rule__StateMachine__Group_4__0 )? ) ;
    public final void rule__StateMachine__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:951:1: ( ( ( rule__StateMachine__Group_4__0 )? ) )
            // InternalMyDSL.g:952:1: ( ( rule__StateMachine__Group_4__0 )? )
            {
            // InternalMyDSL.g:952:1: ( ( rule__StateMachine__Group_4__0 )? )
            // InternalMyDSL.g:953:2: ( rule__StateMachine__Group_4__0 )?
            {
             before(grammarAccess.getStateMachineAccess().getGroup_4()); 
            // InternalMyDSL.g:954:2: ( rule__StateMachine__Group_4__0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==20) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDSL.g:954:3: rule__StateMachine__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__StateMachine__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStateMachineAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__4__Impl"


    // $ANTLR start "rule__StateMachine__Group__5"
    // InternalMyDSL.g:962:1: rule__StateMachine__Group__5 : rule__StateMachine__Group__5__Impl rule__StateMachine__Group__6 ;
    public final void rule__StateMachine__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:966:1: ( rule__StateMachine__Group__5__Impl rule__StateMachine__Group__6 )
            // InternalMyDSL.g:967:2: rule__StateMachine__Group__5__Impl rule__StateMachine__Group__6
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__5"


    // $ANTLR start "rule__StateMachine__Group__5__Impl"
    // InternalMyDSL.g:974:1: rule__StateMachine__Group__5__Impl : ( ( rule__StateMachine__Group_5__0 )? ) ;
    public final void rule__StateMachine__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:978:1: ( ( ( rule__StateMachine__Group_5__0 )? ) )
            // InternalMyDSL.g:979:1: ( ( rule__StateMachine__Group_5__0 )? )
            {
            // InternalMyDSL.g:979:1: ( ( rule__StateMachine__Group_5__0 )? )
            // InternalMyDSL.g:980:2: ( rule__StateMachine__Group_5__0 )?
            {
             before(grammarAccess.getStateMachineAccess().getGroup_5()); 
            // InternalMyDSL.g:981:2: ( rule__StateMachine__Group_5__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDSL.g:981:3: rule__StateMachine__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__StateMachine__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStateMachineAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__5__Impl"


    // $ANTLR start "rule__StateMachine__Group__6"
    // InternalMyDSL.g:989:1: rule__StateMachine__Group__6 : rule__StateMachine__Group__6__Impl rule__StateMachine__Group__7 ;
    public final void rule__StateMachine__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:993:1: ( rule__StateMachine__Group__6__Impl rule__StateMachine__Group__7 )
            // InternalMyDSL.g:994:2: rule__StateMachine__Group__6__Impl rule__StateMachine__Group__7
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__6"


    // $ANTLR start "rule__StateMachine__Group__6__Impl"
    // InternalMyDSL.g:1001:1: rule__StateMachine__Group__6__Impl : ( ( rule__StateMachine__Group_6__0 )? ) ;
    public final void rule__StateMachine__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1005:1: ( ( ( rule__StateMachine__Group_6__0 )? ) )
            // InternalMyDSL.g:1006:1: ( ( rule__StateMachine__Group_6__0 )? )
            {
            // InternalMyDSL.g:1006:1: ( ( rule__StateMachine__Group_6__0 )? )
            // InternalMyDSL.g:1007:2: ( rule__StateMachine__Group_6__0 )?
            {
             before(grammarAccess.getStateMachineAccess().getGroup_6()); 
            // InternalMyDSL.g:1008:2: ( rule__StateMachine__Group_6__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDSL.g:1008:3: rule__StateMachine__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__StateMachine__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStateMachineAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__6__Impl"


    // $ANTLR start "rule__StateMachine__Group__7"
    // InternalMyDSL.g:1016:1: rule__StateMachine__Group__7 : rule__StateMachine__Group__7__Impl ;
    public final void rule__StateMachine__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1020:1: ( rule__StateMachine__Group__7__Impl )
            // InternalMyDSL.g:1021:2: rule__StateMachine__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__7"


    // $ANTLR start "rule__StateMachine__Group__7__Impl"
    // InternalMyDSL.g:1027:1: rule__StateMachine__Group__7__Impl : ( '}' ) ;
    public final void rule__StateMachine__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1031:1: ( ( '}' ) )
            // InternalMyDSL.g:1032:1: ( '}' )
            {
            // InternalMyDSL.g:1032:1: ( '}' )
            // InternalMyDSL.g:1033:2: '}'
            {
             before(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_7()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__7__Impl"


    // $ANTLR start "rule__StateMachine__Group_4__0"
    // InternalMyDSL.g:1043:1: rule__StateMachine__Group_4__0 : rule__StateMachine__Group_4__0__Impl rule__StateMachine__Group_4__1 ;
    public final void rule__StateMachine__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1047:1: ( rule__StateMachine__Group_4__0__Impl rule__StateMachine__Group_4__1 )
            // InternalMyDSL.g:1048:2: rule__StateMachine__Group_4__0__Impl rule__StateMachine__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__StateMachine__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__0"


    // $ANTLR start "rule__StateMachine__Group_4__0__Impl"
    // InternalMyDSL.g:1055:1: rule__StateMachine__Group_4__0__Impl : ( 'initialState' ) ;
    public final void rule__StateMachine__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1059:1: ( ( 'initialState' ) )
            // InternalMyDSL.g:1060:1: ( 'initialState' )
            {
            // InternalMyDSL.g:1060:1: ( 'initialState' )
            // InternalMyDSL.g:1061:2: 'initialState'
            {
             before(grammarAccess.getStateMachineAccess().getInitialStateKeyword_4_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getInitialStateKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_4__1"
    // InternalMyDSL.g:1070:1: rule__StateMachine__Group_4__1 : rule__StateMachine__Group_4__1__Impl ;
    public final void rule__StateMachine__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1074:1: ( rule__StateMachine__Group_4__1__Impl )
            // InternalMyDSL.g:1075:2: rule__StateMachine__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__1"


    // $ANTLR start "rule__StateMachine__Group_4__1__Impl"
    // InternalMyDSL.g:1081:1: rule__StateMachine__Group_4__1__Impl : ( ( rule__StateMachine__InitialStateAssignment_4_1 ) ) ;
    public final void rule__StateMachine__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1085:1: ( ( ( rule__StateMachine__InitialStateAssignment_4_1 ) ) )
            // InternalMyDSL.g:1086:1: ( ( rule__StateMachine__InitialStateAssignment_4_1 ) )
            {
            // InternalMyDSL.g:1086:1: ( ( rule__StateMachine__InitialStateAssignment_4_1 ) )
            // InternalMyDSL.g:1087:2: ( rule__StateMachine__InitialStateAssignment_4_1 )
            {
             before(grammarAccess.getStateMachineAccess().getInitialStateAssignment_4_1()); 
            // InternalMyDSL.g:1088:2: ( rule__StateMachine__InitialStateAssignment_4_1 )
            // InternalMyDSL.g:1088:3: rule__StateMachine__InitialStateAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__InitialStateAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getInitialStateAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__0"
    // InternalMyDSL.g:1097:1: rule__StateMachine__Group_5__0 : rule__StateMachine__Group_5__0__Impl rule__StateMachine__Group_5__1 ;
    public final void rule__StateMachine__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1101:1: ( rule__StateMachine__Group_5__0__Impl rule__StateMachine__Group_5__1 )
            // InternalMyDSL.g:1102:2: rule__StateMachine__Group_5__0__Impl rule__StateMachine__Group_5__1
            {
            pushFollow(FOLLOW_5);
            rule__StateMachine__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__0"


    // $ANTLR start "rule__StateMachine__Group_5__0__Impl"
    // InternalMyDSL.g:1109:1: rule__StateMachine__Group_5__0__Impl : ( 'state' ) ;
    public final void rule__StateMachine__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1113:1: ( ( 'state' ) )
            // InternalMyDSL.g:1114:1: ( 'state' )
            {
            // InternalMyDSL.g:1114:1: ( 'state' )
            // InternalMyDSL.g:1115:2: 'state'
            {
             before(grammarAccess.getStateMachineAccess().getStateKeyword_5_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getStateKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__1"
    // InternalMyDSL.g:1124:1: rule__StateMachine__Group_5__1 : rule__StateMachine__Group_5__1__Impl rule__StateMachine__Group_5__2 ;
    public final void rule__StateMachine__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1128:1: ( rule__StateMachine__Group_5__1__Impl rule__StateMachine__Group_5__2 )
            // InternalMyDSL.g:1129:2: rule__StateMachine__Group_5__1__Impl rule__StateMachine__Group_5__2
            {
            pushFollow(FOLLOW_12);
            rule__StateMachine__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__1"


    // $ANTLR start "rule__StateMachine__Group_5__1__Impl"
    // InternalMyDSL.g:1136:1: rule__StateMachine__Group_5__1__Impl : ( '{' ) ;
    public final void rule__StateMachine__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1140:1: ( ( '{' ) )
            // InternalMyDSL.g:1141:1: ( '{' )
            {
            // InternalMyDSL.g:1141:1: ( '{' )
            // InternalMyDSL.g:1142:2: '{'
            {
             before(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__2"
    // InternalMyDSL.g:1151:1: rule__StateMachine__Group_5__2 : rule__StateMachine__Group_5__2__Impl rule__StateMachine__Group_5__3 ;
    public final void rule__StateMachine__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1155:1: ( rule__StateMachine__Group_5__2__Impl rule__StateMachine__Group_5__3 )
            // InternalMyDSL.g:1156:2: rule__StateMachine__Group_5__2__Impl rule__StateMachine__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__2"


    // $ANTLR start "rule__StateMachine__Group_5__2__Impl"
    // InternalMyDSL.g:1163:1: rule__StateMachine__Group_5__2__Impl : ( ( rule__StateMachine__StateAssignment_5_2 ) ) ;
    public final void rule__StateMachine__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1167:1: ( ( ( rule__StateMachine__StateAssignment_5_2 ) ) )
            // InternalMyDSL.g:1168:1: ( ( rule__StateMachine__StateAssignment_5_2 ) )
            {
            // InternalMyDSL.g:1168:1: ( ( rule__StateMachine__StateAssignment_5_2 ) )
            // InternalMyDSL.g:1169:2: ( rule__StateMachine__StateAssignment_5_2 )
            {
             before(grammarAccess.getStateMachineAccess().getStateAssignment_5_2()); 
            // InternalMyDSL.g:1170:2: ( rule__StateMachine__StateAssignment_5_2 )
            // InternalMyDSL.g:1170:3: rule__StateMachine__StateAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__StateAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getStateAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__2__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__3"
    // InternalMyDSL.g:1178:1: rule__StateMachine__Group_5__3 : rule__StateMachine__Group_5__3__Impl rule__StateMachine__Group_5__4 ;
    public final void rule__StateMachine__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1182:1: ( rule__StateMachine__Group_5__3__Impl rule__StateMachine__Group_5__4 )
            // InternalMyDSL.g:1183:2: rule__StateMachine__Group_5__3__Impl rule__StateMachine__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__3"


    // $ANTLR start "rule__StateMachine__Group_5__3__Impl"
    // InternalMyDSL.g:1190:1: rule__StateMachine__Group_5__3__Impl : ( ( rule__StateMachine__Group_5_3__0 )* ) ;
    public final void rule__StateMachine__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1194:1: ( ( ( rule__StateMachine__Group_5_3__0 )* ) )
            // InternalMyDSL.g:1195:1: ( ( rule__StateMachine__Group_5_3__0 )* )
            {
            // InternalMyDSL.g:1195:1: ( ( rule__StateMachine__Group_5_3__0 )* )
            // InternalMyDSL.g:1196:2: ( rule__StateMachine__Group_5_3__0 )*
            {
             before(grammarAccess.getStateMachineAccess().getGroup_5_3()); 
            // InternalMyDSL.g:1197:2: ( rule__StateMachine__Group_5_3__0 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==17) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalMyDSL.g:1197:3: rule__StateMachine__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__StateMachine__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getStateMachineAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__3__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__4"
    // InternalMyDSL.g:1205:1: rule__StateMachine__Group_5__4 : rule__StateMachine__Group_5__4__Impl ;
    public final void rule__StateMachine__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1209:1: ( rule__StateMachine__Group_5__4__Impl )
            // InternalMyDSL.g:1210:2: rule__StateMachine__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__4"


    // $ANTLR start "rule__StateMachine__Group_5__4__Impl"
    // InternalMyDSL.g:1216:1: rule__StateMachine__Group_5__4__Impl : ( '}' ) ;
    public final void rule__StateMachine__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1220:1: ( ( '}' ) )
            // InternalMyDSL.g:1221:1: ( '}' )
            {
            // InternalMyDSL.g:1221:1: ( '}' )
            // InternalMyDSL.g:1222:2: '}'
            {
             before(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__4__Impl"


    // $ANTLR start "rule__StateMachine__Group_5_3__0"
    // InternalMyDSL.g:1232:1: rule__StateMachine__Group_5_3__0 : rule__StateMachine__Group_5_3__0__Impl rule__StateMachine__Group_5_3__1 ;
    public final void rule__StateMachine__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1236:1: ( rule__StateMachine__Group_5_3__0__Impl rule__StateMachine__Group_5_3__1 )
            // InternalMyDSL.g:1237:2: rule__StateMachine__Group_5_3__0__Impl rule__StateMachine__Group_5_3__1
            {
            pushFollow(FOLLOW_12);
            rule__StateMachine__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__0"


    // $ANTLR start "rule__StateMachine__Group_5_3__0__Impl"
    // InternalMyDSL.g:1244:1: rule__StateMachine__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__StateMachine__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1248:1: ( ( ',' ) )
            // InternalMyDSL.g:1249:1: ( ',' )
            {
            // InternalMyDSL.g:1249:1: ( ',' )
            // InternalMyDSL.g:1250:2: ','
            {
             before(grammarAccess.getStateMachineAccess().getCommaKeyword_5_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_5_3__1"
    // InternalMyDSL.g:1259:1: rule__StateMachine__Group_5_3__1 : rule__StateMachine__Group_5_3__1__Impl ;
    public final void rule__StateMachine__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1263:1: ( rule__StateMachine__Group_5_3__1__Impl )
            // InternalMyDSL.g:1264:2: rule__StateMachine__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__1"


    // $ANTLR start "rule__StateMachine__Group_5_3__1__Impl"
    // InternalMyDSL.g:1270:1: rule__StateMachine__Group_5_3__1__Impl : ( ( rule__StateMachine__StateAssignment_5_3_1 ) ) ;
    public final void rule__StateMachine__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1274:1: ( ( ( rule__StateMachine__StateAssignment_5_3_1 ) ) )
            // InternalMyDSL.g:1275:1: ( ( rule__StateMachine__StateAssignment_5_3_1 ) )
            {
            // InternalMyDSL.g:1275:1: ( ( rule__StateMachine__StateAssignment_5_3_1 ) )
            // InternalMyDSL.g:1276:2: ( rule__StateMachine__StateAssignment_5_3_1 )
            {
             before(grammarAccess.getStateMachineAccess().getStateAssignment_5_3_1()); 
            // InternalMyDSL.g:1277:2: ( rule__StateMachine__StateAssignment_5_3_1 )
            // InternalMyDSL.g:1277:3: rule__StateMachine__StateAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__StateAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getStateAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__0"
    // InternalMyDSL.g:1286:1: rule__StateMachine__Group_6__0 : rule__StateMachine__Group_6__0__Impl rule__StateMachine__Group_6__1 ;
    public final void rule__StateMachine__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1290:1: ( rule__StateMachine__Group_6__0__Impl rule__StateMachine__Group_6__1 )
            // InternalMyDSL.g:1291:2: rule__StateMachine__Group_6__0__Impl rule__StateMachine__Group_6__1
            {
            pushFollow(FOLLOW_5);
            rule__StateMachine__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__0"


    // $ANTLR start "rule__StateMachine__Group_6__0__Impl"
    // InternalMyDSL.g:1298:1: rule__StateMachine__Group_6__0__Impl : ( 'transition' ) ;
    public final void rule__StateMachine__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1302:1: ( ( 'transition' ) )
            // InternalMyDSL.g:1303:1: ( 'transition' )
            {
            // InternalMyDSL.g:1303:1: ( 'transition' )
            // InternalMyDSL.g:1304:2: 'transition'
            {
             before(grammarAccess.getStateMachineAccess().getTransitionKeyword_6_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getTransitionKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__1"
    // InternalMyDSL.g:1313:1: rule__StateMachine__Group_6__1 : rule__StateMachine__Group_6__1__Impl rule__StateMachine__Group_6__2 ;
    public final void rule__StateMachine__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1317:1: ( rule__StateMachine__Group_6__1__Impl rule__StateMachine__Group_6__2 )
            // InternalMyDSL.g:1318:2: rule__StateMachine__Group_6__1__Impl rule__StateMachine__Group_6__2
            {
            pushFollow(FOLLOW_13);
            rule__StateMachine__Group_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__1"


    // $ANTLR start "rule__StateMachine__Group_6__1__Impl"
    // InternalMyDSL.g:1325:1: rule__StateMachine__Group_6__1__Impl : ( '{' ) ;
    public final void rule__StateMachine__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1329:1: ( ( '{' ) )
            // InternalMyDSL.g:1330:1: ( '{' )
            {
            // InternalMyDSL.g:1330:1: ( '{' )
            // InternalMyDSL.g:1331:2: '{'
            {
             before(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_6_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__2"
    // InternalMyDSL.g:1340:1: rule__StateMachine__Group_6__2 : rule__StateMachine__Group_6__2__Impl rule__StateMachine__Group_6__3 ;
    public final void rule__StateMachine__Group_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1344:1: ( rule__StateMachine__Group_6__2__Impl rule__StateMachine__Group_6__3 )
            // InternalMyDSL.g:1345:2: rule__StateMachine__Group_6__2__Impl rule__StateMachine__Group_6__3
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__2"


    // $ANTLR start "rule__StateMachine__Group_6__2__Impl"
    // InternalMyDSL.g:1352:1: rule__StateMachine__Group_6__2__Impl : ( ( rule__StateMachine__TransitionAssignment_6_2 ) ) ;
    public final void rule__StateMachine__Group_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1356:1: ( ( ( rule__StateMachine__TransitionAssignment_6_2 ) ) )
            // InternalMyDSL.g:1357:1: ( ( rule__StateMachine__TransitionAssignment_6_2 ) )
            {
            // InternalMyDSL.g:1357:1: ( ( rule__StateMachine__TransitionAssignment_6_2 ) )
            // InternalMyDSL.g:1358:2: ( rule__StateMachine__TransitionAssignment_6_2 )
            {
             before(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_2()); 
            // InternalMyDSL.g:1359:2: ( rule__StateMachine__TransitionAssignment_6_2 )
            // InternalMyDSL.g:1359:3: rule__StateMachine__TransitionAssignment_6_2
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__TransitionAssignment_6_2();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__2__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__3"
    // InternalMyDSL.g:1367:1: rule__StateMachine__Group_6__3 : rule__StateMachine__Group_6__3__Impl rule__StateMachine__Group_6__4 ;
    public final void rule__StateMachine__Group_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1371:1: ( rule__StateMachine__Group_6__3__Impl rule__StateMachine__Group_6__4 )
            // InternalMyDSL.g:1372:2: rule__StateMachine__Group_6__3__Impl rule__StateMachine__Group_6__4
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_6__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__3"


    // $ANTLR start "rule__StateMachine__Group_6__3__Impl"
    // InternalMyDSL.g:1379:1: rule__StateMachine__Group_6__3__Impl : ( ( rule__StateMachine__Group_6_3__0 )* ) ;
    public final void rule__StateMachine__Group_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1383:1: ( ( ( rule__StateMachine__Group_6_3__0 )* ) )
            // InternalMyDSL.g:1384:1: ( ( rule__StateMachine__Group_6_3__0 )* )
            {
            // InternalMyDSL.g:1384:1: ( ( rule__StateMachine__Group_6_3__0 )* )
            // InternalMyDSL.g:1385:2: ( rule__StateMachine__Group_6_3__0 )*
            {
             before(grammarAccess.getStateMachineAccess().getGroup_6_3()); 
            // InternalMyDSL.g:1386:2: ( rule__StateMachine__Group_6_3__0 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==17) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalMyDSL.g:1386:3: rule__StateMachine__Group_6_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__StateMachine__Group_6_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getStateMachineAccess().getGroup_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__3__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__4"
    // InternalMyDSL.g:1394:1: rule__StateMachine__Group_6__4 : rule__StateMachine__Group_6__4__Impl ;
    public final void rule__StateMachine__Group_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1398:1: ( rule__StateMachine__Group_6__4__Impl )
            // InternalMyDSL.g:1399:2: rule__StateMachine__Group_6__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__4"


    // $ANTLR start "rule__StateMachine__Group_6__4__Impl"
    // InternalMyDSL.g:1405:1: rule__StateMachine__Group_6__4__Impl : ( '}' ) ;
    public final void rule__StateMachine__Group_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1409:1: ( ( '}' ) )
            // InternalMyDSL.g:1410:1: ( '}' )
            {
            // InternalMyDSL.g:1410:1: ( '}' )
            // InternalMyDSL.g:1411:2: '}'
            {
             before(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_6_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_6_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__4__Impl"


    // $ANTLR start "rule__StateMachine__Group_6_3__0"
    // InternalMyDSL.g:1421:1: rule__StateMachine__Group_6_3__0 : rule__StateMachine__Group_6_3__0__Impl rule__StateMachine__Group_6_3__1 ;
    public final void rule__StateMachine__Group_6_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1425:1: ( rule__StateMachine__Group_6_3__0__Impl rule__StateMachine__Group_6_3__1 )
            // InternalMyDSL.g:1426:2: rule__StateMachine__Group_6_3__0__Impl rule__StateMachine__Group_6_3__1
            {
            pushFollow(FOLLOW_13);
            rule__StateMachine__Group_6_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__0"


    // $ANTLR start "rule__StateMachine__Group_6_3__0__Impl"
    // InternalMyDSL.g:1433:1: rule__StateMachine__Group_6_3__0__Impl : ( ',' ) ;
    public final void rule__StateMachine__Group_6_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1437:1: ( ( ',' ) )
            // InternalMyDSL.g:1438:1: ( ',' )
            {
            // InternalMyDSL.g:1438:1: ( ',' )
            // InternalMyDSL.g:1439:2: ','
            {
             before(grammarAccess.getStateMachineAccess().getCommaKeyword_6_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getCommaKeyword_6_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_6_3__1"
    // InternalMyDSL.g:1448:1: rule__StateMachine__Group_6_3__1 : rule__StateMachine__Group_6_3__1__Impl ;
    public final void rule__StateMachine__Group_6_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1452:1: ( rule__StateMachine__Group_6_3__1__Impl )
            // InternalMyDSL.g:1453:2: rule__StateMachine__Group_6_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__1"


    // $ANTLR start "rule__StateMachine__Group_6_3__1__Impl"
    // InternalMyDSL.g:1459:1: rule__StateMachine__Group_6_3__1__Impl : ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) ) ;
    public final void rule__StateMachine__Group_6_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1463:1: ( ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) ) )
            // InternalMyDSL.g:1464:1: ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) )
            {
            // InternalMyDSL.g:1464:1: ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) )
            // InternalMyDSL.g:1465:2: ( rule__StateMachine__TransitionAssignment_6_3_1 )
            {
             before(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_3_1()); 
            // InternalMyDSL.g:1466:2: ( rule__StateMachine__TransitionAssignment_6_3_1 )
            // InternalMyDSL.g:1466:3: rule__StateMachine__TransitionAssignment_6_3_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__TransitionAssignment_6_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__1__Impl"


    // $ANTLR start "rule__Channel__Group__0"
    // InternalMyDSL.g:1475:1: rule__Channel__Group__0 : rule__Channel__Group__0__Impl rule__Channel__Group__1 ;
    public final void rule__Channel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1479:1: ( rule__Channel__Group__0__Impl rule__Channel__Group__1 )
            // InternalMyDSL.g:1480:2: rule__Channel__Group__0__Impl rule__Channel__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Channel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__0"


    // $ANTLR start "rule__Channel__Group__0__Impl"
    // InternalMyDSL.g:1487:1: rule__Channel__Group__0__Impl : ( () ) ;
    public final void rule__Channel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1491:1: ( ( () ) )
            // InternalMyDSL.g:1492:1: ( () )
            {
            // InternalMyDSL.g:1492:1: ( () )
            // InternalMyDSL.g:1493:2: ()
            {
             before(grammarAccess.getChannelAccess().getChannelAction_0()); 
            // InternalMyDSL.g:1494:2: ()
            // InternalMyDSL.g:1494:3: 
            {
            }

             after(grammarAccess.getChannelAccess().getChannelAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__0__Impl"


    // $ANTLR start "rule__Channel__Group__1"
    // InternalMyDSL.g:1502:1: rule__Channel__Group__1 : rule__Channel__Group__1__Impl rule__Channel__Group__2 ;
    public final void rule__Channel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1506:1: ( rule__Channel__Group__1__Impl rule__Channel__Group__2 )
            // InternalMyDSL.g:1507:2: rule__Channel__Group__1__Impl rule__Channel__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Channel__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__1"


    // $ANTLR start "rule__Channel__Group__1__Impl"
    // InternalMyDSL.g:1514:1: rule__Channel__Group__1__Impl : ( ( rule__Channel__SynchronousAssignment_1 )? ) ;
    public final void rule__Channel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1518:1: ( ( ( rule__Channel__SynchronousAssignment_1 )? ) )
            // InternalMyDSL.g:1519:1: ( ( rule__Channel__SynchronousAssignment_1 )? )
            {
            // InternalMyDSL.g:1519:1: ( ( rule__Channel__SynchronousAssignment_1 )? )
            // InternalMyDSL.g:1520:2: ( rule__Channel__SynchronousAssignment_1 )?
            {
             before(grammarAccess.getChannelAccess().getSynchronousAssignment_1()); 
            // InternalMyDSL.g:1521:2: ( rule__Channel__SynchronousAssignment_1 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==29) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDSL.g:1521:3: rule__Channel__SynchronousAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Channel__SynchronousAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getChannelAccess().getSynchronousAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__1__Impl"


    // $ANTLR start "rule__Channel__Group__2"
    // InternalMyDSL.g:1529:1: rule__Channel__Group__2 : rule__Channel__Group__2__Impl rule__Channel__Group__3 ;
    public final void rule__Channel__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1533:1: ( rule__Channel__Group__2__Impl rule__Channel__Group__3 )
            // InternalMyDSL.g:1534:2: rule__Channel__Group__2__Impl rule__Channel__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Channel__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__2"


    // $ANTLR start "rule__Channel__Group__2__Impl"
    // InternalMyDSL.g:1541:1: rule__Channel__Group__2__Impl : ( 'Channel' ) ;
    public final void rule__Channel__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1545:1: ( ( 'Channel' ) )
            // InternalMyDSL.g:1546:1: ( 'Channel' )
            {
            // InternalMyDSL.g:1546:1: ( 'Channel' )
            // InternalMyDSL.g:1547:2: 'Channel'
            {
             before(grammarAccess.getChannelAccess().getChannelKeyword_2()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getChannelAccess().getChannelKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__2__Impl"


    // $ANTLR start "rule__Channel__Group__3"
    // InternalMyDSL.g:1556:1: rule__Channel__Group__3 : rule__Channel__Group__3__Impl ;
    public final void rule__Channel__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1560:1: ( rule__Channel__Group__3__Impl )
            // InternalMyDSL.g:1561:2: rule__Channel__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Channel__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__3"


    // $ANTLR start "rule__Channel__Group__3__Impl"
    // InternalMyDSL.g:1567:1: rule__Channel__Group__3__Impl : ( ( rule__Channel__NameAssignment_3 ) ) ;
    public final void rule__Channel__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1571:1: ( ( ( rule__Channel__NameAssignment_3 ) ) )
            // InternalMyDSL.g:1572:1: ( ( rule__Channel__NameAssignment_3 ) )
            {
            // InternalMyDSL.g:1572:1: ( ( rule__Channel__NameAssignment_3 ) )
            // InternalMyDSL.g:1573:2: ( rule__Channel__NameAssignment_3 )
            {
             before(grammarAccess.getChannelAccess().getNameAssignment_3()); 
            // InternalMyDSL.g:1574:2: ( rule__Channel__NameAssignment_3 )
            // InternalMyDSL.g:1574:3: rule__Channel__NameAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Channel__NameAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getChannelAccess().getNameAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__3__Impl"


    // $ANTLR start "rule__State__Group__0"
    // InternalMyDSL.g:1583:1: rule__State__Group__0 : rule__State__Group__0__Impl rule__State__Group__1 ;
    public final void rule__State__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1587:1: ( rule__State__Group__0__Impl rule__State__Group__1 )
            // InternalMyDSL.g:1588:2: rule__State__Group__0__Impl rule__State__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__State__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0"


    // $ANTLR start "rule__State__Group__0__Impl"
    // InternalMyDSL.g:1595:1: rule__State__Group__0__Impl : ( () ) ;
    public final void rule__State__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1599:1: ( ( () ) )
            // InternalMyDSL.g:1600:1: ( () )
            {
            // InternalMyDSL.g:1600:1: ( () )
            // InternalMyDSL.g:1601:2: ()
            {
             before(grammarAccess.getStateAccess().getStateAction_0()); 
            // InternalMyDSL.g:1602:2: ()
            // InternalMyDSL.g:1602:3: 
            {
            }

             after(grammarAccess.getStateAccess().getStateAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0__Impl"


    // $ANTLR start "rule__State__Group__1"
    // InternalMyDSL.g:1610:1: rule__State__Group__1 : rule__State__Group__1__Impl rule__State__Group__2 ;
    public final void rule__State__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1614:1: ( rule__State__Group__1__Impl rule__State__Group__2 )
            // InternalMyDSL.g:1615:2: rule__State__Group__1__Impl rule__State__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__State__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1"


    // $ANTLR start "rule__State__Group__1__Impl"
    // InternalMyDSL.g:1622:1: rule__State__Group__1__Impl : ( 'State' ) ;
    public final void rule__State__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1626:1: ( ( 'State' ) )
            // InternalMyDSL.g:1627:1: ( 'State' )
            {
            // InternalMyDSL.g:1627:1: ( 'State' )
            // InternalMyDSL.g:1628:2: 'State'
            {
             before(grammarAccess.getStateAccess().getStateKeyword_1()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getStateKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1__Impl"


    // $ANTLR start "rule__State__Group__2"
    // InternalMyDSL.g:1637:1: rule__State__Group__2 : rule__State__Group__2__Impl ;
    public final void rule__State__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1641:1: ( rule__State__Group__2__Impl )
            // InternalMyDSL.g:1642:2: rule__State__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2"


    // $ANTLR start "rule__State__Group__2__Impl"
    // InternalMyDSL.g:1648:1: rule__State__Group__2__Impl : ( ( rule__State__NameAssignment_2 ) ) ;
    public final void rule__State__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1652:1: ( ( ( rule__State__NameAssignment_2 ) ) )
            // InternalMyDSL.g:1653:1: ( ( rule__State__NameAssignment_2 ) )
            {
            // InternalMyDSL.g:1653:1: ( ( rule__State__NameAssignment_2 ) )
            // InternalMyDSL.g:1654:2: ( rule__State__NameAssignment_2 )
            {
             before(grammarAccess.getStateAccess().getNameAssignment_2()); 
            // InternalMyDSL.g:1655:2: ( rule__State__NameAssignment_2 )
            // InternalMyDSL.g:1655:3: rule__State__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__State__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__0"
    // InternalMyDSL.g:1664:1: rule__Transition__Group__0 : rule__Transition__Group__0__Impl rule__Transition__Group__1 ;
    public final void rule__Transition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1668:1: ( rule__Transition__Group__0__Impl rule__Transition__Group__1 )
            // InternalMyDSL.g:1669:2: rule__Transition__Group__0__Impl rule__Transition__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__Transition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0"


    // $ANTLR start "rule__Transition__Group__0__Impl"
    // InternalMyDSL.g:1676:1: rule__Transition__Group__0__Impl : ( () ) ;
    public final void rule__Transition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1680:1: ( ( () ) )
            // InternalMyDSL.g:1681:1: ( () )
            {
            // InternalMyDSL.g:1681:1: ( () )
            // InternalMyDSL.g:1682:2: ()
            {
             before(grammarAccess.getTransitionAccess().getTransitionAction_0()); 
            // InternalMyDSL.g:1683:2: ()
            // InternalMyDSL.g:1683:3: 
            {
            }

             after(grammarAccess.getTransitionAccess().getTransitionAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0__Impl"


    // $ANTLR start "rule__Transition__Group__1"
    // InternalMyDSL.g:1691:1: rule__Transition__Group__1 : rule__Transition__Group__1__Impl rule__Transition__Group__2 ;
    public final void rule__Transition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1695:1: ( rule__Transition__Group__1__Impl rule__Transition__Group__2 )
            // InternalMyDSL.g:1696:2: rule__Transition__Group__1__Impl rule__Transition__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Transition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1"


    // $ANTLR start "rule__Transition__Group__1__Impl"
    // InternalMyDSL.g:1703:1: rule__Transition__Group__1__Impl : ( 'Transition' ) ;
    public final void rule__Transition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1707:1: ( ( 'Transition' ) )
            // InternalMyDSL.g:1708:1: ( 'Transition' )
            {
            // InternalMyDSL.g:1708:1: ( 'Transition' )
            // InternalMyDSL.g:1709:2: 'Transition'
            {
             before(grammarAccess.getTransitionAccess().getTransitionKeyword_1()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTransitionKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1__Impl"


    // $ANTLR start "rule__Transition__Group__2"
    // InternalMyDSL.g:1718:1: rule__Transition__Group__2 : rule__Transition__Group__2__Impl rule__Transition__Group__3 ;
    public final void rule__Transition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1722:1: ( rule__Transition__Group__2__Impl rule__Transition__Group__3 )
            // InternalMyDSL.g:1723:2: rule__Transition__Group__2__Impl rule__Transition__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__Transition__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2"


    // $ANTLR start "rule__Transition__Group__2__Impl"
    // InternalMyDSL.g:1730:1: rule__Transition__Group__2__Impl : ( '{' ) ;
    public final void rule__Transition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1734:1: ( ( '{' ) )
            // InternalMyDSL.g:1735:1: ( '{' )
            {
            // InternalMyDSL.g:1735:1: ( '{' )
            // InternalMyDSL.g:1736:2: '{'
            {
             before(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__3"
    // InternalMyDSL.g:1745:1: rule__Transition__Group__3 : rule__Transition__Group__3__Impl rule__Transition__Group__4 ;
    public final void rule__Transition__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1749:1: ( rule__Transition__Group__3__Impl rule__Transition__Group__4 )
            // InternalMyDSL.g:1750:2: rule__Transition__Group__3__Impl rule__Transition__Group__4
            {
            pushFollow(FOLLOW_14);
            rule__Transition__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3"


    // $ANTLR start "rule__Transition__Group__3__Impl"
    // InternalMyDSL.g:1757:1: rule__Transition__Group__3__Impl : ( ( rule__Transition__Group_3__0 )? ) ;
    public final void rule__Transition__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1761:1: ( ( ( rule__Transition__Group_3__0 )? ) )
            // InternalMyDSL.g:1762:1: ( ( rule__Transition__Group_3__0 )? )
            {
            // InternalMyDSL.g:1762:1: ( ( rule__Transition__Group_3__0 )? )
            // InternalMyDSL.g:1763:2: ( rule__Transition__Group_3__0 )?
            {
             before(grammarAccess.getTransitionAccess().getGroup_3()); 
            // InternalMyDSL.g:1764:2: ( rule__Transition__Group_3__0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==26) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDSL.g:1764:3: rule__Transition__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Transition__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTransitionAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3__Impl"


    // $ANTLR start "rule__Transition__Group__4"
    // InternalMyDSL.g:1772:1: rule__Transition__Group__4 : rule__Transition__Group__4__Impl rule__Transition__Group__5 ;
    public final void rule__Transition__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1776:1: ( rule__Transition__Group__4__Impl rule__Transition__Group__5 )
            // InternalMyDSL.g:1777:2: rule__Transition__Group__4__Impl rule__Transition__Group__5
            {
            pushFollow(FOLLOW_14);
            rule__Transition__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4"


    // $ANTLR start "rule__Transition__Group__4__Impl"
    // InternalMyDSL.g:1784:1: rule__Transition__Group__4__Impl : ( ( rule__Transition__Group_4__0 )? ) ;
    public final void rule__Transition__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1788:1: ( ( ( rule__Transition__Group_4__0 )? ) )
            // InternalMyDSL.g:1789:1: ( ( rule__Transition__Group_4__0 )? )
            {
            // InternalMyDSL.g:1789:1: ( ( rule__Transition__Group_4__0 )? )
            // InternalMyDSL.g:1790:2: ( rule__Transition__Group_4__0 )?
            {
             before(grammarAccess.getTransitionAccess().getGroup_4()); 
            // InternalMyDSL.g:1791:2: ( rule__Transition__Group_4__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==27) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDSL.g:1791:3: rule__Transition__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Transition__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTransitionAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4__Impl"


    // $ANTLR start "rule__Transition__Group__5"
    // InternalMyDSL.g:1799:1: rule__Transition__Group__5 : rule__Transition__Group__5__Impl rule__Transition__Group__6 ;
    public final void rule__Transition__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1803:1: ( rule__Transition__Group__5__Impl rule__Transition__Group__6 )
            // InternalMyDSL.g:1804:2: rule__Transition__Group__5__Impl rule__Transition__Group__6
            {
            pushFollow(FOLLOW_14);
            rule__Transition__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5"


    // $ANTLR start "rule__Transition__Group__5__Impl"
    // InternalMyDSL.g:1811:1: rule__Transition__Group__5__Impl : ( ( rule__Transition__Group_5__0 )? ) ;
    public final void rule__Transition__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1815:1: ( ( ( rule__Transition__Group_5__0 )? ) )
            // InternalMyDSL.g:1816:1: ( ( rule__Transition__Group_5__0 )? )
            {
            // InternalMyDSL.g:1816:1: ( ( rule__Transition__Group_5__0 )? )
            // InternalMyDSL.g:1817:2: ( rule__Transition__Group_5__0 )?
            {
             before(grammarAccess.getTransitionAccess().getGroup_5()); 
            // InternalMyDSL.g:1818:2: ( rule__Transition__Group_5__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==28) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDSL.g:1818:3: rule__Transition__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Transition__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTransitionAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5__Impl"


    // $ANTLR start "rule__Transition__Group__6"
    // InternalMyDSL.g:1826:1: rule__Transition__Group__6 : rule__Transition__Group__6__Impl rule__Transition__Group__7 ;
    public final void rule__Transition__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1830:1: ( rule__Transition__Group__6__Impl rule__Transition__Group__7 )
            // InternalMyDSL.g:1831:2: rule__Transition__Group__6__Impl rule__Transition__Group__7
            {
            pushFollow(FOLLOW_14);
            rule__Transition__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6"


    // $ANTLR start "rule__Transition__Group__6__Impl"
    // InternalMyDSL.g:1838:1: rule__Transition__Group__6__Impl : ( ( rule__Transition__Group_6__0 )? ) ;
    public final void rule__Transition__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1842:1: ( ( ( rule__Transition__Group_6__0 )? ) )
            // InternalMyDSL.g:1843:1: ( ( rule__Transition__Group_6__0 )? )
            {
            // InternalMyDSL.g:1843:1: ( ( rule__Transition__Group_6__0 )? )
            // InternalMyDSL.g:1844:2: ( rule__Transition__Group_6__0 )?
            {
             before(grammarAccess.getTransitionAccess().getGroup_6()); 
            // InternalMyDSL.g:1845:2: ( rule__Transition__Group_6__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==18) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDSL.g:1845:3: rule__Transition__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Transition__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTransitionAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6__Impl"


    // $ANTLR start "rule__Transition__Group__7"
    // InternalMyDSL.g:1853:1: rule__Transition__Group__7 : rule__Transition__Group__7__Impl ;
    public final void rule__Transition__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1857:1: ( rule__Transition__Group__7__Impl )
            // InternalMyDSL.g:1858:2: rule__Transition__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7"


    // $ANTLR start "rule__Transition__Group__7__Impl"
    // InternalMyDSL.g:1864:1: rule__Transition__Group__7__Impl : ( '}' ) ;
    public final void rule__Transition__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1868:1: ( ( '}' ) )
            // InternalMyDSL.g:1869:1: ( '}' )
            {
            // InternalMyDSL.g:1869:1: ( '}' )
            // InternalMyDSL.g:1870:2: '}'
            {
             before(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_7()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7__Impl"


    // $ANTLR start "rule__Transition__Group_3__0"
    // InternalMyDSL.g:1880:1: rule__Transition__Group_3__0 : rule__Transition__Group_3__0__Impl rule__Transition__Group_3__1 ;
    public final void rule__Transition__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1884:1: ( rule__Transition__Group_3__0__Impl rule__Transition__Group_3__1 )
            // InternalMyDSL.g:1885:2: rule__Transition__Group_3__0__Impl rule__Transition__Group_3__1
            {
            pushFollow(FOLLOW_15);
            rule__Transition__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_3__0"


    // $ANTLR start "rule__Transition__Group_3__0__Impl"
    // InternalMyDSL.g:1892:1: rule__Transition__Group_3__0__Impl : ( 'sendReceive' ) ;
    public final void rule__Transition__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1896:1: ( ( 'sendReceive' ) )
            // InternalMyDSL.g:1897:1: ( 'sendReceive' )
            {
            // InternalMyDSL.g:1897:1: ( 'sendReceive' )
            // InternalMyDSL.g:1898:2: 'sendReceive'
            {
             before(grammarAccess.getTransitionAccess().getSendReceiveKeyword_3_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getSendReceiveKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_3__0__Impl"


    // $ANTLR start "rule__Transition__Group_3__1"
    // InternalMyDSL.g:1907:1: rule__Transition__Group_3__1 : rule__Transition__Group_3__1__Impl ;
    public final void rule__Transition__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1911:1: ( rule__Transition__Group_3__1__Impl )
            // InternalMyDSL.g:1912:2: rule__Transition__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_3__1"


    // $ANTLR start "rule__Transition__Group_3__1__Impl"
    // InternalMyDSL.g:1918:1: rule__Transition__Group_3__1__Impl : ( ( rule__Transition__SendReceiveAssignment_3_1 ) ) ;
    public final void rule__Transition__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1922:1: ( ( ( rule__Transition__SendReceiveAssignment_3_1 ) ) )
            // InternalMyDSL.g:1923:1: ( ( rule__Transition__SendReceiveAssignment_3_1 ) )
            {
            // InternalMyDSL.g:1923:1: ( ( rule__Transition__SendReceiveAssignment_3_1 ) )
            // InternalMyDSL.g:1924:2: ( rule__Transition__SendReceiveAssignment_3_1 )
            {
             before(grammarAccess.getTransitionAccess().getSendReceiveAssignment_3_1()); 
            // InternalMyDSL.g:1925:2: ( rule__Transition__SendReceiveAssignment_3_1 )
            // InternalMyDSL.g:1925:3: rule__Transition__SendReceiveAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__SendReceiveAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getSendReceiveAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_3__1__Impl"


    // $ANTLR start "rule__Transition__Group_4__0"
    // InternalMyDSL.g:1934:1: rule__Transition__Group_4__0 : rule__Transition__Group_4__0__Impl rule__Transition__Group_4__1 ;
    public final void rule__Transition__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1938:1: ( rule__Transition__Group_4__0__Impl rule__Transition__Group_4__1 )
            // InternalMyDSL.g:1939:2: rule__Transition__Group_4__0__Impl rule__Transition__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_4__0"


    // $ANTLR start "rule__Transition__Group_4__0__Impl"
    // InternalMyDSL.g:1946:1: rule__Transition__Group_4__0__Impl : ( 'source' ) ;
    public final void rule__Transition__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1950:1: ( ( 'source' ) )
            // InternalMyDSL.g:1951:1: ( 'source' )
            {
            // InternalMyDSL.g:1951:1: ( 'source' )
            // InternalMyDSL.g:1952:2: 'source'
            {
             before(grammarAccess.getTransitionAccess().getSourceKeyword_4_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getSourceKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_4__0__Impl"


    // $ANTLR start "rule__Transition__Group_4__1"
    // InternalMyDSL.g:1961:1: rule__Transition__Group_4__1 : rule__Transition__Group_4__1__Impl ;
    public final void rule__Transition__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1965:1: ( rule__Transition__Group_4__1__Impl )
            // InternalMyDSL.g:1966:2: rule__Transition__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_4__1"


    // $ANTLR start "rule__Transition__Group_4__1__Impl"
    // InternalMyDSL.g:1972:1: rule__Transition__Group_4__1__Impl : ( ( rule__Transition__SourceAssignment_4_1 ) ) ;
    public final void rule__Transition__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1976:1: ( ( ( rule__Transition__SourceAssignment_4_1 ) ) )
            // InternalMyDSL.g:1977:1: ( ( rule__Transition__SourceAssignment_4_1 ) )
            {
            // InternalMyDSL.g:1977:1: ( ( rule__Transition__SourceAssignment_4_1 ) )
            // InternalMyDSL.g:1978:2: ( rule__Transition__SourceAssignment_4_1 )
            {
             before(grammarAccess.getTransitionAccess().getSourceAssignment_4_1()); 
            // InternalMyDSL.g:1979:2: ( rule__Transition__SourceAssignment_4_1 )
            // InternalMyDSL.g:1979:3: rule__Transition__SourceAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__SourceAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getSourceAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_4__1__Impl"


    // $ANTLR start "rule__Transition__Group_5__0"
    // InternalMyDSL.g:1988:1: rule__Transition__Group_5__0 : rule__Transition__Group_5__0__Impl rule__Transition__Group_5__1 ;
    public final void rule__Transition__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:1992:1: ( rule__Transition__Group_5__0__Impl rule__Transition__Group_5__1 )
            // InternalMyDSL.g:1993:2: rule__Transition__Group_5__0__Impl rule__Transition__Group_5__1
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_5__0"


    // $ANTLR start "rule__Transition__Group_5__0__Impl"
    // InternalMyDSL.g:2000:1: rule__Transition__Group_5__0__Impl : ( 'target' ) ;
    public final void rule__Transition__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2004:1: ( ( 'target' ) )
            // InternalMyDSL.g:2005:1: ( 'target' )
            {
            // InternalMyDSL.g:2005:1: ( 'target' )
            // InternalMyDSL.g:2006:2: 'target'
            {
             before(grammarAccess.getTransitionAccess().getTargetKeyword_5_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTargetKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_5__0__Impl"


    // $ANTLR start "rule__Transition__Group_5__1"
    // InternalMyDSL.g:2015:1: rule__Transition__Group_5__1 : rule__Transition__Group_5__1__Impl ;
    public final void rule__Transition__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2019:1: ( rule__Transition__Group_5__1__Impl )
            // InternalMyDSL.g:2020:2: rule__Transition__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_5__1"


    // $ANTLR start "rule__Transition__Group_5__1__Impl"
    // InternalMyDSL.g:2026:1: rule__Transition__Group_5__1__Impl : ( ( rule__Transition__TargetAssignment_5_1 ) ) ;
    public final void rule__Transition__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2030:1: ( ( ( rule__Transition__TargetAssignment_5_1 ) ) )
            // InternalMyDSL.g:2031:1: ( ( rule__Transition__TargetAssignment_5_1 ) )
            {
            // InternalMyDSL.g:2031:1: ( ( rule__Transition__TargetAssignment_5_1 ) )
            // InternalMyDSL.g:2032:2: ( rule__Transition__TargetAssignment_5_1 )
            {
             before(grammarAccess.getTransitionAccess().getTargetAssignment_5_1()); 
            // InternalMyDSL.g:2033:2: ( rule__Transition__TargetAssignment_5_1 )
            // InternalMyDSL.g:2033:3: rule__Transition__TargetAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__TargetAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getTargetAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_5__1__Impl"


    // $ANTLR start "rule__Transition__Group_6__0"
    // InternalMyDSL.g:2042:1: rule__Transition__Group_6__0 : rule__Transition__Group_6__0__Impl rule__Transition__Group_6__1 ;
    public final void rule__Transition__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2046:1: ( rule__Transition__Group_6__0__Impl rule__Transition__Group_6__1 )
            // InternalMyDSL.g:2047:2: rule__Transition__Group_6__0__Impl rule__Transition__Group_6__1
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_6__0"


    // $ANTLR start "rule__Transition__Group_6__0__Impl"
    // InternalMyDSL.g:2054:1: rule__Transition__Group_6__0__Impl : ( 'channel' ) ;
    public final void rule__Transition__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2058:1: ( ( 'channel' ) )
            // InternalMyDSL.g:2059:1: ( 'channel' )
            {
            // InternalMyDSL.g:2059:1: ( 'channel' )
            // InternalMyDSL.g:2060:2: 'channel'
            {
             before(grammarAccess.getTransitionAccess().getChannelKeyword_6_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getChannelKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_6__0__Impl"


    // $ANTLR start "rule__Transition__Group_6__1"
    // InternalMyDSL.g:2069:1: rule__Transition__Group_6__1 : rule__Transition__Group_6__1__Impl ;
    public final void rule__Transition__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2073:1: ( rule__Transition__Group_6__1__Impl )
            // InternalMyDSL.g:2074:2: rule__Transition__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_6__1"


    // $ANTLR start "rule__Transition__Group_6__1__Impl"
    // InternalMyDSL.g:2080:1: rule__Transition__Group_6__1__Impl : ( ( rule__Transition__ChannelAssignment_6_1 ) ) ;
    public final void rule__Transition__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2084:1: ( ( ( rule__Transition__ChannelAssignment_6_1 ) ) )
            // InternalMyDSL.g:2085:1: ( ( rule__Transition__ChannelAssignment_6_1 ) )
            {
            // InternalMyDSL.g:2085:1: ( ( rule__Transition__ChannelAssignment_6_1 ) )
            // InternalMyDSL.g:2086:2: ( rule__Transition__ChannelAssignment_6_1 )
            {
             before(grammarAccess.getTransitionAccess().getChannelAssignment_6_1()); 
            // InternalMyDSL.g:2087:2: ( rule__Transition__ChannelAssignment_6_1 )
            // InternalMyDSL.g:2087:3: rule__Transition__ChannelAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__ChannelAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getChannelAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_6__1__Impl"


    // $ANTLR start "rule__Network__NameAssignment_2"
    // InternalMyDSL.g:2096:1: rule__Network__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Network__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2100:1: ( ( ruleEString ) )
            // InternalMyDSL.g:2101:2: ( ruleEString )
            {
            // InternalMyDSL.g:2101:2: ( ruleEString )
            // InternalMyDSL.g:2102:3: ruleEString
            {
             before(grammarAccess.getNetworkAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__NameAssignment_2"


    // $ANTLR start "rule__Network__StateMachineAssignment_4_2"
    // InternalMyDSL.g:2111:1: rule__Network__StateMachineAssignment_4_2 : ( ruleStateMachine ) ;
    public final void rule__Network__StateMachineAssignment_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2115:1: ( ( ruleStateMachine ) )
            // InternalMyDSL.g:2116:2: ( ruleStateMachine )
            {
            // InternalMyDSL.g:2116:2: ( ruleStateMachine )
            // InternalMyDSL.g:2117:3: ruleStateMachine
            {
             before(grammarAccess.getNetworkAccess().getStateMachineStateMachineParserRuleCall_4_2_0()); 
            pushFollow(FOLLOW_2);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getStateMachineStateMachineParserRuleCall_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__StateMachineAssignment_4_2"


    // $ANTLR start "rule__Network__StateMachineAssignment_4_3_1"
    // InternalMyDSL.g:2126:1: rule__Network__StateMachineAssignment_4_3_1 : ( ruleStateMachine ) ;
    public final void rule__Network__StateMachineAssignment_4_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2130:1: ( ( ruleStateMachine ) )
            // InternalMyDSL.g:2131:2: ( ruleStateMachine )
            {
            // InternalMyDSL.g:2131:2: ( ruleStateMachine )
            // InternalMyDSL.g:2132:3: ruleStateMachine
            {
             before(grammarAccess.getNetworkAccess().getStateMachineStateMachineParserRuleCall_4_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getStateMachineStateMachineParserRuleCall_4_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__StateMachineAssignment_4_3_1"


    // $ANTLR start "rule__Network__ChannelAssignment_5_2"
    // InternalMyDSL.g:2141:1: rule__Network__ChannelAssignment_5_2 : ( ruleChannel ) ;
    public final void rule__Network__ChannelAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2145:1: ( ( ruleChannel ) )
            // InternalMyDSL.g:2146:2: ( ruleChannel )
            {
            // InternalMyDSL.g:2146:2: ( ruleChannel )
            // InternalMyDSL.g:2147:3: ruleChannel
            {
             before(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleChannel();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__ChannelAssignment_5_2"


    // $ANTLR start "rule__Network__ChannelAssignment_5_3_1"
    // InternalMyDSL.g:2156:1: rule__Network__ChannelAssignment_5_3_1 : ( ruleChannel ) ;
    public final void rule__Network__ChannelAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2160:1: ( ( ruleChannel ) )
            // InternalMyDSL.g:2161:2: ( ruleChannel )
            {
            // InternalMyDSL.g:2161:2: ( ruleChannel )
            // InternalMyDSL.g:2162:3: ruleChannel
            {
             before(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleChannel();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__ChannelAssignment_5_3_1"


    // $ANTLR start "rule__StateMachine__NameAssignment_2"
    // InternalMyDSL.g:2171:1: rule__StateMachine__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__StateMachine__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2175:1: ( ( ruleEString ) )
            // InternalMyDSL.g:2176:2: ( ruleEString )
            {
            // InternalMyDSL.g:2176:2: ( ruleEString )
            // InternalMyDSL.g:2177:3: ruleEString
            {
             before(grammarAccess.getStateMachineAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__NameAssignment_2"


    // $ANTLR start "rule__StateMachine__InitialStateAssignment_4_1"
    // InternalMyDSL.g:2186:1: rule__StateMachine__InitialStateAssignment_4_1 : ( ( ruleEString ) ) ;
    public final void rule__StateMachine__InitialStateAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2190:1: ( ( ( ruleEString ) ) )
            // InternalMyDSL.g:2191:2: ( ( ruleEString ) )
            {
            // InternalMyDSL.g:2191:2: ( ( ruleEString ) )
            // InternalMyDSL.g:2192:3: ( ruleEString )
            {
             before(grammarAccess.getStateMachineAccess().getInitialStateStateCrossReference_4_1_0()); 
            // InternalMyDSL.g:2193:3: ( ruleEString )
            // InternalMyDSL.g:2194:4: ruleEString
            {
             before(grammarAccess.getStateMachineAccess().getInitialStateStateEStringParserRuleCall_4_1_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getInitialStateStateEStringParserRuleCall_4_1_0_1()); 

            }

             after(grammarAccess.getStateMachineAccess().getInitialStateStateCrossReference_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__InitialStateAssignment_4_1"


    // $ANTLR start "rule__StateMachine__StateAssignment_5_2"
    // InternalMyDSL.g:2205:1: rule__StateMachine__StateAssignment_5_2 : ( ruleState ) ;
    public final void rule__StateMachine__StateAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2209:1: ( ( ruleState ) )
            // InternalMyDSL.g:2210:2: ( ruleState )
            {
            // InternalMyDSL.g:2210:2: ( ruleState )
            // InternalMyDSL.g:2211:3: ruleState
            {
             before(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__StateAssignment_5_2"


    // $ANTLR start "rule__StateMachine__StateAssignment_5_3_1"
    // InternalMyDSL.g:2220:1: rule__StateMachine__StateAssignment_5_3_1 : ( ruleState ) ;
    public final void rule__StateMachine__StateAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2224:1: ( ( ruleState ) )
            // InternalMyDSL.g:2225:2: ( ruleState )
            {
            // InternalMyDSL.g:2225:2: ( ruleState )
            // InternalMyDSL.g:2226:3: ruleState
            {
             before(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__StateAssignment_5_3_1"


    // $ANTLR start "rule__StateMachine__TransitionAssignment_6_2"
    // InternalMyDSL.g:2235:1: rule__StateMachine__TransitionAssignment_6_2 : ( ruleTransition ) ;
    public final void rule__StateMachine__TransitionAssignment_6_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2239:1: ( ( ruleTransition ) )
            // InternalMyDSL.g:2240:2: ( ruleTransition )
            {
            // InternalMyDSL.g:2240:2: ( ruleTransition )
            // InternalMyDSL.g:2241:3: ruleTransition
            {
             before(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_2_0()); 
            pushFollow(FOLLOW_2);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__TransitionAssignment_6_2"


    // $ANTLR start "rule__StateMachine__TransitionAssignment_6_3_1"
    // InternalMyDSL.g:2250:1: rule__StateMachine__TransitionAssignment_6_3_1 : ( ruleTransition ) ;
    public final void rule__StateMachine__TransitionAssignment_6_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2254:1: ( ( ruleTransition ) )
            // InternalMyDSL.g:2255:2: ( ruleTransition )
            {
            // InternalMyDSL.g:2255:2: ( ruleTransition )
            // InternalMyDSL.g:2256:3: ruleTransition
            {
             before(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__TransitionAssignment_6_3_1"


    // $ANTLR start "rule__Channel__SynchronousAssignment_1"
    // InternalMyDSL.g:2265:1: rule__Channel__SynchronousAssignment_1 : ( ( 'synchronous' ) ) ;
    public final void rule__Channel__SynchronousAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2269:1: ( ( ( 'synchronous' ) ) )
            // InternalMyDSL.g:2270:2: ( ( 'synchronous' ) )
            {
            // InternalMyDSL.g:2270:2: ( ( 'synchronous' ) )
            // InternalMyDSL.g:2271:3: ( 'synchronous' )
            {
             before(grammarAccess.getChannelAccess().getSynchronousSynchronousKeyword_1_0()); 
            // InternalMyDSL.g:2272:3: ( 'synchronous' )
            // InternalMyDSL.g:2273:4: 'synchronous'
            {
             before(grammarAccess.getChannelAccess().getSynchronousSynchronousKeyword_1_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getChannelAccess().getSynchronousSynchronousKeyword_1_0()); 

            }

             after(grammarAccess.getChannelAccess().getSynchronousSynchronousKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__SynchronousAssignment_1"


    // $ANTLR start "rule__Channel__NameAssignment_3"
    // InternalMyDSL.g:2284:1: rule__Channel__NameAssignment_3 : ( ruleEString ) ;
    public final void rule__Channel__NameAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2288:1: ( ( ruleEString ) )
            // InternalMyDSL.g:2289:2: ( ruleEString )
            {
            // InternalMyDSL.g:2289:2: ( ruleEString )
            // InternalMyDSL.g:2290:3: ruleEString
            {
             before(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__NameAssignment_3"


    // $ANTLR start "rule__State__NameAssignment_2"
    // InternalMyDSL.g:2299:1: rule__State__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__State__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2303:1: ( ( ruleEString ) )
            // InternalMyDSL.g:2304:2: ( ruleEString )
            {
            // InternalMyDSL.g:2304:2: ( ruleEString )
            // InternalMyDSL.g:2305:3: ruleEString
            {
             before(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__NameAssignment_2"


    // $ANTLR start "rule__Transition__SendReceiveAssignment_3_1"
    // InternalMyDSL.g:2314:1: rule__Transition__SendReceiveAssignment_3_1 : ( ruleSendReceive ) ;
    public final void rule__Transition__SendReceiveAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2318:1: ( ( ruleSendReceive ) )
            // InternalMyDSL.g:2319:2: ( ruleSendReceive )
            {
            // InternalMyDSL.g:2319:2: ( ruleSendReceive )
            // InternalMyDSL.g:2320:3: ruleSendReceive
            {
             before(grammarAccess.getTransitionAccess().getSendReceiveSendReceiveEnumRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleSendReceive();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getSendReceiveSendReceiveEnumRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__SendReceiveAssignment_3_1"


    // $ANTLR start "rule__Transition__SourceAssignment_4_1"
    // InternalMyDSL.g:2329:1: rule__Transition__SourceAssignment_4_1 : ( ( ruleEString ) ) ;
    public final void rule__Transition__SourceAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2333:1: ( ( ( ruleEString ) ) )
            // InternalMyDSL.g:2334:2: ( ( ruleEString ) )
            {
            // InternalMyDSL.g:2334:2: ( ( ruleEString ) )
            // InternalMyDSL.g:2335:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getSourceStateCrossReference_4_1_0()); 
            // InternalMyDSL.g:2336:3: ( ruleEString )
            // InternalMyDSL.g:2337:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getSourceStateEStringParserRuleCall_4_1_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getSourceStateEStringParserRuleCall_4_1_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getSourceStateCrossReference_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__SourceAssignment_4_1"


    // $ANTLR start "rule__Transition__TargetAssignment_5_1"
    // InternalMyDSL.g:2348:1: rule__Transition__TargetAssignment_5_1 : ( ( ruleEString ) ) ;
    public final void rule__Transition__TargetAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2352:1: ( ( ( ruleEString ) ) )
            // InternalMyDSL.g:2353:2: ( ( ruleEString ) )
            {
            // InternalMyDSL.g:2353:2: ( ( ruleEString ) )
            // InternalMyDSL.g:2354:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getTargetStateCrossReference_5_1_0()); 
            // InternalMyDSL.g:2355:3: ( ruleEString )
            // InternalMyDSL.g:2356:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getTargetStateEStringParserRuleCall_5_1_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getTargetStateEStringParserRuleCall_5_1_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getTargetStateCrossReference_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__TargetAssignment_5_1"


    // $ANTLR start "rule__Transition__ChannelAssignment_6_1"
    // InternalMyDSL.g:2367:1: rule__Transition__ChannelAssignment_6_1 : ( ( ruleEString ) ) ;
    public final void rule__Transition__ChannelAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDSL.g:2371:1: ( ( ( ruleEString ) ) )
            // InternalMyDSL.g:2372:2: ( ( ruleEString ) )
            {
            // InternalMyDSL.g:2372:2: ( ( ruleEString ) )
            // InternalMyDSL.g:2373:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getChannelChannelCrossReference_6_1_0()); 
            // InternalMyDSL.g:2374:3: ( ruleEString )
            // InternalMyDSL.g:2375:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getChannelChannelEStringParserRuleCall_6_1_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getChannelChannelEStringParserRuleCall_6_1_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getChannelChannelCrossReference_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__ChannelAssignment_6_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000058000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000028000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000020800000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000708000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x000000001C048000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000001800L});

}