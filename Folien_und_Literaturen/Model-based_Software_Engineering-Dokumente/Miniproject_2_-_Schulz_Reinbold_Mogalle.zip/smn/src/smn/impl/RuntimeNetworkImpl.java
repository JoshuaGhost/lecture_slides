/**
 */
package smn.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EcoreEMap;
import org.eclipse.emf.ecore.util.InternalEList;
import smn.Channel;
import smn.Network;
import smn.RuntimeNetwork;
import smn.SmnPackage;
import smn.State;
import smn.StateMachine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Runtime Network</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smn.impl.RuntimeNetworkImpl#getNetwork <em>Network</em>}</li>
 *   <li>{@link smn.impl.RuntimeNetworkImpl#getCurrentStateMap <em>Current State Map</em>}</li>
 *   <li>{@link smn.impl.RuntimeNetworkImpl#getChannelBufferMap <em>Channel Buffer Map</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RuntimeNetworkImpl extends MinimalEObjectImpl.Container implements RuntimeNetwork {
	/**
	 * The cached value of the '{@link #getNetwork() <em>Network</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetwork()
	 * @generated
	 * @ordered
	 */
	protected Network network;
	/**
	 * The cached value of the '{@link #getCurrentStateMap() <em>Current State Map</em>}' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrentStateMap()
	 * @generated
	 * @ordered
	 */
	protected EMap<StateMachine, State> currentStateMap;
	/**
	 * The cached value of the '{@link #getChannelBufferMap() <em>Channel Buffer Map</em>}' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChannelBufferMap()
	 * @generated
	 * @ordered
	 */
	protected EMap<Channel, Integer> channelBufferMap;
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RuntimeNetworkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmnPackage.Literals.RUNTIME_NETWORK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EMap<StateMachine, State> getCurrentStateMap() {
		if (currentStateMap == null) {
			currentStateMap = new EcoreEMap<StateMachine,State>(SmnPackage.Literals.STATE_MACHINE_TO_STATE_MAP, StateMachineToStateMapImpl.class, this, SmnPackage.RUNTIME_NETWORK__CURRENT_STATE_MAP);
		}
		return currentStateMap;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmnPackage.RUNTIME_NETWORK__NETWORK:
				return basicSetNetwork(null, msgs);
			case SmnPackage.RUNTIME_NETWORK__CURRENT_STATE_MAP:
				return ((InternalEList<?>)getCurrentStateMap()).basicRemove(otherEnd, msgs);
			case SmnPackage.RUNTIME_NETWORK__CHANNEL_BUFFER_MAP:
				return ((InternalEList<?>)getChannelBufferMap()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EMap<Channel, Integer> getChannelBufferMap() {
		if (channelBufferMap == null) {
			channelBufferMap = new EcoreEMap<Channel,Integer>(SmnPackage.Literals.CHANNEL_TO_EINTEGER_OBJECT_MAP, ChannelToEIntegerObjectMapImpl.class, this, SmnPackage.RUNTIME_NETWORK__CHANNEL_BUFFER_MAP);
		}
		return channelBufferMap;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Network getNetwork() {
		return network;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNetwork(Network newNetwork, NotificationChain msgs) {
		Network oldNetwork = network;
		network = newNetwork;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmnPackage.RUNTIME_NETWORK__NETWORK, oldNetwork, newNetwork);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNetwork(Network newNetwork) {
		if (newNetwork != network) {
			NotificationChain msgs = null;
			if (network != null)
				msgs = ((InternalEObject)network).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmnPackage.RUNTIME_NETWORK__NETWORK, null, msgs);
			if (newNetwork != null)
				msgs = ((InternalEObject)newNetwork).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmnPackage.RUNTIME_NETWORK__NETWORK, null, msgs);
			msgs = basicSetNetwork(newNetwork, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmnPackage.RUNTIME_NETWORK__NETWORK, newNetwork, newNetwork));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmnPackage.RUNTIME_NETWORK__NETWORK:
				return getNetwork();
			case SmnPackage.RUNTIME_NETWORK__CURRENT_STATE_MAP:
				if (coreType) return getCurrentStateMap();
				else return getCurrentStateMap().map();
			case SmnPackage.RUNTIME_NETWORK__CHANNEL_BUFFER_MAP:
				if (coreType) return getChannelBufferMap();
				else return getChannelBufferMap().map();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmnPackage.RUNTIME_NETWORK__NETWORK:
				setNetwork((Network)newValue);
				return;
			case SmnPackage.RUNTIME_NETWORK__CURRENT_STATE_MAP:
				((EStructuralFeature.Setting)getCurrentStateMap()).set(newValue);
				return;
			case SmnPackage.RUNTIME_NETWORK__CHANNEL_BUFFER_MAP:
				((EStructuralFeature.Setting)getChannelBufferMap()).set(newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmnPackage.RUNTIME_NETWORK__NETWORK:
				setNetwork((Network)null);
				return;
			case SmnPackage.RUNTIME_NETWORK__CURRENT_STATE_MAP:
				getCurrentStateMap().clear();
				return;
			case SmnPackage.RUNTIME_NETWORK__CHANNEL_BUFFER_MAP:
				getChannelBufferMap().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmnPackage.RUNTIME_NETWORK__NETWORK:
				return network != null;
			case SmnPackage.RUNTIME_NETWORK__CURRENT_STATE_MAP:
				return currentStateMap != null && !currentStateMap.isEmpty();
			case SmnPackage.RUNTIME_NETWORK__CHANNEL_BUFFER_MAP:
				return channelBufferMap != null && !channelBufferMap.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RuntimeNetworkImpl
