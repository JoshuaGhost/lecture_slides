/**
 */
package smn;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smn.Network#getStateMachine <em>State Machine</em>}</li>
 *   <li>{@link smn.Network#getChannel <em>Channel</em>}</li>
 * </ul>
 *
 * @see smn.SmnPackage#getNetwork()
 * @model
 * @generated
 */
public interface Network extends NamedElement {
	/**
	 * Returns the value of the '<em><b>State Machine</b></em>' containment reference list.
	 * The list contents are of type {@link smn.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State Machine</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State Machine</em>' containment reference list.
	 * @see smn.SmnPackage#getNetwork_StateMachine()
	 * @model containment="true"
	 * @generated
	 */
	EList<StateMachine> getStateMachine();

	/**
	 * Returns the value of the '<em><b>Channel</b></em>' containment reference list.
	 * The list contents are of type {@link smn.Channel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Channel</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Channel</em>' containment reference list.
	 * @see smn.SmnPackage#getNetwork_Channel()
	 * @model containment="true"
	 * @generated
	 */
	EList<Channel> getChannel();

} // Network
