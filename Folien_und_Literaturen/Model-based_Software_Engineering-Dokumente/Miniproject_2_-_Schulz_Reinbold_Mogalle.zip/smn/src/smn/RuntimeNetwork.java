/**
 */
package smn;

import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Runtime Network</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smn.RuntimeNetwork#getNetwork <em>Network</em>}</li>
 *   <li>{@link smn.RuntimeNetwork#getCurrentStateMap <em>Current State Map</em>}</li>
 *   <li>{@link smn.RuntimeNetwork#getChannelBufferMap <em>Channel Buffer Map</em>}</li>
 * </ul>
 *
 * @see smn.SmnPackage#getRuntimeNetwork()
 * @model
 * @generated
 */
public interface RuntimeNetwork extends EObject {
	/**
	 * Returns the value of the '<em><b>Current State Map</b></em>' map.
	 * The key is of type {@link smn.StateMachine},
	 * and the value is of type {@link smn.State},
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Current State Map</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current State Map</em>' map.
	 * @see smn.SmnPackage#getRuntimeNetwork_CurrentStateMap()
	 * @model mapType="smn.StateMachineToStateMap<smn.StateMachine, smn.State>"
	 * @generated
	 */
	EMap<StateMachine, State> getCurrentStateMap();

	/**
	 * Returns the value of the '<em><b>Channel Buffer Map</b></em>' map.
	 * The key is of type {@link smn.Channel},
	 * and the value is of type {@link java.lang.Integer},
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Channel Buffer Map</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Channel Buffer Map</em>' map.
	 * @see smn.SmnPackage#getRuntimeNetwork_ChannelBufferMap()
	 * @model mapType="smn.ChannelToEIntegerObjectMap<smn.Channel, org.eclipse.emf.ecore.EIntegerObject>"
	 * @generated
	 */
	EMap<Channel, Integer> getChannelBufferMap();

	/**
	 * Returns the value of the '<em><b>Network</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Network</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Network</em>' containment reference.
	 * @see #setNetwork(Network)
	 * @see smn.SmnPackage#getRuntimeNetwork_Network()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Network getNetwork();

	/**
	 * Sets the value of the '{@link smn.RuntimeNetwork#getNetwork <em>Network</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Network</em>' containment reference.
	 * @see #getNetwork()
	 * @generated
	 */
	void setNetwork(Network value);

} // RuntimeNetwork
