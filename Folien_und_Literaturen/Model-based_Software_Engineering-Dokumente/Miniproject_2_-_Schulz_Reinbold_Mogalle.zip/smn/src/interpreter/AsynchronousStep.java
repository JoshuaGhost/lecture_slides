package interpreter;

import smn.*;

public class AsynchronousStep implements Step {
	RuntimeNetwork rn;
	StateMachine sm;
	Transition t;

	public AsynchronousStep(RuntimeNetwork rn, StateMachine sm, Transition t) {
		this.rn = rn;
		this.sm = sm;
		this.t = t;
		if (t.getChannel().isSynchronous()) {
			throw new IllegalArgumentException("Channel of the transition must be asynchronous.");
		}
	}

	public boolean canFire() {
		State currentState = rn.getCurrentStateMap().get(sm);
		if (currentState != t.getSource()) {
			return false;
		}

		Channel ch = t.getChannel();
		int bufferCount = rn.getChannelBufferMap().get(ch);
		if (t.getSendReceive() == SendReceive.RECEIVE && bufferCount == 0) {
			return false;
		}
		return true;
	}

	public void fire() {
		if (!canFire()) {
			return;
		}

		rn.getCurrentStateMap().put(sm, t.getTarget());

		Channel ch = t.getChannel();
		int bufferCount = rn.getChannelBufferMap().get(ch);
		switch (t.getSendReceive()) {
		case SEND:
			bufferCount += 1;
			break;
		case RECEIVE:
			bufferCount -= 1;
			break;
		}
		rn.getChannelBufferMap().put(ch, bufferCount);
		System.out.println(sm.getName() + ":" + t.getSource().getName() + "->" + t.getTarget().getName() + "(" + t.getSendReceive()
				+ ") on " + ch.getName() + " (new buffer: " + bufferCount + ").");
	}
}
