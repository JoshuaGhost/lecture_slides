package interpreter;

import org.eclipse.emf.common.util.EMap;

import smn.*;

public class SynchronousStep implements Step {
	private RuntimeNetwork rn;
	private StateMachine smSend;
	private Transition tSend;
	private StateMachine smReceive;
	private Transition tReceive;

	public SynchronousStep(RuntimeNetwork rn, StateMachine smSend, Transition tSend, StateMachine smReceive,
			Transition tReceive) {
		this.rn = rn;
		this.smSend = smSend;
		this.tSend = tSend;
		this.smReceive = smReceive;
		this.tReceive = tReceive;

		if (tSend.getSendReceive() != SendReceive.SEND) {
			throw new IllegalArgumentException("tSend hast to be a sending transition.");
		}
		if (tReceive.getSendReceive() != SendReceive.RECEIVE) {
			throw new IllegalArgumentException("tReceive has to be a receiving transition.");
		}
		if (!tSend.getChannel().isSynchronous()) {
			throw new IllegalArgumentException("Channel of tSend has to be synchronous.");
		}
		if (!tReceive.getChannel().isSynchronous()) {
			throw new IllegalArgumentException("Channel of tReceive has to be synchronous.");
		}
		if (tReceive.getChannel() != tSend.getChannel()) {
			throw new IllegalArgumentException("tSend and tReceive have to trigger on the same channel.");
		}
		if (smSend == smReceive) {
			throw new IllegalArgumentException("tSend and tReceive must not be located in the same state machine.");
		}
	}

	@Override
	public boolean canFire() {
		EMap<StateMachine, State> currentStates = rn.getCurrentStateMap();
		if (currentStates.get(smSend) != tSend.getSource()) {
			return false;
		}
		if (currentStates.get(smReceive) != tReceive.getSource()) {
			return false;
		}
		return true;
	}

	@Override
	public void fire() {
		if (!canFire()) {
			return;
		}

		rn.getCurrentStateMap().put(smSend, tSend.getTarget());
		rn.getCurrentStateMap().put(smReceive, tReceive.getTarget());
		Channel ch = tSend.getChannel();
		String sendInfo = smSend.getName() + ":" + tSend.getSource().getName() + "->" + tSend.getTarget().getName() + "(SEND)";
		String receiveInfo = smReceive.getName() + ":" + tReceive.getSource().getName() + "->" + tReceive.getTarget().getName() + "(RECEIVE)";
		System.out.println(sendInfo + ", " + receiveInfo + " on " + ch.getName() + ".");
	}
}
