package interpreter;

import org.eclipse.emf.common.util.BasicEMap;

import smn.Channel;
import smn.Network;
import smn.State;
import smn.StateMachine;
import smn.impl.RuntimeNetworkImpl;

public class RuntimeNetworkWrapper extends RuntimeNetworkImpl {
	
	public RuntimeNetworkWrapper(Network nw) {
		currentStateMap = new BasicEMap<StateMachine, State>();
		channelBufferMap = new BasicEMap<Channel, Integer>();
		network = nw;
		
		for (StateMachine sm : nw.getStateMachine()) {
			currentStateMap.put(sm, sm.getInitialState());
		}
		for (Channel ch : nw.getChannel())
		{
			if (!ch.isSynchronous()) {
				channelBufferMap.put(ch, 0);
			}
		}
	}

}
