package interpreter;

public interface Step {
	boolean canFire();
	void fire();
}
