package interpreter;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import smn.*;

public class SmnInterpreter {

	private static String[] MODEL_FILES = { "model/runtime/Cafe.smn", 
			"model/runtime/Door.smn", 
			"model/runtime/PedestrianCrossing.smn" };
	private static int AMOUNT_OF_STEPS_PER_SIMULATION = 30;

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		SmnFileLoader loader = new SmnFileLoader();
		/*
		RuntimeNetwork network = loader.loadRuntimeNetwork("model/runtime/Cafe.smn");
		SmnInterpreter interpreter = new SmnInterpreter(network);
		interpreter.simulateSteps(AMOUNT_OF_STEPS_PER_SIMULATION);
		*/
		
		for (String modelFile : MODEL_FILES) {
			RuntimeNetwork network = loader.loadRuntimeNetwork(modelFile);
			SmnInterpreter interpreter = new SmnInterpreter(network);
			interpreter.simulateSteps(AMOUNT_OF_STEPS_PER_SIMULATION);
		} 
		
		long endTime = System.currentTimeMillis();
		System.out.println("Laufzeit in Millisekunden:" + (endTime-startTime));
	}

	private Random rnd = new Random();
	private List<Step> steps;

	public SmnInterpreter(RuntimeNetwork simulationTarget) {
		steps = computeSteps(simulationTarget);
		System.out.println("Interpreter created for network \"" + simulationTarget.getNetwork().getName() + "\".");
	}

	public void simulateSteps(int nrOfSteps) {
		for (int i = 0; i < nrOfSteps; i++) {
			Step step = selectRandomActiveStep(steps);
			
			if (step == null) {
				System.out.println("Deadlock");
				return;
			}
			
			step.fire();
		}
	}

	private Step selectRandomActiveStep(List<Step> steps) {
		List<Step> activeSteps = new ArrayList<Step>();
		for (Step step : steps) {
			if (step.canFire()) {
				activeSteps.add(step);
			}
		}
		if (activeSteps.isEmpty()) {
			return null;
		}
		
		int rndIndex = rnd.nextInt(activeSteps.size());
		return activeSteps.get(rndIndex);
	}

	private List<Step> computeSteps(RuntimeNetwork rnw) {
		List<Step> list = new ArrayList<Step>();
		Network nw = rnw.getNetwork();

		// Compute all async transition steps
		for (StateMachine sm : nw.getStateMachine()) {
			for (Transition t : sm.getTransition()) {
				if (!t.getChannel().isSynchronous()) {
					list.add(new AsynchronousStep(rnw, sm, t));
				}
			}
		}

		// Compute all sync transition steps
		for (StateMachine sm1 : nw.getStateMachine()) {
			for (Transition t1 : sm1.getTransition()) {
				if (t1.getSendReceive() != SendReceive.SEND || !t1.getChannel().isSynchronous()) {
					continue;
				}

				// Search for matching receive transitions
				for (StateMachine sm2 : nw.getStateMachine()) {
					if (sm1 == sm2) {
						continue;
					}
					for (Transition t2 : sm2.getTransition()) {
						if (t2.getSendReceive() != SendReceive.RECEIVE || t1.getChannel() != t2.getChannel()) {
							continue;
						}
						list.add(new SynchronousStep(rnw, sm1, t1, sm2, t2));

					}
				}
			}
		}
		return list;
	}
}
