package interpreter;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import smn.Network;
import smn.RuntimeNetwork;
import smn.SmnPackage;

public class SmnFileLoader {
	public Network loadNetwork(String file){
	    return (Network) getResource(file);
	}
	public RuntimeNetwork loadRuntimeNetwork(String file){
	    return (RuntimeNetwork) getResource(file);
	}
	
	private EObject getResource(String file) {
		SmnPackage.eINSTANCE.eClass();

	    Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
	    Map<String, Object> m = reg.getExtensionToFactoryMap();
	    m.put("smn", new XMIResourceFactoryImpl());

	    ResourceSet resSet = new ResourceSetImpl();
	    Resource resource = resSet.getResource(URI
	        .createURI(file), true);
	    return resource.getContents().get(0);
	}
}
