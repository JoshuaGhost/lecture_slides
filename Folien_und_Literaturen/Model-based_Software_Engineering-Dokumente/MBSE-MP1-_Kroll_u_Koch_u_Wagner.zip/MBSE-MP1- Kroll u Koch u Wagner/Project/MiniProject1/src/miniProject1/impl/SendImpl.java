/**
 */
package miniProject1.impl;

import miniProject1.MiniProject1Package;
import miniProject1.Send;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Send</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SendImpl extends TransitionImpl implements Send {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SendImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniProject1Package.Literals.SEND;
	}

} //SendImpl
