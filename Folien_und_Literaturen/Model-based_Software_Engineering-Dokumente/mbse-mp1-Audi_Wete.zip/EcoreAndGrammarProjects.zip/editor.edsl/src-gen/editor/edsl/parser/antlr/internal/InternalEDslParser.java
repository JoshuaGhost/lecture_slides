package editor.edsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import editor.edsl.services.EDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalEDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Network'", "'{'", "'declaration'", "','", "'}'", "'stateMachine'", "'StateMachine'", "'initialState'", "'state'", "'transition'", "'Channel'", "'State'", "'('", "'incoming'", "'outgoing'", "')'", "'Transition'", "'source'", "'target'", "'channel'", "'synch'", "'asynch'", "'send'", "'receive'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalEDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalEDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalEDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalEDsl.g"; }



     	private EDslGrammarAccess grammarAccess;

        public InternalEDslParser(TokenStream input, EDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Network";
       	}

       	@Override
       	protected EDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleNetwork"
    // InternalEDsl.g:65:1: entryRuleNetwork returns [EObject current=null] : iv_ruleNetwork= ruleNetwork EOF ;
    public final EObject entryRuleNetwork() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNetwork = null;


        try {
            // InternalEDsl.g:65:48: (iv_ruleNetwork= ruleNetwork EOF )
            // InternalEDsl.g:66:2: iv_ruleNetwork= ruleNetwork EOF
            {
             newCompositeNode(grammarAccess.getNetworkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNetwork=ruleNetwork();

            state._fsp--;

             current =iv_ruleNetwork; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNetwork"


    // $ANTLR start "ruleNetwork"
    // InternalEDsl.g:72:1: ruleNetwork returns [EObject current=null] : (otherlv_0= 'Network' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}' )? (otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}' )? otherlv_15= '}' ) ;
    public final EObject ruleNetwork() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_declaration_5_0 = null;

        EObject lv_declaration_7_0 = null;

        EObject lv_stateMachine_11_0 = null;

        EObject lv_stateMachine_13_0 = null;



        	enterRule();

        try {
            // InternalEDsl.g:78:2: ( (otherlv_0= 'Network' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}' )? (otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}' )? otherlv_15= '}' ) )
            // InternalEDsl.g:79:2: (otherlv_0= 'Network' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}' )? (otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}' )? otherlv_15= '}' )
            {
            // InternalEDsl.g:79:2: (otherlv_0= 'Network' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}' )? (otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}' )? otherlv_15= '}' )
            // InternalEDsl.g:80:3: otherlv_0= 'Network' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}' )? (otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}' )? otherlv_15= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getNetworkAccess().getNetworkKeyword_0());
            		
            // InternalEDsl.g:84:3: ( (lv_name_1_0= ruleEString ) )
            // InternalEDsl.g:85:4: (lv_name_1_0= ruleEString )
            {
            // InternalEDsl.g:85:4: (lv_name_1_0= ruleEString )
            // InternalEDsl.g:86:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getNetworkAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getNetworkRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"editor.edsl.EDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalEDsl.g:107:3: (otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==13) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalEDsl.g:108:4: otherlv_3= 'declaration' otherlv_4= '{' ( (lv_declaration_5_0= ruleChannel ) ) (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )* otherlv_8= '}'
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_4); 

                    				newLeafNode(otherlv_3, grammarAccess.getNetworkAccess().getDeclarationKeyword_3_0());
                    			
                    otherlv_4=(Token)match(input,12,FOLLOW_6); 

                    				newLeafNode(otherlv_4, grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_3_1());
                    			
                    // InternalEDsl.g:116:4: ( (lv_declaration_5_0= ruleChannel ) )
                    // InternalEDsl.g:117:5: (lv_declaration_5_0= ruleChannel )
                    {
                    // InternalEDsl.g:117:5: (lv_declaration_5_0= ruleChannel )
                    // InternalEDsl.g:118:6: lv_declaration_5_0= ruleChannel
                    {

                    						newCompositeNode(grammarAccess.getNetworkAccess().getDeclarationChannelParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_declaration_5_0=ruleChannel();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkRule());
                    						}
                    						add(
                    							current,
                    							"declaration",
                    							lv_declaration_5_0,
                    							"editor.edsl.EDsl.Channel");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalEDsl.g:135:4: (otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==14) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalEDsl.g:136:5: otherlv_6= ',' ( (lv_declaration_7_0= ruleChannel ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_6); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getNetworkAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalEDsl.g:140:5: ( (lv_declaration_7_0= ruleChannel ) )
                    	    // InternalEDsl.g:141:6: (lv_declaration_7_0= ruleChannel )
                    	    {
                    	    // InternalEDsl.g:141:6: (lv_declaration_7_0= ruleChannel )
                    	    // InternalEDsl.g:142:7: lv_declaration_7_0= ruleChannel
                    	    {

                    	    							newCompositeNode(grammarAccess.getNetworkAccess().getDeclarationChannelParserRuleCall_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_declaration_7_0=ruleChannel();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getNetworkRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"declaration",
                    	    								lv_declaration_7_0,
                    	    								"editor.edsl.EDsl.Channel");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,15,FOLLOW_8); 

                    				newLeafNode(otherlv_8, grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_3_4());
                    			

                    }
                    break;

            }

            // InternalEDsl.g:165:3: (otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==16) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalEDsl.g:166:4: otherlv_9= 'stateMachine' otherlv_10= '{' ( (lv_stateMachine_11_0= ruleStateMachine ) ) (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )* otherlv_14= '}'
                    {
                    otherlv_9=(Token)match(input,16,FOLLOW_4); 

                    				newLeafNode(otherlv_9, grammarAccess.getNetworkAccess().getStateMachineKeyword_4_0());
                    			
                    otherlv_10=(Token)match(input,12,FOLLOW_9); 

                    				newLeafNode(otherlv_10, grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalEDsl.g:174:4: ( (lv_stateMachine_11_0= ruleStateMachine ) )
                    // InternalEDsl.g:175:5: (lv_stateMachine_11_0= ruleStateMachine )
                    {
                    // InternalEDsl.g:175:5: (lv_stateMachine_11_0= ruleStateMachine )
                    // InternalEDsl.g:176:6: lv_stateMachine_11_0= ruleStateMachine
                    {

                    						newCompositeNode(grammarAccess.getNetworkAccess().getStateMachineStateMachineParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_stateMachine_11_0=ruleStateMachine();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkRule());
                    						}
                    						add(
                    							current,
                    							"stateMachine",
                    							lv_stateMachine_11_0,
                    							"editor.edsl.EDsl.StateMachine");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalEDsl.g:193:4: (otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) ) )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==14) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalEDsl.g:194:5: otherlv_12= ',' ( (lv_stateMachine_13_0= ruleStateMachine ) )
                    	    {
                    	    otherlv_12=(Token)match(input,14,FOLLOW_9); 

                    	    					newLeafNode(otherlv_12, grammarAccess.getNetworkAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalEDsl.g:198:5: ( (lv_stateMachine_13_0= ruleStateMachine ) )
                    	    // InternalEDsl.g:199:6: (lv_stateMachine_13_0= ruleStateMachine )
                    	    {
                    	    // InternalEDsl.g:199:6: (lv_stateMachine_13_0= ruleStateMachine )
                    	    // InternalEDsl.g:200:7: lv_stateMachine_13_0= ruleStateMachine
                    	    {

                    	    							newCompositeNode(grammarAccess.getNetworkAccess().getStateMachineStateMachineParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_stateMachine_13_0=ruleStateMachine();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getNetworkRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"stateMachine",
                    	    								lv_stateMachine_13_0,
                    	    								"editor.edsl.EDsl.StateMachine");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    otherlv_14=(Token)match(input,15,FOLLOW_10); 

                    				newLeafNode(otherlv_14, grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_15=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNetwork"


    // $ANTLR start "entryRuleEString"
    // InternalEDsl.g:231:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalEDsl.g:231:47: (iv_ruleEString= ruleEString EOF )
            // InternalEDsl.g:232:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalEDsl.g:238:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalEDsl.g:244:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalEDsl.g:245:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalEDsl.g:245:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_STRING) ) {
                alt5=1;
            }
            else if ( (LA5_0==RULE_ID) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalEDsl.g:246:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalEDsl.g:254:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleStateMachine"
    // InternalEDsl.g:265:1: entryRuleStateMachine returns [EObject current=null] : iv_ruleStateMachine= ruleStateMachine EOF ;
    public final EObject entryRuleStateMachine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStateMachine = null;


        try {
            // InternalEDsl.g:265:53: (iv_ruleStateMachine= ruleStateMachine EOF )
            // InternalEDsl.g:266:2: iv_ruleStateMachine= ruleStateMachine EOF
            {
             newCompositeNode(grammarAccess.getStateMachineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStateMachine=ruleStateMachine();

            state._fsp--;

             current =iv_ruleStateMachine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStateMachine"


    // $ANTLR start "ruleStateMachine"
    // InternalEDsl.g:272:1: ruleStateMachine returns [EObject current=null] : (otherlv_0= 'StateMachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'initialState' ( (otherlv_4= RULE_ID ) ) (otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}' )? (otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) ;
    public final EObject ruleStateMachine() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        EObject lv_state_7_0 = null;

        EObject lv_state_9_0 = null;

        EObject lv_transition_13_0 = null;

        EObject lv_transition_15_0 = null;



        	enterRule();

        try {
            // InternalEDsl.g:278:2: ( (otherlv_0= 'StateMachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'initialState' ( (otherlv_4= RULE_ID ) ) (otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}' )? (otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) )
            // InternalEDsl.g:279:2: (otherlv_0= 'StateMachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'initialState' ( (otherlv_4= RULE_ID ) ) (otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}' )? (otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            {
            // InternalEDsl.g:279:2: (otherlv_0= 'StateMachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'initialState' ( (otherlv_4= RULE_ID ) ) (otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}' )? (otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            // InternalEDsl.g:280:3: otherlv_0= 'StateMachine' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'initialState' ( (otherlv_4= RULE_ID ) ) (otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}' )? (otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}' )? otherlv_17= '}'
            {
            otherlv_0=(Token)match(input,17,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getStateMachineAccess().getStateMachineKeyword_0());
            		
            // InternalEDsl.g:284:3: ( (lv_name_1_0= ruleEString ) )
            // InternalEDsl.g:285:4: (lv_name_1_0= ruleEString )
            {
            // InternalEDsl.g:285:4: (lv_name_1_0= ruleEString )
            // InternalEDsl.g:286:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getStateMachineAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStateMachineRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"editor.edsl.EDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,18,FOLLOW_12); 

            			newLeafNode(otherlv_3, grammarAccess.getStateMachineAccess().getInitialStateKeyword_3());
            		
            // InternalEDsl.g:311:3: ( (otherlv_4= RULE_ID ) )
            // InternalEDsl.g:312:4: (otherlv_4= RULE_ID )
            {
            // InternalEDsl.g:312:4: (otherlv_4= RULE_ID )
            // InternalEDsl.g:313:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStateMachineRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(otherlv_4, grammarAccess.getStateMachineAccess().getInitialStateStateCrossReference_4_0());
            				

            }


            }

            // InternalEDsl.g:324:3: (otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}' )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalEDsl.g:325:4: otherlv_5= 'state' otherlv_6= '{' ( (lv_state_7_0= ruleState ) ) (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )* otherlv_10= '}'
                    {
                    otherlv_5=(Token)match(input,19,FOLLOW_4); 

                    				newLeafNode(otherlv_5, grammarAccess.getStateMachineAccess().getStateKeyword_5_0());
                    			
                    otherlv_6=(Token)match(input,12,FOLLOW_14); 

                    				newLeafNode(otherlv_6, grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalEDsl.g:333:4: ( (lv_state_7_0= ruleState ) )
                    // InternalEDsl.g:334:5: (lv_state_7_0= ruleState )
                    {
                    // InternalEDsl.g:334:5: (lv_state_7_0= ruleState )
                    // InternalEDsl.g:335:6: lv_state_7_0= ruleState
                    {

                    						newCompositeNode(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_state_7_0=ruleState();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    						}
                    						add(
                    							current,
                    							"state",
                    							lv_state_7_0,
                    							"editor.edsl.EDsl.State");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalEDsl.g:352:4: (otherlv_8= ',' ( (lv_state_9_0= ruleState ) ) )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==14) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // InternalEDsl.g:353:5: otherlv_8= ',' ( (lv_state_9_0= ruleState ) )
                    	    {
                    	    otherlv_8=(Token)match(input,14,FOLLOW_14); 

                    	    					newLeafNode(otherlv_8, grammarAccess.getStateMachineAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalEDsl.g:357:5: ( (lv_state_9_0= ruleState ) )
                    	    // InternalEDsl.g:358:6: (lv_state_9_0= ruleState )
                    	    {
                    	    // InternalEDsl.g:358:6: (lv_state_9_0= ruleState )
                    	    // InternalEDsl.g:359:7: lv_state_9_0= ruleState
                    	    {

                    	    							newCompositeNode(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_state_9_0=ruleState();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"state",
                    	    								lv_state_9_0,
                    	    								"editor.edsl.EDsl.State");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);

                    otherlv_10=(Token)match(input,15,FOLLOW_15); 

                    				newLeafNode(otherlv_10, grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalEDsl.g:382:3: (otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==20) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalEDsl.g:383:4: otherlv_11= 'transition' otherlv_12= '{' ( (lv_transition_13_0= ruleTransition ) ) (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )* otherlv_16= '}'
                    {
                    otherlv_11=(Token)match(input,20,FOLLOW_4); 

                    				newLeafNode(otherlv_11, grammarAccess.getStateMachineAccess().getTransitionKeyword_6_0());
                    			
                    otherlv_12=(Token)match(input,12,FOLLOW_16); 

                    				newLeafNode(otherlv_12, grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalEDsl.g:391:4: ( (lv_transition_13_0= ruleTransition ) )
                    // InternalEDsl.g:392:5: (lv_transition_13_0= ruleTransition )
                    {
                    // InternalEDsl.g:392:5: (lv_transition_13_0= ruleTransition )
                    // InternalEDsl.g:393:6: lv_transition_13_0= ruleTransition
                    {

                    						newCompositeNode(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_transition_13_0=ruleTransition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    						}
                    						add(
                    							current,
                    							"transition",
                    							lv_transition_13_0,
                    							"editor.edsl.EDsl.Transition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalEDsl.g:410:4: (otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) ) )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==14) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // InternalEDsl.g:411:5: otherlv_14= ',' ( (lv_transition_15_0= ruleTransition ) )
                    	    {
                    	    otherlv_14=(Token)match(input,14,FOLLOW_16); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getStateMachineAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalEDsl.g:415:5: ( (lv_transition_15_0= ruleTransition ) )
                    	    // InternalEDsl.g:416:6: (lv_transition_15_0= ruleTransition )
                    	    {
                    	    // InternalEDsl.g:416:6: (lv_transition_15_0= ruleTransition )
                    	    // InternalEDsl.g:417:7: lv_transition_15_0= ruleTransition
                    	    {

                    	    							newCompositeNode(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_transition_15_0=ruleTransition();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"transition",
                    	    								lv_transition_15_0,
                    	    								"editor.edsl.EDsl.Transition");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    otherlv_16=(Token)match(input,15,FOLLOW_10); 

                    				newLeafNode(otherlv_16, grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_17=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStateMachine"


    // $ANTLR start "entryRuleChannel"
    // InternalEDsl.g:448:1: entryRuleChannel returns [EObject current=null] : iv_ruleChannel= ruleChannel EOF ;
    public final EObject entryRuleChannel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChannel = null;


        try {
            // InternalEDsl.g:448:48: (iv_ruleChannel= ruleChannel EOF )
            // InternalEDsl.g:449:2: iv_ruleChannel= ruleChannel EOF
            {
             newCompositeNode(grammarAccess.getChannelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChannel=ruleChannel();

            state._fsp--;

             current =iv_ruleChannel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChannel"


    // $ANTLR start "ruleChannel"
    // InternalEDsl.g:455:1: ruleChannel returns [EObject current=null] : ( () otherlv_1= 'Channel' ( (lv_type_2_0= ruleChannelType ) ) ( (lv_name_3_0= ruleEString ) ) ) ;
    public final EObject ruleChannel() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Enumerator lv_type_2_0 = null;

        AntlrDatatypeRuleToken lv_name_3_0 = null;



        	enterRule();

        try {
            // InternalEDsl.g:461:2: ( ( () otherlv_1= 'Channel' ( (lv_type_2_0= ruleChannelType ) ) ( (lv_name_3_0= ruleEString ) ) ) )
            // InternalEDsl.g:462:2: ( () otherlv_1= 'Channel' ( (lv_type_2_0= ruleChannelType ) ) ( (lv_name_3_0= ruleEString ) ) )
            {
            // InternalEDsl.g:462:2: ( () otherlv_1= 'Channel' ( (lv_type_2_0= ruleChannelType ) ) ( (lv_name_3_0= ruleEString ) ) )
            // InternalEDsl.g:463:3: () otherlv_1= 'Channel' ( (lv_type_2_0= ruleChannelType ) ) ( (lv_name_3_0= ruleEString ) )
            {
            // InternalEDsl.g:463:3: ()
            // InternalEDsl.g:464:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getChannelAccess().getChannelAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,21,FOLLOW_17); 

            			newLeafNode(otherlv_1, grammarAccess.getChannelAccess().getChannelKeyword_1());
            		
            // InternalEDsl.g:474:3: ( (lv_type_2_0= ruleChannelType ) )
            // InternalEDsl.g:475:4: (lv_type_2_0= ruleChannelType )
            {
            // InternalEDsl.g:475:4: (lv_type_2_0= ruleChannelType )
            // InternalEDsl.g:476:5: lv_type_2_0= ruleChannelType
            {

            					newCompositeNode(grammarAccess.getChannelAccess().getTypeChannelTypeEnumRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_type_2_0=ruleChannelType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChannelRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_2_0,
            						"editor.edsl.EDsl.ChannelType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalEDsl.g:493:3: ( (lv_name_3_0= ruleEString ) )
            // InternalEDsl.g:494:4: (lv_name_3_0= ruleEString )
            {
            // InternalEDsl.g:494:4: (lv_name_3_0= ruleEString )
            // InternalEDsl.g:495:5: lv_name_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChannelRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"editor.edsl.EDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChannel"


    // $ANTLR start "entryRuleState"
    // InternalEDsl.g:516:1: entryRuleState returns [EObject current=null] : iv_ruleState= ruleState EOF ;
    public final EObject entryRuleState() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleState = null;


        try {
            // InternalEDsl.g:516:46: (iv_ruleState= ruleState EOF )
            // InternalEDsl.g:517:2: iv_ruleState= ruleState EOF
            {
             newCompositeNode(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleState=ruleState();

            state._fsp--;

             current =iv_ruleState; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalEDsl.g:523:1: ruleState returns [EObject current=null] : (otherlv_0= 'State' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' otherlv_3= 'incoming' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ',' otherlv_8= 'outgoing' ( (otherlv_9= RULE_ID ) ) (otherlv_10= ',' ( (otherlv_11= RULE_ID ) ) )* otherlv_12= ')' ) ;
    public final EObject ruleState() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalEDsl.g:529:2: ( (otherlv_0= 'State' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' otherlv_3= 'incoming' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ',' otherlv_8= 'outgoing' ( (otherlv_9= RULE_ID ) ) (otherlv_10= ',' ( (otherlv_11= RULE_ID ) ) )* otherlv_12= ')' ) )
            // InternalEDsl.g:530:2: (otherlv_0= 'State' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' otherlv_3= 'incoming' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ',' otherlv_8= 'outgoing' ( (otherlv_9= RULE_ID ) ) (otherlv_10= ',' ( (otherlv_11= RULE_ID ) ) )* otherlv_12= ')' )
            {
            // InternalEDsl.g:530:2: (otherlv_0= 'State' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' otherlv_3= 'incoming' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ',' otherlv_8= 'outgoing' ( (otherlv_9= RULE_ID ) ) (otherlv_10= ',' ( (otherlv_11= RULE_ID ) ) )* otherlv_12= ')' )
            // InternalEDsl.g:531:3: otherlv_0= 'State' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '(' otherlv_3= 'incoming' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ',' otherlv_8= 'outgoing' ( (otherlv_9= RULE_ID ) ) (otherlv_10= ',' ( (otherlv_11= RULE_ID ) ) )* otherlv_12= ')'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getStateAccess().getStateKeyword_0());
            		
            // InternalEDsl.g:535:3: ( (lv_name_1_0= ruleEString ) )
            // InternalEDsl.g:536:4: (lv_name_1_0= ruleEString )
            {
            // InternalEDsl.g:536:4: (lv_name_1_0= ruleEString )
            // InternalEDsl.g:537:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getStateAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_18);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStateRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"editor.edsl.EDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,23,FOLLOW_19); 

            			newLeafNode(otherlv_2, grammarAccess.getStateAccess().getLeftParenthesisKeyword_2());
            		
            otherlv_3=(Token)match(input,24,FOLLOW_12); 

            			newLeafNode(otherlv_3, grammarAccess.getStateAccess().getIncomingKeyword_3());
            		
            // InternalEDsl.g:562:3: ( (otherlv_4= RULE_ID ) )
            // InternalEDsl.g:563:4: (otherlv_4= RULE_ID )
            {
            // InternalEDsl.g:563:4: (otherlv_4= RULE_ID )
            // InternalEDsl.g:564:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStateRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_20); 

            					newLeafNode(otherlv_4, grammarAccess.getStateAccess().getIncomingTransitionCrossReference_4_0());
            				

            }


            }

            // InternalEDsl.g:575:3: (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==14) ) {
                    int LA10_1 = input.LA(2);

                    if ( (LA10_1==RULE_ID) ) {
                        alt10=1;
                    }


                }


                switch (alt10) {
            	case 1 :
            	    // InternalEDsl.g:576:4: otherlv_5= ',' ( (otherlv_6= RULE_ID ) )
            	    {
            	    otherlv_5=(Token)match(input,14,FOLLOW_12); 

            	    				newLeafNode(otherlv_5, grammarAccess.getStateAccess().getCommaKeyword_5_0());
            	    			
            	    // InternalEDsl.g:580:4: ( (otherlv_6= RULE_ID ) )
            	    // InternalEDsl.g:581:5: (otherlv_6= RULE_ID )
            	    {
            	    // InternalEDsl.g:581:5: (otherlv_6= RULE_ID )
            	    // InternalEDsl.g:582:6: otherlv_6= RULE_ID
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getStateRule());
            	    						}
            	    					
            	    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_20); 

            	    						newLeafNode(otherlv_6, grammarAccess.getStateAccess().getIncomingTransitionCrossReference_5_1_0());
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            otherlv_7=(Token)match(input,14,FOLLOW_21); 

            			newLeafNode(otherlv_7, grammarAccess.getStateAccess().getCommaKeyword_6());
            		
            otherlv_8=(Token)match(input,25,FOLLOW_12); 

            			newLeafNode(otherlv_8, grammarAccess.getStateAccess().getOutgoingKeyword_7());
            		
            // InternalEDsl.g:602:3: ( (otherlv_9= RULE_ID ) )
            // InternalEDsl.g:603:4: (otherlv_9= RULE_ID )
            {
            // InternalEDsl.g:603:4: (otherlv_9= RULE_ID )
            // InternalEDsl.g:604:5: otherlv_9= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStateRule());
            					}
            				
            otherlv_9=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(otherlv_9, grammarAccess.getStateAccess().getOutgoingTransitionCrossReference_8_0());
            				

            }


            }

            // InternalEDsl.g:615:3: (otherlv_10= ',' ( (otherlv_11= RULE_ID ) ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==14) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalEDsl.g:616:4: otherlv_10= ',' ( (otherlv_11= RULE_ID ) )
            	    {
            	    otherlv_10=(Token)match(input,14,FOLLOW_12); 

            	    				newLeafNode(otherlv_10, grammarAccess.getStateAccess().getCommaKeyword_9_0());
            	    			
            	    // InternalEDsl.g:620:4: ( (otherlv_11= RULE_ID ) )
            	    // InternalEDsl.g:621:5: (otherlv_11= RULE_ID )
            	    {
            	    // InternalEDsl.g:621:5: (otherlv_11= RULE_ID )
            	    // InternalEDsl.g:622:6: otherlv_11= RULE_ID
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getStateRule());
            	    						}
            	    					
            	    otherlv_11=(Token)match(input,RULE_ID,FOLLOW_22); 

            	    						newLeafNode(otherlv_11, grammarAccess.getStateAccess().getOutgoingTransitionCrossReference_9_1_0());
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            otherlv_12=(Token)match(input,26,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getStateAccess().getRightParenthesisKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleTransition"
    // InternalEDsl.g:642:1: entryRuleTransition returns [EObject current=null] : iv_ruleTransition= ruleTransition EOF ;
    public final EObject entryRuleTransition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTransition = null;


        try {
            // InternalEDsl.g:642:51: (iv_ruleTransition= ruleTransition EOF )
            // InternalEDsl.g:643:2: iv_ruleTransition= ruleTransition EOF
            {
             newCompositeNode(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTransition=ruleTransition();

            state._fsp--;

             current =iv_ruleTransition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalEDsl.g:649:1: ruleTransition returns [EObject current=null] : (otherlv_0= 'Transition' ( (lv_type_1_0= ruleLabelType ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' otherlv_4= 'source' ( (otherlv_5= RULE_ID ) ) otherlv_6= ',' otherlv_7= 'target' ( (otherlv_8= RULE_ID ) ) otherlv_9= ',' otherlv_10= 'channel' ( (otherlv_11= RULE_ID ) ) otherlv_12= ')' ) ;
    public final EObject ruleTransition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Enumerator lv_type_1_0 = null;

        AntlrDatatypeRuleToken lv_name_2_0 = null;



        	enterRule();

        try {
            // InternalEDsl.g:655:2: ( (otherlv_0= 'Transition' ( (lv_type_1_0= ruleLabelType ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' otherlv_4= 'source' ( (otherlv_5= RULE_ID ) ) otherlv_6= ',' otherlv_7= 'target' ( (otherlv_8= RULE_ID ) ) otherlv_9= ',' otherlv_10= 'channel' ( (otherlv_11= RULE_ID ) ) otherlv_12= ')' ) )
            // InternalEDsl.g:656:2: (otherlv_0= 'Transition' ( (lv_type_1_0= ruleLabelType ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' otherlv_4= 'source' ( (otherlv_5= RULE_ID ) ) otherlv_6= ',' otherlv_7= 'target' ( (otherlv_8= RULE_ID ) ) otherlv_9= ',' otherlv_10= 'channel' ( (otherlv_11= RULE_ID ) ) otherlv_12= ')' )
            {
            // InternalEDsl.g:656:2: (otherlv_0= 'Transition' ( (lv_type_1_0= ruleLabelType ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' otherlv_4= 'source' ( (otherlv_5= RULE_ID ) ) otherlv_6= ',' otherlv_7= 'target' ( (otherlv_8= RULE_ID ) ) otherlv_9= ',' otherlv_10= 'channel' ( (otherlv_11= RULE_ID ) ) otherlv_12= ')' )
            // InternalEDsl.g:657:3: otherlv_0= 'Transition' ( (lv_type_1_0= ruleLabelType ) ) ( (lv_name_2_0= ruleEString ) ) otherlv_3= '(' otherlv_4= 'source' ( (otherlv_5= RULE_ID ) ) otherlv_6= ',' otherlv_7= 'target' ( (otherlv_8= RULE_ID ) ) otherlv_9= ',' otherlv_10= 'channel' ( (otherlv_11= RULE_ID ) ) otherlv_12= ')'
            {
            otherlv_0=(Token)match(input,27,FOLLOW_23); 

            			newLeafNode(otherlv_0, grammarAccess.getTransitionAccess().getTransitionKeyword_0());
            		
            // InternalEDsl.g:661:3: ( (lv_type_1_0= ruleLabelType ) )
            // InternalEDsl.g:662:4: (lv_type_1_0= ruleLabelType )
            {
            // InternalEDsl.g:662:4: (lv_type_1_0= ruleLabelType )
            // InternalEDsl.g:663:5: lv_type_1_0= ruleLabelType
            {

            					newCompositeNode(grammarAccess.getTransitionAccess().getTypeLabelTypeEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_3);
            lv_type_1_0=ruleLabelType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTransitionRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"editor.edsl.EDsl.LabelType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalEDsl.g:680:3: ( (lv_name_2_0= ruleEString ) )
            // InternalEDsl.g:681:4: (lv_name_2_0= ruleEString )
            {
            // InternalEDsl.g:681:4: (lv_name_2_0= ruleEString )
            // InternalEDsl.g:682:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getTransitionAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_18);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTransitionRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"editor.edsl.EDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,23,FOLLOW_24); 

            			newLeafNode(otherlv_3, grammarAccess.getTransitionAccess().getLeftParenthesisKeyword_3());
            		
            otherlv_4=(Token)match(input,28,FOLLOW_12); 

            			newLeafNode(otherlv_4, grammarAccess.getTransitionAccess().getSourceKeyword_4());
            		
            // InternalEDsl.g:707:3: ( (otherlv_5= RULE_ID ) )
            // InternalEDsl.g:708:4: (otherlv_5= RULE_ID )
            {
            // InternalEDsl.g:708:4: (otherlv_5= RULE_ID )
            // InternalEDsl.g:709:5: otherlv_5= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				
            otherlv_5=(Token)match(input,RULE_ID,FOLLOW_20); 

            					newLeafNode(otherlv_5, grammarAccess.getTransitionAccess().getSourceStateCrossReference_5_0());
            				

            }


            }

            otherlv_6=(Token)match(input,14,FOLLOW_25); 

            			newLeafNode(otherlv_6, grammarAccess.getTransitionAccess().getCommaKeyword_6());
            		
            otherlv_7=(Token)match(input,29,FOLLOW_12); 

            			newLeafNode(otherlv_7, grammarAccess.getTransitionAccess().getTargetKeyword_7());
            		
            // InternalEDsl.g:728:3: ( (otherlv_8= RULE_ID ) )
            // InternalEDsl.g:729:4: (otherlv_8= RULE_ID )
            {
            // InternalEDsl.g:729:4: (otherlv_8= RULE_ID )
            // InternalEDsl.g:730:5: otherlv_8= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				
            otherlv_8=(Token)match(input,RULE_ID,FOLLOW_20); 

            					newLeafNode(otherlv_8, grammarAccess.getTransitionAccess().getTargetStateCrossReference_8_0());
            				

            }


            }

            otherlv_9=(Token)match(input,14,FOLLOW_26); 

            			newLeafNode(otherlv_9, grammarAccess.getTransitionAccess().getCommaKeyword_9());
            		
            otherlv_10=(Token)match(input,30,FOLLOW_12); 

            			newLeafNode(otherlv_10, grammarAccess.getTransitionAccess().getChannelKeyword_10());
            		
            // InternalEDsl.g:749:3: ( (otherlv_11= RULE_ID ) )
            // InternalEDsl.g:750:4: (otherlv_11= RULE_ID )
            {
            // InternalEDsl.g:750:4: (otherlv_11= RULE_ID )
            // InternalEDsl.g:751:5: otherlv_11= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				
            otherlv_11=(Token)match(input,RULE_ID,FOLLOW_27); 

            					newLeafNode(otherlv_11, grammarAccess.getTransitionAccess().getChannelChannelCrossReference_11_0());
            				

            }


            }

            otherlv_12=(Token)match(input,26,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getTransitionAccess().getRightParenthesisKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTransition"


    // $ANTLR start "ruleChannelType"
    // InternalEDsl.g:770:1: ruleChannelType returns [Enumerator current=null] : ( (enumLiteral_0= 'synch' ) | (enumLiteral_1= 'asynch' ) ) ;
    public final Enumerator ruleChannelType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalEDsl.g:776:2: ( ( (enumLiteral_0= 'synch' ) | (enumLiteral_1= 'asynch' ) ) )
            // InternalEDsl.g:777:2: ( (enumLiteral_0= 'synch' ) | (enumLiteral_1= 'asynch' ) )
            {
            // InternalEDsl.g:777:2: ( (enumLiteral_0= 'synch' ) | (enumLiteral_1= 'asynch' ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==31) ) {
                alt12=1;
            }
            else if ( (LA12_0==32) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalEDsl.g:778:3: (enumLiteral_0= 'synch' )
                    {
                    // InternalEDsl.g:778:3: (enumLiteral_0= 'synch' )
                    // InternalEDsl.g:779:4: enumLiteral_0= 'synch'
                    {
                    enumLiteral_0=(Token)match(input,31,FOLLOW_2); 

                    				current = grammarAccess.getChannelTypeAccess().getSynchEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getChannelTypeAccess().getSynchEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalEDsl.g:786:3: (enumLiteral_1= 'asynch' )
                    {
                    // InternalEDsl.g:786:3: (enumLiteral_1= 'asynch' )
                    // InternalEDsl.g:787:4: enumLiteral_1= 'asynch'
                    {
                    enumLiteral_1=(Token)match(input,32,FOLLOW_2); 

                    				current = grammarAccess.getChannelTypeAccess().getAsynchEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getChannelTypeAccess().getAsynchEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChannelType"


    // $ANTLR start "ruleLabelType"
    // InternalEDsl.g:797:1: ruleLabelType returns [Enumerator current=null] : ( (enumLiteral_0= 'send' ) | (enumLiteral_1= 'receive' ) ) ;
    public final Enumerator ruleLabelType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalEDsl.g:803:2: ( ( (enumLiteral_0= 'send' ) | (enumLiteral_1= 'receive' ) ) )
            // InternalEDsl.g:804:2: ( (enumLiteral_0= 'send' ) | (enumLiteral_1= 'receive' ) )
            {
            // InternalEDsl.g:804:2: ( (enumLiteral_0= 'send' ) | (enumLiteral_1= 'receive' ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==33) ) {
                alt13=1;
            }
            else if ( (LA13_0==34) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalEDsl.g:805:3: (enumLiteral_0= 'send' )
                    {
                    // InternalEDsl.g:805:3: (enumLiteral_0= 'send' )
                    // InternalEDsl.g:806:4: enumLiteral_0= 'send'
                    {
                    enumLiteral_0=(Token)match(input,33,FOLLOW_2); 

                    				current = grammarAccess.getLabelTypeAccess().getSendEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getLabelTypeAccess().getSendEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalEDsl.g:813:3: (enumLiteral_1= 'receive' )
                    {
                    // InternalEDsl.g:813:3: (enumLiteral_1= 'receive' )
                    // InternalEDsl.g:814:4: enumLiteral_1= 'receive'
                    {
                    enumLiteral_1=(Token)match(input,34,FOLLOW_2); 

                    				current = grammarAccess.getLabelTypeAccess().getReceiveEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getLabelTypeAccess().getReceiveEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLabelType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x000000000001A000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000188000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000108000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000180000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000004004000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000600000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000004000000L});

}