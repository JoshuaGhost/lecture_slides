/**
 */
package editor;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Channel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link editor.Channel#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see editor.EditorPackage#getChannel()
 * @model
 * @generated
 */
public interface Channel extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link editor.ChannelType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see editor.ChannelType
	 * @see #setType(ChannelType)
	 * @see editor.EditorPackage#getChannel_Type()
	 * @model required="true"
	 * @generated
	 */
	ChannelType getType();

	/**
	 * Sets the value of the '{@link editor.Channel#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see editor.ChannelType
	 * @see #getType()
	 * @generated
	 */
	void setType(ChannelType value);

} // Channel
