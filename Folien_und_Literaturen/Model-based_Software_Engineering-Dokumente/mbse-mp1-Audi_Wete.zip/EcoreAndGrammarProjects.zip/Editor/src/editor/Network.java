/**
 */
package editor;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link editor.Network#getStateMachine <em>State Machine</em>}</li>
 *   <li>{@link editor.Network#getDeclaration <em>Declaration</em>}</li>
 * </ul>
 *
 * @see editor.EditorPackage#getNetwork()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='NoDuplicatesDeclarationName NoDuplicatesStateMachineName'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot NoDuplicatesDeclarationName='Tuple {\n\tmessage : String = \'There are more than one channel of the network \\\'\' + self.name + \'\\\' with de same name.\',\n\tstatus : Boolean = self.declaration->forAll(d1, d2 |\n\t\t\t\td1 <> d2 implies d1.name <> d2.name)\n}.status' NoDuplicatesStateMachineName='Tuple {\n\tmessage : String = \'There are more than one state machine of the network \\\'\' + self.name + \'\\\' with de same name.\',\n\tstatus : Boolean = self.stateMachine->forAll(sm1,\n\t\t\t\tsm2 | sm1 <> sm2 implies sm1.name <> sm2.name)\n}.status'"
 * @generated
 */
public interface Network extends NamedElement {
	/**
	 * Returns the value of the '<em><b>State Machine</b></em>' containment reference list.
	 * The list contents are of type {@link editor.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State Machine</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State Machine</em>' containment reference list.
	 * @see editor.EditorPackage#getNetwork_StateMachine()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<StateMachine> getStateMachine();

	/**
	 * Returns the value of the '<em><b>Declaration</b></em>' containment reference list.
	 * The list contents are of type {@link editor.Channel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Declaration</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Declaration</em>' containment reference list.
	 * @see editor.EditorPackage#getNetwork_Declaration()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Channel> getDeclaration();

} // Network
