/**
 */
package MiniProject2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network Interpreter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link MiniProject2.NetworkInterpreter#getRtnetwork <em>Rtnetwork</em>}</li>
 * </ul>
 *
 * @see MiniProject2.MiniProject2Package#getNetworkInterpreter()
 * @model
 * @generated
 */
public interface NetworkInterpreter extends EObject {
	/**
	 * Returns the value of the '<em><b>Rtnetwork</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rtnetwork</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rtnetwork</em>' reference.
	 * @see #setRtnetwork(RuntimeNetwork)
	 * @see MiniProject2.MiniProject2Package#getNetworkInterpreter_Rtnetwork()
	 * @model required="true"
	 * @generated
	 */
	RuntimeNetwork getRtnetwork();

	/**
	 * Sets the value of the '{@link MiniProject2.NetworkInterpreter#getRtnetwork <em>Rtnetwork</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rtnetwork</em>' reference.
	 * @see #getRtnetwork()
	 * @generated
	 */
	void setRtnetwork(RuntimeNetwork value);

} // NetworkInterpreter
