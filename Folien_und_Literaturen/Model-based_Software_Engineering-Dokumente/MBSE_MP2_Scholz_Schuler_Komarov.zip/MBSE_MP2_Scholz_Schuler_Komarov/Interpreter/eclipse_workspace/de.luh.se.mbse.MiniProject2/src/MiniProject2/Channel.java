/**
 */
package MiniProject2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Channel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link MiniProject2.Channel#getName <em>Name</em>}</li>
 *   <li>{@link MiniProject2.Channel#isSynchron <em>Synchron</em>}</li>
 * </ul>
 *
 * @see MiniProject2.MiniProject2Package#getChannel()
 * @model
 * @generated
 */
public interface Channel extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see MiniProject2.MiniProject2Package#getChannel_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link MiniProject2.Channel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Synchron</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Synchron</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Synchron</em>' attribute.
	 * @see #setSynchron(boolean)
	 * @see MiniProject2.MiniProject2Package#getChannel_Synchron()
	 * @model
	 * @generated
	 */
	boolean isSynchron();

	/**
	 * Sets the value of the '{@link MiniProject2.Channel#isSynchron <em>Synchron</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Synchron</em>' attribute.
	 * @see #isSynchron()
	 * @generated
	 */
	void setSynchron(boolean value);

} // Channel
