/**
 */
package MiniProject2;

import java.util.Map;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Runtime Network</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link MiniProject2.RuntimeNetwork#getNetwork <em>Network</em>}</li>
 *   <li>{@link MiniProject2.RuntimeNetwork#getMachineToCurrentState <em>Machine To Current State</em>}</li>
 *   <li>{@link MiniProject2.RuntimeNetwork#getChannelToBuffer <em>Channel To Buffer</em>}</li>
 * </ul>
 *
 * @see MiniProject2.MiniProject2Package#getRuntimeNetwork()
 * @model
 * @generated
 */
public interface RuntimeNetwork extends EObject {
	/**
	 * Returns the value of the '<em><b>Network</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Network</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Network</em>' reference.
	 * @see #setNetwork(Network)
	 * @see MiniProject2.MiniProject2Package#getRuntimeNetwork_Network()
	 * @model required="true"
	 * @generated
	 */
	Network getNetwork();

	/**
	 * Sets the value of the '{@link MiniProject2.RuntimeNetwork#getNetwork <em>Network</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Network</em>' reference.
	 * @see #getNetwork()
	 * @generated
	 */
	void setNetwork(Network value);

	/**
	 * Returns the value of the '<em><b>Machine To Current State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Machine To Current State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Machine To Current State</em>' attribute.
	 * @see #setMachineToCurrentState(Map)
	 * @see MiniProject2.MiniProject2Package#getRuntimeNetwork_MachineToCurrentState()
	 * @model required="true" transient="true"
	 * @generated
	 */
	Map<StateMachine, State> getMachineToCurrentState();

	/**
	 * Sets the value of the '{@link MiniProject2.RuntimeNetwork#getMachineToCurrentState <em>Machine To Current State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Machine To Current State</em>' attribute.
	 * @see #getMachineToCurrentState()
	 * @generated
	 */
	void setMachineToCurrentState(Map<StateMachine, State> value);

	/**
	 * Returns the value of the '<em><b>Channel To Buffer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Channel To Buffer</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Channel To Buffer</em>' attribute.
	 * @see #setChannelToBuffer(Map)
	 * @see MiniProject2.MiniProject2Package#getRuntimeNetwork_ChannelToBuffer()
	 * @model required="true" transient="true"
	 * @generated
	 */
	Map<Channel, Integer> getChannelToBuffer();

	/**
	 * Sets the value of the '{@link MiniProject2.RuntimeNetwork#getChannelToBuffer <em>Channel To Buffer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Channel To Buffer</em>' attribute.
	 * @see #getChannelToBuffer()
	 * @generated
	 */
	void setChannelToBuffer(Map<Channel, Integer> value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean makeStep();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void init();

} // RuntimeNetwork
