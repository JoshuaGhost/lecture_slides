/**
 */
package MiniProject2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link MiniProject2.Network#getStatemachine <em>Statemachine</em>}</li>
 *   <li>{@link MiniProject2.Network#getName <em>Name</em>}</li>
 *   <li>{@link MiniProject2.Network#getChannel <em>Channel</em>}</li>
 * </ul>
 *
 * @see MiniProject2.MiniProject2Package#getNetwork()
 * @model
 * @generated
 */
public interface Network extends EObject {
	/**
	 * Returns the value of the '<em><b>Statemachine</b></em>' reference list.
	 * The list contents are of type {@link MiniProject2.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Statemachine</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Statemachine</em>' reference list.
	 * @see MiniProject2.MiniProject2Package#getNetwork_Statemachine()
	 * @model
	 * @generated
	 */
	EList<StateMachine> getStatemachine();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see MiniProject2.MiniProject2Package#getNetwork_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link MiniProject2.Network#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Channel</b></em>' reference list.
	 * The list contents are of type {@link MiniProject2.Channel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Channel</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Channel</em>' reference list.
	 * @see MiniProject2.MiniProject2Package#getNetwork_Channel()
	 * @model
	 * @generated
	 */
	EList<Channel> getChannel();

} // Network
