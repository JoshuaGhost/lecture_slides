import java.io.File;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import MiniProject2.Channel;
import MiniProject2.MiniProject2Package;
import MiniProject2.RuntimeNetwork;
import MiniProject2.StateMachine;
import MiniProject2.impl.MiniProject2FactoryImpl;
import MiniProject2.impl.NetworkImpl;

public class RuntimeNetworkController {
	public static MiniProject2FactoryImpl miniProject2FactoryImpl = new MiniProject2FactoryImpl();
	public static RuntimeNetwork runtimenetwork;

	public static void main(String[] args) {
		ResourceSet resourceSet = new ResourceSetImpl();
		 
		// Register the default resource factory -- only needed for stand-alone!
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
		    Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		 
		// Register the package -- only needed for stand-alone!
		// You find the correct name of the package in the generated model code
		@SuppressWarnings("unused")
		MiniProject2Package libraryPackage = MiniProject2Package.eINSTANCE;
		
		
		URI fileURI = URI.createFileURI(new File("PedestrianCrossing.xmi").getAbsolutePath());
		//URI fileURI = URI.createFileURI(new File("Cafe.xmi").getAbsolutePath());
		//URI fileURI = URI.createFileURI(new File("Candy.xmi").getAbsolutePath());
		
		Resource resource = resourceSet.getResource(fileURI, true);
		
		runtimenetwork = miniProject2FactoryImpl.createRuntimeNetwork();
		runtimenetwork.setNetwork((NetworkImpl) resource.getContents().get(0));
		runtimenetwork.init();
		
		long startTime = System.currentTimeMillis();
		
		int x = 0;
		boolean y = true;
		while (x < 100 && y) {
			System.out.println("----------------------");
			
			System.out.print("Buffers: ");
			for (Channel c : runtimenetwork.getChannelToBuffer().keySet()) {
				System.out.print(c.getName() + ":" + runtimenetwork.getChannelToBuffer().get(c) + " ");
			}
			System.out.print("\n");
			
			y = runtimenetwork.makeStep();
			
			System.out.print("SysState: ");
			for (StateMachine sm : runtimenetwork.getNetwork().getStatemachine()) {
				System.out.print(sm.getName() + ":" + runtimenetwork.getMachineToCurrentState().get(sm).getName() + " ");
			}
			System.out.print("\n");
			
			x++;
		}
		if (!y) {
			System.out.println("No possible step found.");
		}
		
		long stopTime = System.currentTimeMillis();
	    long elapsedTime = stopTime - startTime;
		System.out.println("Performed " + x + " steps in " + elapsedTime + " milliseconds.");
	}

}
