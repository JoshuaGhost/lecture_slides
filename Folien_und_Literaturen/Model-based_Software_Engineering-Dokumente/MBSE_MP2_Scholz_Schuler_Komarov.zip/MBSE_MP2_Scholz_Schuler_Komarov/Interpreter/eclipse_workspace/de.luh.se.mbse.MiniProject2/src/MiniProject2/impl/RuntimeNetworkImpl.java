/**
 */
package MiniProject2.impl;

import MiniProject2.Channel;
import MiniProject2.MiniProject2Package;
import MiniProject2.Network;
import MiniProject2.RuntimeNetwork;
import MiniProject2.State;
import MiniProject2.StateMachine;
import MiniProject2.Transition;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Runtime Network</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link MiniProject2.impl.RuntimeNetworkImpl#getNetwork <em>Network</em>}</li>
 *   <li>{@link MiniProject2.impl.RuntimeNetworkImpl#getMachineToCurrentState <em>Machine To Current State</em>}</li>
 *   <li>{@link MiniProject2.impl.RuntimeNetworkImpl#getChannelToBuffer <em>Channel To Buffer</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RuntimeNetworkImpl extends MinimalEObjectImpl.Container implements RuntimeNetwork {
	/**
	 * The cached value of the '{@link #getNetwork() <em>Network</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNetwork()
	 * @generated
	 * @ordered
	 */
	protected Network network;

	/**
	 * The cached value of the '{@link #getMachineToCurrentState() <em>Machine To Current State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMachineToCurrentState()
	 * @generated
	 * @ordered
	 */
	protected Map<StateMachine, State> machineToCurrentState;

	/**
	 * The cached value of the '{@link #getChannelToBuffer() <em>Channel To Buffer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChannelToBuffer()
	 * @generated
	 * @ordered
	 */
	protected Map<Channel, Integer> channelToBuffer;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RuntimeNetworkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniProject2Package.Literals.RUNTIME_NETWORK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Network getNetwork() {
		if (network != null && network.eIsProxy()) {
			InternalEObject oldNetwork = (InternalEObject)network;
			network = (Network)eResolveProxy(oldNetwork);
			if (network != oldNetwork) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MiniProject2Package.RUNTIME_NETWORK__NETWORK, oldNetwork, network));
			}
		}
		return network;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Network basicGetNetwork() {
		return network;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNetwork(Network newNetwork) {
		Network oldNetwork = network;
		network = newNetwork;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MiniProject2Package.RUNTIME_NETWORK__NETWORK, oldNetwork, network));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Map<StateMachine, State> getMachineToCurrentState() {
		return machineToCurrentState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMachineToCurrentState(Map<StateMachine, State> newMachineToCurrentState) {
		Map<StateMachine, State> oldMachineToCurrentState = machineToCurrentState;
		machineToCurrentState = newMachineToCurrentState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MiniProject2Package.RUNTIME_NETWORK__MACHINE_TO_CURRENT_STATE, oldMachineToCurrentState, machineToCurrentState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Map<Channel, Integer> getChannelToBuffer() {
		return channelToBuffer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChannelToBuffer(Map<Channel, Integer> newChannelToBuffer) {
		Map<Channel, Integer> oldChannelToBuffer = channelToBuffer;
		channelToBuffer = newChannelToBuffer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MiniProject2Package.RUNTIME_NETWORK__CHANNEL_TO_BUFFER, oldChannelToBuffer, channelToBuffer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return 
	 * @generated NOT
	 */
	public boolean makeStep() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		//throw new UnsupportedOperationException();
		Map<StateMachine, State> currentStateMap = this.getMachineToCurrentState();
		Map<Transition, StateMachine> possibleTransitions = new HashMap<Transition, StateMachine>();
		Map<Channel, Integer> buffers = this.getChannelToBuffer();
		
		for (StateMachine sm: this.getNetwork().getStatemachine()) {
			for (Transition tr : sm.getTransition()) {
				if (tr.getSource().equals(currentStateMap.get(sm))) {
					possibleTransitions.put(tr, sm);
					//System.out.print("[Possible Transition] ");
					//System.out.print(" Source: " + tr.getSource().getName());
					//System.out.print(" Target: " + tr.getTarget().getName());
					//System.out.println(" Channel: " + tr.getChannel().getName());
				}
			}
		}
		
		if (possibleTransitions.size() == 0) {
			System.out.println("No transition possible.");
			return false;
		}
		
		
		List<Transition> trans = new ArrayList<>();
		trans.addAll(possibleTransitions.keySet());
		Collections.shuffle(trans, new Random(System.nanoTime()));
		for (Transition tr1 : trans) {
			Channel channel = tr1.getChannel();
			
			if (!channel.isSynchron()) {
				if (tr1.isSend()) {
					currentStateMap.put(possibleTransitions.get(tr1), tr1.getTarget());
					Integer currentBuffer = buffers.get(channel);
					buffers.put(channel, currentBuffer+1);
					System.out.print("[ASYNC - " + channel.getName() + " SEND] ");
					System.out.print(possibleTransitions.get(tr1).getName() + "." + tr1.getSource().getName());
					System.out.print(" to ");
					System.out.print(possibleTransitions.get(tr1).getName() + "."  + tr1.getTarget().getName());
					System.out.print("\n");
					return true;
				} else if (buffers.get(channel) > 0) {
					currentStateMap.put(possibleTransitions.get(tr1), tr1.getTarget());
					Integer currentBuffer = buffers.get(channel);
					buffers.put(channel, currentBuffer-1);
					System.out.print("[ASYNC - " + channel.getName() + " RECV] ");
					System.out.print(possibleTransitions.get(tr1).getName() + "." + tr1.getSource().getName());
					System.out.print(" to ");
					System.out.print(possibleTransitions.get(tr1).getName() + "."  + tr1.getTarget().getName());
					System.out.print("\n");
					return true;
				}
			} else {
				LinkedList<Transition> candidates_tr1 = new LinkedList<>();
				
				for (Transition tr2 : possibleTransitions.keySet()) {
					if (tr2.getChannel().equals(channel) && tr2.isSend() != tr1.isSend()) {
						candidates_tr1.add(tr2);
					}
				}
				
				if (candidates_tr1.size() > 0) {
					if (tr1.isSend()) {
						Collections.shuffle(candidates_tr1, new Random(System.nanoTime()));
						Transition chosen = candidates_tr1.get(0);
						currentStateMap.put(possibleTransitions.get(tr1), tr1.getTarget());
						currentStateMap.put(possibleTransitions.get(chosen), chosen.getTarget());
						
						System.out.print("[SYNC - " + channel.getName());
						System.out.print(" SEND] ");
						System.out.print(possibleTransitions.get(tr1).getName() + "." + tr1.getSource().getName());
						System.out.print(" to ");
						System.out.print(possibleTransitions.get(tr1).getName() + "."  + tr1.getTarget().getName());
						System.out.print("\n");
						System.out.print("[SYNC - " + channel.getName());
						System.out.print(" RECV] ");
						System.out.print(possibleTransitions.get(chosen).getName() + "." + chosen.getSource().getName());
						System.out.print(" to ");
						System.out.print(possibleTransitions.get(chosen).getName() + "."  + chosen.getTarget().getName());
						System.out.print("\n");
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	public void init() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		//throw new UnsupportedOperationException();
		this.setMachineToCurrentState(new HashMap<StateMachine,State>());
		for (StateMachine sm: this.getNetwork().getStatemachine()) {
			for (State state : sm.getState()) {
				if (sm.getInitial().equals(state.getName())) {
					this.getMachineToCurrentState().put(sm, state);
				}
			}
			if (this.getMachineToCurrentState().get(sm) == null) {
				System.err.println("Error: Statemachine has no initial state: " +  sm);
				return;
			}
		}
		//System.out.println(this.getMachineToCurrentState());

		this.setChannelToBuffer(new HashMap<Channel,Integer>());
		for (Channel channel : this.getNetwork().getChannel()) {
			if (!channel.isSynchron()) {
				this.getChannelToBuffer().put(channel, 0);
			}
			for (StateMachine sm : this.getNetwork().getStatemachine()) {
				for (Transition tr : sm.getTransition()) {
					if (tr.getChannel().getName().equals(channel.getName())) {
						tr.setChannel(channel);
					}
				}
			}
		}
		
		//System.out.println(this.getChannelToBuffer());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MiniProject2Package.RUNTIME_NETWORK__NETWORK:
				if (resolve) return getNetwork();
				return basicGetNetwork();
			case MiniProject2Package.RUNTIME_NETWORK__MACHINE_TO_CURRENT_STATE:
				return getMachineToCurrentState();
			case MiniProject2Package.RUNTIME_NETWORK__CHANNEL_TO_BUFFER:
				return getChannelToBuffer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MiniProject2Package.RUNTIME_NETWORK__NETWORK:
				setNetwork((Network)newValue);
				return;
			case MiniProject2Package.RUNTIME_NETWORK__MACHINE_TO_CURRENT_STATE:
				setMachineToCurrentState((Map<StateMachine, State>)newValue);
				return;
			case MiniProject2Package.RUNTIME_NETWORK__CHANNEL_TO_BUFFER:
				setChannelToBuffer((Map<Channel, Integer>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MiniProject2Package.RUNTIME_NETWORK__NETWORK:
				setNetwork((Network)null);
				return;
			case MiniProject2Package.RUNTIME_NETWORK__MACHINE_TO_CURRENT_STATE:
				setMachineToCurrentState((Map<StateMachine, State>)null);
				return;
			case MiniProject2Package.RUNTIME_NETWORK__CHANNEL_TO_BUFFER:
				setChannelToBuffer((Map<Channel, Integer>)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MiniProject2Package.RUNTIME_NETWORK__NETWORK:
				return network != null;
			case MiniProject2Package.RUNTIME_NETWORK__MACHINE_TO_CURRENT_STATE:
				return machineToCurrentState != null;
			case MiniProject2Package.RUNTIME_NETWORK__CHANNEL_TO_BUFFER:
				return channelToBuffer != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case MiniProject2Package.RUNTIME_NETWORK___MAKE_STEP:
				return makeStep();
			case MiniProject2Package.RUNTIME_NETWORK___INIT:
				init();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (machineToCurrentState: ");
		result.append(machineToCurrentState);
		result.append(", channelToBuffer: ");
		result.append(channelToBuffer);
		result.append(')');
		return result.toString();
	}

} //RuntimeNetworkImpl
