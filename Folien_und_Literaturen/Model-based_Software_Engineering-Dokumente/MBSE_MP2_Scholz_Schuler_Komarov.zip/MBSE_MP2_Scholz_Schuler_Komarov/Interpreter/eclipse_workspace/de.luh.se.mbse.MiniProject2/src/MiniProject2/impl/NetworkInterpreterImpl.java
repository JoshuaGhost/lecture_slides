/**
 */
package MiniProject2.impl;

import MiniProject2.MiniProject2Package;
import MiniProject2.NetworkInterpreter;
import MiniProject2.RuntimeNetwork;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Network Interpreter</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link MiniProject2.impl.NetworkInterpreterImpl#getRtnetwork <em>Rtnetwork</em>}</li>
 * </ul>
 *
 * @generated
 */
public class NetworkInterpreterImpl extends MinimalEObjectImpl.Container implements NetworkInterpreter {
	/**
	 * The cached value of the '{@link #getRtnetwork() <em>Rtnetwork</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRtnetwork()
	 * @generated
	 * @ordered
	 */
	protected RuntimeNetwork rtnetwork;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkInterpreterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MiniProject2Package.Literals.NETWORK_INTERPRETER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RuntimeNetwork getRtnetwork() {
		if (rtnetwork != null && rtnetwork.eIsProxy()) {
			InternalEObject oldRtnetwork = (InternalEObject)rtnetwork;
			rtnetwork = (RuntimeNetwork)eResolveProxy(oldRtnetwork);
			if (rtnetwork != oldRtnetwork) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MiniProject2Package.NETWORK_INTERPRETER__RTNETWORK, oldRtnetwork, rtnetwork));
			}
		}
		return rtnetwork;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RuntimeNetwork basicGetRtnetwork() {
		return rtnetwork;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRtnetwork(RuntimeNetwork newRtnetwork) {
		RuntimeNetwork oldRtnetwork = rtnetwork;
		rtnetwork = newRtnetwork;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MiniProject2Package.NETWORK_INTERPRETER__RTNETWORK, oldRtnetwork, rtnetwork));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MiniProject2Package.NETWORK_INTERPRETER__RTNETWORK:
				if (resolve) return getRtnetwork();
				return basicGetRtnetwork();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MiniProject2Package.NETWORK_INTERPRETER__RTNETWORK:
				setRtnetwork((RuntimeNetwork)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MiniProject2Package.NETWORK_INTERPRETER__RTNETWORK:
				setRtnetwork((RuntimeNetwork)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MiniProject2Package.NETWORK_INTERPRETER__RTNETWORK:
				return rtnetwork != null;
		}
		return super.eIsSet(featureID);
	}

} //NetworkInterpreterImpl
