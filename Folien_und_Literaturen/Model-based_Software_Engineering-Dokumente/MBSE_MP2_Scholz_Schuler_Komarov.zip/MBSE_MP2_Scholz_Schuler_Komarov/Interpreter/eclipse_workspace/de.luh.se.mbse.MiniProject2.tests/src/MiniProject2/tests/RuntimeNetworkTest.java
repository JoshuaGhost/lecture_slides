/**
 */
package MiniProject2.tests;

import MiniProject2.MiniProject2Factory;
import MiniProject2.RuntimeNetwork;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Runtime Network</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link MiniProject2.RuntimeNetwork#makeStep() <em>Make Step</em>}</li>
 *   <li>{@link MiniProject2.RuntimeNetwork#init() <em>Init</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class RuntimeNetworkTest extends TestCase {

	/**
	 * The fixture for this Runtime Network test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RuntimeNetwork fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(RuntimeNetworkTest.class);
	}

	/**
	 * Constructs a new Runtime Network test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RuntimeNetworkTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Runtime Network test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(RuntimeNetwork fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Runtime Network test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RuntimeNetwork getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MiniProject2Factory.eINSTANCE.createRuntimeNetwork());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link MiniProject2.RuntimeNetwork#makeStep() <em>Make Step</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see MiniProject2.RuntimeNetwork#makeStep()
	 * @generated
	 */
	public void testMakeStep() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link MiniProject2.RuntimeNetwork#init() <em>Init</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see MiniProject2.RuntimeNetwork#init()
	 * @generated
	 */
	public void testInit() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //RuntimeNetworkTest
