/**
 */
package MiniProject2.tests;

import MiniProject2.MiniProject2Factory;
import MiniProject2.NetworkInterpreter;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Network Interpreter</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class NetworkInterpreterTest extends TestCase {

	/**
	 * The fixture for this Network Interpreter test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkInterpreter fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(NetworkInterpreterTest.class);
	}

	/**
	 * Constructs a new Network Interpreter test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkInterpreterTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Network Interpreter test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(NetworkInterpreter fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Network Interpreter test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkInterpreter getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MiniProject2Factory.eINSTANCE.createNetworkInterpreter());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //NetworkInterpreterTest
