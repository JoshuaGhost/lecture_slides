package de.luh.se.mbse.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import de.luh.se.mbse.services.MiniProject1DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMiniProject1DSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Network'", "'{'", "'statemachines'", "','", "'}'", "'channels'", "'StateMachine'", "'initialstate'", "'states'", "'transitions'", "'Channel'", "'synchron'", "'State'", "'Transition'", "'source'", "'target'", "'channel'", "'send'", "'true'", "'false'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMiniProject1DSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMiniProject1DSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMiniProject1DSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMiniProject1DSL.g"; }



     	private MiniProject1DSLGrammarAccess grammarAccess;

        public InternalMiniProject1DSLParser(TokenStream input, MiniProject1DSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Network";
       	}

       	@Override
       	protected MiniProject1DSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleNetwork"
    // InternalMiniProject1DSL.g:64:1: entryRuleNetwork returns [EObject current=null] : iv_ruleNetwork= ruleNetwork EOF ;
    public final EObject entryRuleNetwork() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNetwork = null;


        try {
            // InternalMiniProject1DSL.g:64:48: (iv_ruleNetwork= ruleNetwork EOF )
            // InternalMiniProject1DSL.g:65:2: iv_ruleNetwork= ruleNetwork EOF
            {
             newCompositeNode(grammarAccess.getNetworkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNetwork=ruleNetwork();

            state._fsp--;

             current =iv_ruleNetwork; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNetwork"


    // $ANTLR start "ruleNetwork"
    // InternalMiniProject1DSL.g:71:1: ruleNetwork returns [EObject current=null] : ( () otherlv_1= 'Network' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}' )? (otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}' )? otherlv_16= '}' ) ;
    public final EObject ruleNetwork() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_statemachine_6_0 = null;

        EObject lv_statemachine_8_0 = null;

        EObject lv_channel_12_0 = null;

        EObject lv_channel_14_0 = null;



        	enterRule();

        try {
            // InternalMiniProject1DSL.g:77:2: ( ( () otherlv_1= 'Network' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}' )? (otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}' )? otherlv_16= '}' ) )
            // InternalMiniProject1DSL.g:78:2: ( () otherlv_1= 'Network' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}' )? (otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}' )? otherlv_16= '}' )
            {
            // InternalMiniProject1DSL.g:78:2: ( () otherlv_1= 'Network' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}' )? (otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}' )? otherlv_16= '}' )
            // InternalMiniProject1DSL.g:79:3: () otherlv_1= 'Network' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}' )? (otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}' )? otherlv_16= '}'
            {
            // InternalMiniProject1DSL.g:79:3: ()
            // InternalMiniProject1DSL.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getNetworkAccess().getNetworkAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getNetworkAccess().getNetworkKeyword_1());
            		
            // InternalMiniProject1DSL.g:90:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMiniProject1DSL.g:91:4: (lv_name_2_0= ruleEString )
            {
            // InternalMiniProject1DSL.g:91:4: (lv_name_2_0= ruleEString )
            // InternalMiniProject1DSL.g:92:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getNetworkAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getNetworkRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"de.luh.se.mbse.MiniProject1DSL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_5); 

            			newLeafNode(otherlv_3, grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMiniProject1DSL.g:113:3: (otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==13) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMiniProject1DSL.g:114:4: otherlv_4= 'statemachines' otherlv_5= '{' ( (lv_statemachine_6_0= ruleStateMachine ) ) (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )* otherlv_9= '}'
                    {
                    otherlv_4=(Token)match(input,13,FOLLOW_4); 

                    				newLeafNode(otherlv_4, grammarAccess.getNetworkAccess().getStatemachinesKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,12,FOLLOW_6); 

                    				newLeafNode(otherlv_5, grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMiniProject1DSL.g:122:4: ( (lv_statemachine_6_0= ruleStateMachine ) )
                    // InternalMiniProject1DSL.g:123:5: (lv_statemachine_6_0= ruleStateMachine )
                    {
                    // InternalMiniProject1DSL.g:123:5: (lv_statemachine_6_0= ruleStateMachine )
                    // InternalMiniProject1DSL.g:124:6: lv_statemachine_6_0= ruleStateMachine
                    {

                    						newCompositeNode(grammarAccess.getNetworkAccess().getStatemachineStateMachineParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_statemachine_6_0=ruleStateMachine();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkRule());
                    						}
                    						add(
                    							current,
                    							"statemachine",
                    							lv_statemachine_6_0,
                    							"de.luh.se.mbse.MiniProject1DSL.StateMachine");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMiniProject1DSL.g:141:4: (otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==14) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalMiniProject1DSL.g:142:5: otherlv_7= ',' ( (lv_statemachine_8_0= ruleStateMachine ) )
                    	    {
                    	    otherlv_7=(Token)match(input,14,FOLLOW_6); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getNetworkAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMiniProject1DSL.g:146:5: ( (lv_statemachine_8_0= ruleStateMachine ) )
                    	    // InternalMiniProject1DSL.g:147:6: (lv_statemachine_8_0= ruleStateMachine )
                    	    {
                    	    // InternalMiniProject1DSL.g:147:6: (lv_statemachine_8_0= ruleStateMachine )
                    	    // InternalMiniProject1DSL.g:148:7: lv_statemachine_8_0= ruleStateMachine
                    	    {

                    	    							newCompositeNode(grammarAccess.getNetworkAccess().getStatemachineStateMachineParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_statemachine_8_0=ruleStateMachine();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getNetworkRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"statemachine",
                    	    								lv_statemachine_8_0,
                    	    								"de.luh.se.mbse.MiniProject1DSL.StateMachine");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,15,FOLLOW_8); 

                    				newLeafNode(otherlv_9, grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalMiniProject1DSL.g:171:3: (otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==16) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalMiniProject1DSL.g:172:4: otherlv_10= 'channels' otherlv_11= '{' ( (lv_channel_12_0= ruleChannel ) ) (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )* otherlv_15= '}'
                    {
                    otherlv_10=(Token)match(input,16,FOLLOW_4); 

                    				newLeafNode(otherlv_10, grammarAccess.getNetworkAccess().getChannelsKeyword_5_0());
                    			
                    otherlv_11=(Token)match(input,12,FOLLOW_9); 

                    				newLeafNode(otherlv_11, grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalMiniProject1DSL.g:180:4: ( (lv_channel_12_0= ruleChannel ) )
                    // InternalMiniProject1DSL.g:181:5: (lv_channel_12_0= ruleChannel )
                    {
                    // InternalMiniProject1DSL.g:181:5: (lv_channel_12_0= ruleChannel )
                    // InternalMiniProject1DSL.g:182:6: lv_channel_12_0= ruleChannel
                    {

                    						newCompositeNode(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_channel_12_0=ruleChannel();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetworkRule());
                    						}
                    						add(
                    							current,
                    							"channel",
                    							lv_channel_12_0,
                    							"de.luh.se.mbse.MiniProject1DSL.Channel");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMiniProject1DSL.g:199:4: (otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) ) )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==14) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalMiniProject1DSL.g:200:5: otherlv_13= ',' ( (lv_channel_14_0= ruleChannel ) )
                    	    {
                    	    otherlv_13=(Token)match(input,14,FOLLOW_9); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getNetworkAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalMiniProject1DSL.g:204:5: ( (lv_channel_14_0= ruleChannel ) )
                    	    // InternalMiniProject1DSL.g:205:6: (lv_channel_14_0= ruleChannel )
                    	    {
                    	    // InternalMiniProject1DSL.g:205:6: (lv_channel_14_0= ruleChannel )
                    	    // InternalMiniProject1DSL.g:206:7: lv_channel_14_0= ruleChannel
                    	    {

                    	    							newCompositeNode(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_channel_14_0=ruleChannel();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getNetworkRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"channel",
                    	    								lv_channel_14_0,
                    	    								"de.luh.se.mbse.MiniProject1DSL.Channel");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    otherlv_15=(Token)match(input,15,FOLLOW_10); 

                    				newLeafNode(otherlv_15, grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            otherlv_16=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNetwork"


    // $ANTLR start "entryRuleStateMachine"
    // InternalMiniProject1DSL.g:237:1: entryRuleStateMachine returns [EObject current=null] : iv_ruleStateMachine= ruleStateMachine EOF ;
    public final EObject entryRuleStateMachine() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStateMachine = null;


        try {
            // InternalMiniProject1DSL.g:237:53: (iv_ruleStateMachine= ruleStateMachine EOF )
            // InternalMiniProject1DSL.g:238:2: iv_ruleStateMachine= ruleStateMachine EOF
            {
             newCompositeNode(grammarAccess.getStateMachineRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStateMachine=ruleStateMachine();

            state._fsp--;

             current =iv_ruleStateMachine; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStateMachine"


    // $ANTLR start "ruleStateMachine"
    // InternalMiniProject1DSL.g:244:1: ruleStateMachine returns [EObject current=null] : ( () otherlv_1= 'StateMachine' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'initialstate' ( ( ruleEString ) ) )? (otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}' )? (otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}' )? otherlv_18= '}' ) ;
    public final EObject ruleStateMachine() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_state_8_0 = null;

        EObject lv_state_10_0 = null;

        EObject lv_transition_14_0 = null;

        EObject lv_transition_16_0 = null;



        	enterRule();

        try {
            // InternalMiniProject1DSL.g:250:2: ( ( () otherlv_1= 'StateMachine' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'initialstate' ( ( ruleEString ) ) )? (otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}' )? (otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}' )? otherlv_18= '}' ) )
            // InternalMiniProject1DSL.g:251:2: ( () otherlv_1= 'StateMachine' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'initialstate' ( ( ruleEString ) ) )? (otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}' )? (otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}' )? otherlv_18= '}' )
            {
            // InternalMiniProject1DSL.g:251:2: ( () otherlv_1= 'StateMachine' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'initialstate' ( ( ruleEString ) ) )? (otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}' )? (otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}' )? otherlv_18= '}' )
            // InternalMiniProject1DSL.g:252:3: () otherlv_1= 'StateMachine' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'initialstate' ( ( ruleEString ) ) )? (otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}' )? (otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}' )? otherlv_18= '}'
            {
            // InternalMiniProject1DSL.g:252:3: ()
            // InternalMiniProject1DSL.g:253:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStateMachineAccess().getStateMachineAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,17,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getStateMachineAccess().getStateMachineKeyword_1());
            		
            // InternalMiniProject1DSL.g:263:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMiniProject1DSL.g:264:4: (lv_name_2_0= ruleEString )
            {
            // InternalMiniProject1DSL.g:264:4: (lv_name_2_0= ruleEString )
            // InternalMiniProject1DSL.g:265:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getStateMachineAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStateMachineRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"de.luh.se.mbse.MiniProject1DSL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_11); 

            			newLeafNode(otherlv_3, grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMiniProject1DSL.g:286:3: (otherlv_4= 'initialstate' ( ( ruleEString ) ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==18) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalMiniProject1DSL.g:287:4: otherlv_4= 'initialstate' ( ( ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,18,FOLLOW_3); 

                    				newLeafNode(otherlv_4, grammarAccess.getStateMachineAccess().getInitialstateKeyword_4_0());
                    			
                    // InternalMiniProject1DSL.g:291:4: ( ( ruleEString ) )
                    // InternalMiniProject1DSL.g:292:5: ( ruleEString )
                    {
                    // InternalMiniProject1DSL.g:292:5: ( ruleEString )
                    // InternalMiniProject1DSL.g:293:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getStateMachineRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getStateMachineAccess().getInitialStateCrossReference_4_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMiniProject1DSL.g:308:3: (otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}' )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMiniProject1DSL.g:309:4: otherlv_6= 'states' otherlv_7= '{' ( (lv_state_8_0= ruleState ) ) (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )* otherlv_11= '}'
                    {
                    otherlv_6=(Token)match(input,19,FOLLOW_4); 

                    				newLeafNode(otherlv_6, grammarAccess.getStateMachineAccess().getStatesKeyword_5_0());
                    			
                    otherlv_7=(Token)match(input,12,FOLLOW_13); 

                    				newLeafNode(otherlv_7, grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalMiniProject1DSL.g:317:4: ( (lv_state_8_0= ruleState ) )
                    // InternalMiniProject1DSL.g:318:5: (lv_state_8_0= ruleState )
                    {
                    // InternalMiniProject1DSL.g:318:5: (lv_state_8_0= ruleState )
                    // InternalMiniProject1DSL.g:319:6: lv_state_8_0= ruleState
                    {

                    						newCompositeNode(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_state_8_0=ruleState();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    						}
                    						add(
                    							current,
                    							"state",
                    							lv_state_8_0,
                    							"de.luh.se.mbse.MiniProject1DSL.State");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMiniProject1DSL.g:336:4: (otherlv_9= ',' ( (lv_state_10_0= ruleState ) ) )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==14) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // InternalMiniProject1DSL.g:337:5: otherlv_9= ',' ( (lv_state_10_0= ruleState ) )
                    	    {
                    	    otherlv_9=(Token)match(input,14,FOLLOW_13); 

                    	    					newLeafNode(otherlv_9, grammarAccess.getStateMachineAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalMiniProject1DSL.g:341:5: ( (lv_state_10_0= ruleState ) )
                    	    // InternalMiniProject1DSL.g:342:6: (lv_state_10_0= ruleState )
                    	    {
                    	    // InternalMiniProject1DSL.g:342:6: (lv_state_10_0= ruleState )
                    	    // InternalMiniProject1DSL.g:343:7: lv_state_10_0= ruleState
                    	    {

                    	    							newCompositeNode(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_state_10_0=ruleState();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"state",
                    	    								lv_state_10_0,
                    	    								"de.luh.se.mbse.MiniProject1DSL.State");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);

                    otherlv_11=(Token)match(input,15,FOLLOW_14); 

                    				newLeafNode(otherlv_11, grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalMiniProject1DSL.g:366:3: (otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==20) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMiniProject1DSL.g:367:4: otherlv_12= 'transitions' otherlv_13= '{' ( (lv_transition_14_0= ruleTransition ) ) (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )* otherlv_17= '}'
                    {
                    otherlv_12=(Token)match(input,20,FOLLOW_4); 

                    				newLeafNode(otherlv_12, grammarAccess.getStateMachineAccess().getTransitionsKeyword_6_0());
                    			
                    otherlv_13=(Token)match(input,12,FOLLOW_15); 

                    				newLeafNode(otherlv_13, grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalMiniProject1DSL.g:375:4: ( (lv_transition_14_0= ruleTransition ) )
                    // InternalMiniProject1DSL.g:376:5: (lv_transition_14_0= ruleTransition )
                    {
                    // InternalMiniProject1DSL.g:376:5: (lv_transition_14_0= ruleTransition )
                    // InternalMiniProject1DSL.g:377:6: lv_transition_14_0= ruleTransition
                    {

                    						newCompositeNode(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_transition_14_0=ruleTransition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    						}
                    						add(
                    							current,
                    							"transition",
                    							lv_transition_14_0,
                    							"de.luh.se.mbse.MiniProject1DSL.Transition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMiniProject1DSL.g:394:4: (otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) ) )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==14) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // InternalMiniProject1DSL.g:395:5: otherlv_15= ',' ( (lv_transition_16_0= ruleTransition ) )
                    	    {
                    	    otherlv_15=(Token)match(input,14,FOLLOW_15); 

                    	    					newLeafNode(otherlv_15, grammarAccess.getStateMachineAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalMiniProject1DSL.g:399:5: ( (lv_transition_16_0= ruleTransition ) )
                    	    // InternalMiniProject1DSL.g:400:6: (lv_transition_16_0= ruleTransition )
                    	    {
                    	    // InternalMiniProject1DSL.g:400:6: (lv_transition_16_0= ruleTransition )
                    	    // InternalMiniProject1DSL.g:401:7: lv_transition_16_0= ruleTransition
                    	    {

                    	    							newCompositeNode(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_transition_16_0=ruleTransition();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getStateMachineRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"transition",
                    	    								lv_transition_16_0,
                    	    								"de.luh.se.mbse.MiniProject1DSL.Transition");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    otherlv_17=(Token)match(input,15,FOLLOW_10); 

                    				newLeafNode(otherlv_17, grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_18=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStateMachine"


    // $ANTLR start "entryRuleEString"
    // InternalMiniProject1DSL.g:432:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMiniProject1DSL.g:432:47: (iv_ruleEString= ruleEString EOF )
            // InternalMiniProject1DSL.g:433:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMiniProject1DSL.g:439:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMiniProject1DSL.g:445:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMiniProject1DSL.g:446:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMiniProject1DSL.g:446:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_STRING) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_ID) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalMiniProject1DSL.g:447:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMiniProject1DSL.g:455:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleChannel"
    // InternalMiniProject1DSL.g:466:1: entryRuleChannel returns [EObject current=null] : iv_ruleChannel= ruleChannel EOF ;
    public final EObject entryRuleChannel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChannel = null;


        try {
            // InternalMiniProject1DSL.g:466:48: (iv_ruleChannel= ruleChannel EOF )
            // InternalMiniProject1DSL.g:467:2: iv_ruleChannel= ruleChannel EOF
            {
             newCompositeNode(grammarAccess.getChannelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChannel=ruleChannel();

            state._fsp--;

             current =iv_ruleChannel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChannel"


    // $ANTLR start "ruleChannel"
    // InternalMiniProject1DSL.g:473:1: ruleChannel returns [EObject current=null] : ( () otherlv_1= 'Channel' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'synchron' ( (lv_synchron_5_0= ruleEBoolean ) ) otherlv_6= '}' ) ;
    public final EObject ruleChannel() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_synchron_5_0 = null;



        	enterRule();

        try {
            // InternalMiniProject1DSL.g:479:2: ( ( () otherlv_1= 'Channel' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'synchron' ( (lv_synchron_5_0= ruleEBoolean ) ) otherlv_6= '}' ) )
            // InternalMiniProject1DSL.g:480:2: ( () otherlv_1= 'Channel' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'synchron' ( (lv_synchron_5_0= ruleEBoolean ) ) otherlv_6= '}' )
            {
            // InternalMiniProject1DSL.g:480:2: ( () otherlv_1= 'Channel' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'synchron' ( (lv_synchron_5_0= ruleEBoolean ) ) otherlv_6= '}' )
            // InternalMiniProject1DSL.g:481:3: () otherlv_1= 'Channel' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'synchron' ( (lv_synchron_5_0= ruleEBoolean ) ) otherlv_6= '}'
            {
            // InternalMiniProject1DSL.g:481:3: ()
            // InternalMiniProject1DSL.g:482:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getChannelAccess().getChannelAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getChannelAccess().getChannelKeyword_1());
            		
            // InternalMiniProject1DSL.g:492:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMiniProject1DSL.g:493:4: (lv_name_2_0= ruleEString )
            {
            // InternalMiniProject1DSL.g:493:4: (lv_name_2_0= ruleEString )
            // InternalMiniProject1DSL.g:494:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChannelRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"de.luh.se.mbse.MiniProject1DSL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_16); 

            			newLeafNode(otherlv_3, grammarAccess.getChannelAccess().getLeftCurlyBracketKeyword_3());
            		
            otherlv_4=(Token)match(input,22,FOLLOW_17); 

            			newLeafNode(otherlv_4, grammarAccess.getChannelAccess().getSynchronKeyword_4());
            		
            // InternalMiniProject1DSL.g:519:3: ( (lv_synchron_5_0= ruleEBoolean ) )
            // InternalMiniProject1DSL.g:520:4: (lv_synchron_5_0= ruleEBoolean )
            {
            // InternalMiniProject1DSL.g:520:4: (lv_synchron_5_0= ruleEBoolean )
            // InternalMiniProject1DSL.g:521:5: lv_synchron_5_0= ruleEBoolean
            {

            					newCompositeNode(grammarAccess.getChannelAccess().getSynchronEBooleanParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_10);
            lv_synchron_5_0=ruleEBoolean();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getChannelRule());
            					}
            					set(
            						current,
            						"synchron",
            						lv_synchron_5_0,
            						"de.luh.se.mbse.MiniProject1DSL.EBoolean");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getChannelAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChannel"


    // $ANTLR start "entryRuleState"
    // InternalMiniProject1DSL.g:546:1: entryRuleState returns [EObject current=null] : iv_ruleState= ruleState EOF ;
    public final EObject entryRuleState() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleState = null;


        try {
            // InternalMiniProject1DSL.g:546:46: (iv_ruleState= ruleState EOF )
            // InternalMiniProject1DSL.g:547:2: iv_ruleState= ruleState EOF
            {
             newCompositeNode(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleState=ruleState();

            state._fsp--;

             current =iv_ruleState; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalMiniProject1DSL.g:553:1: ruleState returns [EObject current=null] : ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) ) ;
    public final EObject ruleState() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;



        	enterRule();

        try {
            // InternalMiniProject1DSL.g:559:2: ( ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) ) )
            // InternalMiniProject1DSL.g:560:2: ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) )
            {
            // InternalMiniProject1DSL.g:560:2: ( () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) ) )
            // InternalMiniProject1DSL.g:561:3: () otherlv_1= 'State' ( (lv_name_2_0= ruleEString ) )
            {
            // InternalMiniProject1DSL.g:561:3: ()
            // InternalMiniProject1DSL.g:562:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getStateAccess().getStateAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,23,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getStateAccess().getStateKeyword_1());
            		
            // InternalMiniProject1DSL.g:572:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMiniProject1DSL.g:573:4: (lv_name_2_0= ruleEString )
            {
            // InternalMiniProject1DSL.g:573:4: (lv_name_2_0= ruleEString )
            // InternalMiniProject1DSL.g:574:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStateRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"de.luh.se.mbse.MiniProject1DSL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleTransition"
    // InternalMiniProject1DSL.g:595:1: entryRuleTransition returns [EObject current=null] : iv_ruleTransition= ruleTransition EOF ;
    public final EObject entryRuleTransition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTransition = null;


        try {
            // InternalMiniProject1DSL.g:595:51: (iv_ruleTransition= ruleTransition EOF )
            // InternalMiniProject1DSL.g:596:2: iv_ruleTransition= ruleTransition EOF
            {
             newCompositeNode(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTransition=ruleTransition();

            state._fsp--;

             current =iv_ruleTransition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalMiniProject1DSL.g:602:1: ruleTransition returns [EObject current=null] : (otherlv_0= 'Transition' otherlv_1= '{' otherlv_2= 'source' ( ( ruleEString ) ) otherlv_4= 'target' ( ( ruleEString ) ) otherlv_6= 'channel' ( ( ruleEString ) ) otherlv_8= 'send' ( (lv_send_9_0= ruleEBoolean ) ) otherlv_10= '}' ) ;
    public final EObject ruleTransition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_send_9_0 = null;



        	enterRule();

        try {
            // InternalMiniProject1DSL.g:608:2: ( (otherlv_0= 'Transition' otherlv_1= '{' otherlv_2= 'source' ( ( ruleEString ) ) otherlv_4= 'target' ( ( ruleEString ) ) otherlv_6= 'channel' ( ( ruleEString ) ) otherlv_8= 'send' ( (lv_send_9_0= ruleEBoolean ) ) otherlv_10= '}' ) )
            // InternalMiniProject1DSL.g:609:2: (otherlv_0= 'Transition' otherlv_1= '{' otherlv_2= 'source' ( ( ruleEString ) ) otherlv_4= 'target' ( ( ruleEString ) ) otherlv_6= 'channel' ( ( ruleEString ) ) otherlv_8= 'send' ( (lv_send_9_0= ruleEBoolean ) ) otherlv_10= '}' )
            {
            // InternalMiniProject1DSL.g:609:2: (otherlv_0= 'Transition' otherlv_1= '{' otherlv_2= 'source' ( ( ruleEString ) ) otherlv_4= 'target' ( ( ruleEString ) ) otherlv_6= 'channel' ( ( ruleEString ) ) otherlv_8= 'send' ( (lv_send_9_0= ruleEBoolean ) ) otherlv_10= '}' )
            // InternalMiniProject1DSL.g:610:3: otherlv_0= 'Transition' otherlv_1= '{' otherlv_2= 'source' ( ( ruleEString ) ) otherlv_4= 'target' ( ( ruleEString ) ) otherlv_6= 'channel' ( ( ruleEString ) ) otherlv_8= 'send' ( (lv_send_9_0= ruleEBoolean ) ) otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,24,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getTransitionAccess().getTransitionKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_18); 

            			newLeafNode(otherlv_1, grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,25,FOLLOW_3); 

            			newLeafNode(otherlv_2, grammarAccess.getTransitionAccess().getSourceKeyword_2());
            		
            // InternalMiniProject1DSL.g:622:3: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:623:4: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:623:4: ( ruleEString )
            // InternalMiniProject1DSL.g:624:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				

            					newCompositeNode(grammarAccess.getTransitionAccess().getSourceStateCrossReference_3_0());
            				
            pushFollow(FOLLOW_19);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,26,FOLLOW_3); 

            			newLeafNode(otherlv_4, grammarAccess.getTransitionAccess().getTargetKeyword_4());
            		
            // InternalMiniProject1DSL.g:642:3: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:643:4: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:643:4: ( ruleEString )
            // InternalMiniProject1DSL.g:644:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				

            					newCompositeNode(grammarAccess.getTransitionAccess().getTargetStateCrossReference_5_0());
            				
            pushFollow(FOLLOW_20);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_3); 

            			newLeafNode(otherlv_6, grammarAccess.getTransitionAccess().getChannelKeyword_6());
            		
            // InternalMiniProject1DSL.g:662:3: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:663:4: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:663:4: ( ruleEString )
            // InternalMiniProject1DSL.g:664:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTransitionRule());
            					}
            				

            					newCompositeNode(grammarAccess.getTransitionAccess().getChannelChannelCrossReference_7_0());
            				
            pushFollow(FOLLOW_21);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,28,FOLLOW_17); 

            			newLeafNode(otherlv_8, grammarAccess.getTransitionAccess().getSendKeyword_8());
            		
            // InternalMiniProject1DSL.g:682:3: ( (lv_send_9_0= ruleEBoolean ) )
            // InternalMiniProject1DSL.g:683:4: (lv_send_9_0= ruleEBoolean )
            {
            // InternalMiniProject1DSL.g:683:4: (lv_send_9_0= ruleEBoolean )
            // InternalMiniProject1DSL.g:684:5: lv_send_9_0= ruleEBoolean
            {

            					newCompositeNode(grammarAccess.getTransitionAccess().getSendEBooleanParserRuleCall_9_0());
            				
            pushFollow(FOLLOW_10);
            lv_send_9_0=ruleEBoolean();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTransitionRule());
            					}
            					set(
            						current,
            						"send",
            						lv_send_9_0,
            						"de.luh.se.mbse.MiniProject1DSL.EBoolean");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTransition"


    // $ANTLR start "entryRuleEBoolean"
    // InternalMiniProject1DSL.g:709:1: entryRuleEBoolean returns [String current=null] : iv_ruleEBoolean= ruleEBoolean EOF ;
    public final String entryRuleEBoolean() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEBoolean = null;


        try {
            // InternalMiniProject1DSL.g:709:48: (iv_ruleEBoolean= ruleEBoolean EOF )
            // InternalMiniProject1DSL.g:710:2: iv_ruleEBoolean= ruleEBoolean EOF
            {
             newCompositeNode(grammarAccess.getEBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEBoolean=ruleEBoolean();

            state._fsp--;

             current =iv_ruleEBoolean.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEBoolean"


    // $ANTLR start "ruleEBoolean"
    // InternalMiniProject1DSL.g:716:1: ruleEBoolean returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'true' | kw= 'false' ) ;
    public final AntlrDatatypeRuleToken ruleEBoolean() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMiniProject1DSL.g:722:2: ( (kw= 'true' | kw= 'false' ) )
            // InternalMiniProject1DSL.g:723:2: (kw= 'true' | kw= 'false' )
            {
            // InternalMiniProject1DSL.g:723:2: (kw= 'true' | kw= 'false' )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==29) ) {
                alt11=1;
            }
            else if ( (LA11_0==30) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalMiniProject1DSL.g:724:3: kw= 'true'
                    {
                    kw=(Token)match(input,29,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEBooleanAccess().getTrueKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMiniProject1DSL.g:730:3: kw= 'false'
                    {
                    kw=(Token)match(input,30,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEBooleanAccess().getFalseKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEBoolean"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x000000000001A000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000000001C8000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000188000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000108000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000060000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000010000000L});

}