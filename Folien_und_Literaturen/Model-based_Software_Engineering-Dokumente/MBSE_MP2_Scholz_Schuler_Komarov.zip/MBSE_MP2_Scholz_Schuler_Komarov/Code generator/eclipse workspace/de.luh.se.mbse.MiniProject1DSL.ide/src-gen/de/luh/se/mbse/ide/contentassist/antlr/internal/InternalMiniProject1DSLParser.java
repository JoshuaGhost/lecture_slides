package de.luh.se.mbse.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import de.luh.se.mbse.services.MiniProject1DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMiniProject1DSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'true'", "'false'", "'Network'", "'{'", "'}'", "'statemachines'", "','", "'channels'", "'StateMachine'", "'initialstate'", "'states'", "'transitions'", "'Channel'", "'synchron'", "'State'", "'Transition'", "'source'", "'target'", "'channel'", "'send'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMiniProject1DSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMiniProject1DSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMiniProject1DSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMiniProject1DSL.g"; }


    	private MiniProject1DSLGrammarAccess grammarAccess;

    	public void setGrammarAccess(MiniProject1DSLGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleNetwork"
    // InternalMiniProject1DSL.g:53:1: entryRuleNetwork : ruleNetwork EOF ;
    public final void entryRuleNetwork() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:54:1: ( ruleNetwork EOF )
            // InternalMiniProject1DSL.g:55:1: ruleNetwork EOF
            {
             before(grammarAccess.getNetworkRule()); 
            pushFollow(FOLLOW_1);
            ruleNetwork();

            state._fsp--;

             after(grammarAccess.getNetworkRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNetwork"


    // $ANTLR start "ruleNetwork"
    // InternalMiniProject1DSL.g:62:1: ruleNetwork : ( ( rule__Network__Group__0 ) ) ;
    public final void ruleNetwork() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:66:2: ( ( ( rule__Network__Group__0 ) ) )
            // InternalMiniProject1DSL.g:67:2: ( ( rule__Network__Group__0 ) )
            {
            // InternalMiniProject1DSL.g:67:2: ( ( rule__Network__Group__0 ) )
            // InternalMiniProject1DSL.g:68:3: ( rule__Network__Group__0 )
            {
             before(grammarAccess.getNetworkAccess().getGroup()); 
            // InternalMiniProject1DSL.g:69:3: ( rule__Network__Group__0 )
            // InternalMiniProject1DSL.g:69:4: rule__Network__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNetwork"


    // $ANTLR start "entryRuleStateMachine"
    // InternalMiniProject1DSL.g:78:1: entryRuleStateMachine : ruleStateMachine EOF ;
    public final void entryRuleStateMachine() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:79:1: ( ruleStateMachine EOF )
            // InternalMiniProject1DSL.g:80:1: ruleStateMachine EOF
            {
             before(grammarAccess.getStateMachineRule()); 
            pushFollow(FOLLOW_1);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getStateMachineRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStateMachine"


    // $ANTLR start "ruleStateMachine"
    // InternalMiniProject1DSL.g:87:1: ruleStateMachine : ( ( rule__StateMachine__Group__0 ) ) ;
    public final void ruleStateMachine() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:91:2: ( ( ( rule__StateMachine__Group__0 ) ) )
            // InternalMiniProject1DSL.g:92:2: ( ( rule__StateMachine__Group__0 ) )
            {
            // InternalMiniProject1DSL.g:92:2: ( ( rule__StateMachine__Group__0 ) )
            // InternalMiniProject1DSL.g:93:3: ( rule__StateMachine__Group__0 )
            {
             before(grammarAccess.getStateMachineAccess().getGroup()); 
            // InternalMiniProject1DSL.g:94:3: ( rule__StateMachine__Group__0 )
            // InternalMiniProject1DSL.g:94:4: rule__StateMachine__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStateMachine"


    // $ANTLR start "entryRuleEString"
    // InternalMiniProject1DSL.g:103:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:104:1: ( ruleEString EOF )
            // InternalMiniProject1DSL.g:105:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMiniProject1DSL.g:112:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:116:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalMiniProject1DSL.g:117:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalMiniProject1DSL.g:117:2: ( ( rule__EString__Alternatives ) )
            // InternalMiniProject1DSL.g:118:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalMiniProject1DSL.g:119:3: ( rule__EString__Alternatives )
            // InternalMiniProject1DSL.g:119:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleChannel"
    // InternalMiniProject1DSL.g:128:1: entryRuleChannel : ruleChannel EOF ;
    public final void entryRuleChannel() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:129:1: ( ruleChannel EOF )
            // InternalMiniProject1DSL.g:130:1: ruleChannel EOF
            {
             before(grammarAccess.getChannelRule()); 
            pushFollow(FOLLOW_1);
            ruleChannel();

            state._fsp--;

             after(grammarAccess.getChannelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleChannel"


    // $ANTLR start "ruleChannel"
    // InternalMiniProject1DSL.g:137:1: ruleChannel : ( ( rule__Channel__Group__0 ) ) ;
    public final void ruleChannel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:141:2: ( ( ( rule__Channel__Group__0 ) ) )
            // InternalMiniProject1DSL.g:142:2: ( ( rule__Channel__Group__0 ) )
            {
            // InternalMiniProject1DSL.g:142:2: ( ( rule__Channel__Group__0 ) )
            // InternalMiniProject1DSL.g:143:3: ( rule__Channel__Group__0 )
            {
             before(grammarAccess.getChannelAccess().getGroup()); 
            // InternalMiniProject1DSL.g:144:3: ( rule__Channel__Group__0 )
            // InternalMiniProject1DSL.g:144:4: rule__Channel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Channel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getChannelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleChannel"


    // $ANTLR start "entryRuleState"
    // InternalMiniProject1DSL.g:153:1: entryRuleState : ruleState EOF ;
    public final void entryRuleState() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:154:1: ( ruleState EOF )
            // InternalMiniProject1DSL.g:155:1: ruleState EOF
            {
             before(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleState"


    // $ANTLR start "ruleState"
    // InternalMiniProject1DSL.g:162:1: ruleState : ( ( rule__State__Group__0 ) ) ;
    public final void ruleState() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:166:2: ( ( ( rule__State__Group__0 ) ) )
            // InternalMiniProject1DSL.g:167:2: ( ( rule__State__Group__0 ) )
            {
            // InternalMiniProject1DSL.g:167:2: ( ( rule__State__Group__0 ) )
            // InternalMiniProject1DSL.g:168:3: ( rule__State__Group__0 )
            {
             before(grammarAccess.getStateAccess().getGroup()); 
            // InternalMiniProject1DSL.g:169:3: ( rule__State__Group__0 )
            // InternalMiniProject1DSL.g:169:4: rule__State__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleState"


    // $ANTLR start "entryRuleTransition"
    // InternalMiniProject1DSL.g:178:1: entryRuleTransition : ruleTransition EOF ;
    public final void entryRuleTransition() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:179:1: ( ruleTransition EOF )
            // InternalMiniProject1DSL.g:180:1: ruleTransition EOF
            {
             before(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getTransitionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTransition"


    // $ANTLR start "ruleTransition"
    // InternalMiniProject1DSL.g:187:1: ruleTransition : ( ( rule__Transition__Group__0 ) ) ;
    public final void ruleTransition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:191:2: ( ( ( rule__Transition__Group__0 ) ) )
            // InternalMiniProject1DSL.g:192:2: ( ( rule__Transition__Group__0 ) )
            {
            // InternalMiniProject1DSL.g:192:2: ( ( rule__Transition__Group__0 ) )
            // InternalMiniProject1DSL.g:193:3: ( rule__Transition__Group__0 )
            {
             before(grammarAccess.getTransitionAccess().getGroup()); 
            // InternalMiniProject1DSL.g:194:3: ( rule__Transition__Group__0 )
            // InternalMiniProject1DSL.g:194:4: rule__Transition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTransition"


    // $ANTLR start "entryRuleEBoolean"
    // InternalMiniProject1DSL.g:203:1: entryRuleEBoolean : ruleEBoolean EOF ;
    public final void entryRuleEBoolean() throws RecognitionException {
        try {
            // InternalMiniProject1DSL.g:204:1: ( ruleEBoolean EOF )
            // InternalMiniProject1DSL.g:205:1: ruleEBoolean EOF
            {
             before(grammarAccess.getEBooleanRule()); 
            pushFollow(FOLLOW_1);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getEBooleanRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEBoolean"


    // $ANTLR start "ruleEBoolean"
    // InternalMiniProject1DSL.g:212:1: ruleEBoolean : ( ( rule__EBoolean__Alternatives ) ) ;
    public final void ruleEBoolean() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:216:2: ( ( ( rule__EBoolean__Alternatives ) ) )
            // InternalMiniProject1DSL.g:217:2: ( ( rule__EBoolean__Alternatives ) )
            {
            // InternalMiniProject1DSL.g:217:2: ( ( rule__EBoolean__Alternatives ) )
            // InternalMiniProject1DSL.g:218:3: ( rule__EBoolean__Alternatives )
            {
             before(grammarAccess.getEBooleanAccess().getAlternatives()); 
            // InternalMiniProject1DSL.g:219:3: ( rule__EBoolean__Alternatives )
            // InternalMiniProject1DSL.g:219:4: rule__EBoolean__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EBoolean__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEBooleanAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEBoolean"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalMiniProject1DSL.g:227:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:231:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_ID) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMiniProject1DSL.g:232:2: ( RULE_STRING )
                    {
                    // InternalMiniProject1DSL.g:232:2: ( RULE_STRING )
                    // InternalMiniProject1DSL.g:233:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMiniProject1DSL.g:238:2: ( RULE_ID )
                    {
                    // InternalMiniProject1DSL.g:238:2: ( RULE_ID )
                    // InternalMiniProject1DSL.g:239:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__EBoolean__Alternatives"
    // InternalMiniProject1DSL.g:248:1: rule__EBoolean__Alternatives : ( ( 'true' ) | ( 'false' ) );
    public final void rule__EBoolean__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:252:1: ( ( 'true' ) | ( 'false' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==11) ) {
                alt2=1;
            }
            else if ( (LA2_0==12) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalMiniProject1DSL.g:253:2: ( 'true' )
                    {
                    // InternalMiniProject1DSL.g:253:2: ( 'true' )
                    // InternalMiniProject1DSL.g:254:3: 'true'
                    {
                     before(grammarAccess.getEBooleanAccess().getTrueKeyword_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getEBooleanAccess().getTrueKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMiniProject1DSL.g:259:2: ( 'false' )
                    {
                    // InternalMiniProject1DSL.g:259:2: ( 'false' )
                    // InternalMiniProject1DSL.g:260:3: 'false'
                    {
                     before(grammarAccess.getEBooleanAccess().getFalseKeyword_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getEBooleanAccess().getFalseKeyword_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EBoolean__Alternatives"


    // $ANTLR start "rule__Network__Group__0"
    // InternalMiniProject1DSL.g:269:1: rule__Network__Group__0 : rule__Network__Group__0__Impl rule__Network__Group__1 ;
    public final void rule__Network__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:273:1: ( rule__Network__Group__0__Impl rule__Network__Group__1 )
            // InternalMiniProject1DSL.g:274:2: rule__Network__Group__0__Impl rule__Network__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Network__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__0"


    // $ANTLR start "rule__Network__Group__0__Impl"
    // InternalMiniProject1DSL.g:281:1: rule__Network__Group__0__Impl : ( () ) ;
    public final void rule__Network__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:285:1: ( ( () ) )
            // InternalMiniProject1DSL.g:286:1: ( () )
            {
            // InternalMiniProject1DSL.g:286:1: ( () )
            // InternalMiniProject1DSL.g:287:2: ()
            {
             before(grammarAccess.getNetworkAccess().getNetworkAction_0()); 
            // InternalMiniProject1DSL.g:288:2: ()
            // InternalMiniProject1DSL.g:288:3: 
            {
            }

             after(grammarAccess.getNetworkAccess().getNetworkAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__0__Impl"


    // $ANTLR start "rule__Network__Group__1"
    // InternalMiniProject1DSL.g:296:1: rule__Network__Group__1 : rule__Network__Group__1__Impl rule__Network__Group__2 ;
    public final void rule__Network__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:300:1: ( rule__Network__Group__1__Impl rule__Network__Group__2 )
            // InternalMiniProject1DSL.g:301:2: rule__Network__Group__1__Impl rule__Network__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Network__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__1"


    // $ANTLR start "rule__Network__Group__1__Impl"
    // InternalMiniProject1DSL.g:308:1: rule__Network__Group__1__Impl : ( 'Network' ) ;
    public final void rule__Network__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:312:1: ( ( 'Network' ) )
            // InternalMiniProject1DSL.g:313:1: ( 'Network' )
            {
            // InternalMiniProject1DSL.g:313:1: ( 'Network' )
            // InternalMiniProject1DSL.g:314:2: 'Network'
            {
             before(grammarAccess.getNetworkAccess().getNetworkKeyword_1()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getNetworkKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__1__Impl"


    // $ANTLR start "rule__Network__Group__2"
    // InternalMiniProject1DSL.g:323:1: rule__Network__Group__2 : rule__Network__Group__2__Impl rule__Network__Group__3 ;
    public final void rule__Network__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:327:1: ( rule__Network__Group__2__Impl rule__Network__Group__3 )
            // InternalMiniProject1DSL.g:328:2: rule__Network__Group__2__Impl rule__Network__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Network__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__2"


    // $ANTLR start "rule__Network__Group__2__Impl"
    // InternalMiniProject1DSL.g:335:1: rule__Network__Group__2__Impl : ( ( rule__Network__NameAssignment_2 ) ) ;
    public final void rule__Network__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:339:1: ( ( ( rule__Network__NameAssignment_2 ) ) )
            // InternalMiniProject1DSL.g:340:1: ( ( rule__Network__NameAssignment_2 ) )
            {
            // InternalMiniProject1DSL.g:340:1: ( ( rule__Network__NameAssignment_2 ) )
            // InternalMiniProject1DSL.g:341:2: ( rule__Network__NameAssignment_2 )
            {
             before(grammarAccess.getNetworkAccess().getNameAssignment_2()); 
            // InternalMiniProject1DSL.g:342:2: ( rule__Network__NameAssignment_2 )
            // InternalMiniProject1DSL.g:342:3: rule__Network__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Network__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__2__Impl"


    // $ANTLR start "rule__Network__Group__3"
    // InternalMiniProject1DSL.g:350:1: rule__Network__Group__3 : rule__Network__Group__3__Impl rule__Network__Group__4 ;
    public final void rule__Network__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:354:1: ( rule__Network__Group__3__Impl rule__Network__Group__4 )
            // InternalMiniProject1DSL.g:355:2: rule__Network__Group__3__Impl rule__Network__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Network__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__3"


    // $ANTLR start "rule__Network__Group__3__Impl"
    // InternalMiniProject1DSL.g:362:1: rule__Network__Group__3__Impl : ( '{' ) ;
    public final void rule__Network__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:366:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:367:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:367:1: ( '{' )
            // InternalMiniProject1DSL.g:368:2: '{'
            {
             before(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__3__Impl"


    // $ANTLR start "rule__Network__Group__4"
    // InternalMiniProject1DSL.g:377:1: rule__Network__Group__4 : rule__Network__Group__4__Impl rule__Network__Group__5 ;
    public final void rule__Network__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:381:1: ( rule__Network__Group__4__Impl rule__Network__Group__5 )
            // InternalMiniProject1DSL.g:382:2: rule__Network__Group__4__Impl rule__Network__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__Network__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__4"


    // $ANTLR start "rule__Network__Group__4__Impl"
    // InternalMiniProject1DSL.g:389:1: rule__Network__Group__4__Impl : ( ( rule__Network__Group_4__0 )? ) ;
    public final void rule__Network__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:393:1: ( ( ( rule__Network__Group_4__0 )? ) )
            // InternalMiniProject1DSL.g:394:1: ( ( rule__Network__Group_4__0 )? )
            {
            // InternalMiniProject1DSL.g:394:1: ( ( rule__Network__Group_4__0 )? )
            // InternalMiniProject1DSL.g:395:2: ( rule__Network__Group_4__0 )?
            {
             before(grammarAccess.getNetworkAccess().getGroup_4()); 
            // InternalMiniProject1DSL.g:396:2: ( rule__Network__Group_4__0 )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==16) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalMiniProject1DSL.g:396:3: rule__Network__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Network__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getNetworkAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__4__Impl"


    // $ANTLR start "rule__Network__Group__5"
    // InternalMiniProject1DSL.g:404:1: rule__Network__Group__5 : rule__Network__Group__5__Impl rule__Network__Group__6 ;
    public final void rule__Network__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:408:1: ( rule__Network__Group__5__Impl rule__Network__Group__6 )
            // InternalMiniProject1DSL.g:409:2: rule__Network__Group__5__Impl rule__Network__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__Network__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__5"


    // $ANTLR start "rule__Network__Group__5__Impl"
    // InternalMiniProject1DSL.g:416:1: rule__Network__Group__5__Impl : ( ( rule__Network__Group_5__0 )? ) ;
    public final void rule__Network__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:420:1: ( ( ( rule__Network__Group_5__0 )? ) )
            // InternalMiniProject1DSL.g:421:1: ( ( rule__Network__Group_5__0 )? )
            {
            // InternalMiniProject1DSL.g:421:1: ( ( rule__Network__Group_5__0 )? )
            // InternalMiniProject1DSL.g:422:2: ( rule__Network__Group_5__0 )?
            {
             before(grammarAccess.getNetworkAccess().getGroup_5()); 
            // InternalMiniProject1DSL.g:423:2: ( rule__Network__Group_5__0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==18) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalMiniProject1DSL.g:423:3: rule__Network__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Network__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getNetworkAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__5__Impl"


    // $ANTLR start "rule__Network__Group__6"
    // InternalMiniProject1DSL.g:431:1: rule__Network__Group__6 : rule__Network__Group__6__Impl ;
    public final void rule__Network__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:435:1: ( rule__Network__Group__6__Impl )
            // InternalMiniProject1DSL.g:436:2: rule__Network__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__6"


    // $ANTLR start "rule__Network__Group__6__Impl"
    // InternalMiniProject1DSL.g:442:1: rule__Network__Group__6__Impl : ( '}' ) ;
    public final void rule__Network__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:446:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:447:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:447:1: ( '}' )
            // InternalMiniProject1DSL.g:448:2: '}'
            {
             before(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_6()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group__6__Impl"


    // $ANTLR start "rule__Network__Group_4__0"
    // InternalMiniProject1DSL.g:458:1: rule__Network__Group_4__0 : rule__Network__Group_4__0__Impl rule__Network__Group_4__1 ;
    public final void rule__Network__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:462:1: ( rule__Network__Group_4__0__Impl rule__Network__Group_4__1 )
            // InternalMiniProject1DSL.g:463:2: rule__Network__Group_4__0__Impl rule__Network__Group_4__1
            {
            pushFollow(FOLLOW_5);
            rule__Network__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__0"


    // $ANTLR start "rule__Network__Group_4__0__Impl"
    // InternalMiniProject1DSL.g:470:1: rule__Network__Group_4__0__Impl : ( 'statemachines' ) ;
    public final void rule__Network__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:474:1: ( ( 'statemachines' ) )
            // InternalMiniProject1DSL.g:475:1: ( 'statemachines' )
            {
            // InternalMiniProject1DSL.g:475:1: ( 'statemachines' )
            // InternalMiniProject1DSL.g:476:2: 'statemachines'
            {
             before(grammarAccess.getNetworkAccess().getStatemachinesKeyword_4_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getStatemachinesKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__0__Impl"


    // $ANTLR start "rule__Network__Group_4__1"
    // InternalMiniProject1DSL.g:485:1: rule__Network__Group_4__1 : rule__Network__Group_4__1__Impl rule__Network__Group_4__2 ;
    public final void rule__Network__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:489:1: ( rule__Network__Group_4__1__Impl rule__Network__Group_4__2 )
            // InternalMiniProject1DSL.g:490:2: rule__Network__Group_4__1__Impl rule__Network__Group_4__2
            {
            pushFollow(FOLLOW_7);
            rule__Network__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__1"


    // $ANTLR start "rule__Network__Group_4__1__Impl"
    // InternalMiniProject1DSL.g:497:1: rule__Network__Group_4__1__Impl : ( '{' ) ;
    public final void rule__Network__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:501:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:502:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:502:1: ( '{' )
            // InternalMiniProject1DSL.g:503:2: '{'
            {
             before(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_4_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__1__Impl"


    // $ANTLR start "rule__Network__Group_4__2"
    // InternalMiniProject1DSL.g:512:1: rule__Network__Group_4__2 : rule__Network__Group_4__2__Impl rule__Network__Group_4__3 ;
    public final void rule__Network__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:516:1: ( rule__Network__Group_4__2__Impl rule__Network__Group_4__3 )
            // InternalMiniProject1DSL.g:517:2: rule__Network__Group_4__2__Impl rule__Network__Group_4__3
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_4__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__2"


    // $ANTLR start "rule__Network__Group_4__2__Impl"
    // InternalMiniProject1DSL.g:524:1: rule__Network__Group_4__2__Impl : ( ( rule__Network__StatemachineAssignment_4_2 ) ) ;
    public final void rule__Network__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:528:1: ( ( ( rule__Network__StatemachineAssignment_4_2 ) ) )
            // InternalMiniProject1DSL.g:529:1: ( ( rule__Network__StatemachineAssignment_4_2 ) )
            {
            // InternalMiniProject1DSL.g:529:1: ( ( rule__Network__StatemachineAssignment_4_2 ) )
            // InternalMiniProject1DSL.g:530:2: ( rule__Network__StatemachineAssignment_4_2 )
            {
             before(grammarAccess.getNetworkAccess().getStatemachineAssignment_4_2()); 
            // InternalMiniProject1DSL.g:531:2: ( rule__Network__StatemachineAssignment_4_2 )
            // InternalMiniProject1DSL.g:531:3: rule__Network__StatemachineAssignment_4_2
            {
            pushFollow(FOLLOW_2);
            rule__Network__StatemachineAssignment_4_2();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getStatemachineAssignment_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__2__Impl"


    // $ANTLR start "rule__Network__Group_4__3"
    // InternalMiniProject1DSL.g:539:1: rule__Network__Group_4__3 : rule__Network__Group_4__3__Impl rule__Network__Group_4__4 ;
    public final void rule__Network__Group_4__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:543:1: ( rule__Network__Group_4__3__Impl rule__Network__Group_4__4 )
            // InternalMiniProject1DSL.g:544:2: rule__Network__Group_4__3__Impl rule__Network__Group_4__4
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_4__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__3"


    // $ANTLR start "rule__Network__Group_4__3__Impl"
    // InternalMiniProject1DSL.g:551:1: rule__Network__Group_4__3__Impl : ( ( rule__Network__Group_4_3__0 )* ) ;
    public final void rule__Network__Group_4__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:555:1: ( ( ( rule__Network__Group_4_3__0 )* ) )
            // InternalMiniProject1DSL.g:556:1: ( ( rule__Network__Group_4_3__0 )* )
            {
            // InternalMiniProject1DSL.g:556:1: ( ( rule__Network__Group_4_3__0 )* )
            // InternalMiniProject1DSL.g:557:2: ( rule__Network__Group_4_3__0 )*
            {
             before(grammarAccess.getNetworkAccess().getGroup_4_3()); 
            // InternalMiniProject1DSL.g:558:2: ( rule__Network__Group_4_3__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==17) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalMiniProject1DSL.g:558:3: rule__Network__Group_4_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Network__Group_4_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getNetworkAccess().getGroup_4_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__3__Impl"


    // $ANTLR start "rule__Network__Group_4__4"
    // InternalMiniProject1DSL.g:566:1: rule__Network__Group_4__4 : rule__Network__Group_4__4__Impl ;
    public final void rule__Network__Group_4__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:570:1: ( rule__Network__Group_4__4__Impl )
            // InternalMiniProject1DSL.g:571:2: rule__Network__Group_4__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_4__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__4"


    // $ANTLR start "rule__Network__Group_4__4__Impl"
    // InternalMiniProject1DSL.g:577:1: rule__Network__Group_4__4__Impl : ( '}' ) ;
    public final void rule__Network__Group_4__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:581:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:582:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:582:1: ( '}' )
            // InternalMiniProject1DSL.g:583:2: '}'
            {
             before(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_4_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_4_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4__4__Impl"


    // $ANTLR start "rule__Network__Group_4_3__0"
    // InternalMiniProject1DSL.g:593:1: rule__Network__Group_4_3__0 : rule__Network__Group_4_3__0__Impl rule__Network__Group_4_3__1 ;
    public final void rule__Network__Group_4_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:597:1: ( rule__Network__Group_4_3__0__Impl rule__Network__Group_4_3__1 )
            // InternalMiniProject1DSL.g:598:2: rule__Network__Group_4_3__0__Impl rule__Network__Group_4_3__1
            {
            pushFollow(FOLLOW_7);
            rule__Network__Group_4_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_4_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__0"


    // $ANTLR start "rule__Network__Group_4_3__0__Impl"
    // InternalMiniProject1DSL.g:605:1: rule__Network__Group_4_3__0__Impl : ( ',' ) ;
    public final void rule__Network__Group_4_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:609:1: ( ( ',' ) )
            // InternalMiniProject1DSL.g:610:1: ( ',' )
            {
            // InternalMiniProject1DSL.g:610:1: ( ',' )
            // InternalMiniProject1DSL.g:611:2: ','
            {
             before(grammarAccess.getNetworkAccess().getCommaKeyword_4_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getCommaKeyword_4_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__0__Impl"


    // $ANTLR start "rule__Network__Group_4_3__1"
    // InternalMiniProject1DSL.g:620:1: rule__Network__Group_4_3__1 : rule__Network__Group_4_3__1__Impl ;
    public final void rule__Network__Group_4_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:624:1: ( rule__Network__Group_4_3__1__Impl )
            // InternalMiniProject1DSL.g:625:2: rule__Network__Group_4_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_4_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__1"


    // $ANTLR start "rule__Network__Group_4_3__1__Impl"
    // InternalMiniProject1DSL.g:631:1: rule__Network__Group_4_3__1__Impl : ( ( rule__Network__StatemachineAssignment_4_3_1 ) ) ;
    public final void rule__Network__Group_4_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:635:1: ( ( ( rule__Network__StatemachineAssignment_4_3_1 ) ) )
            // InternalMiniProject1DSL.g:636:1: ( ( rule__Network__StatemachineAssignment_4_3_1 ) )
            {
            // InternalMiniProject1DSL.g:636:1: ( ( rule__Network__StatemachineAssignment_4_3_1 ) )
            // InternalMiniProject1DSL.g:637:2: ( rule__Network__StatemachineAssignment_4_3_1 )
            {
             before(grammarAccess.getNetworkAccess().getStatemachineAssignment_4_3_1()); 
            // InternalMiniProject1DSL.g:638:2: ( rule__Network__StatemachineAssignment_4_3_1 )
            // InternalMiniProject1DSL.g:638:3: rule__Network__StatemachineAssignment_4_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Network__StatemachineAssignment_4_3_1();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getStatemachineAssignment_4_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_4_3__1__Impl"


    // $ANTLR start "rule__Network__Group_5__0"
    // InternalMiniProject1DSL.g:647:1: rule__Network__Group_5__0 : rule__Network__Group_5__0__Impl rule__Network__Group_5__1 ;
    public final void rule__Network__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:651:1: ( rule__Network__Group_5__0__Impl rule__Network__Group_5__1 )
            // InternalMiniProject1DSL.g:652:2: rule__Network__Group_5__0__Impl rule__Network__Group_5__1
            {
            pushFollow(FOLLOW_5);
            rule__Network__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__0"


    // $ANTLR start "rule__Network__Group_5__0__Impl"
    // InternalMiniProject1DSL.g:659:1: rule__Network__Group_5__0__Impl : ( 'channels' ) ;
    public final void rule__Network__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:663:1: ( ( 'channels' ) )
            // InternalMiniProject1DSL.g:664:1: ( 'channels' )
            {
            // InternalMiniProject1DSL.g:664:1: ( 'channels' )
            // InternalMiniProject1DSL.g:665:2: 'channels'
            {
             before(grammarAccess.getNetworkAccess().getChannelsKeyword_5_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getChannelsKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__0__Impl"


    // $ANTLR start "rule__Network__Group_5__1"
    // InternalMiniProject1DSL.g:674:1: rule__Network__Group_5__1 : rule__Network__Group_5__1__Impl rule__Network__Group_5__2 ;
    public final void rule__Network__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:678:1: ( rule__Network__Group_5__1__Impl rule__Network__Group_5__2 )
            // InternalMiniProject1DSL.g:679:2: rule__Network__Group_5__1__Impl rule__Network__Group_5__2
            {
            pushFollow(FOLLOW_10);
            rule__Network__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__1"


    // $ANTLR start "rule__Network__Group_5__1__Impl"
    // InternalMiniProject1DSL.g:686:1: rule__Network__Group_5__1__Impl : ( '{' ) ;
    public final void rule__Network__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:690:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:691:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:691:1: ( '{' )
            // InternalMiniProject1DSL.g:692:2: '{'
            {
             before(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__1__Impl"


    // $ANTLR start "rule__Network__Group_5__2"
    // InternalMiniProject1DSL.g:701:1: rule__Network__Group_5__2 : rule__Network__Group_5__2__Impl rule__Network__Group_5__3 ;
    public final void rule__Network__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:705:1: ( rule__Network__Group_5__2__Impl rule__Network__Group_5__3 )
            // InternalMiniProject1DSL.g:706:2: rule__Network__Group_5__2__Impl rule__Network__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__2"


    // $ANTLR start "rule__Network__Group_5__2__Impl"
    // InternalMiniProject1DSL.g:713:1: rule__Network__Group_5__2__Impl : ( ( rule__Network__ChannelAssignment_5_2 ) ) ;
    public final void rule__Network__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:717:1: ( ( ( rule__Network__ChannelAssignment_5_2 ) ) )
            // InternalMiniProject1DSL.g:718:1: ( ( rule__Network__ChannelAssignment_5_2 ) )
            {
            // InternalMiniProject1DSL.g:718:1: ( ( rule__Network__ChannelAssignment_5_2 ) )
            // InternalMiniProject1DSL.g:719:2: ( rule__Network__ChannelAssignment_5_2 )
            {
             before(grammarAccess.getNetworkAccess().getChannelAssignment_5_2()); 
            // InternalMiniProject1DSL.g:720:2: ( rule__Network__ChannelAssignment_5_2 )
            // InternalMiniProject1DSL.g:720:3: rule__Network__ChannelAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__Network__ChannelAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getChannelAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__2__Impl"


    // $ANTLR start "rule__Network__Group_5__3"
    // InternalMiniProject1DSL.g:728:1: rule__Network__Group_5__3 : rule__Network__Group_5__3__Impl rule__Network__Group_5__4 ;
    public final void rule__Network__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:732:1: ( rule__Network__Group_5__3__Impl rule__Network__Group_5__4 )
            // InternalMiniProject1DSL.g:733:2: rule__Network__Group_5__3__Impl rule__Network__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__Network__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__3"


    // $ANTLR start "rule__Network__Group_5__3__Impl"
    // InternalMiniProject1DSL.g:740:1: rule__Network__Group_5__3__Impl : ( ( rule__Network__Group_5_3__0 )* ) ;
    public final void rule__Network__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:744:1: ( ( ( rule__Network__Group_5_3__0 )* ) )
            // InternalMiniProject1DSL.g:745:1: ( ( rule__Network__Group_5_3__0 )* )
            {
            // InternalMiniProject1DSL.g:745:1: ( ( rule__Network__Group_5_3__0 )* )
            // InternalMiniProject1DSL.g:746:2: ( rule__Network__Group_5_3__0 )*
            {
             before(grammarAccess.getNetworkAccess().getGroup_5_3()); 
            // InternalMiniProject1DSL.g:747:2: ( rule__Network__Group_5_3__0 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==17) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMiniProject1DSL.g:747:3: rule__Network__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Network__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getNetworkAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__3__Impl"


    // $ANTLR start "rule__Network__Group_5__4"
    // InternalMiniProject1DSL.g:755:1: rule__Network__Group_5__4 : rule__Network__Group_5__4__Impl ;
    public final void rule__Network__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:759:1: ( rule__Network__Group_5__4__Impl )
            // InternalMiniProject1DSL.g:760:2: rule__Network__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__4"


    // $ANTLR start "rule__Network__Group_5__4__Impl"
    // InternalMiniProject1DSL.g:766:1: rule__Network__Group_5__4__Impl : ( '}' ) ;
    public final void rule__Network__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:770:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:771:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:771:1: ( '}' )
            // InternalMiniProject1DSL.g:772:2: '}'
            {
             before(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5__4__Impl"


    // $ANTLR start "rule__Network__Group_5_3__0"
    // InternalMiniProject1DSL.g:782:1: rule__Network__Group_5_3__0 : rule__Network__Group_5_3__0__Impl rule__Network__Group_5_3__1 ;
    public final void rule__Network__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:786:1: ( rule__Network__Group_5_3__0__Impl rule__Network__Group_5_3__1 )
            // InternalMiniProject1DSL.g:787:2: rule__Network__Group_5_3__0__Impl rule__Network__Group_5_3__1
            {
            pushFollow(FOLLOW_10);
            rule__Network__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Network__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__0"


    // $ANTLR start "rule__Network__Group_5_3__0__Impl"
    // InternalMiniProject1DSL.g:794:1: rule__Network__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__Network__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:798:1: ( ( ',' ) )
            // InternalMiniProject1DSL.g:799:1: ( ',' )
            {
            // InternalMiniProject1DSL.g:799:1: ( ',' )
            // InternalMiniProject1DSL.g:800:2: ','
            {
             before(grammarAccess.getNetworkAccess().getCommaKeyword_5_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getNetworkAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__0__Impl"


    // $ANTLR start "rule__Network__Group_5_3__1"
    // InternalMiniProject1DSL.g:809:1: rule__Network__Group_5_3__1 : rule__Network__Group_5_3__1__Impl ;
    public final void rule__Network__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:813:1: ( rule__Network__Group_5_3__1__Impl )
            // InternalMiniProject1DSL.g:814:2: rule__Network__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Network__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__1"


    // $ANTLR start "rule__Network__Group_5_3__1__Impl"
    // InternalMiniProject1DSL.g:820:1: rule__Network__Group_5_3__1__Impl : ( ( rule__Network__ChannelAssignment_5_3_1 ) ) ;
    public final void rule__Network__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:824:1: ( ( ( rule__Network__ChannelAssignment_5_3_1 ) ) )
            // InternalMiniProject1DSL.g:825:1: ( ( rule__Network__ChannelAssignment_5_3_1 ) )
            {
            // InternalMiniProject1DSL.g:825:1: ( ( rule__Network__ChannelAssignment_5_3_1 ) )
            // InternalMiniProject1DSL.g:826:2: ( rule__Network__ChannelAssignment_5_3_1 )
            {
             before(grammarAccess.getNetworkAccess().getChannelAssignment_5_3_1()); 
            // InternalMiniProject1DSL.g:827:2: ( rule__Network__ChannelAssignment_5_3_1 )
            // InternalMiniProject1DSL.g:827:3: rule__Network__ChannelAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Network__ChannelAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getNetworkAccess().getChannelAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__Group_5_3__1__Impl"


    // $ANTLR start "rule__StateMachine__Group__0"
    // InternalMiniProject1DSL.g:836:1: rule__StateMachine__Group__0 : rule__StateMachine__Group__0__Impl rule__StateMachine__Group__1 ;
    public final void rule__StateMachine__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:840:1: ( rule__StateMachine__Group__0__Impl rule__StateMachine__Group__1 )
            // InternalMiniProject1DSL.g:841:2: rule__StateMachine__Group__0__Impl rule__StateMachine__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__StateMachine__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__0"


    // $ANTLR start "rule__StateMachine__Group__0__Impl"
    // InternalMiniProject1DSL.g:848:1: rule__StateMachine__Group__0__Impl : ( () ) ;
    public final void rule__StateMachine__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:852:1: ( ( () ) )
            // InternalMiniProject1DSL.g:853:1: ( () )
            {
            // InternalMiniProject1DSL.g:853:1: ( () )
            // InternalMiniProject1DSL.g:854:2: ()
            {
             before(grammarAccess.getStateMachineAccess().getStateMachineAction_0()); 
            // InternalMiniProject1DSL.g:855:2: ()
            // InternalMiniProject1DSL.g:855:3: 
            {
            }

             after(grammarAccess.getStateMachineAccess().getStateMachineAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__0__Impl"


    // $ANTLR start "rule__StateMachine__Group__1"
    // InternalMiniProject1DSL.g:863:1: rule__StateMachine__Group__1 : rule__StateMachine__Group__1__Impl rule__StateMachine__Group__2 ;
    public final void rule__StateMachine__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:867:1: ( rule__StateMachine__Group__1__Impl rule__StateMachine__Group__2 )
            // InternalMiniProject1DSL.g:868:2: rule__StateMachine__Group__1__Impl rule__StateMachine__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__StateMachine__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__1"


    // $ANTLR start "rule__StateMachine__Group__1__Impl"
    // InternalMiniProject1DSL.g:875:1: rule__StateMachine__Group__1__Impl : ( 'StateMachine' ) ;
    public final void rule__StateMachine__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:879:1: ( ( 'StateMachine' ) )
            // InternalMiniProject1DSL.g:880:1: ( 'StateMachine' )
            {
            // InternalMiniProject1DSL.g:880:1: ( 'StateMachine' )
            // InternalMiniProject1DSL.g:881:2: 'StateMachine'
            {
             before(grammarAccess.getStateMachineAccess().getStateMachineKeyword_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getStateMachineKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__1__Impl"


    // $ANTLR start "rule__StateMachine__Group__2"
    // InternalMiniProject1DSL.g:890:1: rule__StateMachine__Group__2 : rule__StateMachine__Group__2__Impl rule__StateMachine__Group__3 ;
    public final void rule__StateMachine__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:894:1: ( rule__StateMachine__Group__2__Impl rule__StateMachine__Group__3 )
            // InternalMiniProject1DSL.g:895:2: rule__StateMachine__Group__2__Impl rule__StateMachine__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__StateMachine__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__2"


    // $ANTLR start "rule__StateMachine__Group__2__Impl"
    // InternalMiniProject1DSL.g:902:1: rule__StateMachine__Group__2__Impl : ( ( rule__StateMachine__NameAssignment_2 ) ) ;
    public final void rule__StateMachine__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:906:1: ( ( ( rule__StateMachine__NameAssignment_2 ) ) )
            // InternalMiniProject1DSL.g:907:1: ( ( rule__StateMachine__NameAssignment_2 ) )
            {
            // InternalMiniProject1DSL.g:907:1: ( ( rule__StateMachine__NameAssignment_2 ) )
            // InternalMiniProject1DSL.g:908:2: ( rule__StateMachine__NameAssignment_2 )
            {
             before(grammarAccess.getStateMachineAccess().getNameAssignment_2()); 
            // InternalMiniProject1DSL.g:909:2: ( rule__StateMachine__NameAssignment_2 )
            // InternalMiniProject1DSL.g:909:3: rule__StateMachine__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__2__Impl"


    // $ANTLR start "rule__StateMachine__Group__3"
    // InternalMiniProject1DSL.g:917:1: rule__StateMachine__Group__3 : rule__StateMachine__Group__3__Impl rule__StateMachine__Group__4 ;
    public final void rule__StateMachine__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:921:1: ( rule__StateMachine__Group__3__Impl rule__StateMachine__Group__4 )
            // InternalMiniProject1DSL.g:922:2: rule__StateMachine__Group__3__Impl rule__StateMachine__Group__4
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__3"


    // $ANTLR start "rule__StateMachine__Group__3__Impl"
    // InternalMiniProject1DSL.g:929:1: rule__StateMachine__Group__3__Impl : ( '{' ) ;
    public final void rule__StateMachine__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:933:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:934:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:934:1: ( '{' )
            // InternalMiniProject1DSL.g:935:2: '{'
            {
             before(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__3__Impl"


    // $ANTLR start "rule__StateMachine__Group__4"
    // InternalMiniProject1DSL.g:944:1: rule__StateMachine__Group__4 : rule__StateMachine__Group__4__Impl rule__StateMachine__Group__5 ;
    public final void rule__StateMachine__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:948:1: ( rule__StateMachine__Group__4__Impl rule__StateMachine__Group__5 )
            // InternalMiniProject1DSL.g:949:2: rule__StateMachine__Group__4__Impl rule__StateMachine__Group__5
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__4"


    // $ANTLR start "rule__StateMachine__Group__4__Impl"
    // InternalMiniProject1DSL.g:956:1: rule__StateMachine__Group__4__Impl : ( ( rule__StateMachine__Group_4__0 )? ) ;
    public final void rule__StateMachine__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:960:1: ( ( ( rule__StateMachine__Group_4__0 )? ) )
            // InternalMiniProject1DSL.g:961:1: ( ( rule__StateMachine__Group_4__0 )? )
            {
            // InternalMiniProject1DSL.g:961:1: ( ( rule__StateMachine__Group_4__0 )? )
            // InternalMiniProject1DSL.g:962:2: ( rule__StateMachine__Group_4__0 )?
            {
             before(grammarAccess.getStateMachineAccess().getGroup_4()); 
            // InternalMiniProject1DSL.g:963:2: ( rule__StateMachine__Group_4__0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==20) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMiniProject1DSL.g:963:3: rule__StateMachine__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__StateMachine__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStateMachineAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__4__Impl"


    // $ANTLR start "rule__StateMachine__Group__5"
    // InternalMiniProject1DSL.g:971:1: rule__StateMachine__Group__5 : rule__StateMachine__Group__5__Impl rule__StateMachine__Group__6 ;
    public final void rule__StateMachine__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:975:1: ( rule__StateMachine__Group__5__Impl rule__StateMachine__Group__6 )
            // InternalMiniProject1DSL.g:976:2: rule__StateMachine__Group__5__Impl rule__StateMachine__Group__6
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__5"


    // $ANTLR start "rule__StateMachine__Group__5__Impl"
    // InternalMiniProject1DSL.g:983:1: rule__StateMachine__Group__5__Impl : ( ( rule__StateMachine__Group_5__0 )? ) ;
    public final void rule__StateMachine__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:987:1: ( ( ( rule__StateMachine__Group_5__0 )? ) )
            // InternalMiniProject1DSL.g:988:1: ( ( rule__StateMachine__Group_5__0 )? )
            {
            // InternalMiniProject1DSL.g:988:1: ( ( rule__StateMachine__Group_5__0 )? )
            // InternalMiniProject1DSL.g:989:2: ( rule__StateMachine__Group_5__0 )?
            {
             before(grammarAccess.getStateMachineAccess().getGroup_5()); 
            // InternalMiniProject1DSL.g:990:2: ( rule__StateMachine__Group_5__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMiniProject1DSL.g:990:3: rule__StateMachine__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__StateMachine__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStateMachineAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__5__Impl"


    // $ANTLR start "rule__StateMachine__Group__6"
    // InternalMiniProject1DSL.g:998:1: rule__StateMachine__Group__6 : rule__StateMachine__Group__6__Impl rule__StateMachine__Group__7 ;
    public final void rule__StateMachine__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1002:1: ( rule__StateMachine__Group__6__Impl rule__StateMachine__Group__7 )
            // InternalMiniProject1DSL.g:1003:2: rule__StateMachine__Group__6__Impl rule__StateMachine__Group__7
            {
            pushFollow(FOLLOW_11);
            rule__StateMachine__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__6"


    // $ANTLR start "rule__StateMachine__Group__6__Impl"
    // InternalMiniProject1DSL.g:1010:1: rule__StateMachine__Group__6__Impl : ( ( rule__StateMachine__Group_6__0 )? ) ;
    public final void rule__StateMachine__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1014:1: ( ( ( rule__StateMachine__Group_6__0 )? ) )
            // InternalMiniProject1DSL.g:1015:1: ( ( rule__StateMachine__Group_6__0 )? )
            {
            // InternalMiniProject1DSL.g:1015:1: ( ( rule__StateMachine__Group_6__0 )? )
            // InternalMiniProject1DSL.g:1016:2: ( rule__StateMachine__Group_6__0 )?
            {
             before(grammarAccess.getStateMachineAccess().getGroup_6()); 
            // InternalMiniProject1DSL.g:1017:2: ( rule__StateMachine__Group_6__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMiniProject1DSL.g:1017:3: rule__StateMachine__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__StateMachine__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStateMachineAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__6__Impl"


    // $ANTLR start "rule__StateMachine__Group__7"
    // InternalMiniProject1DSL.g:1025:1: rule__StateMachine__Group__7 : rule__StateMachine__Group__7__Impl ;
    public final void rule__StateMachine__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1029:1: ( rule__StateMachine__Group__7__Impl )
            // InternalMiniProject1DSL.g:1030:2: rule__StateMachine__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__7"


    // $ANTLR start "rule__StateMachine__Group__7__Impl"
    // InternalMiniProject1DSL.g:1036:1: rule__StateMachine__Group__7__Impl : ( '}' ) ;
    public final void rule__StateMachine__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1040:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:1041:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:1041:1: ( '}' )
            // InternalMiniProject1DSL.g:1042:2: '}'
            {
             before(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_7()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group__7__Impl"


    // $ANTLR start "rule__StateMachine__Group_4__0"
    // InternalMiniProject1DSL.g:1052:1: rule__StateMachine__Group_4__0 : rule__StateMachine__Group_4__0__Impl rule__StateMachine__Group_4__1 ;
    public final void rule__StateMachine__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1056:1: ( rule__StateMachine__Group_4__0__Impl rule__StateMachine__Group_4__1 )
            // InternalMiniProject1DSL.g:1057:2: rule__StateMachine__Group_4__0__Impl rule__StateMachine__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__StateMachine__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__0"


    // $ANTLR start "rule__StateMachine__Group_4__0__Impl"
    // InternalMiniProject1DSL.g:1064:1: rule__StateMachine__Group_4__0__Impl : ( 'initialstate' ) ;
    public final void rule__StateMachine__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1068:1: ( ( 'initialstate' ) )
            // InternalMiniProject1DSL.g:1069:1: ( 'initialstate' )
            {
            // InternalMiniProject1DSL.g:1069:1: ( 'initialstate' )
            // InternalMiniProject1DSL.g:1070:2: 'initialstate'
            {
             before(grammarAccess.getStateMachineAccess().getInitialstateKeyword_4_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getInitialstateKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_4__1"
    // InternalMiniProject1DSL.g:1079:1: rule__StateMachine__Group_4__1 : rule__StateMachine__Group_4__1__Impl ;
    public final void rule__StateMachine__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1083:1: ( rule__StateMachine__Group_4__1__Impl )
            // InternalMiniProject1DSL.g:1084:2: rule__StateMachine__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__1"


    // $ANTLR start "rule__StateMachine__Group_4__1__Impl"
    // InternalMiniProject1DSL.g:1090:1: rule__StateMachine__Group_4__1__Impl : ( ( rule__StateMachine__InitialAssignment_4_1 ) ) ;
    public final void rule__StateMachine__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1094:1: ( ( ( rule__StateMachine__InitialAssignment_4_1 ) ) )
            // InternalMiniProject1DSL.g:1095:1: ( ( rule__StateMachine__InitialAssignment_4_1 ) )
            {
            // InternalMiniProject1DSL.g:1095:1: ( ( rule__StateMachine__InitialAssignment_4_1 ) )
            // InternalMiniProject1DSL.g:1096:2: ( rule__StateMachine__InitialAssignment_4_1 )
            {
             before(grammarAccess.getStateMachineAccess().getInitialAssignment_4_1()); 
            // InternalMiniProject1DSL.g:1097:2: ( rule__StateMachine__InitialAssignment_4_1 )
            // InternalMiniProject1DSL.g:1097:3: rule__StateMachine__InitialAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__InitialAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getInitialAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_4__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__0"
    // InternalMiniProject1DSL.g:1106:1: rule__StateMachine__Group_5__0 : rule__StateMachine__Group_5__0__Impl rule__StateMachine__Group_5__1 ;
    public final void rule__StateMachine__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1110:1: ( rule__StateMachine__Group_5__0__Impl rule__StateMachine__Group_5__1 )
            // InternalMiniProject1DSL.g:1111:2: rule__StateMachine__Group_5__0__Impl rule__StateMachine__Group_5__1
            {
            pushFollow(FOLLOW_5);
            rule__StateMachine__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__0"


    // $ANTLR start "rule__StateMachine__Group_5__0__Impl"
    // InternalMiniProject1DSL.g:1118:1: rule__StateMachine__Group_5__0__Impl : ( 'states' ) ;
    public final void rule__StateMachine__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1122:1: ( ( 'states' ) )
            // InternalMiniProject1DSL.g:1123:1: ( 'states' )
            {
            // InternalMiniProject1DSL.g:1123:1: ( 'states' )
            // InternalMiniProject1DSL.g:1124:2: 'states'
            {
             before(grammarAccess.getStateMachineAccess().getStatesKeyword_5_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getStatesKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__1"
    // InternalMiniProject1DSL.g:1133:1: rule__StateMachine__Group_5__1 : rule__StateMachine__Group_5__1__Impl rule__StateMachine__Group_5__2 ;
    public final void rule__StateMachine__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1137:1: ( rule__StateMachine__Group_5__1__Impl rule__StateMachine__Group_5__2 )
            // InternalMiniProject1DSL.g:1138:2: rule__StateMachine__Group_5__1__Impl rule__StateMachine__Group_5__2
            {
            pushFollow(FOLLOW_12);
            rule__StateMachine__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__1"


    // $ANTLR start "rule__StateMachine__Group_5__1__Impl"
    // InternalMiniProject1DSL.g:1145:1: rule__StateMachine__Group_5__1__Impl : ( '{' ) ;
    public final void rule__StateMachine__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1149:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:1150:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:1150:1: ( '{' )
            // InternalMiniProject1DSL.g:1151:2: '{'
            {
             before(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__2"
    // InternalMiniProject1DSL.g:1160:1: rule__StateMachine__Group_5__2 : rule__StateMachine__Group_5__2__Impl rule__StateMachine__Group_5__3 ;
    public final void rule__StateMachine__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1164:1: ( rule__StateMachine__Group_5__2__Impl rule__StateMachine__Group_5__3 )
            // InternalMiniProject1DSL.g:1165:2: rule__StateMachine__Group_5__2__Impl rule__StateMachine__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__2"


    // $ANTLR start "rule__StateMachine__Group_5__2__Impl"
    // InternalMiniProject1DSL.g:1172:1: rule__StateMachine__Group_5__2__Impl : ( ( rule__StateMachine__StateAssignment_5_2 ) ) ;
    public final void rule__StateMachine__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1176:1: ( ( ( rule__StateMachine__StateAssignment_5_2 ) ) )
            // InternalMiniProject1DSL.g:1177:1: ( ( rule__StateMachine__StateAssignment_5_2 ) )
            {
            // InternalMiniProject1DSL.g:1177:1: ( ( rule__StateMachine__StateAssignment_5_2 ) )
            // InternalMiniProject1DSL.g:1178:2: ( rule__StateMachine__StateAssignment_5_2 )
            {
             before(grammarAccess.getStateMachineAccess().getStateAssignment_5_2()); 
            // InternalMiniProject1DSL.g:1179:2: ( rule__StateMachine__StateAssignment_5_2 )
            // InternalMiniProject1DSL.g:1179:3: rule__StateMachine__StateAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__StateAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getStateAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__2__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__3"
    // InternalMiniProject1DSL.g:1187:1: rule__StateMachine__Group_5__3 : rule__StateMachine__Group_5__3__Impl rule__StateMachine__Group_5__4 ;
    public final void rule__StateMachine__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1191:1: ( rule__StateMachine__Group_5__3__Impl rule__StateMachine__Group_5__4 )
            // InternalMiniProject1DSL.g:1192:2: rule__StateMachine__Group_5__3__Impl rule__StateMachine__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__3"


    // $ANTLR start "rule__StateMachine__Group_5__3__Impl"
    // InternalMiniProject1DSL.g:1199:1: rule__StateMachine__Group_5__3__Impl : ( ( rule__StateMachine__Group_5_3__0 )* ) ;
    public final void rule__StateMachine__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1203:1: ( ( ( rule__StateMachine__Group_5_3__0 )* ) )
            // InternalMiniProject1DSL.g:1204:1: ( ( rule__StateMachine__Group_5_3__0 )* )
            {
            // InternalMiniProject1DSL.g:1204:1: ( ( rule__StateMachine__Group_5_3__0 )* )
            // InternalMiniProject1DSL.g:1205:2: ( rule__StateMachine__Group_5_3__0 )*
            {
             before(grammarAccess.getStateMachineAccess().getGroup_5_3()); 
            // InternalMiniProject1DSL.g:1206:2: ( rule__StateMachine__Group_5_3__0 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==17) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalMiniProject1DSL.g:1206:3: rule__StateMachine__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__StateMachine__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getStateMachineAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__3__Impl"


    // $ANTLR start "rule__StateMachine__Group_5__4"
    // InternalMiniProject1DSL.g:1214:1: rule__StateMachine__Group_5__4 : rule__StateMachine__Group_5__4__Impl ;
    public final void rule__StateMachine__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1218:1: ( rule__StateMachine__Group_5__4__Impl )
            // InternalMiniProject1DSL.g:1219:2: rule__StateMachine__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__4"


    // $ANTLR start "rule__StateMachine__Group_5__4__Impl"
    // InternalMiniProject1DSL.g:1225:1: rule__StateMachine__Group_5__4__Impl : ( '}' ) ;
    public final void rule__StateMachine__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1229:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:1230:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:1230:1: ( '}' )
            // InternalMiniProject1DSL.g:1231:2: '}'
            {
             before(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5__4__Impl"


    // $ANTLR start "rule__StateMachine__Group_5_3__0"
    // InternalMiniProject1DSL.g:1241:1: rule__StateMachine__Group_5_3__0 : rule__StateMachine__Group_5_3__0__Impl rule__StateMachine__Group_5_3__1 ;
    public final void rule__StateMachine__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1245:1: ( rule__StateMachine__Group_5_3__0__Impl rule__StateMachine__Group_5_3__1 )
            // InternalMiniProject1DSL.g:1246:2: rule__StateMachine__Group_5_3__0__Impl rule__StateMachine__Group_5_3__1
            {
            pushFollow(FOLLOW_12);
            rule__StateMachine__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__0"


    // $ANTLR start "rule__StateMachine__Group_5_3__0__Impl"
    // InternalMiniProject1DSL.g:1253:1: rule__StateMachine__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__StateMachine__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1257:1: ( ( ',' ) )
            // InternalMiniProject1DSL.g:1258:1: ( ',' )
            {
            // InternalMiniProject1DSL.g:1258:1: ( ',' )
            // InternalMiniProject1DSL.g:1259:2: ','
            {
             before(grammarAccess.getStateMachineAccess().getCommaKeyword_5_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_5_3__1"
    // InternalMiniProject1DSL.g:1268:1: rule__StateMachine__Group_5_3__1 : rule__StateMachine__Group_5_3__1__Impl ;
    public final void rule__StateMachine__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1272:1: ( rule__StateMachine__Group_5_3__1__Impl )
            // InternalMiniProject1DSL.g:1273:2: rule__StateMachine__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__1"


    // $ANTLR start "rule__StateMachine__Group_5_3__1__Impl"
    // InternalMiniProject1DSL.g:1279:1: rule__StateMachine__Group_5_3__1__Impl : ( ( rule__StateMachine__StateAssignment_5_3_1 ) ) ;
    public final void rule__StateMachine__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1283:1: ( ( ( rule__StateMachine__StateAssignment_5_3_1 ) ) )
            // InternalMiniProject1DSL.g:1284:1: ( ( rule__StateMachine__StateAssignment_5_3_1 ) )
            {
            // InternalMiniProject1DSL.g:1284:1: ( ( rule__StateMachine__StateAssignment_5_3_1 ) )
            // InternalMiniProject1DSL.g:1285:2: ( rule__StateMachine__StateAssignment_5_3_1 )
            {
             before(grammarAccess.getStateMachineAccess().getStateAssignment_5_3_1()); 
            // InternalMiniProject1DSL.g:1286:2: ( rule__StateMachine__StateAssignment_5_3_1 )
            // InternalMiniProject1DSL.g:1286:3: rule__StateMachine__StateAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__StateAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getStateAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_5_3__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__0"
    // InternalMiniProject1DSL.g:1295:1: rule__StateMachine__Group_6__0 : rule__StateMachine__Group_6__0__Impl rule__StateMachine__Group_6__1 ;
    public final void rule__StateMachine__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1299:1: ( rule__StateMachine__Group_6__0__Impl rule__StateMachine__Group_6__1 )
            // InternalMiniProject1DSL.g:1300:2: rule__StateMachine__Group_6__0__Impl rule__StateMachine__Group_6__1
            {
            pushFollow(FOLLOW_5);
            rule__StateMachine__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__0"


    // $ANTLR start "rule__StateMachine__Group_6__0__Impl"
    // InternalMiniProject1DSL.g:1307:1: rule__StateMachine__Group_6__0__Impl : ( 'transitions' ) ;
    public final void rule__StateMachine__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1311:1: ( ( 'transitions' ) )
            // InternalMiniProject1DSL.g:1312:1: ( 'transitions' )
            {
            // InternalMiniProject1DSL.g:1312:1: ( 'transitions' )
            // InternalMiniProject1DSL.g:1313:2: 'transitions'
            {
             before(grammarAccess.getStateMachineAccess().getTransitionsKeyword_6_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getTransitionsKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__1"
    // InternalMiniProject1DSL.g:1322:1: rule__StateMachine__Group_6__1 : rule__StateMachine__Group_6__1__Impl rule__StateMachine__Group_6__2 ;
    public final void rule__StateMachine__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1326:1: ( rule__StateMachine__Group_6__1__Impl rule__StateMachine__Group_6__2 )
            // InternalMiniProject1DSL.g:1327:2: rule__StateMachine__Group_6__1__Impl rule__StateMachine__Group_6__2
            {
            pushFollow(FOLLOW_13);
            rule__StateMachine__Group_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__1"


    // $ANTLR start "rule__StateMachine__Group_6__1__Impl"
    // InternalMiniProject1DSL.g:1334:1: rule__StateMachine__Group_6__1__Impl : ( '{' ) ;
    public final void rule__StateMachine__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1338:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:1339:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:1339:1: ( '{' )
            // InternalMiniProject1DSL.g:1340:2: '{'
            {
             before(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_6_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getLeftCurlyBracketKeyword_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__1__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__2"
    // InternalMiniProject1DSL.g:1349:1: rule__StateMachine__Group_6__2 : rule__StateMachine__Group_6__2__Impl rule__StateMachine__Group_6__3 ;
    public final void rule__StateMachine__Group_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1353:1: ( rule__StateMachine__Group_6__2__Impl rule__StateMachine__Group_6__3 )
            // InternalMiniProject1DSL.g:1354:2: rule__StateMachine__Group_6__2__Impl rule__StateMachine__Group_6__3
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__2"


    // $ANTLR start "rule__StateMachine__Group_6__2__Impl"
    // InternalMiniProject1DSL.g:1361:1: rule__StateMachine__Group_6__2__Impl : ( ( rule__StateMachine__TransitionAssignment_6_2 ) ) ;
    public final void rule__StateMachine__Group_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1365:1: ( ( ( rule__StateMachine__TransitionAssignment_6_2 ) ) )
            // InternalMiniProject1DSL.g:1366:1: ( ( rule__StateMachine__TransitionAssignment_6_2 ) )
            {
            // InternalMiniProject1DSL.g:1366:1: ( ( rule__StateMachine__TransitionAssignment_6_2 ) )
            // InternalMiniProject1DSL.g:1367:2: ( rule__StateMachine__TransitionAssignment_6_2 )
            {
             before(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_2()); 
            // InternalMiniProject1DSL.g:1368:2: ( rule__StateMachine__TransitionAssignment_6_2 )
            // InternalMiniProject1DSL.g:1368:3: rule__StateMachine__TransitionAssignment_6_2
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__TransitionAssignment_6_2();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__2__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__3"
    // InternalMiniProject1DSL.g:1376:1: rule__StateMachine__Group_6__3 : rule__StateMachine__Group_6__3__Impl rule__StateMachine__Group_6__4 ;
    public final void rule__StateMachine__Group_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1380:1: ( rule__StateMachine__Group_6__3__Impl rule__StateMachine__Group_6__4 )
            // InternalMiniProject1DSL.g:1381:2: rule__StateMachine__Group_6__3__Impl rule__StateMachine__Group_6__4
            {
            pushFollow(FOLLOW_8);
            rule__StateMachine__Group_6__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__3"


    // $ANTLR start "rule__StateMachine__Group_6__3__Impl"
    // InternalMiniProject1DSL.g:1388:1: rule__StateMachine__Group_6__3__Impl : ( ( rule__StateMachine__Group_6_3__0 )* ) ;
    public final void rule__StateMachine__Group_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1392:1: ( ( ( rule__StateMachine__Group_6_3__0 )* ) )
            // InternalMiniProject1DSL.g:1393:1: ( ( rule__StateMachine__Group_6_3__0 )* )
            {
            // InternalMiniProject1DSL.g:1393:1: ( ( rule__StateMachine__Group_6_3__0 )* )
            // InternalMiniProject1DSL.g:1394:2: ( rule__StateMachine__Group_6_3__0 )*
            {
             before(grammarAccess.getStateMachineAccess().getGroup_6_3()); 
            // InternalMiniProject1DSL.g:1395:2: ( rule__StateMachine__Group_6_3__0 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==17) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalMiniProject1DSL.g:1395:3: rule__StateMachine__Group_6_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__StateMachine__Group_6_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getStateMachineAccess().getGroup_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__3__Impl"


    // $ANTLR start "rule__StateMachine__Group_6__4"
    // InternalMiniProject1DSL.g:1403:1: rule__StateMachine__Group_6__4 : rule__StateMachine__Group_6__4__Impl ;
    public final void rule__StateMachine__Group_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1407:1: ( rule__StateMachine__Group_6__4__Impl )
            // InternalMiniProject1DSL.g:1408:2: rule__StateMachine__Group_6__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__4"


    // $ANTLR start "rule__StateMachine__Group_6__4__Impl"
    // InternalMiniProject1DSL.g:1414:1: rule__StateMachine__Group_6__4__Impl : ( '}' ) ;
    public final void rule__StateMachine__Group_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1418:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:1419:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:1419:1: ( '}' )
            // InternalMiniProject1DSL.g:1420:2: '}'
            {
             before(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_6_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getRightCurlyBracketKeyword_6_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6__4__Impl"


    // $ANTLR start "rule__StateMachine__Group_6_3__0"
    // InternalMiniProject1DSL.g:1430:1: rule__StateMachine__Group_6_3__0 : rule__StateMachine__Group_6_3__0__Impl rule__StateMachine__Group_6_3__1 ;
    public final void rule__StateMachine__Group_6_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1434:1: ( rule__StateMachine__Group_6_3__0__Impl rule__StateMachine__Group_6_3__1 )
            // InternalMiniProject1DSL.g:1435:2: rule__StateMachine__Group_6_3__0__Impl rule__StateMachine__Group_6_3__1
            {
            pushFollow(FOLLOW_13);
            rule__StateMachine__Group_6_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__0"


    // $ANTLR start "rule__StateMachine__Group_6_3__0__Impl"
    // InternalMiniProject1DSL.g:1442:1: rule__StateMachine__Group_6_3__0__Impl : ( ',' ) ;
    public final void rule__StateMachine__Group_6_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1446:1: ( ( ',' ) )
            // InternalMiniProject1DSL.g:1447:1: ( ',' )
            {
            // InternalMiniProject1DSL.g:1447:1: ( ',' )
            // InternalMiniProject1DSL.g:1448:2: ','
            {
             before(grammarAccess.getStateMachineAccess().getCommaKeyword_6_3_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getStateMachineAccess().getCommaKeyword_6_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__0__Impl"


    // $ANTLR start "rule__StateMachine__Group_6_3__1"
    // InternalMiniProject1DSL.g:1457:1: rule__StateMachine__Group_6_3__1 : rule__StateMachine__Group_6_3__1__Impl ;
    public final void rule__StateMachine__Group_6_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1461:1: ( rule__StateMachine__Group_6_3__1__Impl )
            // InternalMiniProject1DSL.g:1462:2: rule__StateMachine__Group_6_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__Group_6_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__1"


    // $ANTLR start "rule__StateMachine__Group_6_3__1__Impl"
    // InternalMiniProject1DSL.g:1468:1: rule__StateMachine__Group_6_3__1__Impl : ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) ) ;
    public final void rule__StateMachine__Group_6_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1472:1: ( ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) ) )
            // InternalMiniProject1DSL.g:1473:1: ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) )
            {
            // InternalMiniProject1DSL.g:1473:1: ( ( rule__StateMachine__TransitionAssignment_6_3_1 ) )
            // InternalMiniProject1DSL.g:1474:2: ( rule__StateMachine__TransitionAssignment_6_3_1 )
            {
             before(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_3_1()); 
            // InternalMiniProject1DSL.g:1475:2: ( rule__StateMachine__TransitionAssignment_6_3_1 )
            // InternalMiniProject1DSL.g:1475:3: rule__StateMachine__TransitionAssignment_6_3_1
            {
            pushFollow(FOLLOW_2);
            rule__StateMachine__TransitionAssignment_6_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStateMachineAccess().getTransitionAssignment_6_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__Group_6_3__1__Impl"


    // $ANTLR start "rule__Channel__Group__0"
    // InternalMiniProject1DSL.g:1484:1: rule__Channel__Group__0 : rule__Channel__Group__0__Impl rule__Channel__Group__1 ;
    public final void rule__Channel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1488:1: ( rule__Channel__Group__0__Impl rule__Channel__Group__1 )
            // InternalMiniProject1DSL.g:1489:2: rule__Channel__Group__0__Impl rule__Channel__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Channel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__0"


    // $ANTLR start "rule__Channel__Group__0__Impl"
    // InternalMiniProject1DSL.g:1496:1: rule__Channel__Group__0__Impl : ( () ) ;
    public final void rule__Channel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1500:1: ( ( () ) )
            // InternalMiniProject1DSL.g:1501:1: ( () )
            {
            // InternalMiniProject1DSL.g:1501:1: ( () )
            // InternalMiniProject1DSL.g:1502:2: ()
            {
             before(grammarAccess.getChannelAccess().getChannelAction_0()); 
            // InternalMiniProject1DSL.g:1503:2: ()
            // InternalMiniProject1DSL.g:1503:3: 
            {
            }

             after(grammarAccess.getChannelAccess().getChannelAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__0__Impl"


    // $ANTLR start "rule__Channel__Group__1"
    // InternalMiniProject1DSL.g:1511:1: rule__Channel__Group__1 : rule__Channel__Group__1__Impl rule__Channel__Group__2 ;
    public final void rule__Channel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1515:1: ( rule__Channel__Group__1__Impl rule__Channel__Group__2 )
            // InternalMiniProject1DSL.g:1516:2: rule__Channel__Group__1__Impl rule__Channel__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Channel__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__1"


    // $ANTLR start "rule__Channel__Group__1__Impl"
    // InternalMiniProject1DSL.g:1523:1: rule__Channel__Group__1__Impl : ( 'Channel' ) ;
    public final void rule__Channel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1527:1: ( ( 'Channel' ) )
            // InternalMiniProject1DSL.g:1528:1: ( 'Channel' )
            {
            // InternalMiniProject1DSL.g:1528:1: ( 'Channel' )
            // InternalMiniProject1DSL.g:1529:2: 'Channel'
            {
             before(grammarAccess.getChannelAccess().getChannelKeyword_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getChannelAccess().getChannelKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__1__Impl"


    // $ANTLR start "rule__Channel__Group__2"
    // InternalMiniProject1DSL.g:1538:1: rule__Channel__Group__2 : rule__Channel__Group__2__Impl rule__Channel__Group__3 ;
    public final void rule__Channel__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1542:1: ( rule__Channel__Group__2__Impl rule__Channel__Group__3 )
            // InternalMiniProject1DSL.g:1543:2: rule__Channel__Group__2__Impl rule__Channel__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Channel__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__2"


    // $ANTLR start "rule__Channel__Group__2__Impl"
    // InternalMiniProject1DSL.g:1550:1: rule__Channel__Group__2__Impl : ( ( rule__Channel__NameAssignment_2 ) ) ;
    public final void rule__Channel__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1554:1: ( ( ( rule__Channel__NameAssignment_2 ) ) )
            // InternalMiniProject1DSL.g:1555:1: ( ( rule__Channel__NameAssignment_2 ) )
            {
            // InternalMiniProject1DSL.g:1555:1: ( ( rule__Channel__NameAssignment_2 ) )
            // InternalMiniProject1DSL.g:1556:2: ( rule__Channel__NameAssignment_2 )
            {
             before(grammarAccess.getChannelAccess().getNameAssignment_2()); 
            // InternalMiniProject1DSL.g:1557:2: ( rule__Channel__NameAssignment_2 )
            // InternalMiniProject1DSL.g:1557:3: rule__Channel__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Channel__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getChannelAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__2__Impl"


    // $ANTLR start "rule__Channel__Group__3"
    // InternalMiniProject1DSL.g:1565:1: rule__Channel__Group__3 : rule__Channel__Group__3__Impl rule__Channel__Group__4 ;
    public final void rule__Channel__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1569:1: ( rule__Channel__Group__3__Impl rule__Channel__Group__4 )
            // InternalMiniProject1DSL.g:1570:2: rule__Channel__Group__3__Impl rule__Channel__Group__4
            {
            pushFollow(FOLLOW_14);
            rule__Channel__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__3"


    // $ANTLR start "rule__Channel__Group__3__Impl"
    // InternalMiniProject1DSL.g:1577:1: rule__Channel__Group__3__Impl : ( '{' ) ;
    public final void rule__Channel__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1581:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:1582:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:1582:1: ( '{' )
            // InternalMiniProject1DSL.g:1583:2: '{'
            {
             before(grammarAccess.getChannelAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getChannelAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__3__Impl"


    // $ANTLR start "rule__Channel__Group__4"
    // InternalMiniProject1DSL.g:1592:1: rule__Channel__Group__4 : rule__Channel__Group__4__Impl rule__Channel__Group__5 ;
    public final void rule__Channel__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1596:1: ( rule__Channel__Group__4__Impl rule__Channel__Group__5 )
            // InternalMiniProject1DSL.g:1597:2: rule__Channel__Group__4__Impl rule__Channel__Group__5
            {
            pushFollow(FOLLOW_15);
            rule__Channel__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__4"


    // $ANTLR start "rule__Channel__Group__4__Impl"
    // InternalMiniProject1DSL.g:1604:1: rule__Channel__Group__4__Impl : ( 'synchron' ) ;
    public final void rule__Channel__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1608:1: ( ( 'synchron' ) )
            // InternalMiniProject1DSL.g:1609:1: ( 'synchron' )
            {
            // InternalMiniProject1DSL.g:1609:1: ( 'synchron' )
            // InternalMiniProject1DSL.g:1610:2: 'synchron'
            {
             before(grammarAccess.getChannelAccess().getSynchronKeyword_4()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getChannelAccess().getSynchronKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__4__Impl"


    // $ANTLR start "rule__Channel__Group__5"
    // InternalMiniProject1DSL.g:1619:1: rule__Channel__Group__5 : rule__Channel__Group__5__Impl rule__Channel__Group__6 ;
    public final void rule__Channel__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1623:1: ( rule__Channel__Group__5__Impl rule__Channel__Group__6 )
            // InternalMiniProject1DSL.g:1624:2: rule__Channel__Group__5__Impl rule__Channel__Group__6
            {
            pushFollow(FOLLOW_16);
            rule__Channel__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Channel__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__5"


    // $ANTLR start "rule__Channel__Group__5__Impl"
    // InternalMiniProject1DSL.g:1631:1: rule__Channel__Group__5__Impl : ( ( rule__Channel__SynchronAssignment_5 ) ) ;
    public final void rule__Channel__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1635:1: ( ( ( rule__Channel__SynchronAssignment_5 ) ) )
            // InternalMiniProject1DSL.g:1636:1: ( ( rule__Channel__SynchronAssignment_5 ) )
            {
            // InternalMiniProject1DSL.g:1636:1: ( ( rule__Channel__SynchronAssignment_5 ) )
            // InternalMiniProject1DSL.g:1637:2: ( rule__Channel__SynchronAssignment_5 )
            {
             before(grammarAccess.getChannelAccess().getSynchronAssignment_5()); 
            // InternalMiniProject1DSL.g:1638:2: ( rule__Channel__SynchronAssignment_5 )
            // InternalMiniProject1DSL.g:1638:3: rule__Channel__SynchronAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Channel__SynchronAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getChannelAccess().getSynchronAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__5__Impl"


    // $ANTLR start "rule__Channel__Group__6"
    // InternalMiniProject1DSL.g:1646:1: rule__Channel__Group__6 : rule__Channel__Group__6__Impl ;
    public final void rule__Channel__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1650:1: ( rule__Channel__Group__6__Impl )
            // InternalMiniProject1DSL.g:1651:2: rule__Channel__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Channel__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__6"


    // $ANTLR start "rule__Channel__Group__6__Impl"
    // InternalMiniProject1DSL.g:1657:1: rule__Channel__Group__6__Impl : ( '}' ) ;
    public final void rule__Channel__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1661:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:1662:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:1662:1: ( '}' )
            // InternalMiniProject1DSL.g:1663:2: '}'
            {
             before(grammarAccess.getChannelAccess().getRightCurlyBracketKeyword_6()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getChannelAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__Group__6__Impl"


    // $ANTLR start "rule__State__Group__0"
    // InternalMiniProject1DSL.g:1673:1: rule__State__Group__0 : rule__State__Group__0__Impl rule__State__Group__1 ;
    public final void rule__State__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1677:1: ( rule__State__Group__0__Impl rule__State__Group__1 )
            // InternalMiniProject1DSL.g:1678:2: rule__State__Group__0__Impl rule__State__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__State__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0"


    // $ANTLR start "rule__State__Group__0__Impl"
    // InternalMiniProject1DSL.g:1685:1: rule__State__Group__0__Impl : ( () ) ;
    public final void rule__State__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1689:1: ( ( () ) )
            // InternalMiniProject1DSL.g:1690:1: ( () )
            {
            // InternalMiniProject1DSL.g:1690:1: ( () )
            // InternalMiniProject1DSL.g:1691:2: ()
            {
             before(grammarAccess.getStateAccess().getStateAction_0()); 
            // InternalMiniProject1DSL.g:1692:2: ()
            // InternalMiniProject1DSL.g:1692:3: 
            {
            }

             after(grammarAccess.getStateAccess().getStateAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0__Impl"


    // $ANTLR start "rule__State__Group__1"
    // InternalMiniProject1DSL.g:1700:1: rule__State__Group__1 : rule__State__Group__1__Impl rule__State__Group__2 ;
    public final void rule__State__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1704:1: ( rule__State__Group__1__Impl rule__State__Group__2 )
            // InternalMiniProject1DSL.g:1705:2: rule__State__Group__1__Impl rule__State__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__State__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1"


    // $ANTLR start "rule__State__Group__1__Impl"
    // InternalMiniProject1DSL.g:1712:1: rule__State__Group__1__Impl : ( 'State' ) ;
    public final void rule__State__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1716:1: ( ( 'State' ) )
            // InternalMiniProject1DSL.g:1717:1: ( 'State' )
            {
            // InternalMiniProject1DSL.g:1717:1: ( 'State' )
            // InternalMiniProject1DSL.g:1718:2: 'State'
            {
             before(grammarAccess.getStateAccess().getStateKeyword_1()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getStateKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1__Impl"


    // $ANTLR start "rule__State__Group__2"
    // InternalMiniProject1DSL.g:1727:1: rule__State__Group__2 : rule__State__Group__2__Impl ;
    public final void rule__State__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1731:1: ( rule__State__Group__2__Impl )
            // InternalMiniProject1DSL.g:1732:2: rule__State__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2"


    // $ANTLR start "rule__State__Group__2__Impl"
    // InternalMiniProject1DSL.g:1738:1: rule__State__Group__2__Impl : ( ( rule__State__NameAssignment_2 ) ) ;
    public final void rule__State__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1742:1: ( ( ( rule__State__NameAssignment_2 ) ) )
            // InternalMiniProject1DSL.g:1743:1: ( ( rule__State__NameAssignment_2 ) )
            {
            // InternalMiniProject1DSL.g:1743:1: ( ( rule__State__NameAssignment_2 ) )
            // InternalMiniProject1DSL.g:1744:2: ( rule__State__NameAssignment_2 )
            {
             before(grammarAccess.getStateAccess().getNameAssignment_2()); 
            // InternalMiniProject1DSL.g:1745:2: ( rule__State__NameAssignment_2 )
            // InternalMiniProject1DSL.g:1745:3: rule__State__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__State__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__0"
    // InternalMiniProject1DSL.g:1754:1: rule__Transition__Group__0 : rule__Transition__Group__0__Impl rule__Transition__Group__1 ;
    public final void rule__Transition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1758:1: ( rule__Transition__Group__0__Impl rule__Transition__Group__1 )
            // InternalMiniProject1DSL.g:1759:2: rule__Transition__Group__0__Impl rule__Transition__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Transition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0"


    // $ANTLR start "rule__Transition__Group__0__Impl"
    // InternalMiniProject1DSL.g:1766:1: rule__Transition__Group__0__Impl : ( 'Transition' ) ;
    public final void rule__Transition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1770:1: ( ( 'Transition' ) )
            // InternalMiniProject1DSL.g:1771:1: ( 'Transition' )
            {
            // InternalMiniProject1DSL.g:1771:1: ( 'Transition' )
            // InternalMiniProject1DSL.g:1772:2: 'Transition'
            {
             before(grammarAccess.getTransitionAccess().getTransitionKeyword_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTransitionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0__Impl"


    // $ANTLR start "rule__Transition__Group__1"
    // InternalMiniProject1DSL.g:1781:1: rule__Transition__Group__1 : rule__Transition__Group__1__Impl rule__Transition__Group__2 ;
    public final void rule__Transition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1785:1: ( rule__Transition__Group__1__Impl rule__Transition__Group__2 )
            // InternalMiniProject1DSL.g:1786:2: rule__Transition__Group__1__Impl rule__Transition__Group__2
            {
            pushFollow(FOLLOW_17);
            rule__Transition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1"


    // $ANTLR start "rule__Transition__Group__1__Impl"
    // InternalMiniProject1DSL.g:1793:1: rule__Transition__Group__1__Impl : ( '{' ) ;
    public final void rule__Transition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1797:1: ( ( '{' ) )
            // InternalMiniProject1DSL.g:1798:1: ( '{' )
            {
            // InternalMiniProject1DSL.g:1798:1: ( '{' )
            // InternalMiniProject1DSL.g:1799:2: '{'
            {
             before(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1__Impl"


    // $ANTLR start "rule__Transition__Group__2"
    // InternalMiniProject1DSL.g:1808:1: rule__Transition__Group__2 : rule__Transition__Group__2__Impl rule__Transition__Group__3 ;
    public final void rule__Transition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1812:1: ( rule__Transition__Group__2__Impl rule__Transition__Group__3 )
            // InternalMiniProject1DSL.g:1813:2: rule__Transition__Group__2__Impl rule__Transition__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2"


    // $ANTLR start "rule__Transition__Group__2__Impl"
    // InternalMiniProject1DSL.g:1820:1: rule__Transition__Group__2__Impl : ( 'source' ) ;
    public final void rule__Transition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1824:1: ( ( 'source' ) )
            // InternalMiniProject1DSL.g:1825:1: ( 'source' )
            {
            // InternalMiniProject1DSL.g:1825:1: ( 'source' )
            // InternalMiniProject1DSL.g:1826:2: 'source'
            {
             before(grammarAccess.getTransitionAccess().getSourceKeyword_2()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getSourceKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__3"
    // InternalMiniProject1DSL.g:1835:1: rule__Transition__Group__3 : rule__Transition__Group__3__Impl rule__Transition__Group__4 ;
    public final void rule__Transition__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1839:1: ( rule__Transition__Group__3__Impl rule__Transition__Group__4 )
            // InternalMiniProject1DSL.g:1840:2: rule__Transition__Group__3__Impl rule__Transition__Group__4
            {
            pushFollow(FOLLOW_18);
            rule__Transition__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3"


    // $ANTLR start "rule__Transition__Group__3__Impl"
    // InternalMiniProject1DSL.g:1847:1: rule__Transition__Group__3__Impl : ( ( rule__Transition__SourceAssignment_3 ) ) ;
    public final void rule__Transition__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1851:1: ( ( ( rule__Transition__SourceAssignment_3 ) ) )
            // InternalMiniProject1DSL.g:1852:1: ( ( rule__Transition__SourceAssignment_3 ) )
            {
            // InternalMiniProject1DSL.g:1852:1: ( ( rule__Transition__SourceAssignment_3 ) )
            // InternalMiniProject1DSL.g:1853:2: ( rule__Transition__SourceAssignment_3 )
            {
             before(grammarAccess.getTransitionAccess().getSourceAssignment_3()); 
            // InternalMiniProject1DSL.g:1854:2: ( rule__Transition__SourceAssignment_3 )
            // InternalMiniProject1DSL.g:1854:3: rule__Transition__SourceAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Transition__SourceAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getSourceAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3__Impl"


    // $ANTLR start "rule__Transition__Group__4"
    // InternalMiniProject1DSL.g:1862:1: rule__Transition__Group__4 : rule__Transition__Group__4__Impl rule__Transition__Group__5 ;
    public final void rule__Transition__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1866:1: ( rule__Transition__Group__4__Impl rule__Transition__Group__5 )
            // InternalMiniProject1DSL.g:1867:2: rule__Transition__Group__4__Impl rule__Transition__Group__5
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4"


    // $ANTLR start "rule__Transition__Group__4__Impl"
    // InternalMiniProject1DSL.g:1874:1: rule__Transition__Group__4__Impl : ( 'target' ) ;
    public final void rule__Transition__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1878:1: ( ( 'target' ) )
            // InternalMiniProject1DSL.g:1879:1: ( 'target' )
            {
            // InternalMiniProject1DSL.g:1879:1: ( 'target' )
            // InternalMiniProject1DSL.g:1880:2: 'target'
            {
             before(grammarAccess.getTransitionAccess().getTargetKeyword_4()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTargetKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4__Impl"


    // $ANTLR start "rule__Transition__Group__5"
    // InternalMiniProject1DSL.g:1889:1: rule__Transition__Group__5 : rule__Transition__Group__5__Impl rule__Transition__Group__6 ;
    public final void rule__Transition__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1893:1: ( rule__Transition__Group__5__Impl rule__Transition__Group__6 )
            // InternalMiniProject1DSL.g:1894:2: rule__Transition__Group__5__Impl rule__Transition__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__Transition__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5"


    // $ANTLR start "rule__Transition__Group__5__Impl"
    // InternalMiniProject1DSL.g:1901:1: rule__Transition__Group__5__Impl : ( ( rule__Transition__TargetAssignment_5 ) ) ;
    public final void rule__Transition__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1905:1: ( ( ( rule__Transition__TargetAssignment_5 ) ) )
            // InternalMiniProject1DSL.g:1906:1: ( ( rule__Transition__TargetAssignment_5 ) )
            {
            // InternalMiniProject1DSL.g:1906:1: ( ( rule__Transition__TargetAssignment_5 ) )
            // InternalMiniProject1DSL.g:1907:2: ( rule__Transition__TargetAssignment_5 )
            {
             before(grammarAccess.getTransitionAccess().getTargetAssignment_5()); 
            // InternalMiniProject1DSL.g:1908:2: ( rule__Transition__TargetAssignment_5 )
            // InternalMiniProject1DSL.g:1908:3: rule__Transition__TargetAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Transition__TargetAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getTargetAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5__Impl"


    // $ANTLR start "rule__Transition__Group__6"
    // InternalMiniProject1DSL.g:1916:1: rule__Transition__Group__6 : rule__Transition__Group__6__Impl rule__Transition__Group__7 ;
    public final void rule__Transition__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1920:1: ( rule__Transition__Group__6__Impl rule__Transition__Group__7 )
            // InternalMiniProject1DSL.g:1921:2: rule__Transition__Group__6__Impl rule__Transition__Group__7
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6"


    // $ANTLR start "rule__Transition__Group__6__Impl"
    // InternalMiniProject1DSL.g:1928:1: rule__Transition__Group__6__Impl : ( 'channel' ) ;
    public final void rule__Transition__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1932:1: ( ( 'channel' ) )
            // InternalMiniProject1DSL.g:1933:1: ( 'channel' )
            {
            // InternalMiniProject1DSL.g:1933:1: ( 'channel' )
            // InternalMiniProject1DSL.g:1934:2: 'channel'
            {
             before(grammarAccess.getTransitionAccess().getChannelKeyword_6()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getChannelKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6__Impl"


    // $ANTLR start "rule__Transition__Group__7"
    // InternalMiniProject1DSL.g:1943:1: rule__Transition__Group__7 : rule__Transition__Group__7__Impl rule__Transition__Group__8 ;
    public final void rule__Transition__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1947:1: ( rule__Transition__Group__7__Impl rule__Transition__Group__8 )
            // InternalMiniProject1DSL.g:1948:2: rule__Transition__Group__7__Impl rule__Transition__Group__8
            {
            pushFollow(FOLLOW_20);
            rule__Transition__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7"


    // $ANTLR start "rule__Transition__Group__7__Impl"
    // InternalMiniProject1DSL.g:1955:1: rule__Transition__Group__7__Impl : ( ( rule__Transition__ChannelAssignment_7 ) ) ;
    public final void rule__Transition__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1959:1: ( ( ( rule__Transition__ChannelAssignment_7 ) ) )
            // InternalMiniProject1DSL.g:1960:1: ( ( rule__Transition__ChannelAssignment_7 ) )
            {
            // InternalMiniProject1DSL.g:1960:1: ( ( rule__Transition__ChannelAssignment_7 ) )
            // InternalMiniProject1DSL.g:1961:2: ( rule__Transition__ChannelAssignment_7 )
            {
             before(grammarAccess.getTransitionAccess().getChannelAssignment_7()); 
            // InternalMiniProject1DSL.g:1962:2: ( rule__Transition__ChannelAssignment_7 )
            // InternalMiniProject1DSL.g:1962:3: rule__Transition__ChannelAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Transition__ChannelAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getChannelAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7__Impl"


    // $ANTLR start "rule__Transition__Group__8"
    // InternalMiniProject1DSL.g:1970:1: rule__Transition__Group__8 : rule__Transition__Group__8__Impl rule__Transition__Group__9 ;
    public final void rule__Transition__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1974:1: ( rule__Transition__Group__8__Impl rule__Transition__Group__9 )
            // InternalMiniProject1DSL.g:1975:2: rule__Transition__Group__8__Impl rule__Transition__Group__9
            {
            pushFollow(FOLLOW_15);
            rule__Transition__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__8"


    // $ANTLR start "rule__Transition__Group__8__Impl"
    // InternalMiniProject1DSL.g:1982:1: rule__Transition__Group__8__Impl : ( 'send' ) ;
    public final void rule__Transition__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:1986:1: ( ( 'send' ) )
            // InternalMiniProject1DSL.g:1987:1: ( 'send' )
            {
            // InternalMiniProject1DSL.g:1987:1: ( 'send' )
            // InternalMiniProject1DSL.g:1988:2: 'send'
            {
             before(grammarAccess.getTransitionAccess().getSendKeyword_8()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getSendKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__8__Impl"


    // $ANTLR start "rule__Transition__Group__9"
    // InternalMiniProject1DSL.g:1997:1: rule__Transition__Group__9 : rule__Transition__Group__9__Impl rule__Transition__Group__10 ;
    public final void rule__Transition__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2001:1: ( rule__Transition__Group__9__Impl rule__Transition__Group__10 )
            // InternalMiniProject1DSL.g:2002:2: rule__Transition__Group__9__Impl rule__Transition__Group__10
            {
            pushFollow(FOLLOW_16);
            rule__Transition__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__9"


    // $ANTLR start "rule__Transition__Group__9__Impl"
    // InternalMiniProject1DSL.g:2009:1: rule__Transition__Group__9__Impl : ( ( rule__Transition__SendAssignment_9 ) ) ;
    public final void rule__Transition__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2013:1: ( ( ( rule__Transition__SendAssignment_9 ) ) )
            // InternalMiniProject1DSL.g:2014:1: ( ( rule__Transition__SendAssignment_9 ) )
            {
            // InternalMiniProject1DSL.g:2014:1: ( ( rule__Transition__SendAssignment_9 ) )
            // InternalMiniProject1DSL.g:2015:2: ( rule__Transition__SendAssignment_9 )
            {
             before(grammarAccess.getTransitionAccess().getSendAssignment_9()); 
            // InternalMiniProject1DSL.g:2016:2: ( rule__Transition__SendAssignment_9 )
            // InternalMiniProject1DSL.g:2016:3: rule__Transition__SendAssignment_9
            {
            pushFollow(FOLLOW_2);
            rule__Transition__SendAssignment_9();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getSendAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__9__Impl"


    // $ANTLR start "rule__Transition__Group__10"
    // InternalMiniProject1DSL.g:2024:1: rule__Transition__Group__10 : rule__Transition__Group__10__Impl ;
    public final void rule__Transition__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2028:1: ( rule__Transition__Group__10__Impl )
            // InternalMiniProject1DSL.g:2029:2: rule__Transition__Group__10__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__10"


    // $ANTLR start "rule__Transition__Group__10__Impl"
    // InternalMiniProject1DSL.g:2035:1: rule__Transition__Group__10__Impl : ( '}' ) ;
    public final void rule__Transition__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2039:1: ( ( '}' ) )
            // InternalMiniProject1DSL.g:2040:1: ( '}' )
            {
            // InternalMiniProject1DSL.g:2040:1: ( '}' )
            // InternalMiniProject1DSL.g:2041:2: '}'
            {
             before(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_10()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__10__Impl"


    // $ANTLR start "rule__Network__NameAssignment_2"
    // InternalMiniProject1DSL.g:2051:1: rule__Network__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Network__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2055:1: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2056:2: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:2056:2: ( ruleEString )
            // InternalMiniProject1DSL.g:2057:3: ruleEString
            {
             before(grammarAccess.getNetworkAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__NameAssignment_2"


    // $ANTLR start "rule__Network__StatemachineAssignment_4_2"
    // InternalMiniProject1DSL.g:2066:1: rule__Network__StatemachineAssignment_4_2 : ( ruleStateMachine ) ;
    public final void rule__Network__StatemachineAssignment_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2070:1: ( ( ruleStateMachine ) )
            // InternalMiniProject1DSL.g:2071:2: ( ruleStateMachine )
            {
            // InternalMiniProject1DSL.g:2071:2: ( ruleStateMachine )
            // InternalMiniProject1DSL.g:2072:3: ruleStateMachine
            {
             before(grammarAccess.getNetworkAccess().getStatemachineStateMachineParserRuleCall_4_2_0()); 
            pushFollow(FOLLOW_2);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getStatemachineStateMachineParserRuleCall_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__StatemachineAssignment_4_2"


    // $ANTLR start "rule__Network__StatemachineAssignment_4_3_1"
    // InternalMiniProject1DSL.g:2081:1: rule__Network__StatemachineAssignment_4_3_1 : ( ruleStateMachine ) ;
    public final void rule__Network__StatemachineAssignment_4_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2085:1: ( ( ruleStateMachine ) )
            // InternalMiniProject1DSL.g:2086:2: ( ruleStateMachine )
            {
            // InternalMiniProject1DSL.g:2086:2: ( ruleStateMachine )
            // InternalMiniProject1DSL.g:2087:3: ruleStateMachine
            {
             before(grammarAccess.getNetworkAccess().getStatemachineStateMachineParserRuleCall_4_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleStateMachine();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getStatemachineStateMachineParserRuleCall_4_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__StatemachineAssignment_4_3_1"


    // $ANTLR start "rule__Network__ChannelAssignment_5_2"
    // InternalMiniProject1DSL.g:2096:1: rule__Network__ChannelAssignment_5_2 : ( ruleChannel ) ;
    public final void rule__Network__ChannelAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2100:1: ( ( ruleChannel ) )
            // InternalMiniProject1DSL.g:2101:2: ( ruleChannel )
            {
            // InternalMiniProject1DSL.g:2101:2: ( ruleChannel )
            // InternalMiniProject1DSL.g:2102:3: ruleChannel
            {
             before(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleChannel();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__ChannelAssignment_5_2"


    // $ANTLR start "rule__Network__ChannelAssignment_5_3_1"
    // InternalMiniProject1DSL.g:2111:1: rule__Network__ChannelAssignment_5_3_1 : ( ruleChannel ) ;
    public final void rule__Network__ChannelAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2115:1: ( ( ruleChannel ) )
            // InternalMiniProject1DSL.g:2116:2: ( ruleChannel )
            {
            // InternalMiniProject1DSL.g:2116:2: ( ruleChannel )
            // InternalMiniProject1DSL.g:2117:3: ruleChannel
            {
             before(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleChannel();

            state._fsp--;

             after(grammarAccess.getNetworkAccess().getChannelChannelParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Network__ChannelAssignment_5_3_1"


    // $ANTLR start "rule__StateMachine__NameAssignment_2"
    // InternalMiniProject1DSL.g:2126:1: rule__StateMachine__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__StateMachine__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2130:1: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2131:2: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:2131:2: ( ruleEString )
            // InternalMiniProject1DSL.g:2132:3: ruleEString
            {
             before(grammarAccess.getStateMachineAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__NameAssignment_2"


    // $ANTLR start "rule__StateMachine__InitialAssignment_4_1"
    // InternalMiniProject1DSL.g:2141:1: rule__StateMachine__InitialAssignment_4_1 : ( ( ruleEString ) ) ;
    public final void rule__StateMachine__InitialAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2145:1: ( ( ( ruleEString ) ) )
            // InternalMiniProject1DSL.g:2146:2: ( ( ruleEString ) )
            {
            // InternalMiniProject1DSL.g:2146:2: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2147:3: ( ruleEString )
            {
             before(grammarAccess.getStateMachineAccess().getInitialStateCrossReference_4_1_0()); 
            // InternalMiniProject1DSL.g:2148:3: ( ruleEString )
            // InternalMiniProject1DSL.g:2149:4: ruleEString
            {
             before(grammarAccess.getStateMachineAccess().getInitialStateEStringParserRuleCall_4_1_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getInitialStateEStringParserRuleCall_4_1_0_1()); 

            }

             after(grammarAccess.getStateMachineAccess().getInitialStateCrossReference_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__InitialAssignment_4_1"


    // $ANTLR start "rule__StateMachine__StateAssignment_5_2"
    // InternalMiniProject1DSL.g:2160:1: rule__StateMachine__StateAssignment_5_2 : ( ruleState ) ;
    public final void rule__StateMachine__StateAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2164:1: ( ( ruleState ) )
            // InternalMiniProject1DSL.g:2165:2: ( ruleState )
            {
            // InternalMiniProject1DSL.g:2165:2: ( ruleState )
            // InternalMiniProject1DSL.g:2166:3: ruleState
            {
             before(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__StateAssignment_5_2"


    // $ANTLR start "rule__StateMachine__StateAssignment_5_3_1"
    // InternalMiniProject1DSL.g:2175:1: rule__StateMachine__StateAssignment_5_3_1 : ( ruleState ) ;
    public final void rule__StateMachine__StateAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2179:1: ( ( ruleState ) )
            // InternalMiniProject1DSL.g:2180:2: ( ruleState )
            {
            // InternalMiniProject1DSL.g:2180:2: ( ruleState )
            // InternalMiniProject1DSL.g:2181:3: ruleState
            {
             before(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleState();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getStateStateParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__StateAssignment_5_3_1"


    // $ANTLR start "rule__StateMachine__TransitionAssignment_6_2"
    // InternalMiniProject1DSL.g:2190:1: rule__StateMachine__TransitionAssignment_6_2 : ( ruleTransition ) ;
    public final void rule__StateMachine__TransitionAssignment_6_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2194:1: ( ( ruleTransition ) )
            // InternalMiniProject1DSL.g:2195:2: ( ruleTransition )
            {
            // InternalMiniProject1DSL.g:2195:2: ( ruleTransition )
            // InternalMiniProject1DSL.g:2196:3: ruleTransition
            {
             before(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_2_0()); 
            pushFollow(FOLLOW_2);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__TransitionAssignment_6_2"


    // $ANTLR start "rule__StateMachine__TransitionAssignment_6_3_1"
    // InternalMiniProject1DSL.g:2205:1: rule__StateMachine__TransitionAssignment_6_3_1 : ( ruleTransition ) ;
    public final void rule__StateMachine__TransitionAssignment_6_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2209:1: ( ( ruleTransition ) )
            // InternalMiniProject1DSL.g:2210:2: ( ruleTransition )
            {
            // InternalMiniProject1DSL.g:2210:2: ( ruleTransition )
            // InternalMiniProject1DSL.g:2211:3: ruleTransition
            {
             before(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTransition();

            state._fsp--;

             after(grammarAccess.getStateMachineAccess().getTransitionTransitionParserRuleCall_6_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__StateMachine__TransitionAssignment_6_3_1"


    // $ANTLR start "rule__Channel__NameAssignment_2"
    // InternalMiniProject1DSL.g:2220:1: rule__Channel__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Channel__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2224:1: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2225:2: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:2225:2: ( ruleEString )
            // InternalMiniProject1DSL.g:2226:3: ruleEString
            {
             before(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getChannelAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__NameAssignment_2"


    // $ANTLR start "rule__Channel__SynchronAssignment_5"
    // InternalMiniProject1DSL.g:2235:1: rule__Channel__SynchronAssignment_5 : ( ruleEBoolean ) ;
    public final void rule__Channel__SynchronAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2239:1: ( ( ruleEBoolean ) )
            // InternalMiniProject1DSL.g:2240:2: ( ruleEBoolean )
            {
            // InternalMiniProject1DSL.g:2240:2: ( ruleEBoolean )
            // InternalMiniProject1DSL.g:2241:3: ruleEBoolean
            {
             before(grammarAccess.getChannelAccess().getSynchronEBooleanParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getChannelAccess().getSynchronEBooleanParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Channel__SynchronAssignment_5"


    // $ANTLR start "rule__State__NameAssignment_2"
    // InternalMiniProject1DSL.g:2250:1: rule__State__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__State__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2254:1: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2255:2: ( ruleEString )
            {
            // InternalMiniProject1DSL.g:2255:2: ( ruleEString )
            // InternalMiniProject1DSL.g:2256:3: ruleEString
            {
             before(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__NameAssignment_2"


    // $ANTLR start "rule__Transition__SourceAssignment_3"
    // InternalMiniProject1DSL.g:2265:1: rule__Transition__SourceAssignment_3 : ( ( ruleEString ) ) ;
    public final void rule__Transition__SourceAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2269:1: ( ( ( ruleEString ) ) )
            // InternalMiniProject1DSL.g:2270:2: ( ( ruleEString ) )
            {
            // InternalMiniProject1DSL.g:2270:2: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2271:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getSourceStateCrossReference_3_0()); 
            // InternalMiniProject1DSL.g:2272:3: ( ruleEString )
            // InternalMiniProject1DSL.g:2273:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getSourceStateEStringParserRuleCall_3_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getSourceStateEStringParserRuleCall_3_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getSourceStateCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__SourceAssignment_3"


    // $ANTLR start "rule__Transition__TargetAssignment_5"
    // InternalMiniProject1DSL.g:2284:1: rule__Transition__TargetAssignment_5 : ( ( ruleEString ) ) ;
    public final void rule__Transition__TargetAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2288:1: ( ( ( ruleEString ) ) )
            // InternalMiniProject1DSL.g:2289:2: ( ( ruleEString ) )
            {
            // InternalMiniProject1DSL.g:2289:2: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2290:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getTargetStateCrossReference_5_0()); 
            // InternalMiniProject1DSL.g:2291:3: ( ruleEString )
            // InternalMiniProject1DSL.g:2292:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getTargetStateEStringParserRuleCall_5_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getTargetStateEStringParserRuleCall_5_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getTargetStateCrossReference_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__TargetAssignment_5"


    // $ANTLR start "rule__Transition__ChannelAssignment_7"
    // InternalMiniProject1DSL.g:2303:1: rule__Transition__ChannelAssignment_7 : ( ( ruleEString ) ) ;
    public final void rule__Transition__ChannelAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2307:1: ( ( ( ruleEString ) ) )
            // InternalMiniProject1DSL.g:2308:2: ( ( ruleEString ) )
            {
            // InternalMiniProject1DSL.g:2308:2: ( ( ruleEString ) )
            // InternalMiniProject1DSL.g:2309:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getChannelChannelCrossReference_7_0()); 
            // InternalMiniProject1DSL.g:2310:3: ( ruleEString )
            // InternalMiniProject1DSL.g:2311:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getChannelChannelEStringParserRuleCall_7_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getChannelChannelEStringParserRuleCall_7_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getChannelChannelCrossReference_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__ChannelAssignment_7"


    // $ANTLR start "rule__Transition__SendAssignment_9"
    // InternalMiniProject1DSL.g:2322:1: rule__Transition__SendAssignment_9 : ( ruleEBoolean ) ;
    public final void rule__Transition__SendAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMiniProject1DSL.g:2326:1: ( ( ruleEBoolean ) )
            // InternalMiniProject1DSL.g:2327:2: ( ruleEBoolean )
            {
            // InternalMiniProject1DSL.g:2327:2: ( ruleEBoolean )
            // InternalMiniProject1DSL.g:2328:3: ruleEBoolean
            {
             before(grammarAccess.getTransitionAccess().getSendEBooleanParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getSendEBooleanParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__SendAssignment_9"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000058000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000028000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000708000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000040000000L});

}