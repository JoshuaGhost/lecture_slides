/**
 */
package smn.impl;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import smn.Channel;
import smn.Network;
import smn.SmnPackage;
import smn.StateMachine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Network</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smn.impl.NetworkImpl#getStateMachine <em>State Machine</em>}</li>
 *   <li>{@link smn.impl.NetworkImpl#getChannel <em>Channel</em>}</li>
 * </ul>
 *
 * @generated
 */
public class NetworkImpl extends NamedElementImpl implements Network {
	/**
	 * The cached value of the '{@link #getStateMachine() <em>State Machine</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStateMachine()
	 * @generated
	 * @ordered
	 */
	protected EList<StateMachine> stateMachine;

	/**
	 * The cached value of the '{@link #getChannel() <em>Channel</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChannel()
	 * @generated
	 * @ordered
	 */
	protected EList<Channel> channel;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmnPackage.Literals.NETWORK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StateMachine> getStateMachine() {
		if (stateMachine == null) {
			stateMachine = new EObjectResolvingEList<StateMachine>(StateMachine.class, this, SmnPackage.NETWORK__STATE_MACHINE);
		}
		return stateMachine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Channel> getChannel() {
		if (channel == null) {
			channel = new EObjectResolvingEList<Channel>(Channel.class, this, SmnPackage.NETWORK__CHANNEL);
		}
		return channel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmnPackage.NETWORK__STATE_MACHINE:
				return getStateMachine();
			case SmnPackage.NETWORK__CHANNEL:
				return getChannel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmnPackage.NETWORK__STATE_MACHINE:
				getStateMachine().clear();
				getStateMachine().addAll((Collection<? extends StateMachine>)newValue);
				return;
			case SmnPackage.NETWORK__CHANNEL:
				getChannel().clear();
				getChannel().addAll((Collection<? extends Channel>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmnPackage.NETWORK__STATE_MACHINE:
				getStateMachine().clear();
				return;
			case SmnPackage.NETWORK__CHANNEL:
				getChannel().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmnPackage.NETWORK__STATE_MACHINE:
				return stateMachine != null && !stateMachine.isEmpty();
			case SmnPackage.NETWORK__CHANNEL:
				return channel != null && !channel.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //NetworkImpl
